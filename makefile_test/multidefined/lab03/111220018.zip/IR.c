#include "IR.h"
int curLabel = 0;
int curVar = 0;
struct InterCode* IC_head;
FILE* fout;

struct InterCode* newIC(int kind)
{
	struct InterCode* n = malloc(sizeof(struct InterCode));
	n->kind = kind;
	n->prev = n->next = NULL;
	return n;
}


struct Operand* newOp(int kind)
{
	struct Operand* o = malloc(sizeof(struct Operand));
	o->kind = kind;
	return o;
}


struct Operand* newAddrOp(int vno)
{
	struct Operand* o = newOp(2);
	o->vno=vno;
	return o;
}


struct Operand* newIntOp(int value)
{
	struct Operand* o = newOp(1);
	o->value = value;
	return o;
}


struct Operand* newVarOp(int vno)
{
	struct Operand* o = newOp(0);
	o->vno=vno;
	return o;
}


struct Operand* newStructOp(int vno)
{
	struct Operand* o = newOp(3);
	o->vno=vno;
	return o;
}

struct Operand* newFuncOp(char* name)
{
	struct Operand* o = newOp(4);
	o->name=name;
	return o;
}

struct Operand* newTempOp()
{
	struct Operand* o = newOp(0);
	o->vno=curVar++;
	return o;
}
int new_label()
{
	return curLabel++;
}


struct InterCode* newLabelIC(int label)
{
	struct InterCode* n = newIC(0);
	n->label = label;
	return n;
}


struct InterCode* newFunIC(char* fname)
{
	struct InterCode* n = newIC(17);
	struct Operand *op=newFuncOp(fname);
	n->op=op;
	return n;
}


struct InterCode* newAssignIC(struct Operand *op1, 
							struct Operand *op2)
{
	struct InterCode* n = newIC(1);
	n->assign.left = op1;
	n->assign.right = op2;
	return n;
}


struct InterCode* newAddIC(struct Operand *result, 
		struct Operand *op1, struct Operand *op2)
{
	struct InterCode* n = newIC(2);
	n->binop.result = result;
	n->binop.op1 = op1;
	n->binop.op2 = op2;
	return n;
}
		

struct InterCode* newSubIC(struct Operand *result, 
		struct Operand *op1, struct Operand *op2)
{
	struct InterCode* n = newIC(3);
	n->binop.result = result;
	n->binop.op1 = op1;
	n->binop.op2 = op2;
	return n;
}
		

struct InterCode* newMulIC(struct Operand *result, 
		struct Operand *op1, struct Operand *op2)
{
	struct InterCode* n = newIC(4);
	n->binop.result = result;
	n->binop.op1 = op1;
	n->binop.op2 = op2;
	return n;
}
		

struct InterCode* newDivIC(struct Operand *result, 
		struct Operand *op1, struct Operand *op2)
{
	struct InterCode* n = newIC(5);
	n->binop.result = result;
	n->binop.op1 = op1;
	n->binop.op2 = op2;
	return n;
}

struct InterCode* newRstarIC(struct Operand *op1, 
							struct Operand *op2)
{
	struct InterCode* n = newIC(6);
	n->assign.left = op1;
	n->assign.right = op2;
	return n;
}

struct InterCode* newLstarIC(struct Operand *op1, 
							struct Operand *op2)
{
	struct InterCode* n = newIC(7);
	n->assign.left = op1;
	n->assign.right = op2;
	return n;
}

struct InterCode* newGotoIC(struct InterCode *label)
{
	struct InterCode* n = newIC(8);
	n->go.label = label;
	return n;
}


struct InterCode* newIfgotoIC(struct Operand *x, 
		struct Operand *y, int relop, struct InterCode *label)
{
	struct InterCode* n = newIC(9);
	n->ifgo.x = x;
	n->ifgo.y = y;
	n->ifgo.relop = relop;
	n->ifgo.label = label;
	return n;
}


struct InterCode* newReturnIC(struct Operand *x)
{
	struct InterCode* n = newIC(10);
	n->op = x;
	return n;
}


struct InterCode* newDecIC(struct Operand *x, int width)
{
	struct InterCode* n = newIC(11);
	n->dec.x = x;
	n->dec.width = width;
	return n;
}


struct InterCode* newArgIC(struct Operand *x)
{
	struct InterCode* n = newIC(12);
	n->op = x;
	return n;
}


struct InterCode* newCallIC(struct Operand *x, char* name)
{
	struct InterCode* n = newIC(13);
	n->call.x = x;
	n->call.name = name;
	return n;
}


struct InterCode* newParaIC(struct Operand *v)
{
	struct InterCode* n = newIC(14);
	n->op = v;
	return n;
}


struct InterCode* newReadIC(struct Operand *x)
{
	struct InterCode* n = newIC(15);
	n->op = x;
	return n;
}


struct InterCode* newWriteIC(struct Operand *x)
{
	struct InterCode* n = newIC(16);
	n->op = x;
	return n;
}

struct InterCode* newAddrIC(struct Operand *op1, 
							struct Operand *op2)
{
	struct InterCode* n = newIC(18);
	n->assign.left = op1;
	n->assign.right = op2;
	return n;
}


struct InterCode* IC_tail(struct InterCode* a)
{
	while(a->next)
		a=a->next;
	return a;
}

void IC_insert(struct InterCode* cur)
{
	if(cur==NULL)
		return;
	if(IC_head==NULL)
	{
		IC_head=cur;
	}
	else
	{
		struct InterCode* tail=IC_tail(IC_head);
		tail->next=cur;
		cur->prev=tail;
	}
}

struct InterCode* IC_connect(struct InterCode* A,struct InterCode* B)
{
	if(A==NULL)
		return B;
	if(B==NULL)
		return A;
	struct InterCode* tail=IC_tail(A);
	tail->next=B;
	B->prev=tail;
	return A;
}

void print_operand(struct Operand* x)
{
	if (x->kind == 2)
		fprintf(fout, "v%d",x->vno);
	else if (x->kind == 3)
		fprintf(fout, "v%d",x->vno);
	else if (x->kind == 1)
		fprintf(fout, "#%d",x->value);
	else if (x->kind == 0)
		fprintf(fout, "v%d",x->vno);
	else if (x->kind == 4)
		fprintf(fout, "%s",x->name);
}

void print_relop(int r)
{
	if (r == 0)
		fprintf(fout, " >= ");
	else if (r == 1)
		fprintf(fout, " > ");
	else if (r == 2)
		fprintf(fout, " <= ");
	else if (r == 3)
		fprintf(fout, " < ");
	else if (r == 4)
		fprintf(fout, " != ");
	else if (r == 5)
		fprintf(fout, " == ");
}

/* display the code! */
void ICprint()
{
	struct InterCode *p = IC_head;
	while (p)
	{
		switch (p->kind)
		{
			case 1:
				print_operand(p->assign.left);
				fprintf(fout," := ");
				print_operand(p->assign.right);
				break;
			case 0:
				fprintf(fout, "LABEL label%d :",p->label);
				break;
			case 2:
				print_operand(p->binop.result);
				fprintf(fout," := ");
				print_operand(p->binop.op1);
				fprintf(fout, " + ");
				print_operand(p->binop.op2);
				break;
			case 3:
				print_operand(p->binop.result);
				fprintf(fout," := ");
				print_operand(p->binop.op1);
				fprintf(fout, " - ");
				print_operand(p->binop.op2);
				break;
			case 4:
				print_operand(p->binop.result);
				fprintf(fout," := ");
				print_operand(p->binop.op1);
				fprintf(fout, " * ");
				print_operand(p->binop.op2);
				break;
			case 5:
				print_operand(p->binop.result);
				fprintf(fout," := ");
				print_operand(p->binop.op1);
				fprintf(fout, " / ");
				print_operand(p->binop.op2);
				break;
			case 6: 
				print_operand(p->assign.left);
				fprintf(fout," := *");
				print_operand(p->assign.right);
				break;
			case 7:
				fprintf(fout,"*");
				print_operand(p->assign.left);
				fprintf(fout," := ");
				print_operand(p->assign.right);
				break;
			case 8:
				fprintf(fout, "GOTO label%d",p->go.label->label); 
				break;
			case 9:
				fprintf(fout, "IF ");
				print_operand(p->ifgo.x);
				print_relop(p->ifgo.relop);
				print_operand(p->ifgo.y);
				fprintf(fout, " GOTO label%d",p->ifgo.label->label);
				break;
			case 10:
				fprintf(fout, "RETURN ");
				print_operand(p->op);
				break;
			case 11:
				fprintf(fout, "DEC ");
				print_operand(p->dec.x);
				fprintf(fout, " %d", p->dec.width);
				break;
			case 12:
				fprintf(fout, "ARG ");
				print_operand(p->op);
				break;
			case 13:
				print_operand(p->call.x);
				fprintf(fout, " := CALL %s", p->call.name);
				break;
			case 14:
				fprintf(fout, "PARAM ");
				print_operand(p->op);
				break;
			case 15:
				fprintf(fout, "READ ");
				print_operand(p->op);
				break;
			case 16:
				fprintf(fout, "WRITE ");
				print_operand(p->op);
				break;
			case 17:
				fprintf(fout, "FUNCTION %s :", p->op->name);
				break;
			case 18:
				print_operand(p->assign.left);
				fprintf(fout," := &");
				print_operand(p->assign.right);
				break;
		}
		fprintf(fout, "\n");
		p=p->next;
	}
}
int getFldSize(struct fld *a)
{
	if(a==NULL)
		return 0;
	return getFldSize(a->next)+getSize(a->type);
}

int getSize(struct typ_node* a)
{
	if(a==NULL)
		return 0;
	else if(a->kind==1||a->kind==2)
	{
		a->size=4;
		return a->size;
	}
	else if(a->kind==3)
	{
		a->size=(a->Array->size)*getSize(a->Array->type);
		return a->size;
	}
	else if(a->kind==4)
	{
		a->size=getFldSize(a->Field);
		return a->size;
	}
}


void IRstart(FILE* f)
{
	struct sym_node* aa=stack[0];
	while(aa)
	{
		getSize(aa->type);
		aa=aa->next;
	}
	IC_head = NULL;
	fout = f;
	IC_head=translate_ExtDefList(root->children[0]);
	ICprint();
}

struct InterCode* translate_Args(struct node* Args,struct Operand** list,int *n)
{
	if(Args->cNum==1)
	{
		struct Operand *t1=newTempOp();
		struct InterCode *Code1=translate_Exp(Args->children[0],t1);
		if(t1->kind==2)
		{
			if(t1->type!=NULL&&t1->type->kind==1)
			{
			struct Operand *t9=newTempOp();
			struct InterCode *tp=newRstarIC(t9,t1);
			t1=t9;
			Code1=IC_connect(Code1,tp);
			}
		}
		int i;
		for(i=*n;i>0;i--)
			list[i]=list[i-1];
		list[0]=t1;
		(*n)=(*n)+1;
		return Code1;
	}
	else if(Args->cNum==3)
	{
		struct Operand *t1=newTempOp();
		struct InterCode *Code1=translate_Exp(Args->children[0],t1);
		if(t1->kind==2)
		{
			if(t1->type!=NULL&&t1->type->kind==1)
			{
			struct Operand *t9=newTempOp();
			struct InterCode *tp=newRstarIC(t9,t1);
			t1=t9;
			Code1=IC_connect(Code1,tp);
			}
		}
		int i;
		for(i=*n;i>0;i--)
			list[i]=list[i-1];
		list[0]=t1;
		(*n)=(*n)+1;
		struct InterCode *Code2=translate_Args(Args->children[2],list,n);
		struct InterCode *Code3=IC_connect(Code1,Code2);
		return Code3;
	}
	return NULL;
}

struct InterCode* translate_Exp(struct node *Exp,struct Operand *place)
{
	if(Exp->cNum==1&&!strcmp(Exp->children[0]->type_name,"INT"))
	{
		place->kind=1;
		place->value=Exp->children[0]->type_int;
		return NULL;
	}
	else if(Exp->cNum==1&&!strcmp(Exp->children[0]->type_name,"ID"))
	{
		struct Operand *var;
		struct sym_node *n=findSym(curStack,Exp->children[0]->type_cont,2);
		if(n==NULL)		
			printf("error!\n");
		if(n->type->kind==4)
		{
			var=newStructOp(n->vid);
			place->kind = 2;			
		}
		else
		{
			place->vno=n->vid;
			place->kind = 0;
			return NULL;			
		}
		struct InterCode *varCode=newAssignIC(place,var);
		return varCode;
	}
	else if(Exp->cNum==3&&!strcmp(Exp->children[1]->type_name,"ASSIGNOP"))
	{
		struct Operand* t0=newTempOp();
		struct Operand* t1=newTempOp();
		struct InterCode *Code0 = translate_Exp(Exp->children[0],t0);
		struct InterCode *Code1 = translate_Exp(Exp->children[2],t1);
		if(t1->kind==2)
		{
			struct Operand* t9=newTempOp();
			struct InterCode *tp=newRstarIC(t9,t1);
			t1=t9;
			Code1=IC_connect(Code1,tp);
		}
		struct InterCode *Code3;
		if(t0->kind==2)
			Code3=newLstarIC(t0,t1);
		else
			Code3 = newAssignIC(t0,t1);
		struct InterCode *Code4=NULL;
		if(place!=NULL)
		{
			if(t0->kind==2)
				Code4=newRstarIC(place,t0);
			else
				Code4 = newAssignIC(place,t0);
		}
		struct InterCode *Code2 = IC_connect(Code3,Code4);
		struct InterCode *ret = IC_connect(Code0,Code1);
		ret = IC_connect(ret,Code2);
		return ret;
	}
	else if(Exp->cNum==3&&((!strcmp(Exp->children[1]->type_name,"PLUS"))||(!strcmp(Exp->children[1]->type_name,"MINUS"))||(!strcmp(Exp->children[1]->type_name,"STAR"))||(!strcmp(Exp->children[1]->type_name,"DIV"))))
	{
		struct Operand* t1=newTempOp();
		struct Operand* t2=newTempOp();
		struct InterCode *Code1 = translate_Exp(Exp->children[0],t1);
		struct InterCode *Code2 = translate_Exp(Exp->children[2],t2);
		if(t1->kind==2)
		{
			struct Operand* t9=newTempOp();
			struct InterCode *tp=newRstarIC(t9,t1);
			t1=t9;
			Code2=IC_connect(Code2,tp);
		}
		if(t2->kind==2)
		{
			struct Operand* t9=newTempOp();
			struct InterCode *tp=newRstarIC(t9,t2);
			t2=t9;
			Code2=IC_connect(Code2,tp);
		}
		struct InterCode *Code3 = NULL;
		if(!strcmp(Exp->children[1]->type_name,"PLUS"))
			Code3 = newAddIC(place,t1,t2);
		else if(!strcmp(Exp->children[1]->type_name,"MINUS"))
			Code3=newSubIC(place,t1,t2);
		else if(!strcmp(Exp->children[1]->type_name,"STAR"))
			Code3=newMulIC(place,t1,t2);
		else if(!strcmp(Exp->children[1]->type_name,"DIV"))
			Code3=newDivIC(place,t1,t2);
		struct InterCode *Code4=IC_connect(Code1,Code2);
		struct InterCode *Code5=IC_connect(Code4,Code3);		
		return Code5;
	}
	else if(Exp->cNum==2&&!strcmp(Exp->children[0]->type_name,"MINUS"))
	{
		struct Operand* t1=newTempOp();
		struct InterCode *Code1 = translate_Exp(Exp->children[1], t1);
		if(t1->kind==2)
		{
			struct Operand* t9=newTempOp();
			struct InterCode *tp=newRstarIC(t9,t1);
			t1=t9;
			Code1=IC_connect(Code1,tp);
		}
		struct Operand* temp=newIntOp(0);
		struct InterCode *Code2 = newSubIC(place,temp,t1);
		if(place==NULL)
			Code2=NULL;
		struct InterCode *Code3= IC_connect(Code1,Code2);
		return Code3;
	}
	else if((Exp->cNum==2&&!strcmp(Exp->children[0]->type_name,"NOT"))||(Exp->cNum==3&&(!strcmp(Exp->children[1]->type_name,"RELOP")||!strcmp(Exp->children[1]->type_name,"AND")||!strcmp(Exp->children[1]->type_name,"OR"))))
	{
		if(place==NULL)
			place=newTempOp();
		int label1=new_label();
		int label2=new_label();
		struct Operand* temp0=newIntOp(0);
		struct Operand* temp1=newIntOp(1);
		struct InterCode *Code0=newAssignIC(place,temp0);
		struct InterCode *Code1=translate_Cond(Exp,label1,label2);
		struct InterCode *l1=newLabelIC(label1);
		struct InterCode *Code3=newAssignIC(place,temp1);
		struct InterCode *Code2=IC_connect(l1,Code3);
		struct InterCode *l2=newLabelIC(label2);
		struct InterCode *t1=IC_connect(Code0,Code1);
		struct InterCode *t2=IC_connect(t1,Code2);
		struct InterCode *t3=IC_connect(t2,l2);
		return t3;
	}
	else if(Exp->cNum==3&&!strcmp(Exp->children[0]->type_name,"ID")&&!strcmp(Exp->children[1]->type_name,"LP"))
	{
		if(place == NULL)
			place = newTempOp();
		struct sym_node *fun=findSym(curStack,Exp->children[0]->type_cont,2);
		if(fun==NULL)
			printf("error!\n");
		if(!strcmp(fun->name,"read"))
		{
			struct InterCode *Code1=newReadIC(place);
			return Code1;
		}
		else
		{
			struct InterCode *Code1=newCallIC(place,fun->name);
			return Code1;
		}
	}
	else if(Exp->cNum==4&&!strcmp(Exp->children[0]->type_name,"ID")&&!strcmp(Exp->children[2]->type_name,"Args"))
	{
		if(place == NULL)
			place=newTempOp();
		struct sym_node *fun=findSym(curStack,Exp->children[0]->type_cont,2);
		if(fun==NULL)
			printf("error!\n");
		struct Operand **argList=malloc(sizeof(struct Operand*)*20);
		int *n=malloc(sizeof(int));	
		*n=0;
		struct InterCode *Code1 = translate_Args(Exp->children[2],argList,n);
		if(!strcmp(fun->name,"write"))
		{
			struct InterCode *Code2 = newWriteIC(argList[0]);
			struct InterCode *ret = IC_connect(Code1,Code2);
			return ret;
		}
		else
		{
			int i;
			struct InterCode *Code2=NULL;
			for(i=0;i<*n;i++)
			{
				struct InterCode *t = newArgIC(argList[i]);
				Code2=IC_connect(Code2,t);
			}
			struct InterCode* Code3=newCallIC(place,fun->name);
			struct InterCode* Code4=IC_connect(Code1,Code2);
			struct InterCode* Code5=IC_connect(Code4,Code3);
			return Code5;
		}
	}
	else if(Exp->cNum==3&&!strcmp(Exp->children[0]->type_name,"LP")&&!strcmp(Exp->children[1]->type_name,"Exp"))
	{
		return translate_Exp(Exp->children[1], place);
	}
	else if(Exp->cNum==3&&!strcmp(Exp->children[1]->type_name,"DOT"))
	{
		place->kind = 2;
		struct InterCode* Code1=translate_Array(Exp,place);
		return Code1;
	}
	else if(Exp->cNum==4&&!strcmp(Exp->children[1]->type_name,"LB"))
	{
		place->kind = 2;
		struct InterCode* Code1=translate_Array(Exp,place);
		return Code1;
	}
	return NULL;
}
struct InterCode* translate_Array(struct node *Exp,struct Operand* place)
{
	struct InterCode* Code1=NULL;
	if(Exp->cNum==1&&!strcmp(Exp->children[0]->type_name,"ID"))
	{
		if(place==NULL)
			return NULL;
		struct Operand *var;
		struct sym_node *n=findSym(curStack,Exp->children[0]->type_cont,2);
		if(n->optype==0)
			var=newVarOp(n->vid);
		else if(n->optype==2)
			var=newAddrOp(n->vid);
		else if(n->optype==3)
			var=newStructOp(n->vid);
		var->type=n->type;
		place->type=var->type;
		if(n->optype==3)
			Code1=newAddrIC(place,var);
		else
			Code1=newAssignIC(place,var);
		return Code1;
	}
	else if(Exp->cNum==4&&!strcmp(Exp->children[1]->type_name,"LB"))
	{
		Code1=translate_Array(Exp->children[0],place);
		struct Operand *t1=newTempOp();
		struct InterCode* Code2=translate_Exp(Exp->children[2],t1);
		Code1=IC_connect(Code1,Code2);
		if(place==NULL)
			return Code1;
		if(t1->kind==2)
		{
			struct Operand *t2=newTempOp();
			Code2=newRstarIC(t2,t1);
			t1=t2;
			Code1=IC_connect(Code1,Code2);
		}
		else if(t1->kind==0)
		{
			struct Operand *t2=newTempOp();
			Code2=newAssignIC(t2,t1);
			t1=t2;
			Code1=IC_connect(Code1,Code2);
		}
		if(t1->kind==1)
			t1->value=(t1->value)*(place->type->Array->type->size);
		else
		{
			struct Operand *t2=newIntOp(place->type->Array->type->size);
			Code2=newMulIC(t1,t1,t2);
			Code1=IC_connect(Code1,Code2);
		}
		place->type=place->type->Array->type;
		Code2=newAddIC(place,t1,place);
		Code1=IC_connect(Code1,Code2);
		return Code1;
	}
	else
	{
		Code1=translate_Array(Exp->children[0],place);
		if(place==NULL)
			return Code1;
		struct Operand *t=newIntOp(0);
		struct fld* ff=place->type->Field;
		while(strcmp(ff->name,Exp->children[2]->type_cont))
		{
			t->value+=ff->type->size;
			ff=ff->next;
		}
		struct InterCode* Code2=newAddIC(place,place,t);
		Code1=IC_connect(Code1,Code2);
		return Code1;
	}
}

struct InterCode* translate_Stmt(struct node *Stmt)
{
	if(Stmt->cNum==2&&!strcmp(Stmt->children[0]->type_name,"Exp"))
	{
		return translate_Exp(Stmt->children[0],NULL);
	}
	else if(Stmt->cNum==1&&!strcmp(Stmt->children[0]->type_name,"CompSt"))
	{
		return translate_CompSt(Stmt->children[0]);
	}
	else if(Stmt->cNum==3&&!strcmp(Stmt->children[0]->type_name,"RETURN"))
	{
		struct Operand *t1=newTempOp();
		struct InterCode *Code1 = translate_Exp(Stmt->children[1],t1);
		struct InterCode *Code2 = newReturnIC(t1);
		return IC_connect(Code1,Code2);
	}
	else if(Stmt->cNum==5&&!strcmp(Stmt->children[0]->type_name,"IF"))
	{
		int label1=new_label();
		int label2=new_label();
		struct InterCode *Code1 = translate_Cond(Stmt->children[2],label1,label2);
		struct InterCode *Code2 = translate_Stmt(Stmt->children[4]);
		struct InterCode *l1=newLabelIC(label1);
		struct InterCode *l2=newLabelIC(label2);
		return IC_connect(IC_connect(IC_connect(Code1,l1),Code2),l2);
	}
	else if(Stmt->cNum==7)
	{
		int label1=new_label();
		int label2=new_label();
		int label3=new_label();
		struct InterCode *Code1 = translate_Cond(Stmt->children[2],label1,label2);
		struct InterCode *Code2 = translate_Stmt(Stmt->children[4]);
		struct InterCode *Code3 = translate_Stmt(Stmt->children[6]);
		struct InterCode *l1=newLabelIC(label1);
		struct InterCode *l2=newLabelIC(label2);
		struct InterCode *l3=newLabelIC(label3);
		struct InterCode *g3=newGotoIC(l3);
		struct InterCode *t=IC_connect(Code1,l1);
		t=IC_connect(t,Code2);
		t=IC_connect(t,g3);
		t=IC_connect(t,l2);
		t=IC_connect(t,Code3);
		t=IC_connect(t,l3);
		return t;
	}
	else if(Stmt->cNum==5&&!strcmp(Stmt->children[0]->type_name,"WHILE"))
	{
		int label1=new_label();
		int label2=new_label();
		int label3=new_label();
		struct InterCode *Code1 = translate_Cond(Stmt->children[2],label2,label3);
		struct InterCode *Code2 = translate_Stmt(Stmt->children[4]);
		struct InterCode *l1=newLabelIC(label1);
		struct InterCode *l2=newLabelIC(label2);
		struct InterCode *l3=newLabelIC(label3);
		struct InterCode *g1=newGotoIC(l1);
		struct InterCode *t=IC_connect(l1,Code1);
		t=IC_connect(t,l2);
		t=IC_connect(t,Code2);
		t=IC_connect(t,g1);
		t=IC_connect(t,l3);
		return t;
	}
	return NULL;
}


int get_relop(char* cont)
{
	if (!strcmp(cont,">="))
		return 0;
	else if (!strcmp(cont,">"))
		return 1;
	else if (!strcmp(cont,"<="))
		return 2;
	else if (!strcmp(cont,"<"))
		return 3;
	else if (!strcmp(cont,"!="))
		return 4;
	else if (!strcmp(cont,"=="))
		return 5;
}
struct InterCode* translate_Cond(struct node *Exp,int label_true,int label_false)
{
	if(Exp->cNum==3&&!strcmp(Exp->children[0]->type_name,"Exp")&&!strcmp(Exp->children[1]->type_name,"RELOP"))
	{
		struct Operand *t1=newTempOp();
		struct Operand *t2=newTempOp();
		struct InterCode *Code1 = translate_Exp(Exp->children[0],t1);
		struct InterCode *Code2 = translate_Exp(Exp->children[2],t2);
		if(t1->kind==2)
		{
			struct Operand* t9=newTempOp();
			struct InterCode *tp=newRstarIC(t9,t1);
			t1=t9;
			Code2=IC_connect(Code2,tp);
		}
		if(t2->kind==2)
		{
			struct Operand* t9=newTempOp();
			struct InterCode *tp=newRstarIC(t9,t2);
			t2=t9;
			Code2=IC_connect(Code2,tp);
		}
		struct InterCode *lt=newLabelIC(label_true);
		struct InterCode *lf=newLabelIC(label_false);
		struct InterCode *Code3 = newIfgotoIC(t1,t2,get_relop(Exp->children[1]->type_cont),lt);
		struct InterCode *Code4 = newGotoIC(lf);
		struct InterCode *t=IC_connect(Code1,Code2);
		t=IC_connect(t,Code3);
		t=IC_connect(t,Code4);
		return t;
	}
	else if(Exp->cNum==2&&!strcmp(Exp->children[0]->type_name,"NOT"))
	{
		return translate_Cond(Exp->children[1],label_false,label_true);
	}
	else if(Exp->cNum==3&&!strcmp(Exp->children[0]->type_name,"Exp")&&!strcmp(Exp->children[1]->type_name,"AND"))
	{
		int label1=new_label();
		struct InterCode *Code1 = translate_Cond(Exp->children[0],label1,label_false);
		struct InterCode *Code2 = translate_Cond(Exp->children[2],label_true,label_false);
		struct InterCode *l1 = newLabelIC(label1);
		struct InterCode *t=IC_connect(Code1,l1);
		t=IC_connect(t,Code2);
		return t;
	}
	else if(Exp->cNum==3&&!strcmp(Exp->children[0]->type_name,"Exp")&&!strcmp(Exp->children[1]->type_name,"OR"))
	{
		int label1=new_label();
		struct InterCode *Code1 = translate_Cond(Exp->children[0],label_true,label1);
		struct InterCode *Code2 = translate_Cond(Exp->children[2],label_true,label_false);
		struct InterCode *l1 = newLabelIC(label1);
		struct InterCode *t=IC_connect(Code1,l1);
		t=IC_connect(t,Code2);
		return t;
	}
	else
	{
		struct Operand *t1=newTempOp();
		struct InterCode *Code1 = translate_Exp(Exp,t1);
		if(t1->kind==2)
		{
			struct Operand* t9=newTempOp();
			struct InterCode *tp=newRstarIC(t9,t1);
			t1=t9;
			Code1=IC_connect(Code1,tp);
		}
		struct Operand *temp=newIntOp(0);
		struct InterCode *lt=newLabelIC(label_true);
		struct InterCode *lf=newLabelIC(label_false);
		struct InterCode *Code2 = newIfgotoIC(t1,temp,4,lt);
		struct InterCode *Code3 = newGotoIC(lf);
		struct InterCode *t = IC_connect(Code1,Code2);
		t=IC_connect(t,Code3);
		return t;
	}
	return NULL;
}

//NEW Code Down
struct InterCode* translate_ExtDefList(struct node* ExtDefList)
{
	if(ExtDefList->cNum==2)
	{
		struct InterCode *Code1 = translate_ExtDef(ExtDefList->children[0]);
		struct InterCode *Code2 = translate_ExtDefList(ExtDefList->children[1]);
		return IC_connect(Code1,Code2);
	}
	else
		return NULL;
}

struct InterCode* translate_ExtDef(struct node* ExtDef)
{
	struct InterCode *Code1 = translate_Specifier(ExtDef->children[0]);
	if(ExtDef->cNum==3&&!strcmp(ExtDef->children[1]->type_name,"FunDec"))
	{
		if(!strcmp(ExtDef->children[2]->type_name,"CompSt"))
		{
			struct InterCode *Code2 = translate_FunDec(ExtDef->children[1]);
			struct InterCode *Code3 = translate_CompSt(ExtDef->children[2]);
			Code1=IC_connect(Code1,Code2);
			Code1=IC_connect(Code1,Code3);
		}
		return Code1;
	}
	else
		return NULL;
}

struct InterCode* translate_FunDec(struct node* FunDec)
{
	struct InterCode *Code1 = newFunIC(FunDec->children[0]->type_cont);
	if(FunDec->cNum==4)
	{
		struct InterCode *Code2 = translate_VarList(FunDec->children[2]);
		Code1=IC_connect(Code1,Code2);
	}
	return Code1;
}

struct InterCode* translate_VarList(struct node* VarList)
{
	struct InterCode *Code1 = translate_ParamDec(VarList->children[0]);
	if(VarList->cNum==3)
	{
		struct InterCode *Code2 = translate_VarList(VarList->children[2]);
		Code1=IC_connect(Code1,Code2);
	}
	return Code1;
}

struct InterCode* translate_ParamDec(struct node* ParamDec)
{
	struct InterCode *Code1=translate_Specifier(ParamDec->children[0]);
	struct InterCode *Code2=translate_VarDec(ParamDec->children[1],1);
	Code1=IC_connect(Code1,Code2);
	return Code1;
}

struct InterCode* translate_StmtList(struct node* StmtList)
{
	if(StmtList->cNum==2)
	{
		struct InterCode *Code1=translate_Stmt(StmtList->children[0]);
		struct InterCode *Code2=translate_StmtList(StmtList->children[1]);
		Code1=IC_connect(Code1,Code2);
		return Code1;
	}
	else
		return NULL;
}

struct InterCode* translate_DecList(struct node* DecList)
{
	struct InterCode *Code1=translate_Dec(DecList->children[0]);
	if(DecList->cNum==3)
	{
		struct InterCode *Code2=translate_DecList(DecList->children[2]);
		Code1=IC_connect(Code1,Code2);
	}
	return Code1;
}

struct InterCode* translate_Dec(struct node* Dec)
{
	struct InterCode *Code1=translate_VarDec(Dec->children[0],0);
	if(Dec->cNum==3)
	{
		struct Operand *t1=newTempOp();
		struct InterCode *Code2=translate_Exp(Dec->children[2],t1);
		Code1=IC_connect(Code1,Code2);
		struct InterCode *Code3;
		struct sym_node *n=findSym(curStack,Dec->children[0]->children[0]->type_cont,2);
		if(n==NULL)
			printf("error!\n");
		struct Operand *var=newVarOp(n->vid);
		if(t1->kind == 2)
			Code3=newRstarIC(var,t1);
		else
			Code3=newAssignIC(var,t1);
		Code1=IC_connect(Code1,Code3);
	}
	return Code1;
}

struct InterCode* translate_Def(struct node* Def)
{
	if(Def==NULL)
		return NULL;
	struct InterCode *Code1=translate_Specifier(Def->children[0]);
	struct InterCode *Code2=translate_DecList(Def->children[1]);
	Code1=IC_connect(Code1,Code2);
	return Code1;
}

struct InterCode* translate_DefList(struct node* DefList)
{
	if(DefList->cNum==0)
		return NULL;
	struct InterCode *Code1=translate_Def(DefList->children[0]);
	struct InterCode *Code2=translate_DefList(DefList->children[1]);
	Code1=IC_connect(Code1,Code2);
	return Code1;
}

struct InterCode* translate_CompSt(struct node* CompSt)
{
	struct InterCode *Code1=translate_DefList(CompSt->children[1]);
	struct InterCode *Code2=translate_StmtList(CompSt->children[2]);
	Code1=IC_connect(Code1,Code2);
	return Code1;
}

struct InterCode* translate_Specifier(struct node* Specifier)
{
	if(!strcmp(Specifier->children[0]->type_name,"StructSpecifier"))
		return translate_StructSpecifier(Specifier->children[0]);
	else
		return NULL;
}

struct InterCode* translate_StructSpecifier(struct node* StructSpecifier)
{
	return NULL;
}

struct InterCode* translate_VarDec(struct node* VarDec,int isParam)
{
	if (VarDec->cNum == 1 && !strcmp(VarDec->children[0]->type_name, "ID"))
	{

		if (VarDec->inStructDef||VarDec->children[0]->inStructDef)
            		return NULL;
		struct InterCode *Code1;
		//printf("%s\n",VarDec->children[0]->type_cont);
		struct sym_node *id=findSym(curStack,VarDec->children[0]->type_cont,2);
		if (isParam)
		{
			struct Operand *var;
			if(id->type->kind==1)
			{
				id->optype=0;
				var=newVarOp(id->vid);
			}
			else
			{
				id->optype=2;
				var=newAddrOp(id->vid);
			}
			Code1=newParaIC(var);
		}
		else
		{
			if (id->type->kind == 1)
			{
				id->optype=0;
				Code1=NULL;
			}			
			else
			{
				id->optype=3;
				struct Operand *var=newStructOp(id->vid);
				Code1=newDecIC(var,id->type->size);
			}
		}
		return Code1;
    }
    else 
	{
        return translate_VarDec(VarDec->children[0],isParam);
    }
}
