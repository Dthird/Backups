#include <stdio.h>
#include "syntax.tab.c"
#include "semantic.c"
#include "IR.c"
extern struct node* root;
int main(int argc,char** argv)
{
	if(argc <= 1)
		return 1;
	FILE* f = fopen(argv[1],"r");
	if(!f)
	{
		perror(argv[1]);
		return 1;
	}
	yyrestart(f);
	yyparse();
	spaceNum=0;
	if(wrong)
		return 1;
	else
	{
		semantic_parse(root);
		FILE* out=fopen(argv[2],"w");
		IRstart(out);
	}
	return 0;
}
