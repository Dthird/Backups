#ifndef _IR_H_
#define _IR_H_
#include <stdlib.h>
#include <stdio.h>
#include "tree.h"
#include "symbol_table.h"
extern int curLabel;
extern int curVar;
struct Operand
{
	int kind;
	union
	{
		char *name;
		int value;
		int vno;
	};
	struct typ_node* type;
};

struct InterCode
{
	int kind;
	union {
		struct { struct Operand *left, *right; } assign;
		struct { struct Operand *result, *op1, *op2; } binop;
		int label;
		struct { struct InterCode *label;} go;
		struct { 
			struct Operand *x, *y;
			int relop;
			struct InterCode *label;
		} ifgo;
		struct Operand* op;
		struct { struct Operand *x; int width; } dec;
		struct { struct Operand *x; char* name; } call;
	};
	struct InterCode *prev,*next;
};
extern struct InterCode* IC_head;
extern struct node* root;
struct InterCode* translate_Args(struct node* Args,struct Operand** list,int *n);
struct InterCode* translate_Exp(struct node *Exp,struct Operand *place);
struct InterCode* translate_Array(struct node *Exp,struct Operand* place);
struct InterCode* translate_Stmt(struct node *Stmt);
int get_relop(char* cont);
struct InterCode* translate_Cond(struct node *Exp,int label_true,int label_false);
struct InterCode* translate_ExtDefList(struct node* ExtDefList);
struct InterCode* translate_ExtDef(struct node* ExtDef);
struct InterCode* translate_FunDec(struct node* FunDec);
struct InterCode* translate_VarList(struct node* VarList);
struct InterCode* translate_ParamDec(struct node* ParamDec);
struct InterCode* translate_StmtList(struct node* StmtList);
struct InterCode* translate_DecList(struct node* DecList);
struct InterCode* translate_Dec(struct node* Dec);
struct InterCode* translate_Def(struct node* Def);
struct InterCode* translate_DefList(struct node* DefList);
struct InterCode* translate_CompSt(struct node* CompSt);
struct InterCode* translate_Specifier(struct node* Specifier);
struct InterCode* translate_StructSpecifier(struct node* StructSpecifier);
int getFldSize(struct fld *a);
int getSize(struct typ_node* a);
struct InterCode* translate_VarDec(struct node* VarDec,int isParam);


void IRstart(FILE* f);
#endif
