#ifndef _TREE_H_
#define _TREE_H_
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symbol_table.h"

struct node{
	int type_int;
	float type_float;
	int line;
	char type_name[20];
	char type_cont[50];
	int cNum;
	char* name;
	int hasLeftValue;
	int inStructDef;
	struct node* children[10];
	struct typ_node* varTyp;	/* syn: value type */
	struct fld* field;			/* syn: field-list type */ 
	struct typ_node* returnType;/* used for Fun->CompSt*/
};
void printTree(struct node* root);
void addNode(struct node* root,struct node* child);
struct node* createNode(int line,char* cont,char* name);
#endif
