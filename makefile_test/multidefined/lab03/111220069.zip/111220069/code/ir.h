#ifndef _IR_H_
#define _IR_H_

#include "syntax_analysis.h"

Operand new_temp();//new a temp
Operand new_label();//new a label
int ComputeSize(VarNode* ptr,int count);//compute var size
void create_operand(Operand op,int kind, int i, char* c);//create a operand
struct OperandNode* insert_op(Operand op, struct OperandNode* arg_list);//insert this operand
struct InterCodeNode* create_node(struct InterCode* code);//create node

/********************************** join several nodes into one ********************************************************/
struct InterCodeNode* join_node(struct InterCodeNode* node1, struct InterCodeNode* node2);//join 2 nodes to 1
struct InterCodeNode* join_node3(struct InterCodeNode* node1, struct InterCodeNode* node2, struct InterCodeNode* node3);//join 3 nodes to 1
struct InterCodeNode* join_node4(struct InterCodeNode* node1, struct InterCodeNode* node2, struct InterCodeNode* node3, struct InterCodeNode* node4);//join 4 nodes to 1
struct InterCodeNode* join_node5(struct InterCodeNode* node1, struct InterCodeNode* node2, struct InterCodeNode* node3, struct InterCodeNode* node4, struct InterCodeNode* node5);//join 5 nodes to 1
struct InterCodeNode* join_node6(struct InterCodeNode* node1, struct InterCodeNode* node2, struct InterCodeNode* node3, struct InterCodeNode* node4, struct InterCodeNode* node5, struct InterCodeNode* node6);//join 6 nodes to 1
struct InterCodeNode* join_node7(struct InterCodeNode* node1, struct InterCodeNode* node2, struct InterCodeNode* node3, struct InterCodeNode* node4, struct InterCodeNode* node5, struct InterCodeNode* node6, struct InterCodeNode* node7);//join 7 nodes to 1

/********************************** dealing with translate fun-->ir_code *************************************************/
struct InterCodeNode* generateIntercode(struct TreeNode *ptr);//main fun of this ir.c file
struct InterCodeNode* translate_ExtDefList(struct TreeNode* extdeflist);//translate ExtDefList node
struct InterCodeNode* translate_ExtDef(struct TreeNode* extdef);//translate ExtDef node
struct InterCodeNode* translate_VarDec(struct TreeNode* vardec,Operand place);//translate VarDec node
struct InterCodeNode* translate_FunDec(struct TreeNode* fundec);//translate FunDec node
struct InterCodeNode* translate_CompSt(struct TreeNode* compst, char* func_name);//translate CompSt node
struct InterCodeNode* translate_DefList(struct TreeNode* deflist, char* func_name);//translate DefList node
struct InterCodeNode* translate_Def(struct TreeNode* def, char* func_name);//translate Def node
struct InterCodeNode* translate_DecList(struct TreeNode* declist, char* func_name);//translate DecList node
struct InterCodeNode* translate_Dec(struct TreeNode* dec, char* func_name);//translate Dec node
struct InterCodeNode* translate_StmtList(struct TreeNode* stmtlist, char* func_name);//translate StmtList node
struct InterCodeNode* translate_Stmt(struct TreeNode* stmt, char* func_name);//translate Stmt node
struct InterCodeNode* translate_Exp(struct TreeNode* exp, Operand place, char* func_name);//translate Exp node
struct InterCodeNode* translate_Args(struct TreeNode* args, struct OperandNode** arg_list_addr, char* func_name);//translate Args node
struct InterCodeNode* translate_Cond(struct TreeNode* exp, Operand label_true, Operand label_false, char* func_name);//translate Cond node like NOT AND OR

/********************************** Output Function-->code.ir *************************************************************/
void fputsOperand(Operand ptr,FILE* stream);//put operand into code.ir
void fputsCode(struct InterCode* ptr,FILE* stream);//put one code into code.ir
void fputsNode(struct InterCodeNode* head,FILE* stream);//put ir nodes into file code.ir

#endif
