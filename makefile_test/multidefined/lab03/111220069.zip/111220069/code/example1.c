int main()
{
int n;
n = read();
if (n > 21) write(1);
else if (n < -21) write (-1);
else write(0);
return 0;
}

