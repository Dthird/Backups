#ifndef _HEAD_H
#define _HEAD_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NAME_SIZE 50
#define STACK_SIZE 20
#define TABLE_SIZE 100000//太小会出现段错误
#define INSTRUCT 1
#define NOTINSTRUCT 2//error type
#define MAX_CHILD_NUM 100
   
typedef struct TreeNode{
    char type[NAME_SIZE];    	//like "ExtDefList"
    char text[NAME_SIZE];    	//like number "12"
    int childnum;    		//child num
    int line;          		//lineno,-1 means terminal
    struct TreeNode *childlist[MAX_CHILD_NUM];
}TreeNode;

/****************************************** used in syntax analysis ****************************************************/
typedef struct Type_* Type;

typedef struct VarNode{
    char name[NAME_SIZE];
    Type type;
    int var_no;
    struct VarNode* next;
    struct VarNode* snext;
}VarNode;

struct Type_{
    enum {basic,array,structure} kind;  //数据类型
    union{
        int basic_info;   
        struct {Type elem;int size;} array;
        VarNode* structure;
    }type_info;
};

typedef struct FuncNode{
    char name[NAME_SIZE];
    Type returnType;
    VarNode* paralist;
    struct FuncNode* next;
}FuncNode;

typedef struct StructNode{
    char name[NAME_SIZE];
    Type type;
    struct StructNode* next;
}StructNode;

/****************************************** used in intermideate representation *********************************************/
typedef struct Operand_* Operand;
struct Operand_ {
    enum {VARIABLE,CONSTANT,ADDRESS,RELOP_OP,LABELOP,TEMP,FUNC,SIZE,REFERENCE,ARGOP} kind;
    union {
        int var_no;
        int value;
        char* relop;
        int label_no;
        int temp_no;
        int arg_no;
        char* func_name;
    }u;
};

struct OperandNode {
    Operand op;
    struct OperandNode* next;
};

struct InterCode {
    enum {ASSIGN, ADD, SUB, MUL, DIVISION, LABEL, REL, GOTO, READ, WRITE, CALL, FUNCTION, RETURN_CODE, ARG, PARAM, DEC} kind;
    union {
        struct {Operand left, right;}assign;
        struct {Operand result, op1, op2;}binop;
        struct {Operand labelop;}label;
        struct {Operand op1, relop, op2, labelop;}rel;
        struct {Operand labelop;}go;
        struct {Operand arg;}read;
        struct {Operand arg;}write;
        struct {Operand op1, op2;}call;
        struct {Operand func_name;}function;
        struct {Operand returnop;}ret;
        struct {Operand argop;}arg;
        struct {Operand var;}param;
        struct {Operand var, size;}dec;
    }u;
};

struct InterCodeNode {
    struct InterCode* code;
    struct InterCodeNode* prev, *next;
};

#endif
