int add(int temp[2])
{
return (temp[0] + temp[1]);
}
int main()
{
int op [2];
int r[1][2];
int i = 0, j = 0;
while (i<2)
{
while (j<2)
{
op[j] = i + j;
j = j + 1;
}
r[0][i] = add(op);
write(r[0][i]);
i = i + 1;
j = 0;
}
return 0;
}

