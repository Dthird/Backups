#ifndef _SYNTAX_ANALYSIS_H
#define _SYNTAX_ANALYSIS_H
#include"head.h"

struct VarNode* VarTable[TABLE_SIZE];
struct FuncNode* FuncTable[TABLE_SIZE];
struct StructNode* StructTable[TABLE_SIZE];
struct VarNode* stack[STACK_SIZE];
int top;

unsigned int hash_position(char* name);
int JudgeOperand(char* type);

void initial_all();

void CreateVarNode(VarNode* var,char *name,Type type);
void InsertVarNode(VarNode* var);
VarNode* SearchVar(char *name);

void InsertFuncNode(FuncNode* func,char* name,Type returnType,VarNode* paralist,struct TreeNode* fun_dec);
VarNode* InsertParaList(VarNode* paralist,VarNode* var,int* flag);
FuncNode* SearchFunc(char *name);
VarNode* SearchPar(char* name,char* func_name);

void CreateStructNode(StructNode* str,char *name,Type type);
int InsertStructNode(StructNode* str);
StructNode* SearchStruct(char *name);

int InsertStack(VarNode* var);
void Delete_Stack_VarTable();

int get_dimension(Type type);
int is_equal_type(Type type1, Type type2);

Type Specifier_analyse(struct TreeNode *specifier,char* func_name);
void ExtDecList_analyse(struct TreeNode *ext_dec_list,Type type,char* func_name);
void VarDec_analyse(VarNode* var,struct TreeNode *var_dec,Type type);
void FunDec_analyse(struct TreeNode *fun_dec,Type type,char* func_name);
VarNode* VarList_analyse(struct TreeNode *varlist,VarNode* paralist,char* func_name);
void ParamDec_analyse(VarNode* var,struct TreeNode *param_dec,char* func_name);
void CompSt_analyse(struct TreeNode *comp_st, char* func_name);
void DefList_analyse(struct TreeNode *def_list,char* func_namei,int error_type);
void StmtList_analyse(struct TreeNode *stmt_list, char* func_name);
void Stmt_analyse(struct TreeNode *stmt_list, char* func_name);
void DecList_analyse(struct TreeNode *dec_list,Type type,char* func_name,int error_type);
void Dec_analyse(struct TreeNode *dec,Type type,char* func_name,int error_type);
void ExtDef_analyse(struct TreeNode *ext_def);
void Def_analyse(struct TreeNode *def,char* func_name,int error_type);
Type Exp_analyse(struct TreeNode *exp,char* func_name);
int Args_analyse(struct TreeNode *args,VarNode* var,char* func_name);
#endif
