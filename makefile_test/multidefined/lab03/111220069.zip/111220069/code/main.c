#include "head.h"
#include "syntax_analysis.c"
#include "ir.c"

extern struct TreeNode* root;
extern struct InterCodeNode* head;
extern int yylineno;
extern int haveerror;
int main(int argc,char** argv){
    yylineno = 1;
    if(argc <= 1){
        printf("Usage:./parser file\n");
        return 0;
    }
    FILE* f = fopen(argv[1],"r");
    if(!f){
        printf("Can not open this file : %s\n",argv[1]);
        return 0;
    }
    
    initial_all();
    yyrestart(f);
    yyparse();
    //没有词法语法错误，进行语义分析
    if(haveerror == 0&&root != NULL&&root->childnum >0){
	//print(root);
	//printf("*************************\n");
	syntax_analysis_total(root->childlist[0]);
    }
    fclose(f);
    //没有语义错误，产生中间代码
    if(haveerror == 0){
        head = generateIntercode(root);
	FILE* ircode = fopen("code.ir","w");
	//printf("-------------------------\n");
        fputsNode(head,ircode);  
	fclose(ircode);
    }
    return 0;
}

