#include "tree.h"
#include "stdio.h"
#include "malloc.h"
#include "stdarg.h"
#include "stdlib.h"
#include "string.h"


/* definition of inter codes */
typedef struct Operand_* Operand;
struct Operand_ {
	enum { VARIABLE, ADDRESS, TEMP, CONSTANT, FLOAT, LABEL} kind;
	union {
		int var_no;
		int addr_no; // addr_no and var_no share the same number queue
		int temp_no;
		int value;	
		float value_float;
		int label;
	} u;
};
typedef struct Arglist_* Arglist;
struct Arglist_{
	Operand op;
	struct Arglist_* next;
};

typedef struct InterCode InterCode;
struct InterCode {
	enum { LAB, FUNC, ASSIGN, ADD, SUB, MUL, DIV, ADDR, MEMR, MEML, JUMP, RELOP, RETURN, DEC, ARG, CALL, PARAM, READ, WRITE } kind;
	union {
		Operand label; // LABEL
		char *func; // FUNC
		struct { Operand left, right; } assign; // ASSIGN
		struct { Operand result, op1, op2; } binop; // ADD, SUB, MUL, DIV
		struct { Operand left, right; } addr; // ADDR
		struct { Operand left, right; } mem; //MEMR, MEML
		Operand jump; // JUMP
		struct { Operand left, right, label; char *relop; } cond; //RELOP
		Operand returnval; // RETURN 
		struct { Operand x; int size; } dec; // DEC
		Operand arg; // ARG
		struct { Operand x; char *func; } call; // CALL
		Operand param; // PARAM
		Operand read; // READ
		Operand write; // WRITE
	} u;
};
typedef struct InterCodes_* InterCodes;
struct InterCodes_ { 
	InterCode code; 
	struct InterCodes_ *pre, *next; 
};

void fillOperand(Operand op, int kind, int value);
void fillInterCode(InterCodes Code, int kind, int num, ...);
void newLabel(Operand label);
void newVariable(char* id, int kind, Operand variable);

/* definition of translations */
InterCodes translate(TreeNode node);
InterCodes translate_ExtDef(TreeNode node);
InterCodes translate_CompSt(TreeNode node);
InterCodes translate_StmtList(TreeNode node);
InterCodes translate_Stmt(TreeNode node);
InterCodes translate_FunDec(TreeNode node);
InterCodes translate_Cond(TreeNode node, Operand label_true, Operand label_false);
InterCodes translate_Exp(TreeNode node, Operand place);

/* file out the inter codes */
void printOperand(FILE *ir, Operand op);
void printInterCode(FILE *ir, InterCode code);
void printInterCodes(InterCodes start);
void generateInterCodes(InterCodes start);

void simplify(InterCodes start);