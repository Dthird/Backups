#include "ir.h"
#include "semantic.h"

void fillOperand(Operand op, int kind, int value){
	op->kind = kind;
	switch(kind){
		case VARIABLE: { op->u.var_no = value; break;}
		case ADDRESS: { op->u.addr_no = value; break;}
		case TEMP: { op->u.temp_no = value; break;}
		case CONSTANT: { op->u.value = value; break;}
		case LABEL: { op->u.label = value; break;}
	}
}
void fillOperand_float(Operand op, float value){ // only used for the kind FLOAT
	op->kind = FLOAT;
	op->u.value_float = value;
}
void copyOperand(Operand op1, Operand op2){
	op1->kind = op2->kind;
	switch(op1->kind){
		case VARIABLE: { (op1->u).var_no = (op2->u).var_no; break;}
		case ADDRESS: { (op1->u).addr_no = (op2->u).addr_no; break;}
		case TEMP: { (op1->u).temp_no = (op2->u).temp_no; break;}
		case CONSTANT: { (op1->u).value = (op2->u).value; break;}
		case LABEL: { (op1->u).label = (op2->u).label; break;}
	}
}
void fillInterCode(InterCodes Code, int kind, int num, ...){ // used for fill an inter code
	/*	arugement list defined as follow
		LAB(1): Operand
		FUNC(1): char *
		ASSIGN(2): Operand, Operand
		ADD(3): Operand, Operand, Operand
		SUB(3): Operand, Operand, Operand
		MUL(3): Operand, Operand, Operand
		DIV(3): Operand, Operand, Operand
		ADDR(2): Operand, Operand
		MEMR(2): Operand, Operand
		MEML(2): Operand, Operand
		JUMP(1): Operand
		RELOP(4): Operand, Operand, Operand, char*
		RETURN(1): Operand
		DEC(2): Operand, int
		ARG(1): Operand
		CALL(2): Operand, char*
		PARAM(1): Operand
		READ(1): Operand
		WRITE(1): Operand
	*/
	va_list ap;
	Code->pre = NULL;
	Code->next = NULL;
	Code->code.kind = kind;
	switch (kind){
		case LAB: case JUMP: case RETURN: case ARG: case PARAM: case READ: case WRITE: { 
			Operand temp = malloc(sizeof(struct Operand_));
			va_start(ap, num);
			copyOperand(temp, va_arg(ap, Operand));
			switch(kind){
				case LAB: Code->code.u.label = temp; break;
				case JUMP: Code->code.u.jump = temp; break;
				case RETURN: Code->code.u.returnval = temp; break;
				case ARG: Code->code.u.arg = temp; break;
				case PARAM: Code->code.u.param = temp; break;
				case READ: Code->code.u.read = temp; break;
				case WRITE: Code->code.u.write = temp; break;
			}
			break; 
		}
		case FUNC: {
			va_start(ap, num);
			Code->code.u.func = malloc(IDLEN * sizeof(char));
			strcpy(Code->code.u.func, va_arg(ap, char *));
			break; 
		}
		case ASSIGN: case ADDR: case MEMR: case MEML: { 
			va_start(ap, num);
			Operand temp1 = malloc(sizeof(struct Operand_)),
					temp2 = malloc(sizeof(struct Operand_));
			copyOperand(temp1, va_arg(ap, Operand));
			copyOperand(temp2, va_arg(ap, Operand));
			switch(kind){
				case ASSIGN:{ Code->code.u.assign.left = temp1; Code->code.u.assign.right = temp2; break;} 
				case ADDR:{ Code->code.u.addr.left = temp1; Code->code.u.addr.right = temp2; break;} 
				case MEMR: case MEML: { Code->code.u.mem.left = temp1; Code->code.u.mem.right = temp2; break;} 
			}	
			break; 
		}
		case ADD: case SUB: case MUL: case DIV: { 
			va_start(ap, num);
			Operand temp1 = malloc(sizeof(struct Operand_)),
					temp2 = malloc(sizeof(struct Operand_)),
					temp3 = malloc(sizeof(struct Operand_));
			copyOperand(temp1, va_arg(ap, Operand));	
			copyOperand(temp2, va_arg(ap, Operand));
			copyOperand(temp3, va_arg(ap, Operand));
			Code->code.u.binop.result = temp1;
			Code->code.u.binop.op1 = temp2;
			Code->code.u.binop.op2 = temp3;
			break; 
		}
		case RELOP:{
			va_start(ap, num);
			Operand temp1 = malloc(sizeof(struct Operand_)),
					temp2 = malloc(sizeof(struct Operand_)),
					temp3 = malloc(sizeof(struct Operand_));
			copyOperand(temp1, va_arg(ap, Operand));	
			copyOperand(temp2, va_arg(ap, Operand));
			copyOperand(temp3, va_arg(ap, Operand));

			Code->code.u.cond.left = temp1;
			Code->code.u.cond.right = temp2;
			Code->code.u.cond.label = temp3;
			Code->code.u.cond.relop = malloc(2 * sizeof(char));
			strcpy(Code->code.u.cond.relop, va_arg(ap, char *));
			break;
		}
		case DEC: {
			va_start(ap, num);
			Operand temp = malloc(sizeof(struct Operand_));
			copyOperand(temp, va_arg(ap, Operand));	
			Code->code.u.dec.x = temp;
			Code->code.u.dec.size = va_arg(ap, int);
			break;
		} 
		case CALL:{
			va_start(ap, num);
			Operand temp = malloc(sizeof(struct Operand_));
			copyOperand(temp, va_arg(ap, Operand));	
			Code->code.u.call.x = temp;
			Code->code.u.call.func =  malloc(IDLEN * sizeof(char));
			strcpy(Code->code.u.call.func, va_arg(ap, char *));
			break;
		}
	}
	va_end(ap);
}
InterCodes getaddr(Operand left, Operand right){
	InterCodes code = malloc(sizeof(struct InterCodes_));
	fillInterCode(code, ADDR, 2, left, right);
	return code;
}
InterCodes getmem(Operand left, Operand right){
	InterCodes code = malloc(sizeof(struct InterCodes_));
	fillInterCode(code, MEMR, 2, left, right);
	return code;
}
InterCodes pushmem(Operand left, Operand right){
	InterCodes code = malloc(sizeof(struct InterCodes_));
	fillInterCode(code, MEML, 2, left, right);
	return code;
}
InterCodes jionInterCode(int num, ...){
	va_list ap;
	va_start(ap, num);
	InterCodes p = va_arg(ap, InterCodes), head;
	head = p;
	while(num > 1){
		if(p == NULL){
			p = va_arg(ap, InterCodes);
			head = p;
			num--;
			continue;
		}
		num--;
		InterCodes q = va_arg(ap, InterCodes);
		if(q == NULL) continue;
		while(p->next != NULL)
			p = p->next;
		p->next = q;
		q->pre = p;
	}
	va_end(ap);
	return head;
}
void newLabel(Operand label){
	static int count = 0;
	count++;
	fillOperand(label, LABEL, count);
}
void newTemp(Operand temp){
	static int count = 0;
	count++;
	fillOperand(temp, TEMP, count);
}
void newVariable(char* id, int kind, Operand variable){
	static int count = 0;
	int index = searchir(id);
	if(index == -1){
		printf("Fail to read variable \"%s\" from Table.\n", id);
		exit(0);
	}
	if(index == 0){
		count++;
		index = count;
		fillir(id, index);
	}
	if(kind == VARIABLE)
		fillOperand(variable, VARIABLE, index);
	else if(kind == ADDRESS)
		fillOperand(variable, ADDRESS, index);
}
InterCodes translate_Args(TreeNode node, Arglist *list){
	if(node->num == 1){ // Args -> Exp
		Operand t1 = malloc(sizeof(struct Operand_));
		newTemp(t1);
		Arglist p = malloc(sizeof(struct Arglist_));
		p->op = t1;
		p->next = NULL;;
		if(*list == NULL){
			(*list) = p;
		}
		else{
			p->next = *list;
			*list = p;
		}
		return translate_Exp(node->node[0], t1);
	}
	else{ // Args -> Exp COMMA Args
		Operand t1 = malloc(sizeof(struct Operand_));
		newTemp(t1);
		Arglist p = malloc(sizeof(struct Arglist_));
		p->op = t1;
		p->next = *list;
		*list = p;
		InterCodes code1 = translate_Exp(node->node[0], t1),
					code2 = translate_Args(node->node[2], list);
		return jionInterCode(2, code1, code2);
	}
}
InterCodes translate_Array(TreeNode node, sizelist list, int size, Operand place){ 
// place: beginning address provided by the upper array
	if(list != NULL){
		Operand t1 = malloc(sizeof(struct Operand_)),
				t2 = malloc(sizeof(struct Operand_));
		InterCodes code1 = translate_Array(node->node[0], list->next, size * list->size, place),
					code2 = translate_Exp(node->node[2], t1),
					code3 = malloc(sizeof(struct InterCodes_)),
					code4 = malloc(sizeof(struct InterCodes_));
		fillOperand(t2, CONSTANT, size);
		fillInterCode(code3, MUL, 3, t1, t1, t2);
		fillInterCode(code4, ADD, 3, place, place, t1);
		return jionInterCode(4, code1, code2, code3, code4);
	}
	else{ // Exp -> ID
		Operand v1 = malloc(sizeof(struct Operand_)),
				t1 = malloc(sizeof(struct Operand_));
		newVariable(node->node[0]->id, ADDRESS, v1);
		InterCodes code2 = malloc(sizeof(struct InterCodes_)),
					code1 = getaddr(t1, v1);
		fillInterCode(code2, ASSIGN, 2, place, t1);
		return jionInterCode(2, code1, code2);
	}
}
InterCodes translate_Exp(TreeNode node, Operand place){
	switch(ExpressionID(node)){
		case 1:{ // Exp -> ID
			InterCodes code1 =  malloc(sizeof(struct InterCodes_));
			Operand v1 = malloc(sizeof(struct Operand_));
			newVariable(node->node[0]->id, VARIABLE, v1);
			if(place == NULL){ // in case place is null
				place = malloc(sizeof(struct Operand_));
				newTemp(place);
			}
			fillInterCode(code1, ASSIGN, 2, place, v1);
			return code1;
		}
		case 24:{ // Exp -> INT
			Operand t1 = malloc(sizeof(struct Operand_));
			fillOperand(t1, CONSTANT, node->node[0]->value_int);
			InterCodes code = malloc(sizeof(struct InterCodes_));
			if(place == NULL){ // in case place is null
				place = malloc(sizeof(struct Operand_));
				newTemp(place);
			}
			fillInterCode(code, ASSIGN, 2, place, t1);
			return code;
		}
		case 25:{ // Exp -> FLOAT
			Operand t1 = malloc(sizeof(struct Operand_));
			fillOperand_float(t1, node->node[0]->value_float);
			InterCodes code = malloc(sizeof(struct InterCodes_));
			if(place == NULL){ // in case place is null
				place = malloc(sizeof(struct Operand_));
				newTemp(place);
			}
			fillInterCode(code, ASSIGN, 2, place, t1);
			return code;
		}
		case 2:{ // Exp -> Exp1 LB Exp2 RB
			TreeNode Exp1 = node->node[0];
			Operand t1 = malloc(sizeof(struct Operand_)),
					t2 = malloc(sizeof(struct Operand_));
			newTemp(t1); newTemp(t2);
			char id[IDLEN];
			getExpID(Exp1, id);
			sizelist list = getdimsize(id);
			InterCodes code1 = translate_Array(node, list, 4, t1),
						code2 = malloc(sizeof(struct InterCodes_));
			fillInterCode(code2, ASSIGN, 2, place, t2);
			return jionInterCode(3, code1, getmem(t2, t1), code2);
		}
		case 3:{ 
			if(node->num == 3){ // Exp -> ID LP RP
				InterCodes code = malloc(sizeof(struct InterCodes_));
				char function[IDLEN];
				strcpy(function, node->node[0]->id);
				if(place == NULL){ // in case place is null
					place = malloc(sizeof(struct Operand_));
					newTemp(place);
				}
				if(strcmp(function, "read") == 0)
					fillInterCode(code, READ, 1, place);
				else
					fillInterCode(code, CALL, 2, place, function);
				return code;
			}
			else{ // Exp -> ID LP Args RP
				char function[IDLEN];
				strcpy(function, node->node[0]->id);
				Arglist list = NULL;
				if(strcmp(function, "write") == 0){
					InterCodes code1 = translate_Args(node->node[2], &list),
								code2 = malloc(sizeof(struct InterCodes_));
					fillInterCode(code2, WRITE, 1, list->op);
					return jionInterCode(2, code1, code2);
				}
				else{
					InterCodes code = translate_Args(node->node[2], &list);
					Arglist p = list;
					while(p != NULL){
						InterCodes temp = malloc(sizeof(struct InterCodes_));
						fillInterCode(temp, ARG, 1, p->op);
					 	code = jionInterCode(2, code, temp);
						p = p->next;
					}
					if(place == NULL){ // in case place is null
						place = malloc(sizeof(struct Operand_));
						newTemp(place);
					}
					InterCodes code_call = malloc(sizeof(struct InterCodes_));
					fillInterCode(code_call, CALL, 2, place, function);
					return jionInterCode(2, code, code_call);
				}
			}
		}
		case 4: { // Exp -> Exp DOT ID  
			printf("Can not translate the code: Contain structure and function parameters of structure type!\n");
			exit(0);
			break;
		}
		case 11:{ // Exp -> Exp1 ASSIGNOP Exp2
			switch(ExpressionID(node->node[0])){
				case 1:{ // Exp1 -> ID
					Operand t1 = malloc(sizeof(struct Operand_)),
							v1 = malloc(sizeof(struct Operand_));
					newTemp(t1);
					newVariable(node->node[0]->node[0]->id, VARIABLE, v1);
					InterCodes code1 = translate_Exp(node->node[2], t1),
								code2 = malloc(sizeof(struct InterCodes_)),
								code_addr = NULL;
					// addr and mem 
					if(ExpressionID(node->node[2]) == 2){
						Operand t2 = malloc(sizeof(struct Operand_));
						newTemp(t2);
						code_addr = getmem(t2, t1);
						fillInterCode(code2, ASSIGN, 2, v1, t2);
					}
					else
						fillInterCode(code2, ASSIGN, 2, v1, t1);

					if(place == NULL){ // in case place is null
						return jionInterCode(3, code1, code_addr, code2);
					}
					else{
						InterCodes code3 = malloc(sizeof(struct InterCodes_));
						fillInterCode(code3, ASSIGN, 2, place, v1);
						return jionInterCode(3, code1, code_addr, code2, code3);
					}
				}
				case 2:{ // Exp1 -> Exp LB Exp RB
					TreeNode Exp1 = node->node[0], Exp2 = node->node[2];
					Operand t1 = malloc(sizeof(struct Operand_)),
							t2 = malloc(sizeof(struct Operand_));
					newTemp(t1); newTemp(t2);
					char id[IDLEN];
					getExpID(Exp1->node[0], id);
					sizelist list = getdimsize(id);
					InterCodes code1 = translate_Array(Exp1, list, 4, t1),
								code2 = translate_Exp(Exp2, t2),
								code3 = malloc(sizeof(struct InterCodes_)),
								code_addr = NULL;
	
					// addr and mem 
					if(ExpressionID(Exp2) == 2){
						Operand t3 = malloc(sizeof(struct Operand_));
						newTemp(t3);
						code_addr = getmem(t3, t2);
						fillInterCode(code3, MEML, 2, t1, t3);
						return jionInterCode(4, code1, code2, code_addr, code3);
					}
					else{
						fillInterCode(code3, MEML, 2, t1, t2);
						return jionInterCode(3, code1, code2, code3);
					}
				}
				case 4: { // Exp1 -> Exp DOT ID  
					printf("Can not translate the code: Contain structure and function parameters of structure type!\n");
					exit(0);
					break;
				}
			}
		}
		case 12:{ // Exp -> Exp RELOP Exp 
				// Exp -> NOT Exp 
				// Exp -> Exp AND Exp 
				// Exp -> Exp OR EXp
			if(place == NULL){ // in case place is null
				place = malloc(sizeof(struct Operand_));
				newTemp(place);
			}
			Operand label1 = malloc(sizeof(struct Operand_)),
					label2 = malloc(sizeof(struct Operand_)),
					t1 = malloc(sizeof(struct Operand_));
			newLabel(label1); newLabel(label2);
			InterCodes code0 =  malloc(sizeof(struct InterCodes_)),
						code1 = translate_Cond(node, label1, label2),
						code2 = malloc(sizeof(struct InterCodes_)),
						code3 = malloc(sizeof(struct InterCodes_)),
						code4 = malloc(sizeof(struct InterCodes_));
			fillOperand(t1, CONSTANT, 0);
			fillInterCode(code0, ASSIGN, 2, place, t1);
			fillInterCode(code2, LAB, 1, label1);
			fillOperand(t1, CONSTANT, 1);
			fillInterCode(code3, ASSIGN, 2, place, t1);
			fillInterCode(code4, LAB, 1, label2);
			return jionInterCode(5, code0, code1, code2, code3, code4);
		}
		case 13:{ // Exp -> Exp operation Exp  
				//operation:ADD SUB MUL DIV
			Operand t1 = malloc(sizeof(struct Operand_)),
					t2 = malloc(sizeof(struct Operand_));
			newTemp(t1); newTemp(t2);
			InterCodes code1 = translate_Exp(node->node[0], t1),
						code2 = translate_Exp(node->node[2], t2),
						code3 = malloc(sizeof(struct InterCodes_));
			char p[16];
			strcpy(p, node->node[1]->token);
			if(place == NULL){ // in case place is null
				place = malloc(sizeof(struct Operand_));
				newTemp(place);
			}

			if(strcmp(p, "PLUS") == 0) fillInterCode(code3, ADD, 3, place, t1, t2);
			else if (strcmp(p, "MINUS") == 0) fillInterCode(code3, SUB, 3, place, t1, t2);
			else if (strcmp(p, "STAR") == 0) fillInterCode(code3, MUL, 3, place, t1, t2);
			else if (strcmp(p, "DIV") == 0) fillInterCode(code3, DIV, 3, place, t1, t2);
			else printf("error!\n");
			return jionInterCode(3, code1, code2, code3);
		}
		case 14:{ // Exp -> LP Exp RP
			return translate_Exp(node->node[1], place);
		}
		case 15:{ // Exp -> MINUS Exp
			Operand t1 = malloc(sizeof(struct Operand_)),
					t2 = malloc(sizeof(struct Operand_));
			newTemp(t1);
			fillOperand(t2, CONSTANT, 0);
			InterCodes code1 = translate_Exp(node->node[1], t1),
						code2 = malloc(sizeof(struct InterCodes_));
			if(place == NULL){ // in case place is null
				place = malloc(sizeof(struct Operand_));
				newTemp(place);
			}
			fillInterCode(code2, SUB, 3, place, t2, t1);
			return jionInterCode(2, code1, code2);
		}
		
	}
}

void translate_VarDec(TreeNode node, Operand op){
	if(node->num == 1){ // VarDec->ID
		newVariable(node->node[0]->id, VARIABLE, op);
	}
	else{ // VarDec->VarDec LB INT RB
		char id[IDLEN];
		getExpID(node, id); // VarDec->ID and Exp->ID share similar structure

		newVariable(id, ADDRESS, op);
		
		int size = getdim(id), i;
		sizelist list = NULL;

		for(i = 0; i < size; i++){
			sizelist temp = malloc(sizeof(struct sizelist_));
			temp->size = 0;
			temp->next = NULL;
			if(list == NULL)
				list = temp;
			else{
				temp->next = list;
				list = temp;
			}
		}

		DFSfillsize(node, list);
		filldimsize(id, list);
	}
}
void translate_Specifier(TreeNode node){
	if(strcmp(node->node[0]->token, "StructSpecifier") == 0){
		printf("Can not translate the code: Contain structure and function parameters of structure type!\n");
		exit(0);
	}
}
void translate_ExtDecList(TreeNode node){
	Operand v1 = malloc(sizeof(struct Operand_));
	translate_VarDec(node->node[0], v1);
	if(node->num == 3)
		translate_ExtDecList(node->node[2]);
}

InterCodes translate_ParamDec(TreeNode node){
	Operand v1 = malloc(sizeof(struct Operand_));
	translate_VarDec(node->node[1], v1);
	InterCodes code = malloc(sizeof(struct InterCodes_));
	fillInterCode(code, PARAM, 1, v1);
	return code;
}
InterCodes translate_Varlist(TreeNode node){
	if(node->num == 3){ // VarList -> ParamDec COMMA VarList
		InterCodes code1 = translate_ParamDec(node->node[0]),
					code2 = translate_Varlist(node->node[2]);
		return jionInterCode(2, code1, code2);
	}
	else{ // VarList -> ParamDec
		return translate_ParamDec(node->node[0]);
	}
}

InterCodes translate_FunDec(TreeNode node){
	if(node->num == 4){ // FunDec -> ID LP VarList RP
		InterCodes code1 = malloc(sizeof(struct InterCodes_)),
					code2 = translate_Varlist(node->node[2]);
		fillInterCode(code1, FUNC, 1, node->node[0]->id);
		return jionInterCode(2, code1, code2);
	}
	else{ //FunDec -> ID LP RP
		InterCodes code = malloc(sizeof(struct InterCodes_));
		fillInterCode(code, FUNC, 1, node->node[0]->id);
		return code;
	}
}
InterCodes translate_Cond(TreeNode node, Operand label_true, Operand label_false){
	switch(ExpressionID(node)){
		case 22:{ // Exp -> Exp RELOP Exp
			Operand t1 = malloc(sizeof(struct Operand_)),
					t2 = malloc(sizeof(struct Operand_));
			newTemp(t1);
			newTemp(t2);
			InterCodes code1 = translate_Exp(node->node[0], t1),
						code2 = translate_Exp(node->node[2], t2),
						code3 = malloc(sizeof(struct InterCodes_)),
						code_label_false =  malloc(sizeof(struct InterCodes_));
			char *relop = malloc(2 * sizeof(char));
			strcpy(relop, node->node[1]->id); // note: the length of id is 32.
			fillInterCode(code3, RELOP, 4, t1, t2, label_true, relop);
			fillInterCode(code_label_false, JUMP, 1, label_false);
			return jionInterCode(4, code1, code2, code3, code_label_false);
		}
		case 16:{ // Exp -> NOT Exp
			return translate_Cond(node->node[1], label_false, label_true);
		}
		case 12:{ // Exp -> Exp AND Exp
			Operand label1 = malloc(sizeof(struct Operand_));
			newLabel(label1);
			InterCodes code1 = translate_Cond(node->node[0], label1, label_false),
						code2 = translate_Cond(node->node[2], label_true, label_false),
						code_label1 = malloc(sizeof(struct InterCodes_));
			fillInterCode(code_label1, LAB, 1, label1);
			return jionInterCode(3, code1, code_label1, code2);
			
		}
		case 23:{ // Exp -> Exp OR Exp
			Operand label1 = malloc(sizeof(struct Operand_));
			newLabel(label1);
			InterCodes code1 = translate_Cond(node->node[0], label_true, label1),
						code2 = translate_Cond(node->node[2], label_true, label_false),
						code_label1 = malloc(sizeof(struct InterCodes_));
			fillInterCode(code_label1, LAB, 1, label1);
			return jionInterCode(3, code1, code_label1, code2);
			
		}
		default:{
			Operand t1 = malloc(sizeof(struct Operand_)), 
					t2 = malloc(sizeof(struct Operand_));
			newTemp(t1);
			fillOperand(t2, CONSTANT, 0);
			InterCodes code1 = translate_Exp(node, t1),
						code2 = malloc(sizeof(struct InterCodes_)),
						code_jump = malloc(sizeof(struct InterCodes_));
			fillInterCode(code2, RELOP, 4, t1, t2, label_true, "!=");
			fillInterCode(code_jump, JUMP, 1, label_false);
			return jionInterCode(3, code1, code2, code_jump);
			
			break;
		}
	}
}
InterCodes translate_Stmt(TreeNode node){
	switch(ExpressionID(node)){
		case 20:{ // Stmt -> Exp SEMI
			return translate_Exp(node->node[0], NULL);
		}
		case 21:{ // Stmt -> CompSt
			return translate_CompSt(node->node[0]);
		}
		case 9:{ // Stmt -> RETURN Exp SEMI
			Operand t1 = malloc(sizeof(struct Operand_));
			newTemp(t1);
			InterCodes code1 = translate_Exp(node->node[1], t1),
			 			code2 = malloc(sizeof(struct InterCodes_));
			fillInterCode(code2, RETURN, 1, t1);
			return jionInterCode(2, code1, code2);
			
		}
		case 17:{ // Stmt -> IF LP Exp RP Stmt
			Operand label_true = malloc(sizeof(struct Operand_)),
					label_false = malloc(sizeof(struct Operand_));	
			newLabel(label_true);
			newLabel(label_false);
			InterCodes code1 = translate_Cond(node->node[2], label_true, label_false),
						code2 = translate_Stmt(node->node[4]),
						code_label_true = malloc(sizeof(struct InterCodes_)),
						code_label_false = malloc(sizeof(struct InterCodes_));
			fillInterCode(code_label_true, LAB, 1, label_true);
			fillInterCode(code_label_false, LAB, 1, label_false);
			return jionInterCode(4, code1, code_label_true, code2, code_label_false);
			
		}
		case 18:{ // Stmt -> IF LP Exp RP Stmt ELSE Stmt
			Operand label_true = malloc(sizeof(struct Operand_)),
					label_false = malloc(sizeof(struct Operand_)),
					label_end = malloc(sizeof(struct Operand_));
			newLabel(label_true);
			newLabel(label_false);
			newLabel(label_end);
			InterCodes code1 = translate_Cond(node->node[2], label_true, label_false),
						code2 = translate_Stmt(node->node[4]),
						code3 = translate_Stmt(node->node[6]),
						code_label_true = malloc(sizeof(struct InterCodes_)),
						code_label_false = malloc(sizeof(struct InterCodes_)),
						code_label_end = malloc(sizeof(struct InterCodes_)),
						code_jump = malloc(sizeof(struct InterCodes_));
			fillInterCode(code_label_true, LAB, 1, label_true);
			fillInterCode(code_label_false, LAB, 1, label_false);
			fillInterCode(code_label_end, LAB, 1, label_end);
			fillInterCode(code_jump, JUMP, 1, label_end);
			return jionInterCode(7, code1, code_label_true, code2, code_jump, code_label_false, code3, code_label_end);
			
		}
		case 19:{ // Stmt -> WHILE LP Exp RP Stmt
			Operand label_begin = malloc(sizeof(struct Operand_)),
					label_true = malloc(sizeof(struct Operand_)),
					label_false = malloc(sizeof(struct Operand_));
			newLabel(label_begin);
			newLabel(label_true);
			newLabel(label_false);
			InterCodes code1 = translate_Cond(node->node[2], label_true, label_false),
						code2 = translate_Stmt(node->node[4]),
						code_label_begin = malloc(sizeof(struct InterCodes_)),
						code_label_true = malloc(sizeof(struct InterCodes_)),
						code_label_false = malloc(sizeof(struct InterCodes_)),
						code_jump = malloc(sizeof(struct InterCodes_));
			fillInterCode(code_label_begin, LAB, 1, label_begin);
			fillInterCode(code_label_true, LAB, 1, label_true);
			fillInterCode(code_label_false, LAB, 1, label_false);
			fillInterCode(code_jump, JUMP, 1, label_begin);
			return jionInterCode(6, code_label_begin, code1, code_label_true, code2, code_jump, code_label_false);
			
		}
	}
}
InterCodes translate_StmtList(TreeNode node){
	if(node->num != 0){ //  StmtList -> Stmt StmtList
		InterCodes code1 = translate_Stmt(node->node[0]),
		 			code2 = translate_StmtList(node->node[1]);
		return jionInterCode(2, code1, code2);
	}
	return NULL;
}
InterCodes translate_Dec(TreeNode node){
	Operand v1 = malloc(sizeof(struct Operand_));
	translate_VarDec(node->node[0], v1);
	if(node->num == 1){ // Dec -> VarDec, in case this is an array declaration
		if(v1->kind == ADDRESS){
			char id[IDLEN];
			getExpID(node->node[0], id);
			sizelist list = getdimsize(id);
			int size = 4; // the size declared by the array
			while(list != NULL){
				size *= list->size;
				list = list->next;
			}
			InterCodes code = malloc(sizeof(struct InterCodes_));
			fillInterCode(code, DEC, 2, v1, size);
			return code;
		}
		else
			return NULL;
	}
	if(node->num == 3){ // Dec -> VarDec ASSIGNOP Exp
		Operand t1 = malloc(sizeof(struct Operand_));
		newTemp(t1);
		InterCodes code2 = malloc(sizeof(struct InterCodes_)),
					code1 = translate_Exp(node->node[2], t1);
		char id[IDLEN];
		getExpID(node->node[0], id);
		newVariable(id, VARIABLE, v1);
		fillInterCode(code2, ASSIGN, 2, v1, t1);
		return jionInterCode(2, code1, code2);
		
	}
}
InterCodes translate_DecList(TreeNode node){
	InterCodes code1 = translate_Dec(node->node[0]);
	if(node->num == 3){
		InterCodes code2 = translate_DecList(node->node[2]);
		code1 = jionInterCode(2, code1, code2);
	}
	return code1;
}
InterCodes translate_Def(TreeNode node){
	translate_Specifier(node->node[0]);
	return translate_DecList(node->node[1]);
}
InterCodes translate_DefList(TreeNode node){
	if(node->num != 0){
		InterCodes code1 = translate_Def(node->node[0]),
					code2 = translate_DefList(node->node[1]);
		return jionInterCode(2, code1, code2);
		
	}
	return NULL;
}
InterCodes translate_CompSt(TreeNode node){ // CompSt -> LC DefList StmtList RC
	InterCodes code1 = translate_DefList(node->node[1]), 
				code2 = translate_StmtList(node->node[2]);
	return jionInterCode(2, code1, code2);
}
InterCodes translate_ExtDef(TreeNode node){
	translate_Specifier(node->node[0]);
	if(ExpressionID(node) == 7){ // ExtDef -> Specifier FunDec CompSt
		InterCodes code1 = translate_FunDec(node->node[1]),
		 			code2 = translate_CompSt(node->node[2]);
		return jionInterCode(2, code1, code2);
		
	}
	if(ExpressionID(node) == 5){ // ExtDef -> Specifier ExtDecList SEMI
		translate_ExtDecList(node->node[1]);
	}
}
InterCodes translate_ExtDefList(TreeNode node){
	if(node->num != 0){ // ExtDefList -> ExtDef ExtDefList
		InterCodes code1 = translate_ExtDef(node->node[0]),
					code2 = translate_ExtDefList(node->node[1]);
		return jionInterCode(2, code1, code2);
		
	}
}
InterCodes translate(TreeNode node){ // Program -> ExtDefList
	return translate_ExtDefList(node->node[0]);
}

void printOperand(FILE *ir, Operand op){
	if(op == NULL)
		fclose(ir);
	switch(op->kind){
		case VARIABLE: { fprintf(ir, "v%d", (op->u).var_no);break; }
		case ADDRESS: { fprintf(ir, "v%d", (op->u).addr_no);break; }
		case TEMP: { fprintf(ir, "t%d", (op->u).temp_no);break; }
		case CONSTANT: { fprintf(ir, "#%d", (op->u).value);break; }
		//case FLOAT: { fprintf(ir, "#%f", (op->u).value_float);break; }
		case LABEL: { fprintf(ir, "label%d", (op->u).label);break; }
	}
}
void printInterCode(FILE *ir, InterCode code){
	switch(code.kind){
		case LAB: { fprintf(ir, "LABEL ");printOperand(ir, code.u.label);fprintf(ir, " :\n");break; }
		case FUNC: { fprintf(ir, "FUNCTION %s :\n", code.u.func);break; }
		case ASSIGN:{ printOperand(ir, code.u.assign.left);fprintf(ir, " := ");printOperand(ir, code.u.assign.right);fprintf(ir, "\n");break; }
		case ADD: { printOperand(ir, code.u.binop.result);fprintf(ir, " := ");printOperand(ir, code.u.binop.op1);fprintf(ir, " + ");printOperand(ir, code.u.binop.op2);fprintf(ir, "\n");break; }
		case SUB: { printOperand(ir, code.u.binop.result);fprintf(ir, " := ");printOperand(ir, code.u.binop.op1);fprintf(ir, " - ");printOperand(ir, code.u.binop.op2);fprintf(ir, "\n");break; }
		case MUL: { printOperand(ir, code.u.binop.result);fprintf(ir, " := ");printOperand(ir, code.u.binop.op1);fprintf(ir, " * ");printOperand(ir, code.u.binop.op2);fprintf(ir, "\n");break; }
		case DIV: { printOperand(ir, code.u.binop.result);fprintf(ir, " := ");printOperand(ir, code.u.binop.op1);fprintf(ir, " / ");printOperand(ir, code.u.binop.op2);fprintf(ir, "\n");break; }
		case ADDR: { printOperand(ir, code.u.addr.left);fprintf(ir, " := &");printOperand(ir, code.u.addr.right);fprintf(ir, "\n");break; }
		case MEMR: { printOperand(ir, code.u.mem.left);fprintf(ir, " := *");printOperand(ir, code.u.mem.right);fprintf(ir, "\n");break; }
		case MEML: { fprintf(ir, "*");printOperand(ir, code.u.mem.left);fprintf(ir, " := ");printOperand(ir, code.u.mem.right);fprintf(ir, "\n");break; }
		case JUMP: { fprintf(ir, "GOTO ");printOperand(ir, code.u.jump);fprintf(ir, "\n");break; }
		case RELOP: { fprintf(ir, "IF ");printOperand(ir, code.u.cond.left);fprintf(ir, " %s ", code.u.cond.relop);printOperand(ir, code.u.cond.right);fprintf(ir, " GOTO ");printOperand(ir, code.u.cond.label);fprintf(ir, "\n");break; }
		case RETURN: { fprintf(ir, "RETURN ");printOperand(ir, code.u.returnval);fprintf(ir, "\n");break; }
		case DEC: { fprintf(ir, "DEC ");printOperand(ir, code.u.dec.x);fprintf(ir, " %d ", code.u.dec.size);fprintf(ir, "\n");break; }
		case ARG: { fprintf(ir, "ARG ");printOperand(ir, code.u.arg);fprintf(ir, "\n");break; }
		case CALL: { printOperand(ir, code.u.call.x);fprintf(ir, " := CALL %s", code.u.call.func);fprintf(ir, "\n");break; }
		case PARAM: { fprintf(ir, "PARAM ");printOperand(ir, code.u.param);fprintf(ir, "\n");break; }
		case READ: { fprintf(ir, "READ ");printOperand(ir, code.u.read);fprintf(ir, "\n");break; }
		case WRITE: { fprintf(ir, "WRITE ");printOperand(ir, code.u.write);fprintf(ir, "\n");break; }
	}
}
void printInterCodes(InterCodes start){
	InterCodes p = start;
	FILE *ir = fopen("result.ir", "w");
	if(ir == NULL){
		printf("Open file failure.\n");
		return;
	}
	while(p != NULL){
		printInterCode(ir, p->code);
		p = p->next;
	}
	fclose(ir);
	printf("The intermidiate code has been written in to file \"result.ir\".\n");
}
void generateInterCodes(InterCodes start){
	InterCodes temp = malloc(sizeof(struct InterCodes_));
	(start->code).kind = FUNC;
	(start->code).u.func = malloc(sizeof(char) * 32);
	strcpy((start->code).u.func,"main");
	(temp->code).kind = READ;
	(temp->code).u.read = malloc(sizeof(struct Operand_));
	((temp->code).u.read)->kind = TEMP;
	((temp->code).u.read)->u.temp_no = 1;
	start->next = temp;
	temp->next = NULL;
	printInterCodes(start);
}

/* Simplify */
void delintercode(InterCodes temp){
	temp->pre->next = temp->next;
	temp->next->pre = temp->pre;
	free(temp);
}
/*
int simplify_temp_close(InterCodes start){
	InterCodes p = start, q;
	while(p != NULL){
		if(p->code.kind == ASSIGN);
		Operand left = p->code.u.assign.left, right = p->code.u.assign.right;
		if(left->kind == TEMP){
			q = p->next;
			if()
		}
		p = p->next;
	}
}
*/
int simplify_temp_constant(InterCodes start){
	Operand left, right;
	int num, value;
	InterCodes p = start, q;
	while(p != NULL){
		if(p->code.kind == ASSIGN){
			left = p->code.u.assign.left;
			right = p->code.u.assign.right;
			if(left->kind == TEMP && right->kind == CONSTANT){ // temp := CONSTANT
				q = p->next;
				num = left->u.temp_no, value = right->u.value;
				delintercode(p);
				while(q != NULL){
					switch(q->code.kind){
						case ASSIGN: {
							left = q->code.u.assign.left;
							right = q->code.u.assign.right;
							if(right->kind == TEMP && right->u.temp_no == num){
								right->kind = CONSTANT;
								right->u.value = value;
							}
							if(left->kind == TEMP && left->u.temp_no == num)
								return 1;
						}
						case ADD:{

						}
						case SUB: {

						}
						case MUL:{

						}
						case DIV:{

						}
						case MEMR:{

						}
						case MEML:{

						}
						case ADDR:{

						}
						case RELOP:{

						}
					}
					q = q->next;
				}
				return 1;			
			}
		}
		p = p->next;
	}
	return 0;
}
void simplify(InterCodes start){
	//while(simplify_temp(start));
}
