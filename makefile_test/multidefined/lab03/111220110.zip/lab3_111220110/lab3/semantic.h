#include "tree.h"

#define SIZE 256
#define SEED 131
#define ARGLEN 32
#define IDLEN 32

typedef struct fieldlist_* fieldlist;
struct fieldlist_{
	char type[IDLEN];
	char id[IDLEN];
	int dim;
	struct fieldlist_* next;
};
typedef struct sizelist_* sizelist; 
struct sizelist_{ // added for array addr figuration
	int size;
	struct sizelist_* next;
};
typedef struct tableitem_* tableitem;
struct tableitem_{
	char id[IDLEN];
	char type[IDLEN];// int, float, struct, struct variable(named as the struct name), struct null(named as "0")
	int dimension;
	int argNum; // arguments number of a function, no more than ARGLEN
	char *argType[ARGLEN];// record arguments type in order, type name no longer than IDLEN
	int ir; // added for intermidiate representition
	sizelist list;
	struct tableitem_* next;
};

typedef struct structitem_* structitem;
struct structitem_{
	char id[IDLEN];
	fieldlist field;
	struct structitem_* next;
};

typedef struct funcitem_* funcitem;
struct funcitem_{
	int line;
	char id[IDLEN];
	char type[IDLEN];// int, float, struct, struct variable(named as the struct name), struct null(named as "0")
	int argNum; // arguments number of a function, no more than ARGLEN
	char *argType[IDLEN];// record arguments type in order, type name no longer than IDLEN
	char *argID[IDLEN];
	int isDefined;
	struct funcitem_* next;
};

//A function declaration table is needed
tableitem Table[SIZE];
structitem structTable[SIZE];// store field info for struct type
funcitem funcTable[SIZE];

void assign(tableitem variable, char *id, char *type, int dim, int num, char *args[ARGLEN]);
void fill(tableitem variable);
void assignfunc(funcitem  item, char *id, char *type, int num, char *typelist[ARGLEN], char *idlist[IDLEN], int isDefined, int line);
void fillfunc(funcitem item);

int searchir(char *id);
void fillir(char *id, int index);
int getdim(char *id);
void filldimsize(char *id, sizelist list);
sizelist getdimsize(char *id);

int ExpressionID(TreeNode node);

void DFS(TreeNode root);
void DFSfillsize(TreeNode node, sizelist list);
void getExpID(TreeNode Exp, char *name);

void semantic();