#ifndef TREENODE_
#define TREENODE_
typedef struct TreeNode_* TreeNode;
struct TreeNode_{
	int line;
	int num; // number of sub nodes
	char token[32]; // name of the node 
	int value_int; // alternative
	float value_float; // alternative
	char id[32]; // alternative
	struct TreeNode_ *node[10];
};
#endif

#ifndef ROOT_
#define ROOT_
TreeNode root;
int mark; // whether there exist error in the program
#endif