#include <stdio.h>
int main(){

	printf("< TEST 1 >\n");
	system("./ir ./test_A/1.cmm");
	printf("< TEST 2 >\n");
	system("./ir ./test_A/2.cmm");
	printf("< TEST 3 >\n");
	system("./ir ./test_A/3.cmm");
	printf("< TEST 4 >\n");
	system("./ir ./test_A/4.cmm");
	printf("< TEST 5 >\n");
	system("./ir ./test_A/5.cmm");
	printf("< TEST 6 >\n");
	system("./ir ./test_A/6.cmm");
	printf("< TEST 7 >\n");
	system("./ir ./test_A/7.cmm");
	printf("< TEST 8 >\n");
	system("./ir ./test_A/8.cmm");
	printf("< TEST 9 >\n");
	system("./ir ./test_A/9.cmm");
	printf("< TEST 10 >\n");
	system("./ir ./test_A/10.cmm");
	printf("< TEST 11 >\n");
	system("./ir ./test_A/11.cmm");
	printf("< TEST 12 >\n");
	system("./ir ./test_A/12.cmm");
	printf("< TEST 13 >\n");
	system("./ir ./test_A/13.cmm");
	printf("< TEST 14 >\n");
	system("./ir ./test_A/14.cmm");
	printf("< TEST 15 >\n");
	system("./ir ./test_A/15.cmm");
	printf("< TEST 16 >\n");
	system("./ir ./test_A/16.cmm");
	printf("< TEST 17 >\n");
	system("./ir ./test_A/17.cmm");
	printf("< TEST 18 >\n");
	system("./ir ./test_A/18.cmm");

	return 0;
}