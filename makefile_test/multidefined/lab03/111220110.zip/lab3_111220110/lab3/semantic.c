#include <stdio.h>	
#include <string.h>
#include <stdarg.h>
#include <malloc.h>
#include "semantic.h"

char vartype[IDLEN];
char functype[IDLEN];
char structid[IDLEN];
int isStruct = 0, isStructNull = 0;


int assigncmp(char *left, char *right){
	char templ[IDLEN], tempr[IDLEN];
	strcpy(templ, "left");
	strcpy(tempr, "right");
	if(strcmp(left, "int_r") == 0 || strcmp(left, "int") == 0)
		strcpy(templ, "int");
	if(strcmp(left, "float_r") == 0 || strcmp(left, "float") == 0)
		strcpy(templ, "float");
	if(strcmp(right, "int_r") == 0 || strcmp(right, "int") == 0)
		strcpy(tempr, "int");
	if(strcmp(right, "float_r") == 0 || strcmp(right, "float") == 0)
		strcpy(tempr, "float");
	if(strcmp(templ, tempr) == 0 || strcmp(left, right) == 0)
		return 1;
	else
		return 0;
}
/*
     ########    ###    ########  ##       ######## 
        ##      ## ##   ##     ## ##       ##       
       ##     ##   ##  ##     ## ##       ##        
      ##    ##     ## ########  ##       ######   
     ##    ######### ##     ## ##       ##       
    ##    ##     ## ##     ## ##       ##       
   ##    ##     ## ########  ######## ######## 
*/


/* BKDR Hash Function */
unsigned int Hash(char *str){
    unsigned int hash = 0;
    while (*str)
        hash = hash * SEED + (*str++);
    return (hash & 0x7FFFFFFF);
}
/* initial the table */
void init(){
	int i;
	for(i = 0; i < SIZE; i++){
		Table[i] = NULL;
		structTable[i] = NULL;
		funcTable[i] = NULL;
	}

	/* add read() and write(int) to Table */
	tableitem read = malloc(sizeof(struct tableitem_)), write = malloc (sizeof(struct tableitem_));
	char *type[ARGLEN];
	type[0] = malloc(ARGLEN * sizeof(char));
	strcpy(type[0], "int");
	assign(read, "read", "int", 0, 0, NULL);
	assign(write, "write", "int", 0, 1, type);
	fill(read);
	fill(write);

	/* add read() and write(int) to funcTable */
	funcitem readfunc = malloc(sizeof(struct funcitem_)), writefunc = malloc(sizeof(struct funcitem_));
	char *id[ARGLEN];
	id[0] = malloc(ARGLEN * sizeof(char));
	strcpy(id[0], "temp");
	assignfunc(readfunc, "read", "int", 0, NULL, NULL, 1, 0);
	assignfunc(writefunc, "write", "int", 1, type, id, 1, 0);
	fillfunc(readfunc);
	fillfunc(writefunc);

}
/* search in the table */
int search(char *identifier){
	int index = (int)Hash(identifier) % SIZE;
	if(Table[index] == NULL){
		//printf("read Table[%d]: NULL\n", index);
		return 0; // first appearance
	}
	else{
		tableitem p = Table[index];
		//printf("read Table[%d]: %s\n", index, Table[index]->id);
		while(p != NULL){
			if(strcmp(identifier, p->id) == 0)
				return 1; // already exist
			p = p->next;
		}
		return 0;
	}
}
int searchir(char *id){
	int index = (int)Hash(id) % SIZE;
	tableitem p = Table[index];
	while(p != NULL){
		if(strcmp(id, p->id) == 0)
			return p->ir;
		p = p->next;
	}
	return -1;
}
void fillir(char *id, int ir){
	int index = (int)Hash(id) % SIZE;
	tableitem p = Table[index];
	while(p != NULL){
		if(strcmp(id, p->id) == 0)
			p->ir = ir;
		p = p->next;
	}
}
int getdim(char *id){
	int index = (int)Hash(id) % SIZE;
	tableitem p = Table[index];
	while(p != NULL){
		if(strcmp(id, p->id) == 0)
			return p->dimension;
		p = p->next;
	}
}
void filldimsize(char *id, sizelist list){
	int index = (int)Hash(id) % SIZE;
	tableitem p = Table[index];
	while(p != NULL){
		if(strcmp(id, p->id) == 0)
			p->list = list;
		p = p->next;
	}
}
sizelist getdimsize(char *id){
	int index = (int)Hash(id) % SIZE;
	tableitem p = Table[index];
	while(p != NULL){
		if(strcmp(id, p->id) == 0)
			return p->list;
		p = p->next;
	}
}
/* assign an table item */
void assign(tableitem variable, char *id, char *type, int dim, int num, char *args[ARGLEN]){
	strcpy(variable->id, id);
	strcpy(variable->type, type);
	variable->dimension = dim;
	variable->argNum = num;
	int i;
	for(i = 0; i < num; i++){
		variable->argType[i] = malloc(IDLEN * sizeof(char));
		strcpy(variable->argType[i], args[i]);
	}
	variable->ir = 0; // added for intermidiate representation
	variable->list = NULL;
	variable->next = NULL;
}
/* fill the variable or functino info into the table */
void fill(tableitem variable){
	int index = (int)Hash(variable->id) % SIZE;
	if(Table[index] == NULL){
		Table[index] = malloc(sizeof(struct tableitem_));
		assign(Table[index], variable->id, variable->type, variable->dimension, variable->argNum, variable->argType);
	}
	else{
		variable->next = Table[index]->next;
		Table[index]->next = variable;	
	}
	//printf("fill Table[%d]: %s\n", index, Table[index]->id);
}
void assignfunc(funcitem item, char *id, char *type, int num, char *typelist[ARGLEN], char *idlist[IDLEN], int isDefined, int line){
	strcpy(item->id, id);
	strcpy(item->type, type);
	item->argNum = num;
	int i;
	for(i = 0; i < num; i++){
		item->argType[i] = malloc(IDLEN * sizeof(char));
		item->argID[i] = malloc(IDLEN * sizeof(char));
		strcpy(item->argType[i], typelist[i]);
		strcpy(item->argID[i], idlist[i]);
	}
	item->isDefined = isDefined;
	item->line = line;
}
void fillfunc(funcitem item){
	int index = (int)Hash(item->id) % SIZE;
	if(funcTable[index] == NULL){
		funcTable[index] = malloc(sizeof(struct funcitem_ ));
		assignfunc(funcTable[index], item->id, item->type, item->argNum, item->argType, item->argID, item->isDefined, item->line);
	}
	else{
		item->next = funcTable[index]->next;
		funcTable[index]->next = item;
	}
}
void getfuncitem(char *funcid, funcitem func){
	int index = (int)Hash(funcid) % SIZE;
	funcitem p = funcTable[index];
	while(strcmp(p->id, funcid) != 0)
		p = p->next;
	assignfunc(func, p->id, p->type, p->argNum, p->argType, p->argID, p->isDefined, p->line);
}
int cmpfunc(funcitem func1, funcitem func2){// return 1 if is the same
	if(strcmp(func1->id, func2->id) != 0)
		return 0;
	if(strcmp(func1->type, func2->type) != 0)
		return 0;
	if(func1->argNum != func2->argNum)
		return 0;
	int i;
	for(i = 0; i < func1->argNum; i++){
		if(strcmp(func1->argType[i], func2->argType[i]) != 0)
			return 0;
		if(strcmp(func1->argID[i], func2->argID[i]) != 0)
			return 0;
	}
	return 1;
}
void changeDefstate(char *funcID){
	int index = (int)Hash(funcID) % SIZE;
	funcitem p = funcTable[index];
	while(strcmp(p->id, funcID) != 0)
		p = p->next;
	//assert(p->isDefined == 0);
	p->isDefined = 1;
}
void gettableitem(char *itemname, tableitem item){
	int index = (int)Hash(itemname) % SIZE;
	tableitem p = Table[index];
	//printf("read Table[%d]: %s\n", index, Table[index]->id);
	while(p != NULL)
		if(strcmp(itemname, p->id) == 0){
			assign(item, p->id, p->type, p->dimension, p->argNum, p->argType);
			break;
		}
		p = p->next;
}
void addstruct(char *structid, char *fieldid, char *type, int dim){
	int index = (int)Hash(structid) % SIZE;
	structitem p = structTable[index];
	while(p != NULL){
		if(strcmp(p->id, structid) == 0){ //the struct already existed
			fieldlist field = malloc(sizeof(struct fieldlist_)), temp = p->field;
			strcpy(field->type, type);
			strcpy(field->id, fieldid);
			field->next = NULL;
			while(p->next != NULL)
				p = p->next;
			temp->next = field;
			break;
		}
		p = p->next;
	}
	if(p == NULL){// the struct does not exist
		p = malloc(sizeof(struct structitem_));
		strcpy(p->id, structid);
		p->field = malloc(sizeof(struct fieldlist_));
		strcpy(p->field->type, type);
		strcpy(p->field->id, fieldid);
		p->field->dim = dim;
		p->next = NULL;
		structTable[index] = p;
	}
}
void replacestruct(char *structid){
	int index = (int)Hash("0") % SIZE;
	structitem p = structTable[index], q;
	q = p;
	while(p->next != NULL){
		q = p;
		p = p->next;
	}
	q->next = NULL;
	fieldlist s = p->field;
	while(s != NULL){
		addstruct(structid, s->id, s->type, s->dim);
		s = s->next;
	}
}
int searchstruct(char *structid, char *field, char *fieldtype){
	// search the structTable for the specific field name
	int index = (int)Hash(structid) % SIZE;
	structitem p = structTable[index];
	if(p == NULL){
		strcpy(fieldtype, "error");
		return 0;
	}
	while(strcmp(structid, p->id) != 0)
		p = p->next;
	fieldlist f = p->field;
	while(f != NULL){
		if(strcmp(field, f->id) == 0){
			strcpy(fieldtype, f->type);
			return 1;
		}
		f = f->next;
	}
	strcpy(fieldtype, "error");
	return 0;
}
void getidtype(char *id, char *type){
	int index = (int)Hash(id) % SIZE;
	tableitem p = Table[index];
	while(p != NULL){
		if(strcmp(id, p->id) == 0){
			strcpy(type, p->type);
			break;
		}
		p = p->next;
	}	
}
void printUndef(){
	int i;
	for(i = 0; i < SIZE; i++){
		funcitem p = malloc(sizeof(struct funcitem_ ));
		p = funcTable[i];
		while(p != NULL){
			if(p->isDefined == 0)
				printf("Error type 18 at line %d: Undefined function \"%s\"\n", p->line, p->id);
			p = p->next;
		}
	}
}
/*
      ######  ##          ###     ######   ######  #### ######## ##    ## 
     ##    ## ##         ## ##   ##    ## ##    ##  ##  ##        ##  ##  
    ##       ##        ##   ##  ##       ##        ##  ##         ####   
   ##       ##       ##     ##  ######   ######   ##  ######      ##    
  ##       ##       #########       ##       ##  ##  ##          ##    
 ##    ## ##       ##     ## ##    ## ##    ##  ##  ##          ##    
 ######  ######## ##     ##  ######   ######  #### ##          ##  
 */
int IdentifyNode(TreeNode node, int count, ...){
	// Para[0] -> Para[1] Para[2] ...Para[count]
	va_list ap;
	int i;
	if(node->num != count)
		return 0;
	va_start(ap, count);
	if(strcmp(node->token, va_arg(ap, char *)) != 0){
		va_end(ap);
		return 0;
	}
	for(i = 0; i < count; i++){
		if(strcmp((node->node[i])->token, va_arg(ap, char *)) != 0){ //the node token does not equal to the ith parameter
			va_end(ap);
			return 0;
		}
	}
	va_end(ap);
	return 1;
}
int ExpressionID(TreeNode node){
	if(IdentifyNode(node, 1, "Exp", "ID")) return 1;
	if(IdentifyNode(node, 4, "Exp", "Exp", "LB", "Exp", "RB")) return 2;
	if(IdentifyNode(node, 4, "Exp", "ID", "LP", "Args", "RP")) return 3;
	if(IdentifyNode(node, 3, "Exp", "ID", "LP", "RP")) return 3;
	if(IdentifyNode(node, 3, "Exp", "Exp", "DOT", "ID")) return 4;
	if(IdentifyNode(node, 3, "Def", "Specifier", "DecList", "SEMI")) return 5;
	if(IdentifyNode(node, 3, "ExtDef", "Specifier", "ExtDecList", "SEMI")) return 5;
	if(IdentifyNode(node, 2, "ExtDef", "Specifier", "SEMI")) return 6;
	if(IdentifyNode(node, 3, "ExtDef", "Specifier", "FunDec", "CompSt")) return 7;
	if(IdentifyNode(node, 3, "ExtDef", "Specifier", "FunDec", "SEMI")) return 8;
	if(IdentifyNode(node, 3, "Stmt", "RETURN", "Exp", "SEMI")) return 9;
	if(IdentifyNode(node, 3, "Dec", "VarDec", "ASSIGNOP", "Exp")) return 10;
	if(IdentifyNode(node, 3, "Exp", "Exp", "ASSIGNOP", "Exp")) return 11;
	if(IdentifyNode(node, 3, "Exp", "Exp", "AND", "Exp")) return 12;
	if(IdentifyNode(node, 3, "Exp", "Exp", "PLUS", "Exp") 
	|| IdentifyNode(node, 3, "Exp", "Exp", "MINUS", "Exp")
	|| IdentifyNode(node, 3, "Exp", "Exp", "STAR", "Exp")
	|| IdentifyNode(node, 3, "Exp", "Exp", "DIV", "Exp")) return 13;
	if(IdentifyNode(node, 3, "Exp", "LP", "Exp", "RP")) return 14;	
	if(IdentifyNode(node, 2, "Exp", "MINUS", "Exp")) return 15;
	if(IdentifyNode(node, 2, "Exp", "NOT", "Exp")) return 16;
	if(IdentifyNode(node, 5, "Stmt", "IF", "LP", "Exp", "RP", "Stmt")) return 17;
	if(IdentifyNode(node, 7, "Stmt", "IF", "LP", "Exp", "RP", "Stmt", "ELSE", "Stmt")) return 18;
	if(IdentifyNode(node, 5, "Stmt", "WHILE", "LP", "Exp", "RP", "Stmt")) return 19;	
	if(IdentifyNode(node, 2, "Stmt", "Exp", "SEMI")) return 20;
	if(IdentifyNode(node, 1, "Stmt", "CompSt")) return 21;
	if(IdentifyNode(node, 3, "Exp", "Exp", "RELOP", "Exp")) return 22;
	if(IdentifyNode(node, 3, "Exp", "Exp", "OR", "Exp")) return 23;
	if(IdentifyNode(node, 1, "Exp", "INT")) return 24;
	if(IdentifyNode(node, 1, "Exp", "FLOAT")) return 25;
	return 0;
}
/*
     ########  ########  ######         ######## ##     ## ##    ##  ######  
     ##     ## ##       ##    ##        ##       ##     ## ###   ## ##    ## 
    ##     ## ##       ##              ##       ##     ## ####  ## ##       
   ##     ## ######    ######         ######   ##     ## ## ## ## ##       
  ##     ## ##             ##        ##       ##     ## ##  #### ##       
 ##     ## ##       ##    ##        ##       ##     ## ##   ### ##    ## 
########  ##        ######         ##        #######  ##    ##  ###### 
*/
void DFSfillsize(TreeNode node, sizelist list){ // VarDec -> VarDec LB Exp RB; Exp -> INT
	if(list != NULL){
		list->size = node->node[2]->value_int;
		DFSfillsize(node->node[0], list->next);
	}
}
void getExpID(TreeNode Exp, char *name){// Exp-> Exp LB Exp RB
	if(Exp->num == 1) //Exp -> ID
		strcpy(name, Exp->node[0]->id);
	else
		getExpID(Exp->node[0], name);
}
void DFSExp(TreeNode node, char *type){ //for local definition initialization
	if(node->num == 1){
		if(strcmp(node->node[0]->token, "INT") == 0)
			strcpy(type, "int_r");
		else if(strcmp(node->node[0]->token, "FLOAT") == 0)
			strcpy(type, "float_r");
		else if(strcmp(node->node[0]->token, "ID") == 0){
			if(!search(node->node[0]->id)){
				printf("Error type 1 at line %d: Undefined variable \"%s\"\n", node->line, node->node[0]->id);
				strcpy(type, "null");
			}
			else{
				char temptype[IDLEN];
				getidtype(node->node[0]->id, temptype);
				strcpy(type, temptype);
			}
		}
	}
	else if(ExpressionID(node) == 2){//Exp -> Exp LB Exp RB
		char tempid[IDLEN], temptype[IDLEN];
		getExpID(node->node[0], tempid);
		if(!search(tempid)){
			printf("Error type 1 at line %d: Undefined variable \"%s\"\n", node->line, tempid);
			strcpy(type, "null");
		}
		else{
			tableitem item = malloc(sizeof(struct tableitem_));
			gettableitem(tempid, item);
			strcpy(type, item->type);
		}
		DFSExp(node->node[2], temptype);
		if(strcmp(temptype, "float") == 0 || strcmp(temptype, "float_r") == 0)
			printf("Error type 12 at line %d: Operands type mistaken\n", node->line);
	}
	else if(ExpressionID(node) == 3){//Exp -> ID LP Args RP; Exp → ID LP RP
		DFS(node);
		getidtype(node->node[0]->id, type);
		// the function can only be a right_value
		if(strcmp(type, "int") == 0)
			strcpy(type, "int_r");
		if(strcmp(type, "float") == 0)
			strcpy(type, "float_r");
		// a struct type
	}
	else if(ExpressionID(node) == 4){ //Exp → Exp DOT ID
		DFSExp(node->node[0], type);
		if(strcmp(type, "int") == 0 || strcmp(type, "float") == 0){
			printf("Error type 13 at line %d: Illegal use of “.”\n", node->line);
			strcpy(type, "error");
		}
		else{
			if(strcmp(type, "0") == 0){
				getExpID(node->node[0], type);
			}
			char temptype[IDLEN];
			if(!searchstruct(type, node->node[2]->id, type)){
				printf("Error type 14 at line %d: Un-existed field \"%s\"\n", node->line, node->node[2]->id);
			}
		}
	}
	else if(ExpressionID(node) == 11){
		char type1[32], type2[32];
		DFSExp(node->node[0], type1);
		DFSExp(node->node[2], type2);
		if(strcmp(type1, "int_r") == 0 || strcmp(type1, "float_r") == 0)
			printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n", node->line);
		if(assigncmp(type1, type2))
			strcpy(type, type1);
		else{
			if(strcmp(type1, "null") != 0 && strcmp(type2, "null") != 0){
				strcpy(type, "error");
				printf("Error type 5 at line %d: Type mismatched\n", node->line);
			}
		}
	}
	else if(ExpressionID(node) == 12 || ExpressionID(node) == 22 || ExpressionID(node) == 23){//Exp -> Exp AND Exp | Exp OR Exp 
		char type1[IDLEN], type2[IDLEN];
		DFSExp(node->node[0], type1);
		DFSExp(node->node[2], type2);
		if(((strcmp(type1, "int") != 0 &&  strcmp(type1, "int_r") != 0) ||
			(strcmp(type2, "int") != 0 &&  strcmp(type2, "int_r") != 0)) && 
			(strcmp(type1, "error") != 0) && (strcmp(type2, "error") != 0)){
			printf("Error type 7 at line %d: Operands type mismatched\n", node->line);
			strcpy(type, "error"); // or int?
		}
		else
			strcpy(type, "int_r"); 
	}
	else if(ExpressionID(node) == 13){	
		char type1[32], type2[32];
		DFSExp(node->node[0], type1);
		DFSExp(node->node[2], type2);
		if(assigncmp(type1, type2))
			strcpy(type, type1);
		else{
			if((strcmp(type1, "null") != 0 && strcmp(type2, "null") != 0) &&
				(strcmp(type1, "error") != 0 && strcmp(type2, "error") != 0)){
				strcpy(type, "error");
				printf("Error type 7 at line %d: Operands type mismatched\n", node->line);
			}
		}
	}
	else if(ExpressionID(node) == 14 || ExpressionID(node) == 15){// Exp -> LP Exp RP, Exp -> MINUS Exp 
		DFSExp(node->node[1], type);
	}
	else if(ExpressionID(node) == 16){// Exp → NOT Exp 
		DFSExp(node->node[1], type);
		if(strcmp(type, "int") != 0 && strcmp(type, "int_r") != 0 && strcmp(type, "error") != 0){
			printf("Error type 7 at line %d: Operands type mismatched\n", node->line);
			strcpy(type, "error"); // or int?
		}
		else
			strcpy(type, "int_r");
	}
}
void DFSDefList(TreeNode node){
	if(node->num == 1)
		DFS(node->node[0]);
	else if(node->num == 2){
		DFS(node->node[0]);
		DFSDefList(node->node[1]);
	}
}
void DFSSpecifier(TreeNode node, char *type){
	TreeNode child = node->node[0];
	if(strcmp(child->token, "TYPE") == 0){
		strcpy(type, child->id);// int or float
	}
	else{
		TreeNode grandchild = child->node[1];// grandchild is "Tag" or "OptTag"
		if(strcmp(grandchild->token, "Tag") == 0){// Specifier -> STRUCT Tag; Tag -> ID;
			strcpy(type, (grandchild->node[0])->id);
			if(!search(type))
				printf("Error type 17 at line %d: Undefined struct \"%s\"\n", grandchild->line, type);
		} 
		else{ // Specifier -> STRUCT OptTag LC DefList RC
			if(grandchild->num != 0){// OptTag is not null
				isStructNull = 0;
				strcpy(structid, (grandchild->node[0])->id);
				if(strcmp(structid, "int") != 0 && strcmp(structid, "float") != 0 && strcmp(structid, "struct") != 0){
					if(search(structid))
						printf("Error type 16 at line %d: Duplicated name \"%s\"\n", grandchild->line, structid);
					else{ // this type is a valid struct type
						tableitem structname = malloc(sizeof(struct tableitem_));
						assign(structname, structid, "struct", 0, -1, NULL);
						fill(structname);
					}
				}
			}
			else{//OptTag is null, e.g. struct {int i, j} temp;
				isStructNull = 1;
				strcpy(structid, "0");
			}
			// attention: initialization not permitted here
			isStruct = 1;
			DFSDefList(child->node[3]);
			isStruct = 0;
			strcpy(type, structid);
		}
	}
}
void DFSVarDec(TreeNode node, char id[IDLEN], int *count){
	if(node->num != 1){
		++(*count);
		DFSVarDec(node->node[0], id, count);
	}
	else
		strcpy(id, node->node[0]->id);
}
void DFSDec(TreeNode node, char id[IDLEN], int *count){
	DFSVarDec(node->node[0], id, count);
	if(node->num != 1){ //Dec -> VarDec ASSIGNOP Exp
		if(isStruct){//initialization is not permitted in a struct definition
			printf("Error type 15 at line %d: Initialization in struct field\n", node->line);
		} 
		else{
			char type[32];
			DFSExp(node->node[2], type);
			if(!assigncmp(vartype, type))
			printf("Error type 5 at line %d: Type mismatched\n", node->line);
		}
	}
}
void DFSExtDecList(TreeNode node, int* num, char *idlist[IDLEN], int dimlist[]){
	dimlist[*num] = 0;
	DFSVarDec(node->node[0], idlist[*num], &dimlist[*num]);// get the variable's name and dimension
	++(*num);
	if(node->num != 1)
		DFSExtDecList(node->node[2], num, idlist, dimlist);
}
void DFSDecList(TreeNode node, int *num, char *idlist[IDLEN], int dimlist[]){
	dimlist[*num] = 0;
	DFSDec(node->node[0], idlist[*num], &dimlist[*num]);
	++(*num);
	if(node->num != 1)
		DFSDecList(node->node[2], num, idlist, dimlist);
}
void DFSParaDec(TreeNode ParaDec, char* type, char* id, int *dim){
	DFSSpecifier(ParaDec->node[0], type);
	DFSVarDec(ParaDec->node[1], id, dim);
	/*
	tableitem temp = malloc(sizeof(struct tableitem_));
	assign(temp, id, type, *dim, -1, NULL);
	fill(temp);
	if(!isStruct && isStructNull){
		replacestruct(id);
		isStructNull = 0;
	}
	*/
}
void DFSVarList(TreeNode VarList, int* num, char* typelist[IDLEN], char* idlist[IDLEN], int dimlist[IDLEN]){
	dimlist[*num] = 0;
	DFSParaDec(VarList->node[0], typelist[*num], idlist[*num], &dimlist[*num]);
	++(*num);
	if(VarList->num != 1)
		DFSVarList(VarList->node[2], num, typelist, idlist, dimlist);
}
int DFSArgs(TreeNode Args, int num, char *typelist[IDLEN], int *count){
	DFS(Args->node[0]);
	if(*count < num){
		char temptype[IDLEN];
		DFSExp(Args->node[0], temptype);
		if(!assigncmp(temptype, typelist[*count]))
			return 0;
		if(Args->num == 1){
			if(*count != num - 1)
				return 0;
			else
				return 1;
		}
		else {
			++(*count);
			return DFSArgs(Args->node[2], num, typelist, count);
		}
	}
	else
		return 0;
}
void DFSStmt(TreeNode Stmt){
	// 9 Stmt -> RETURN Exp SEMI
	// 17 Stmt -> IF LP Exp RP Stmt
	// 18 Stmt -> IF LP Exp RP Stmt ELSE Stmt 
	// 19 Stmt -> WHILE LP Exp RP Stmt
	// 20 Stmt -> Exp SEMI
	// 21 Stmt -> CompSt
	switch(ExpressionID(Stmt)){
		case 9: case 17: case 18: case 19: DFS(Stmt); break;
		case 20: DFS(Stmt->node[0]); break;
		case 21 :{
			TreeNode DefList = Stmt->node[0]->node[1];
				if(DefList->num != 0)
					DFSDefList(DefList);
				DFS(Stmt->node[0]->node[2]);
		}
	}
}
void printArgs(TreeNode Args){ // array is ignored in this function
	char temptype[IDLEN];
	DFSExp(Args->node[0], temptype);
	if(strcmp(temptype, "int_r") == 0)
		strcpy(temptype, "int");
	if(strcmp(temptype, "float_r") == 0)
		strcpy(temptype, "float");
	if(Args->num != 1){
		printf("%s, ", temptype);
		printArgs(Args->node[2]);
	}
	else
		printf("%s", temptype);
}
/*
     ########  ########  ######  
     ##     ## ##       ##    ## 
    ##     ## ##       ##       
   ##     ## ######    ######  
  ##     ## ##             ## 
 ##     ## ##       ##    ## 
########  ##        ######  
*/
void DFS(TreeNode root){
	int i;
	switch(ExpressionID(root)){
		case 1:{
			char tempID[IDLEN];
			strcpy(tempID, root->node[0]->id);
			if(!search(tempID))
				printf("Error type 1 at line %d: Undefined variable \"%s\"\n", root->line, tempID);
			break;
		}
		case 2:{ // Exp-> Exp LB Exp RB
			char tempid[IDLEN], temptype[IDLEN];
			getExpID(root->node[0], tempid);
			if(!search(tempid))
				printf("Error type 1 at line %d: Undefined variable \"%s\"\n", root->line, tempid);
			else{
				tableitem item = malloc(sizeof(struct tableitem_));
				gettableitem(tempid, item);
				if(item->dimension == 0)// does not figure the dimension of the array
					printf("Error type 10 at line %d: \"%s\" must be an array\n", root->line, tempid);
			}
			DFSExp(root->node[2], temptype);
			if(strcmp(temptype, "float") == 0 || strcmp(temptype, "float_r") == 0)
				printf("Error type 12 at line %d: Operands type mistaken\n", root->line);
			break;
		}
		case 3:{	/*	function
					*	Exp -> ID LP Args RPs 
					*	Exp -> ID LP RP
					*/
			char tempID[IDLEN];
			strcpy(tempID, root->node[0]->id);
			if(!search(tempID))
				printf("Error type 2 at line %d: Undefined function \"%s\"\n", root->line, tempID);
			else{ // already difined
				// check the correctness of args (arrays are ignored for the time being)
				tableitem funcitem = malloc(sizeof(struct tableitem_));
				gettableitem(tempID, funcitem);
				if(funcitem->argNum == -1){
					printf("Error type 11 at line %d: \"%s\" must be a function\n", root->line, tempID);
					break;
				}

				if(root->num == 3){// Exp -> ID LP RP; no args
					if(funcitem->argNum != 0){
						printf("Error type 9 at line %d The method \"%s(", root->line, tempID);
						for(i = 0; i < funcitem->argNum - 1; i++)
							printf("%s, ", funcitem->argType[i]);
						printf("%s)\"", funcitem->argType[funcitem->argNum - 1]);
						printf(" is not applicable for the arguments %s\"\"\n", tempID);
					}
				}
				else{ //Exp -> ID LP Args RP
					int *count = malloc(sizeof(int)); *count = 0;
					if(!DFSArgs(root->node[2], funcitem->argNum, funcitem->argType, count)){// incorrect args
						printf("Error type 9 at line %d The method \"%s(", root->line, tempID);
						for(i = 0; i < funcitem->argNum - 1; i++)
							printf("%s, ", funcitem->argType[i]);
						printf("%s)\"", funcitem->argType[funcitem->argNum - 1]);
						printf(" is not applicable for the arguments \"%s(", tempID);
						printArgs(root->node[2]);
						printf(")\"\n");
					}
				}
			}
			break;
		}
		case 5:{	/*	definition of variables
					*	case 1: global definition:
					*	ExtDef -> Specifier ExtDecList SEMI
					*		Specifier -> TYPE | StructSpecifier
					*			StructSpecifier -> STRUCT Tag | STRUCT OptTag LC DefList RC
					* 		ExtDecList -> VarDec | VarDec COMMA ExtDecList 
					*	case 2: local definition
					*	Def -> Specifier DecList SEMI
					*		DecList -> Dec | Dec COMMA DecList
					*			Dec -> VarDec | VarDec ASSIGNOP Exp
					*/

			tableitem variable = malloc(sizeof(struct tableitem_));
			TreeNode VarNode = NULL;

			/* step 1: get the type of the defined variable */
			TreeNode Specifier = root->node[0];
			DFSSpecifier(Specifier, vartype); 
			/* step 2: get the variable names */
			/* 2-1 Definition of num of varibles, dimension list and idlist */
			int *num = malloc(sizeof(int)), 
				dimlist[ARGLEN]; *num = 0; 
			char *idlist[IDLEN];
			for(i = 0; i < ARGLEN; i++) //init idlist
				idlist[i] = malloc(IDLEN * sizeof(char));
			
			/* 2-2 seperately deal with 2 cases */
			if(strcmp(root->node[1]->token, "ExtDecList") == 0){
				//case 1: ExtDef -> Specifier ExtDecList SEMI
				TreeNode ExtDecList = root->node[1];
				VarNode = ExtDecList;
				DFSExtDecList(ExtDecList, num, idlist, dimlist); //get number of varibles, idlist, dimlist
			}
			else{
				//case 2: Def -> Specifier DecList SEMI
				TreeNode DecList = root->node[1];
				VarNode = DecList;
				DFSDecList(DecList, num, idlist, dimlist); //get number of varibles, idlist, dimlist
			}
			if(isStructNull && !isStruct){
				replacestruct(idlist[0]);
				isStructNull = 0;
			}

			/* 2-3 check the corretness of the definition */
			for(i = 0; i < *num; i++){
				//printf("%s: %d\n", idlist[i], dimlist[i]);
				if(search(idlist[i])){
					if(isStruct)
						printf("Error type 15 at line %d: Redefined field \"%s\"\n", VarNode->line, idlist[i]);
					else
						printf("* Error type 3 at line %d: Redefined variable \"%s\"\n", VarNode->line, idlist[i]);
				}
				else{// fill in the table
					if(isStruct){//fill in the structitem table
						addstruct(structid, idlist[i], vartype, dimlist[i]);
					}
					assign(variable, idlist[i], vartype, dimlist[i], -1, NULL);
					fill(variable);
				}
			}
			
			break;
		}
		case 6:{	/*	struct definitions
					*	ExtDef -> Specifier SEMI
					*/
			TreeNode Specifier = root->node[0];
			char form[32]; //form is useless. Optimize here if necessary
			DFSSpecifier(Specifier, form);
			break;
		}
		case 7: case 8: {	/*	function definitions
							*	ExtDef-> Specifier FunDec CompSt
							*/
			tableitem function = malloc(sizeof(struct tableitem_)), variable;
			funcitem functableitem = malloc(sizeof(struct funcitem_ ));
			TreeNode Specifier = root->node[0];
			TreeNode FunDec = root->node[1];
			TreeNode VarList = NULL;
			if(FunDec->num == 4)
				 VarList = FunDec->node[2];
			TreeNode CompSt = root->node[2];

			int *num = malloc(sizeof(int)), 
				dimlist[ARGLEN]; *num = 0; 
			char *typelist[IDLEN], *idlist[IDLEN];
			for(i = 0; i < ARGLEN; i++){//init idlist
				typelist[i] = malloc(IDLEN * sizeof(char));
				idlist[i] = malloc(IDLEN * sizeof(char));
			}				

			/* get the type of the function */
			DFSSpecifier(Specifier, vartype); 
			strcpy(functype, vartype);
			/* get the function identifier */
			char funcID[32]; 
			strcpy(funcID, FunDec->node[0]->id); 
			/* get parameter number and their types */
			if(FunDec->num == 4)// the function has some parameters
				DFSVarList(VarList, num, typelist, idlist, dimlist);// import func!!!!
			
			if(search(funcID)){
				tableitem tempitem = malloc(sizeof(struct tableitem_));
				gettableitem(funcID, tempitem);
				if(tempitem->argNum == -1){
					printf("Error type 4 at line %d: Redefined function \"%s\"\n", FunDec->line, funcID);
					for(i = 0; i < *num; i++){
						//printf("type:%s, id:%s, dim:%d\n", typelist[i], idlist[i], dimlist[i]);
						if(search(idlist[i]))
							printf("** Error type 3 at line %d: Redefined variable \"%s\"\n", FunDec->line, idlist[i]);
						else{
							variable = malloc(sizeof(struct tableitem_));
							assign(variable, idlist[i], typelist[i], dimlist[i], -1, NULL);
							fill(variable);
						}
					}
				}
				else{// the varible name in the table refers to a function
					funcitem tempfunc = malloc(sizeof(struct funcitem_ ));
					getfuncitem(funcID, tempfunc);
					if(ExpressionID(root) == 7)
						assignfunc(functableitem, funcID, vartype, *num, typelist, idlist, 1, root->line);
					else
						assignfunc(functableitem, funcID, vartype, *num, typelist, idlist, 0, root->line);
					if(!cmpfunc(functableitem, tempfunc)){
						if(tempfunc->isDefined == 1 && ExpressionID(root) == 7)
							printf("Error type 4 at line %d: Redefined function \"%s\"\n", FunDec->line, funcID);
						else 
							printf("Error type 19 at line %d: Inconsistent declaration of function \"%s\"\n", FunDec->line, funcID);

						for(i = 0; i < *num; i++){
							//printf("type:%s, id:%s, dim:%d\n", typelist[i], idlist[i], dimlist[i]);
							if(search(idlist[i]))
								printf("*** Error type 3 at line %d: Redefined variable \"%s\"\n", FunDec->line, idlist[i]);
							else{
								variable = malloc(sizeof(struct tableitem_));
								assign(variable, idlist[i], typelist[i], dimlist[i], -1, NULL);
								fill(variable);
							}
						}
					}
					else if(ExpressionID(root) == 7){
						if(tempfunc->isDefined == 1)
							printf("Error type 4 at line %d: Redefined function \"%s\"\n", FunDec->line, funcID);
						else
							changeDefstate(funcID);
					}
				}
			}
			else{
				for(i = 0; i < *num; i++){
					if(search(idlist[i]))
						printf("**** Error type 3 at line %d: Redefined variable \"%s\"\n", FunDec->line, idlist[i]);
					else{
						variable = malloc(sizeof(struct tableitem_));
						assign(variable, idlist[i], typelist[i], dimlist[i], -1, NULL);
						fill(variable);

					}
				}
				assign(function, funcID, vartype, 0, *num, typelist);
				fill(function);
				if(ExpressionID(root) == 7)
					assignfunc(functableitem, funcID, vartype, *num, typelist, idlist, 1, root->line);
				else
					assignfunc(functableitem, funcID, vartype, *num, typelist, idlist, 0, root->line);
				fillfunc(functableitem);
			}
			if(ExpressionID(root) == 7){
				// Definitions in CompSt
				TreeNode DefList = CompSt->node[1];
				if(DefList->num != 0)
					DFSDefList(DefList);
				DFS(CompSt->node[2]);
			}
			break;
		}
		case 9:{
			char returntype[IDLEN];
			DFSExp(root->node[1], returntype);
			if(!assigncmp(returntype, functype))
				printf("Error type 8 at line %d: The return type mismatched\n", root->line);
			break;
		}
		case 10:{
			char form[IDLEN];
			int formint;
			DFSDec(root, form, &formint);
			break;
		}
		case 4: case 11: case 12: case 22: case 23: case 13:{
			char form[IDLEN];
			DFSExp(root, form);
			break;
		}
		case 17: case 18: case 19: {
			// Stmt -> IF LP Exp RP Stmt; 
			// Stmt -> IF LP Exp RP Stmt ELSE Stmt; 
			// Stmt -> WHILE LP Exp RP Stmt;
			char temptype[IDLEN];
			DFSExp(root->node[2], temptype);
			if(strcmp(temptype, "int") != 0 && strcmp(temptype, "int_r") != 0 && strcmp(temptype, "error") != 0 )
				printf("Error type 7 at line %d: Operands type mismatched\n", root->line);
			DFSStmt(root->node[4]);
			if(ExpressionID(root) == 18)
				DFSStmt(root->node[6]);
			break;
		}
		default:{ // carry on with the DFS
			for(i = 0; i < root->num; i++)
				DFS(root->node[i]);
		}
	}
}
/*
        ###    ##    ##    ###    ##       ##    ##  ######  ####  ######  
       ## ##   ###   ##   ## ##   ##        ##  ##  ##    ##  ##  ##    ## 
     ##   ##  ####  ##  ##   ##  ##         ####   ##        ##  ##       
   ##     ## ## ## ## ##     ## ##          ##     ######   ##   ######  
  ######### ##  #### ######### ##          ##          ##  ##        ## 
 ##     ## ##   ### ##     ## ##          ##    ##    ##  ##  ##    ## 
##     ## ##    ## ##     ## ########    ##     ######  ####  ######  
*/

void semantic(){
	init();
	//if(mark == 0)
		DFS(root);
	printUndef();
}
