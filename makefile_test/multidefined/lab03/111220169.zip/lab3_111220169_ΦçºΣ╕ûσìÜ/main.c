#include "syntax.tab.c"
#include "semanteme.h"
#include "IR.h"

int main(int argc, char** argv){
	if(argc <= 1)
		return 1;
	FILE* f1 = fopen(argv[1], "r");
	if(!f1){
		perror(argv[1]);
		return 1;
	}
	FILE* f2 = fopen("output.ir", "w");
	init_HT();
	init_inter();
	yyrestart(f1);
	yyparse();
	if(error_num == 0){
		visit_tree(root);
		check_undef_func();
	}
	translate_tree(root);
	output_inters(f2);
	return 0;
}