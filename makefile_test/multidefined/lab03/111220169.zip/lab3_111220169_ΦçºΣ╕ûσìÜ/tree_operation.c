#include "tree_operation.h"

void init_node(Node** ptr, int t, char* n, int ln, char* d){
	*ptr = (Node*)malloc(sizeof(Node));
	(*ptr)->type = t;
	strcpy((*ptr)->name, n);
	if(d != NULL){
		strcpy((*ptr)->data, d);
	}
	(*ptr)->lineno = ln;
	(*ptr)->child = NULL;
	(*ptr)->sibling = NULL;
}

void add_child(Node* parent, Node* child){
	parent->child = child;
}

void add_sibling(Node* src, Node* sib){
	src->sibling = sib;
}