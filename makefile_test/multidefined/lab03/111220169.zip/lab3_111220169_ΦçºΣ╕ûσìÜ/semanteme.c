#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include "semanteme.h"

int visit_Exp(Node* Exp);
void visit_StmtList(Node* StmtList, Node* fID);
FieldList store_structure(Node* StructSpecifier);
int handle_uncertain_other_Exp_type(Node* Exp, char* struct_name);

void print_error(int error_type, int lineno){
	switch(error_type){
		case 1: printf("Error type 1 at line %d: Undefined variable\n", lineno); break;
		case 2: printf("Error type 2 at line %d: Undefined function\n", lineno); break;
		case 3: printf("Error type 3 at line %d: Redefined variable\n", lineno); break;
		case 4: printf("Error type 4 at line %d: Redefined function\n", lineno); break;
		case 5: printf("Error type 5 at line %d: Type mismatched\n", lineno); break;
		case 6: printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n", lineno); break;
		case 7: printf("Error type 7 at line %d: Operands type mismatched\n", lineno); break;
		case 8: printf("Error type 8 at line %d: The return type mismatched\n", lineno); break;
		case 9: printf("Error type 9 at line %d: The method is not applicable to the defined function\n", lineno); break;
		case 10: printf("Error type 10 at line %d: The symbol before \"[]\" must be an array\n", lineno); break;
		case 11: printf("Error type 11 at line %d: The symbol before \"()\" must be a function\n", lineno); break;
		case 12: printf("Error type 12 at line %d: Operands type mistaken\n", lineno); break;
		case 13: printf("Error type 13 at line %d: Illegal use of \".\"\n", lineno); break;
		case 14: printf("Error type 14 at line %d: Un-existed field\n", lineno); break;
		case 15: printf("Error type 15 at line %d: Redefined field\n", lineno); break;
		case 16: printf("Error type 16 at line %d: Duplicated name\n", lineno); break;
		case 17: printf("Error type 17 at line %d: Undefined struct\n", lineno); break;
		case 18: printf("Error type 18 at line %d: Undefined function\n", lineno); break;
		case 19: printf("Error type 19 at line %d: Inconsistent declaration of function\n", lineno); break;
	}
}

FieldList add_VarDec(Node* VarDec, char* type, int flag){
	FieldList p = (FieldList)malloc(sizeof(struct FieldList_));
	p->type = NULL;
	p->tail = NULL;
	Type cur = p->type;
	Node* ID_VD = VarDec->child;
	while(strcmp(ID_VD->name, "ID") != 0){
		assert(strcmp(ID_VD->name, "VarDec") == 0);
		Type sArray = (Type)malloc(sizeof(struct Type_));
		sArray->kind = array;
		sArray->u.array.arg.size = atoi(ID_VD->sibling->sibling->data);
		sArray->u.array.arg.elem = NULL;
		if(p->type == NULL){
			p->type = sArray;
			cur = p->type;
			p->type->u.array.length = 1;
		}
		else{
			cur->u.array.arg.elem = sArray;
			cur = cur->u.array.arg.elem;
			p->type->u.array.length++;
		}
		ID_VD = ID_VD->child;
	}
	assert(strcmp(ID_VD->name, "ID") == 0);
	if(flag == 0 && check_var_struct(ID_VD->data) == 2){
		print_error(3, ID_VD->lineno);
		//释放内存
		if(p->type != NULL){
			Type fir = p->type->u.array.arg.elem;
			for(Type temp = fir; temp != cur; temp = temp->u.array.arg.elem){
				free(fir);
				fir = temp;
			}
			printf("Free array successfully\n");
		}
		free(p);
		return NULL;
	}
	strcpy(p->name, ID_VD->data);
	if(p->type == NULL){
		p->type = (Type)malloc(sizeof(struct Type_));
		if(strcmp(type, "int") == 0){
			p->type->kind = basic;
			p->type->u.basic = 0;
		}
		else if(strcmp(type, "float") == 0){
			p->type->kind = basic;
			p->type->u.basic = 1;
		}
		else{
			p->type->kind = struct_var;
			strcpy(p->type->u.struct_name, type);
		}
	}
	else{
		Type curT = p->type;
		while(curT->u.array.arg.elem != NULL)
			curT = curT->u.array.arg.elem;
		curT->u.array.arg.elem = (Type)malloc(sizeof(struct Type_));
		curT = curT->u.array.arg.elem;
		if(strcmp(type, "int") == 0){
			curT->kind = basic;
			curT->u.basic = 0;
		}
		else if(strcmp(type, "float") == 0){
			curT->kind = basic;
			curT->u.basic = 1;
		}
		else{
			curT->kind = struct_var;
			strcpy(curT->u.struct_name, type);
		}
	}
	return p;
}

FieldList add_VarDec_in_def_Struct(Node* VarDec, char* type, int if_alarm){
	FieldList p = (FieldList)malloc(sizeof(struct FieldList_));
	p->type = (Type)malloc(sizeof(struct Type_));
	p->tail = NULL;
	Type curT = p->type;
	curT->kind = attribute;
	curT->u.attribute.property = NULL;
	Node* ID_VD = VarDec->child;
	Type basic_array_structvar = NULL;
	Type cur = NULL;
	int count = 1;
	while(strcmp(ID_VD->name, "ID") != 0){
		assert(strcmp(ID_VD->name, "VarDec") == 0);
		Type sArray = (Type)malloc(sizeof(struct Type_));
		sArray->kind = array;
		sArray->u.array.arg.size = atoi(ID_VD->sibling->sibling->data);
		sArray->u.array.arg.elem = NULL;
		if(basic_array_structvar == NULL){
			basic_array_structvar = sArray;
			cur = basic_array_structvar;
		}
		else{
			cur->u.array.arg.elem = sArray;
			cur = cur->u.array.arg.elem;
			count++;
		}
		ID_VD = ID_VD->child;
	}
	assert(strcmp(ID_VD->name, "ID") == 0);
	if(check_var_struct(ID_VD->data) == 2){
		if(if_alarm)
			print_error(15, ID_VD->lineno);
		//释放内存
		if(basic_array_structvar != NULL){
			for(Type temp = basic_array_structvar->u.array.arg.elem; temp != cur; temp = temp->u.array.arg.elem){
				free(basic_array_structvar);
				basic_array_structvar = temp;
			}
			printf("Free var successfully\n");
		}
		free(p);
		return NULL;
	}
	strcpy(p->name, ID_VD->data);
	if(cur != NULL){
		cur->u.array.arg.elem = (Type)malloc(sizeof(struct Type_));
		cur = cur->u.array.arg.elem;
	}
	else
		cur = (Type)malloc(sizeof(struct Type_));
	if(strcmp(type, "int") == 0){
		cur->kind = basic;
		cur->u.basic = 0;
	}
	else if(strcmp(type, "float") == 0){
		cur->kind = basic;
		cur->u.basic = 1;
	}
	else{
		cur->kind = struct_var;
		strcpy(cur->u.struct_name, type);
	}
	if(basic_array_structvar != NULL){
		basic_array_structvar->u.array.length = count;
		curT->u.attribute.property = basic_array_structvar;
	}
	else
		curT->u.attribute.property = cur;
	return p;
}

void visit_Def_in_def_Struct(Node *ntr, FieldList curF, char* struct_name){
	assert(strcmp(ntr->name, "Def") == 0);
	Node* specifier = ntr->child;
	char type[20];
	if(strcmp(specifier->child->name, "TYPE") == 0)
		strcpy(type, specifier->child->data);
	else{
		assert(strcmp(specifier->child->name, "StructSpecifier") == 0);
		char* temp = NULL;
		Node* OT_Tag = specifier->child->child->sibling;
		if(strcmp(OT_Tag->name, "OptTag") == 0)
			temp = store_structure(specifier->child)->name;
		else
			temp = OT_Tag->child->data;
		if(temp == NULL || check_var_struct(temp) == 0){
			print_error(17, specifier->lineno);
			return;
		}
		strcpy(type, temp);
	}
	Node* Dec = specifier->sibling->child;
	while(1){
		Node* VarDec = Dec->child;
		FieldList p = add_VarDec_in_def_Struct(VarDec, type, 1);
		FieldList q = add_VarDec_in_def_Struct(VarDec, type, 0);
		if(p == NULL)
			return;
		strcpy(p->type->u.attribute.struct_name, struct_name);
		strcpy(q->type->u.attribute.struct_name, struct_name);
		if(curF->type->u.structure == NULL)
			curF->type->u.structure = p;
		else{
			FieldList curTail = curF->type->u.structure;
			while(curTail->tail != NULL)
				curTail = curTail->tail;
			curTail->tail = p;
		}
		insert_HT(q);
		if(Dec->sibling != NULL){
			Dec = Dec->sibling->sibling->child;
		}
		else
			break;
	}
}

FieldList store_structure(Node* StructSpecifier){
	assert(strcmp(StructSpecifier->name, "StructSpecifier") == 0);
	Node* TAG_OTAG_LC = StructSpecifier->child->sibling;
	if(strcmp(TAG_OTAG_LC->name, "Tag") == 0){		//声明结构体
		int check = check_var_struct(TAG_OTAG_LC->child->data);
		if(check == 1 || check == 2){	//结构体已经被声明或者定义过
			printf("Redeclaration fault!\n");
			exit(-1);
		}
		else{		//结构体没有被声明或定义过，此处声明
			FieldList f = (FieldList)malloc(sizeof(struct FieldList_));
			strcpy(f->name, TAG_OTAG_LC->child->data);
			f->type = (Type)malloc(sizeof(struct Type_));
			f->type->kind = structure;
			f->type->u.structure = NULL;
			f->tail = NULL;
			insert_HT(f);
			return f;
		}
	}
	else if(strcmp(TAG_OTAG_LC->name, "OptTag") == 0){ //定义有名结构体
		assert(strcmp(TAG_OTAG_LC->child->name, "ID") == 0);
		int check = check_var_struct(TAG_OTAG_LC->child->data);
		if(check == 2){	//结构体已经被定义过
			print_error(16, TAG_OTAG_LC->lineno);
			return NULL;
		}
		else if(check == 1){	//结构体已经被声明过
			FieldList cur = ht[BKDRhash(TAG_OTAG_LC->child->data)];
			assert(cur != NULL);
			while(strcmp(cur->name, TAG_OTAG_LC->child->data) != 0)
				cur = cur->tail;
			assert(cur->type->u.structure == NULL);
			if(strcmp(TAG_OTAG_LC->sibling->sibling->name, "DefList") != 0){
				//TAG_OTAG_LC->sibling->sibling == RC
				//空定义结构体，没想好怎么处理
			}
			else{	//TAG_OTAG_LC->sibling->sibling == DefList
				Node* DefList = TAG_OTAG_LC->sibling->sibling;
				while(DefList != NULL){
					visit_Def_in_def_Struct(DefList->child, cur, TAG_OTAG_LC->child->data);
					DefList = DefList->child->sibling;
				}
			}
			return cur;
		}
		else if(check == 0){	//结构体未被声明和定义
			FieldList f = (FieldList)malloc(sizeof(struct FieldList_));
			strcpy(f->name, TAG_OTAG_LC->child->data);
			f->type = (Type)malloc(sizeof(struct Type_));
			f->type->kind = structure;
			f->tail = NULL;
			if(strcmp(TAG_OTAG_LC->sibling->sibling->name, "DefList") != 0){
				//TAG_OTAG_LC->sibling->sibling == RC
				//空定义结构体，没想好怎么处理
			}
			else{	//TAG_OTAG_LC->sibling->sibling == DefList
				Node* DefList = TAG_OTAG_LC->sibling->sibling;
				while(DefList != NULL){
					visit_Def_in_def_Struct(DefList->child, f, TAG_OTAG_LC->child->data);
					DefList = DefList->child->sibling;
				}
			}
			insert_HT(f);
			return f;
		}
	}
	else if(strcmp(TAG_OTAG_LC->name, "LC") == 0){	//定义无名结构体

	}
	return NULL;
}

char* check_type(Node* specifier){
	char* type = (char*)malloc(sizeof(char)*20);
	if(strcmp(specifier->child->name, "TYPE") == 0)
		strcpy(type, specifier->child->data);
	else{	//Specifier->StructSpecifier
		assert(strcmp(specifier->child->name, "StructSpecifier") == 0);
		Node* OT_Tag = specifier->child->child->sibling;
		if(strcmp(OT_Tag->name, "OptTag") == 0){
			char* temp = store_structure(specifier->child)->name;
			if(temp == NULL){
				free(type);
				return NULL;
			}
			strcpy(type, temp);
		}
		else{
			assert(strcmp(OT_Tag->name, "Tag") == 0);
			if(check_var_struct(OT_Tag->child->data) == 0){
				print_error(17, OT_Tag->child->lineno);
				return NULL;
			}
			strcpy(type, OT_Tag->child->data);
		}
	}
	return type;
}

int visit_ParamDec(Node* ParamDec, FieldList curF, int flag){
	assert(strcmp(ParamDec->name, "ParamDec") == 0);
	char* type = check_type(ParamDec->child);
	if(type == NULL)
		return -1;
	FieldList f = add_VarDec(ParamDec->child->sibling, type, flag);
	if(f == NULL)
		return 0;
	FieldList m = NULL;
	if(flag == 0)
		m = add_VarDec(ParamDec->child->sibling, type, flag);
	if(curF->type->u.function.arg == NULL)
		curF->type->u.function.arg = f;
	else{
		FieldList cur = curF->type->u.function.arg;
		while(cur->tail != NULL)
			cur = cur->tail;
		cur->tail = f;
	}
	curF->type->u.function.arg_num++;
	if(flag == 0 && m != NULL)
		insert_HT(m);
	return 1;
}

FieldList dec_def_function(Node* fID, char* type, int dec_def){	//dec_def=0声明函数，1为定义函数
	int flag = check_function(fID->data);
	FieldList p = (FieldList)malloc(sizeof(struct FieldList_));
	strcpy(p->name, fID->data);
	p->type = (Type)malloc(sizeof(struct FieldList_));
	p->type->kind = function;
	p->type->u.function.arg = NULL;
	p->type->u.function.arg_num = 0;
	strcpy(p->type->u.function.return_type, type);
	p->type->u.function.dec_def = dec_def;
	p->type->u.function.first_lineno = fID->lineno;
	p->tail = NULL;
	Node* VL_RP = fID->sibling->sibling;
	if(strcmp(VL_RP->name, "VarList") == 0){	//函数有参数
		int count = 0;
		while(1){
			if(visit_ParamDec(VL_RP->child, p, flag) == 0){
				free(p);
				return NULL;
			}
			if(VL_RP->child->sibling == NULL)
				break;
			VL_RP = VL_RP->child->sibling->sibling;
		}
	}
	else{	//函数无参数
		assert(strcmp(VL_RP->name, "RP") == 0);
	}
	return p;
}

void visit_CompSt(Node* CompSt, Node* fID){
	Node* DL_SL = CompSt->child->sibling;
	Node* temp = DL_SL;
	if(strcmp(DL_SL->name, "DefList") == 0){	//函数内部变量定义
		while(DL_SL != NULL){
			Node* fSpecifier = DL_SL->child->child;
			Node* DecList = fSpecifier->sibling;
			while(1){
				Node* VarDec = DecList->child->child;
				char* vType = check_type(fSpecifier);
				if(vType == NULL)
					break;
				FieldList p = add_VarDec(VarDec, vType, 0);
				if(p != NULL)
					insert_HT(p);
				else
					break;
				if(VarDec->sibling != NULL){
					//变量定义时初始化
					assert(strcmp(VarDec->sibling->name, "ASSIGNOP") == 0);
					assert(strcmp(vType, "int") == 0 || strcmp(vType, "float") == 0);
					if(VarDec->child->sibling != NULL){
						print_error(6, VarDec->lineno);
						free(p);
						continue;
					}
					Node* Exp = VarDec->sibling->sibling->child;
					int eType = visit_Exp(Exp);
					if(!((eType == -2 || eType == 5) && (strcmp(vType, "int") == 0)) &&
					   !((eType == -1 || eType == 6) && (strcmp(vType, "float") == 0)))
						print_error(5, Exp->lineno);
				}
				if(DecList->child->sibling != NULL)
					DecList = DecList->child->sibling->sibling;
				else
					break;
			}
			DL_SL = DL_SL->child->sibling;
		}
		DL_SL = temp;
		if(strcmp(DL_SL->sibling->name, "StmtList") == 0){
			//函数的各种Exp
			visit_StmtList(DL_SL->sibling, fID);
		}
	}
	else if(strcmp(DL_SL->name, "StmtList") == 0){
		visit_StmtList(DL_SL, fID);
	}
}

void visit_ExtDef(Node *ntr){
	Node* specifier = ntr->child;
	assert(strcmp(specifier->name, "Specifier") == 0);
	char type[20];

	if(strcmp(specifier->sibling->name, "SEMI") == 0){	//结构体处理
		Node* StructSpecifier = specifier->child;
		store_structure(StructSpecifier);
	}
	else{
		char* temp = check_type(specifier);
		if(temp == NULL)
			strcpy(temp, "Wrong_Type_Struct");
		strcpy(type, temp);
	}

	if(strcmp(specifier->sibling->name, "ExtDecList") == 0){	//全局变量,baisc和array
		Node* VarDec = specifier->sibling->child;
		FieldList p = add_VarDec(VarDec, type, 0);
		if(p != NULL)
			insert_HT(p);
	}

	else if(strcmp(specifier->sibling->name, "FunDec") == 0){	//函数
		//先搞清楚声明还是定义
		Node* fID = specifier->sibling->child;
		assert(strcmp(fID->name, "ID") == 0);
		if(strcmp(specifier->sibling->sibling->name, "SEMI") == 0){	//函数声明
			int check = check_function(fID->data);
			if(check != 0){
				FieldList q = get_loc(fID->data, function);
				FieldList p = dec_def_function(fID, type, 1);
				if(p == NULL)
					return;
				if(check_func_multi_dec(q, p) == 0){
					print_error(19, fID->lineno);
					return;
				}
			}
			else{
				FieldList p = dec_def_function(fID, type, 1);
				if(p == NULL)
					return;
				insert_HT(p);
			}
		}
		else{	//函数定义
			int check = check_function(fID->data);
			if(check == 2){
				print_error(4, fID->lineno);
				return;
			}
			if(check == 1){
				FieldList q = get_loc(fID->data, function);
				FieldList p = dec_def_function(fID, type, 1);
				if(p == NULL)
					return;
				if(check_func_multi_dec(q, p) == 0){
					print_error(19, fID->lineno);
					return;
				}
			}
			if(check == 0){
				FieldList p = dec_def_function(fID, type, 2);
				if(p == NULL)
					return;
				insert_HT(p);
			}
			visit_CompSt(specifier->sibling->sibling, fID);
			get_loc(fID->data, function)->type->u.function.dec_def = 2;
		}
	}
}

char* get_ID_from_Exp(Node* Exp){
	if(strcmp(Exp->name, "ID") == 0)
		return Exp->data;
	if(strcmp(Exp->sibling->name, "LB") == 0)
		return get_ID_from_Exp(Exp->child);
	if(strcmp(Exp->sibling->name, "Exp") == 0)
		return get_ID_from_Exp(Exp->sibling->child);
	printf("Error in get_ID_from_Exp\n");
	exit(-1);;
}

int get_array_div_from_Exp(Node* Exp){
	if(Exp->sibling == NULL)
		return 0;
	if(strcmp(Exp->sibling->name, "LB") == 0)
		return get_array_div_from_Exp(Exp->sibling->sibling->child)+1;
	return 0;
}

int visit_Args(Node* fID, Node* Args){
	int arg_num = 1;
	Node* Exp = Args->child;
	while(Exp->sibling != NULL){
		arg_num++;
		Exp = Exp->sibling->sibling->child;
	}
	if(arg_num != get_function_arg_num(fID->data)){
		print_error(9, fID->lineno);
		return -3;
	}
	for(int i = 1; i <= arg_num; i++){
		int actual_arg = visit_Exp(Exp->child);
		int formal_arg = get_function_arg_type(fID->data, i);
		if(actual_arg == -5)
			actual_arg = handle_uncertain_other_Exp_type(Exp->child, NULL);
		if(actual_arg == -4 && formal_arg == -4){
			FieldList actF = get_loc(get_ID_from_Exp(Exp->child), struct_var);
			FieldList formF = get_loc(fID->data, function);
			formF = formF->type->u.function.arg;
			for(int j = 1; j < i; j++)
				formF = formF->tail;
			assert(formF->type->kind == struct_var);
			if(strcmp(actF->type->u.struct_name, formF->type->u.struct_name) != 0){
				print_error(9, Exp->lineno);
				return -3;
			}
		}
		else if((actual_arg == -2 || actual_arg == 5) && formal_arg != -2){
			print_error(9, Exp->lineno);
			return -3;
		}
		else if((actual_arg == -1 || actual_arg == 6) && formal_arg != -1){
			print_error(9, Exp->lineno);
			return -3;
		}
		else if(actual_arg == 1 || actual_arg == 2 || actual_arg == 4){
			int actual_div = get_array_div_from_Exp(Exp->child);
			FieldList formF = get_loc(fID->data, function);
			formF = formF->type->u.function.arg;
			for(int j = 1; j < i; j++)
				formF = formF->tail;
			if(formF->type->kind != array){
				print_error(9, Exp->lineno);
				return -3;
			}
			int formal_div = get_array_div(formF->name);
			if(actual_div != formal_div){
				print_error(9, Exp->lineno);
				return -3;
			}
		}
		else
			return 0;
	}
	printf("Error in visit_Args\n");
	return -1;
}

int handle_uncertain_ASSIGN_Exp_type(Node* Exp, char* struct_name, int type){
	int lType = -5;
	char* exp_id = get_ID_from_Exp(Exp);
	if(check_var_struct(exp_id) != 0){
		FieldList cur = NULL;
		for(int i = 0; i <= 4; i++){
			cur = get_loc(exp_id, i);
			if(cur != NULL)
				break;
		}
		if(cur == NULL){
			print_error(1, Exp->lineno);
			return -3;
		}
		if(cur->type->kind == structure || cur->type->kind == array || cur->type->kind == attribute){
			print_error(type, Exp->lineno);
			return -3;
		}
		if(cur->type->kind == struct_var){
			lType = -4;
			strcpy(struct_name, cur->type->u.struct_name);
		}
		if(cur->type->kind == basic){
			lType = cur->type->u.basic-2;
		}
	}
	else{
		print_error(1, Exp->lineno);
		return -3;
	}
	return lType;
}

int handle_uncertain_other_Exp_type(Node* Exp, char* struct_name){
	int lType = -5;
	char* exp_id = get_ID_from_Exp(Exp);
	if(check_var_struct(exp_id) != 0){
		FieldList cur = NULL;
		for(int i = 0; i <= 4; i++){
			cur = get_loc(exp_id, i);
			if(cur != NULL)
				break;
		}
		if(cur == NULL){
			print_error(1, Exp->lineno);
			return -3;
		}
		if(cur->type->kind == structure || cur->type->kind == attribute){
			print_error(7, Exp->lineno);
			return -3;
		}
		if(cur->type->kind == array){
			Type curT = cur->type;
			while(curT->u.array.arg.elem->kind == array)
				curT = curT->u.array.arg.elem;
			lType = curT->u.basic+1;
		}
		if(cur->type->kind == struct_var){
			lType = -4;
			if(struct_name != NULL)
				strcpy(struct_name, cur->type->u.struct_name);
		}
		if(cur->type->kind == basic)
			lType = cur->type->u.basic-2;
	}
	else{
		print_error(1, Exp->lineno);
		return -3;
	}
	return lType;
}

int visit_Exp(Node* Exp){
	/*返回值类型: 
		-5: 类型不确定 -4: struct_var
		-3: 错误类型 -2: INT基本型  -1: FLOAT基本型  
		1: INT型数组  2: FLOAT型数组  3: Struct  4: Struct数组
		5: Function-INT  6: Function-FLOAT  7: Function-Struct
	*/

	if(strcmp(Exp->name, "INT") == 0)
		return 5;
	if(strcmp(Exp->name, "FLOAT") == 0)
		return 6;
	if(strcmp(Exp->name, "ID") == 0 && Exp->sibling == NULL)
		return -5;
	if(strcmp(Exp->sibling->name, "ASSIGNOP") == 0){
		int lType = visit_Exp(Exp->child);
		Node* rExp = Exp->sibling->sibling->child;
		int rType = visit_Exp(rExp);
		if(lType == -3 || rType == -3)
			return -3;
		char* l_struct_var = (char*)malloc(sizeof(char)*20);
		char* r_struct_var = (char*)malloc(sizeof(char)*20);
		if(lType == -5){
			assert(strcmp(Exp->child->name, "ID") == 0);
			lType = handle_uncertain_ASSIGN_Exp_type(Exp->child, l_struct_var, 6);
		}
		assert(lType != -5);
		if(rType == -5){
			assert(strcmp(rExp->name, "ID") == 0);
			rType = handle_uncertain_ASSIGN_Exp_type(rExp, r_struct_var, 5);
		}
		assert(rType != -5);
		if(lType == -3 || rType == -3)
			return -3;
		if(lType == -4 || rType == -4){
			if(lType + rType != -8){
				print_error(5, Exp->child->lineno);
				return -3;
			}
			assert(l_struct_var != NULL && r_struct_var != NULL);
			if(strcmp(l_struct_var, r_struct_var) != 0){
				print_error(5, Exp->child->lineno);
				return -3;
			}
			else
				return -4;
		}
		if((lType == -2 && (rType == -2 || rType == 5)) || 
		   (lType == -1 && (rType == -1 || rType == 6)))
			return rType;
		else if(lType == -2 || lType == -1){
			print_error(5,Exp->child->lineno);
			return -3;
		}
		else if(lType == -4){
			printf("application come to ltype==-4 here!!!\n\n\n\n");
			if(rType != -4){
				print_error(5, Exp->child->lineno);
				return -3;
			}
			FieldList lField = get_loc(get_ID_from_Exp(Exp->child), struct_var);
			FieldList rField = get_loc(get_ID_from_Exp(rExp), struct_var);
			if(lField == NULL || rField == NULL){
				print_error(1, Exp->child->lineno);
				return -3;
			}
			if(strcmp(lField->type->u.struct_name, rField->type->u.struct_name) != 0){
				print_error(5, Exp->child->lineno);
				return -3;
			}
			return lType;
		}
		else{
			print_error(6, Exp->child->lineno);
			return -3;
		}
		printf("Error in visit_Exp->ASSIGNOP\n");
	}
	if((strcmp(Exp->sibling->name, "AND") == 0) ||
	   		(strcmp(Exp->sibling->name, "OR") == 0) ||
	   		(strcmp(Exp->sibling->name, "RELOP") == 0) ||
	   		(strcmp(Exp->sibling->name, "PLUS") == 0) ||
	   		(strcmp(Exp->sibling->name, "MINUS") == 0) ||
	   		(strcmp(Exp->sibling->name, "STAR") == 0) ||
	   		(strcmp(Exp->sibling->name, "DIV") == 0)){
		int lType = visit_Exp(Exp->child);
		Node* rExp = Exp->sibling->sibling->child;
		int rType = visit_Exp(rExp);
		if(lType == -3 || rType == -3)
			return -3;
		char* l_struct_var = (char*)malloc(sizeof(char)*20);
		char* r_struct_var = (char*)malloc(sizeof(char)*20);
		if(lType == -5){
			assert(strcmp(Exp->child->name, "ID") == 0);
			lType = handle_uncertain_other_Exp_type(Exp->child, l_struct_var);
		}
		assert(lType != -5);
		if(rType == -5){
			assert(strcmp(rExp->name, "ID") == 0);
			rType = handle_uncertain_other_Exp_type(rExp, r_struct_var);
		}
		assert(rType != -5);
		if(lType == -3 || rType == -3)
			return -3;
		if(lType == -4 || rType == -4){
			print_error(7, Exp->child->lineno);
			return -3;
		}
		if(((lType == -2 || lType == 5) && (rType == -2 || rType == 5)) || 
		   ((lType == -1 || lType == 6) && (rType == -1 || rType == 6)))
			return rType;
		else if(lType == -2 || lType == -1 || lType == 5 || lType == 6){
			print_error(7,Exp->child->lineno);
			return -3;
		}
		else if(lType == 1 || lType == 2){
			if((lType == 1 && rType != 1) || (lType == 2 && rType != 2)){
				print_error(7,Exp->child->lineno);
				return -3;
			}
			FieldList lField = get_loc(get_ID_from_Exp(Exp->child), array);
			FieldList rField = get_loc(get_ID_from_Exp(Exp->sibling->sibling->child), array);
			if(lField == NULL || rField == NULL){
				print_error(1, Exp->child->lineno);
				return -3;
			}
			Type lT = lField->type;	Type rT = rField->type;
			assert(lT->kind == array && rT->kind == array);
			if(lT->u.array.length != rT->u.array.length){
				print_error(7, Exp->child->lineno);
				return -3;
			}
			return lType;
		}
		else{
			printf("%s\n", Exp->sibling->name);
			printf("%d, %d\n", lType, rType);
			printf("Error in visit_Exp->RELOP\n");
			exit(-1);
		}
	}

	if((strcmp(Exp->name, "LP") == 0) ||
	   (strcmp(Exp->name, "MINUS") == 0) ||
       (strcmp(Exp->name, "NOT") == 0))
		return visit_Exp(Exp->sibling->child);
	
	if(strcmp(Exp->sibling->name, "LP") == 0){
		assert(strcmp(Exp->name, "ID") == 0);
		if(check_var_struct(Exp->data) != 0){
			print_error(11, Exp->lineno);
			return -3;
		}
		if(check_function(Exp->data) == 0){
			print_error(2, Exp->lineno);
			return -3;
		}
		int return_type = get_function_return_type(Exp->data);
		if(return_type == -10){
			print_error(2, Exp->lineno);
			return -3;
		}
		if(strcmp(Exp->sibling->sibling->name, "Args") == 0){
			Node* Args = Exp->sibling->sibling;
			if(visit_Args(Exp, Args) == -3)
				return -3;
		}
		return return_type;
	}
	else if(strcmp(Exp->sibling->name, "LB") == 0){
		Node* cur = Exp;
		int count = 0;
		while(cur->sibling != NULL && strcmp(cur->sibling->name, "LB") == 0){
			int argType = visit_Exp(cur->sibling->sibling->child);
			if(argType == -5)
				argType = handle_uncertain_other_Exp_type(cur->sibling->sibling->child, NULL);
			if(argType != -2 && argType != 5){
				print_error(12, Exp->lineno);
				return -3;
			}
			cur = cur->child;
			count++;
		}
		if(strcmp(cur->name, "ID") == 0){
			FieldList p = get_loc(cur->data, array);
			if(p == NULL){
				print_error(10, Exp->lineno);
				return -3;
			}
			int array_div = get_array_div(cur->data);
			if(array_div < count){
				print_error(10, Exp->lineno);
				return -3;
			}
			if(array_div == count)
				return get_array_type(cur->data);
			if(array_div > count){
				return get_array_type(cur->data)+3;
			}
		}
		else if(strcmp(cur->child->sibling->name, "DOT") == 0){

		}
	}
	else if(strcmp(Exp->sibling->name, "DOT") == 0){
		int structType = visit_Exp(Exp->child);
		char* sVar = (char*)malloc(sizeof(char)*20);
		if(strcmp(Exp->child->name, "ID") == 0)
			strcpy(sVar, Exp->child->data);
		else if(strcmp(Exp->child->sibling->name, "DOT") == 0)
			strcpy(sVar, Exp->child->sibling->sibling->data);
		if(structType == -5){
			char* struct_name = get_struct_type(sVar);
			if(struct_name == NULL){
				print_error(13, Exp->child->lineno);
				return -3;
			}
			structType = -4;
		}
		if(structType != -4){
			print_error(13, Exp->lineno);
			return -3;
		}
		Node* sID = Exp->sibling->sibling;
		if(check_attr(get_struct_type(sVar), sID->data) == 0){
			print_error(14, Exp->lineno);
			return -3;
		}
		int t = get_struct_attr_type(sVar, Exp->sibling->sibling->data);
		assert(t != 0);
		return t;
	}
	printf("Error in visit_Exp\n");
	return 0;
}

void visit_Stmt(Node* Stmt, Node* fID){
	if(strcmp(Stmt->child->name, "Exp") == 0)
		visit_Exp(Stmt->child->child);
	else if(strcmp(Stmt->child->name, "RETURN") == 0){
		int actual_return_type = visit_Exp(Stmt->child->sibling->child);
		if(actual_return_type == -3)
			return;
		char* struct_name = (char*)malloc(sizeof(char)*20);
		if(actual_return_type == -5)
			actual_return_type = handle_uncertain_other_Exp_type(Stmt->child->sibling->child, struct_name);
		int formal_return_type = get_function_return_type(fID->data);
		if(actual_return_type == -4){
			if(formal_return_type != -4){
				print_error(8, Stmt->child->sibling->child->lineno);
				return;
			}
			FieldList curF = get_loc(fID->data, struct_var);
			if(strcmp(struct_name, curF->type->u.struct_name) != 0){
				print_error(8, Stmt->child->sibling->child->lineno);
				return;
			}
		}
		if(actual_return_type != formal_return_type && actual_return_type+7 != formal_return_type){
			print_error(8, Stmt->child->lineno);
			return;
		}
	}
	else if(strcmp(Stmt->child->name, "IF") == 0){
		Node* Exp = Stmt->child->sibling->sibling;
		visit_Exp(Exp->child);
		Node* ifStmt = Exp->sibling->sibling;
		visit_Stmt(ifStmt, fID);
		if(ifStmt->sibling != NULL)
			visit_Stmt(ifStmt->sibling->sibling, fID);
	}
	else if(strcmp(Stmt->child->name, "WHILE") == 0){
		Node* Exp = Stmt->child->sibling->sibling;
		int type = visit_Exp(Exp->child);
		visit_Stmt(Exp->sibling->sibling, fID);
	}
	else if(strcmp(Stmt->child->name, "CompSt") == 0){
		visit_CompSt(Stmt->child, fID);
	}
	//未处理完Stmt->
}

void visit_StmtList(Node* StmtList, Node* fID){
	if(StmtList == NULL)
		return;
	Node* Stmt = StmtList->child;
	while(1){
		visit_Stmt(Stmt, fID);
		if(Stmt->sibling != NULL)
			Stmt = Stmt->sibling->child;
		else
			break;
	}
}

void visit_tree(Node* root){	
	Node* ExtDef = root->child->child;
	if(ExtDef == NULL)
		return;
	while(1){
		visit_ExtDef(ExtDef);
		if(ExtDef->sibling == NULL)
			return;
		ExtDef = ExtDef->sibling->child;
	}
}