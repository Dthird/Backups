typedef struct Type_* Type;
typedef struct FieldList_* FieldList;

struct Type_{
	enum { basic, array, structure, attribute, struct_var, function } kind;
	union{
		int basic;			//INT=0，FLOAT=1
		struct{
			struct{ 
				Type elem; 
				int size;
			} arg;
			int length;
		} array;
		FieldList structure;
		struct{
			Type property;
			char struct_name[20];
		} attribute;
		char struct_name[20];
		struct{
			FieldList arg;	//形参链表
			int arg_num; 	//形参个数
			char return_type[20];	//返回值类型
			int dec_def;	//是否被定义，2为已定义，1为只声明
			int first_lineno;	//第一次被声明或定义的行号
		} function;
	} u;
};

struct FieldList_{
	char name[20];
	Type type;
	FieldList tail;
};

FieldList ht[131];

unsigned int BKDRhash(char* str);
void init_HT();
void insert_HT(FieldList p);
FieldList get_loc(char* str, int kind);
int check_var_struct(char* str);
int check_array(char* str);
int check_attr(char* struct_str, char* attr_str);
int check_function(char* str);
int get_struct_attr_type(char* struct_str, char* element_str);
int get_function_return_type(char* str);
int get_function_arg_num(char* str);
int get_function_arg_type(char* str, int arg_pos);
char* get_struct_type(char* var_str);
int get_array_div(char* str);
int get_array_type(char* str);
int get_ID_type(char* str);
int check_func_multi_dec(FieldList prev_dec, FieldList cur_dec);
int get_array_size(char* id, int level);
void check_undef_func();
void print_HT();