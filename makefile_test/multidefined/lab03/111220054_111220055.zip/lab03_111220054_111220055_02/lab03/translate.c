#include "translate.h"
#include "happy_tree_friends.h"
extern InterCodes* translate_exp(struct syntax_tree* exp, char* place);
extern InterCodes* translate_stmt(struct syntax_tree* stmt);
//extern InterCodes* translate_cond(struct syntax_tree* exp , char* labeltrue, char* labelfalse);
extern InterCodes* translate_args(struct syntax_tree* args);

extern InterCodes* translate_cond(struct syntax_tree* exp , char* labeltrue , char* labelfalse);

extern InterCodes* translate_Dec(struct syntax_tree* Dec);

extern InterCodes* translate_Str(struct syntax_tree* Str);

/*
 *global variables
 * */
int Temp = 1;
int Label = 1;
int Vari = 1;


int isbasic(Type ptr){
	return ((ptr->kind == basic) ? 1 : -1);
}


int typesize(Type ptr)
{
	if (ptr -> kind == basic)
		return 4;
	// else if (ptr -> level == Array)
	// 	return ((ptr -> array -> size) * typesize(ptr -> array -> next));
	else if (ptr->kind == structrue) {
		int ret = 0;
		FieldList x = ptr->u.structure;
		while (x)
		{
			ret += typesize(x->type);
			x = x->tail;
		}
		return ret;
	}
}


int offset(FieldList ptr, char *name)
{
	int ret = 0;
	while (ptr)
	{
		if (strcmp(name, ptr->name) == 0)
			return ret;
		ret += typesize(ptr->type);
		ptr = ptr->tail;
	}
}

Operand newop(char* type , char* place){
    Operand op = (Operand)malloc(sizeof(struct Operand_));
    if(strcmp("VARIABLE" , type) == 0){
        op->kind = VARIABLE;
        char* n = (char*)malloc(strlen(place)+1);
        strcpy(n , place);
        op->u.var_name = n;
        return op;
    }
    else if(strcmp("FUNC" , type) == 0){
        op->kind = FUNC;
        char* n = (char*)malloc(strlen(place) +1);
        strcpy(n , place);
        op->u.var_name = n;
        return op;
    }
    else if(strcmp("LABEL" , type) == 0){
        op->kind = LABEL;
        char* n = (char*)malloc(strlen(place) +1);
        strcpy(n , place);
        op->u.var_name = n;
        return op;
    }
    else if(strcmp("OP",type) == 0){
    Operand op = (Operand)malloc(sizeof(struct Operand_));
    op->kind = OP;
    char* n = (char*)malloc(3);
    strcpy(n , place);
    op->u.op = n;
    return op;
    }
    else printf("tpye = %s alert : Wrong in newop\n",type);

}


/*
Operand newop(char* op){
    Operand op = (Operand)malloc(sizeof(struct Operand_));
    op->kind = OP;
    char* n = (char*)malloc(strlen(op) + 1);
    strcpy(n , op);
    op->u.op = n;
    return op;
}
*/

Operand newop_const(int value){
    Operand op = (Operand)malloc(sizeof(struct Operand_));
    op->kind = CONSTANT;
    op->u.value = value;
}

struct InterCodes* newcode(char* type , Operand op1 , Operand op2 , Operand op3 , Operand op4){
    struct InterCodes* nv = (InterCodes*)malloc(sizeof(struct InterCodes));
    //kinds
    if(strcmp(type , "ASSIGN") == 0)
        nv->code.kind = ASSIGN;
    else if(strcmp(type , "ADD") == 0)
        nv->code.kind = ADD;
    else if(strcmp(type , "SUB") == 0)
        nv->code.kind = SUB;
    else if(strcmp(type , "MUL") == 0)
        nv->code.kind = MUL;
    else if(strcmp(type , "_DEV") == 0)
        nv->code.kind = MUL;
    else if(strcmp(type , "IFGOTO") == 0)
        nv->code.kind = IFGOTO;
    else if(strcmp(type , "CALL") == 0)
        nv->code.kind = CALL;
    else if(strcmp(type , "ARG") == 0)
        nv->code.kind = ARG;
    else if(strcmp(type , "DEC") == 0)
        nv->code.kind = DEC;
    else if(strcmp(type , "iLABEL") == 0)
        nv->code.kind = iLABEL;
    else if(strcmp(type , "FUNCTION") == 0)
        nv->code.kind = FUNCTION;
    else if(strcmp(type , "GOTO") == 0)
        nv->code.kind = GOTO;
    else if(strcmp(type , "RETURN") == 0)
        nv->code.kind = RETURN;
    else if(strcmp(type , "READ") == 0)
        nv->code.kind = READ;
    else if(strcmp(type , "WRITE") == 0)
        nv->code.kind = WRITE;
    else if(strcmp(type , "PARAM") == 0)
        nv->code.kind = PARAM;
    else if(strcmp(type , "ADDR") == 0)
        nv->code.kind = ADDR;
    else if(strcmp(type , "STAR") == 0)
        nv->code.kind = STAR;
    else if(strcmp(type , "MINUS") == 0)
        nv->code.kind = MINUS;
    else printf("type:%s Wrong newcode\n",type);
    nv->code.u.ops.op1 = op1;
    nv->code.u.ops.op2 = op2;
    nv->code.u.ops.op3 = op3;
    nv->code.u.ops.op4 = op4;
    nv->prev = nv;
    nv->next = nv;
}

char* newaddr() {
	char* t = (char*)malloc(10);
	int num = Temp++;
	int i = 1, j = 0;
	char c[10];

	t[0] = '*';
	t[1] = 't';
	while(num != 0){
		int a = num % 10;
		num = num / 10;
		c[j++] = '0' + a;
	}
	while(j > 0){
		t[i++] = c[--j];
	}
	t[i] = 0;
	return t;
}

char* newvar(){
	char* t = (char*)malloc(10);
	int num = Temp++;
	int i = 1, j = 0;
	char c[10];

	t[0] = 't';
	while(num != 0){
		int a = num % 10;
		num = num / 10;
		c[j++] = '0' + a;
	}
	while(j > 0){
		t[i++] = c[--j];
	}
	t[i] = 0;
	return t;

}
char* newlabel(){
	char* t = (char*)malloc(10);
	int num = Label++;
	int i = 1, j = 0;
	char c[10];

	t[0] = 'l';
	while(num != 0){
		int a = num % 10;
		num = num / 10;
		c[j++] = '0' + a;
	}
	while(j > 0){
		t[i++] = c[--j];
	}
	t[i] = 0;
	return t;

}
char* newv(){
	char* t = (char*)malloc(10);
	int num = Vari++;
	int i = 1, j = 0;
	char c[10];

	t[0] = 'v';
	while(num != 0){
		int a = num % 10;
		num = num / 10;
		c[j++] = '0' + a;
	}
	while(j > 0){
		t[i++] = c[--j];
	}
	t[i] = 0;
	return t;

}

InterCodes* translate_exp(struct syntax_tree* exp , char* place){//place: 变量名
    if(strcmp(exp->leftson->name , "INT") == 0){//EXP=>INT
        int value = exp->leftson->value.intval;
        Operand op1 = newop("VARIABLE", place);
        Operand op2 = newop_const(value);
        InterCodes* code = newcode("ASSIGN",op1 , op2 , 0 , 0);
        return code;
    }
    else if(strcmp(exp->leftson->name , "ID") == 0 && exp->leftson->rightbrother == NULL){
        //EXP => ID
        Operand op1 = newop("VARIABLE" , place);
        Operand op2 = newop("VARIABLE", exp->leftson->value.idval);
        //strcpy(place , exp->leftson->value.idval);//////???
        InterCodes* code = newcode("ASSIGN" , op1 , op2 , 0 , 0);
        return code;
    }
    else if(exp->leftson != NULL && strcmp(exp->leftson->rightbrother->name , "ASSIGNOP") == 0){//exp1 assignop exp2
        if (exp->leftson->leftson->rightbrother != 0 && strcmp(exp->leftson->leftson->rightbrother->name, "DOT") == 0) { //ID DOT ID
            printf("Dot\n");
            if (strcmp(exp->leftson->leftson->leftson->name, "ID") == 0) {
                printf("%s\n", exp->leftson->leftson->leftson->value.idval);
                translate_Str(exp->leftson->leftson->leftson);
            }



            // char* var = newvar();
            // char* t2 = newvar();

            // InterCodes* code1 = translate_exp(exp->leftson->rightbrother->rightbrother , var);

            // Operand op1 = newop("VARIABLE", t2);
            // Operand op2 = newop("VARIABLE" , var);

            // InterCodes* code = newcode("ASSIGN",op1 , op2 , 0 , 0);

            // link(code1, code);
            // if(place != NULL){
            //     Operand op3 = newop("VARIABLE" , place);
            //     Operand op4 = newop("VARIABLE" , exp->leftson->leftson->rightbrother->rightbrother->value.idval);
            //     InterCodes* code3 = newcode("ASSIGN",op3 , op4 , 0 , 0);
            //     code1 = link(code1 , code3);
            // }

            // return code1;
        }

        if(strcmp(exp->leftson->leftson->name , "ID") == 0 ){//id assignop exp
            char* var = newvar();
            InterCodes* code1 = translate_exp(exp->leftson->rightbrother->rightbrother , var);
            Operand op1 = newop("VARIABLE" , exp->leftson->leftson->value.idval);
            Operand op2 = newop("VARIABLE" , var);
            InterCodes* code = newcode("ASSIGN",op1 , op2 , 0 , 0);
            code1 = link(code1 , code);
            if(place != NULL){
                Operand op3 = newop("VARIABLE" , place);
                Operand op4 = newop("VARIABLE" , exp->leftson->value.idval);
                InterCodes* code3 = newcode("ASSIGN",op3 , op4 , 0 , 0);
                code1 = link(code1 , code3);
            }
            return code1;
        }
    }
    else if(exp->leftson != 0 && strcmp("LP",exp->leftson->name) == 0){
        return translate_exp(exp->leftson->rightbrother , place);
    }
    else if(exp->leftson != 0 && exp->leftson->rightbrother != 0 &&( strcmp(exp->leftson->rightbrother->name , "PLUS") == 0||strcmp(exp->leftson->rightbrother->name , "MINUS") == 0 ||strcmp(exp->leftson->rightbrother->name , "STAR") == 0||strcmp(exp->leftson->rightbrother->name , "DIV") == 0)){
        //exp1 plus exp2
        char* t1 = newvar();
        char* t2 = newvar();
        InterCodes* code1 = translate_exp(exp->leftson , t1);
        InterCodes *code2 = translate_exp(exp->leftson->rightbrother->rightbrother , t2);
        Operand op1 = newop("VARIABLE" , place);
        Operand op2 = newop("VARIABLE" , t1);
        char* option = (char*)malloc(2);
        if(strcmp(exp->leftson->rightbrother->name , "PLUS") == 0)
        {
            option[0] = '+';
            option[1] = '\0';
            Operand op3 = newop("VARIABLE" ,option);
            Operand op4 = newop("VARIABLE" , t2);
            InterCodes* code3 = newcode("ADD", op1 , op2 , op3 , op4);
        code1 = link(code1 , code2);
        code1 = link(code1 , code3);
        }
        if(strcmp(exp->leftson->rightbrother->name , "MINUS") == 0)
        {
            option[0] = '-';
            option[1] = '\0';
            Operand op3 = newop("VARIABLE" ,option);
            Operand op4 = newop("VARIABLE" , t2);
            InterCodes* code3 = newcode("SUB", op1 , op2 , op3 , op4);
        code1 = link(code1 , code2);
        code1 = link(code1 , code3);
        }
        if(strcmp(exp->leftson->rightbrother->name , "STAR") == 0)
        {
            option[0] = '*';
            option[1] = '\0';
            Operand op3 = newop("VARIABLE" ,option);
            Operand op4 = newop("VARIABLE" , t2);
            InterCodes* code3 = newcode("MUL", op1 , op2 , op3 , op4);
        code1 = link(code1 , code2);
        code1 = link(code1 , code3);
        }
        if(strcmp(exp->leftson->rightbrother->name , "DIV") == 0)
        {
            option[0] = '/';
            option[1] = '\0';
            Operand op3 = newop("VARIABLE" ,option);
            Operand op4 = newop("VARIABLE" , t2);
            InterCodes* code3 = newcode("_DEV", op1 , op2 , op3 , op4);
        code1 = link(code1 , code2);
        code1 = link(code1 , code3);
        }
        //code1 = link(code1 , code2);
        //code1 = link(code1 , code3);
        return code1;

    }
    else if(strcmp(exp->leftson->name , "MINUS") == 0){
        //minus exp1
        char* t1 = newvar();
        InterCodes *code1 = translate_exp(exp->leftson->rightbrother , place);
        Operand op1 = newop("VARIABLE", place);
        Operand op2 = newop_const(0);
        Operand op3 = newop("VARIABLE" , t1);
        InterCodes *code2 = newcode("MINUS" , op1 , op2 , op3 , 0);
        code1 = link(code1 , code2);
        return code1;
    }
    else if(exp->leftson!= NULL && exp->leftson->rightbrother != NULL &&(strcmp(exp->leftson->rightbrother->name , "RELOP") == 0 || strcmp(exp->leftson->name , "NOT") == 0 || strcmp(exp->leftson->rightbrother->name , "AND") == 0 || strcmp(exp->leftson->rightbrother->name , "OR") == 0)){
        char* label1 = newlabel();
        char* label2 = newlabel();
        Operand op00 = newop("VARIABLE" , place);
        Operand op01 = newop_const(0);
        InterCodes* code0 = newcode("ASSIGN" , op00 , op01 , 0 , 0);
        InterCodes* code1 = translate_cond(exp , label1 , label2);
        Operand op1 = newop("LABEL" , label1);
        Operand op2 = newop("VARIABLE" , place);
        Operand op3 = newop_const(1);
        InterCodes* code2 = newcode("iLABEL" ,op1 ,  0 , 0 , 0);
        InterCodes* code3 = newcode("ASSIGN" , op2 , op3 , 0 , 0);
        Operand op4 = newop("LABEL", label2);
        InterCodes* code4 = newcode("iLABEL" , op4, 0 , 0 , 0);
        code1 = link(code1 ,link(code2 , link(code3 , code4)));
        return code1;
    }
    else if(strcmp(exp->leftson->name, "ID") == 0 && exp->leftson->rightbrother != 0){	//CALL FUNCTION
		FuncNode* sym = findFuncTab(exp->leftson->value.idval);
		char* fName = sym->fName;
		struct syntax_tree* args = exp->leftson->rightbrother->rightbrother;
		if(strcmp(args->name, "RP") == 0){	//No Args
			Operand op1 = newop("VARIABLE", place);
			if(strcmp(fName, "read") == 0){
				InterCodes* code1 = newcode("READ", op1, 0, 0, 0);
				return code1;
			}
			Operand op2 = newop("FUNC", fName);
			InterCodes* code1 = newcode("CALL", op1, op2, 0, 0);
			return code1;
		}
		else{								//With Args
			if(strcmp(exp->leftson->value.idval, "write") == 0){
				char* t1 = newvar();
				InterCodes* code1 = translate_exp(args->leftson, t1);
				Operand op1 = newop("VARIABLE", t1);
				InterCodes* code2 = newcode("WRITE", op1, 0, 0, 0);
				return link(code1, code2);
			}
			InterCodes* code1 = translate_args(args);
			Operand op1 = newop("VARIABLE", place);
			Operand op2 = newop("FUNC", fName);
			InterCodes* code2 = newcode("CALL", op1, op2, 0, 0);
			return link(code1, code2);
		}
	}


}

InterCodes* translate_cond(struct syntax_tree* exp , char* labeltrue , char* labelfalse){
    if(exp->leftson != NULL && exp->leftson->rightbrother != NULL && strcmp(exp->leftson->rightbrother->name , "RELOP") == 0){
        //exp1 relop exp2
        char* t1 = newvar();
        char* t2 = newvar();
        InterCodes *code1 = translate_exp(exp->leftson , t1);
        InterCodes *code2 = translate_exp(exp->leftson->rightbrother->rightbrother , t2);
        char* relop = exp->leftson->rightbrother->value.idval;
        Operand op1 = newop("OP" , relop);
        Operand op2 = newop("VARIABLE",t1);
        Operand op3 = newop("VARIABLE",t2);
        Operand op4 = newop("LABEL",labeltrue);
        Operand op5 = newop("LABEL",labelfalse);

        InterCodes *code3 = newcode("IFGOTO",op2,op1,op3,op4);
        Operand op6 = newop("LABEL",labelfalse);
        InterCodes *code4 = newcode("GOTO",op6,0,0,0);
        link(code1,link(code2,link(code3,code4)));
        return code1;
    }
    else if(exp->leftson != NULL && strcmp(exp->leftson->name,"NOT") == 0){
        //NOT
        return translate_cond(exp->leftson->rightbrother,labelfalse,labeltrue);
    }
    else if(exp->leftson != NULL && strcmp(exp->leftson->rightbrother->name , "AND") == 0){
        //exp1 and exp2
        char* label1 = newlabel();
        InterCodes *code1 = translate_cond(exp->leftson,label1,labelfalse);
        InterCodes *code2 = translate_cond(exp->leftson->rightbrother->rightbrother,labeltrue,labelfalse);
        Operand op1 = newop("LABEL",label1);
        InterCodes *code3 = newcode("iLABEL",op1,0,0,0);
        return link(code1,link(code2,code3));

    }
    else if(exp->leftson != NULL && strcmp(exp->leftson->rightbrother->name , "OR") == 0){
        //exp1 or exp2
        char* label1 = newlabel();
        InterCodes *code1 = translate_cond(exp->leftson,labeltrue,label1);
        InterCodes *code2 = translate_cond(exp->leftson->rightbrother->rightbrother,labeltrue,labelfalse);
        Operand op1 = newop("LABEL",label1);
        InterCodes *code3 = newcode("iLABEL",op1,0,0,0);
        return link(code1,link(code2,code3));

    }
    else {
        char* t1 = newvar();
        InterCodes* code1 = translate_exp(exp,t1);
        Operand op1 = newop("VARIABLE",t1);
        char* opp = (char*)malloc(3);
        opp[0] = '!';
        opp[1] = '=';
        opp[2] = '\0';
        Operand op2 = newop("OP",opp);//???
        Operand op3 = newop_const(0);
        Operand op4 = newop("LABEL",labeltrue);
        InterCodes *code2 = newcode("IFGOTO",op1,op2,op3,op4);
        Operand op5 = newop("LABEL",labelfalse);
        InterCodes *code3 = newcode("iLABEL" , op5,0,0,0);
        return link(code1,link(code2,code3));
    }

}

InterCodes* translate_stmt(struct syntax_tree* stmt){
    if(strcmp(stmt->leftson->name , "Exp") == 0 && strcmp(stmt->leftson->rightbrother->name ,"SEMI") == 0){
        //exp semi
        return translate_exp(stmt->leftson , NULL);
    }
    else if(strcmp(stmt->leftson->name , "CompSt") == 0){
        printf("CompST\n");
        //return translate_CompSt(stmt->leftson);
    }/////////////???????????
    else if(strcmp(stmt->leftson->name , "RETURN")==0 && strcmp(stmt->leftson->rightbrother->name ,"Exp") == 0){
        //return exp semi
        char* t1 = newvar();
        InterCodes *code1 = translate_exp(stmt->leftson->rightbrother , t1);
        Operand op1 = newop("VARIABLE",t1);
        InterCodes *code2 = newcode("RETURN" , op1 , 0 , 0 , 0);
        return link(code1,code2);
    }
    else if(strcmp(stmt->leftson->name , "IF") == 0){
        if(stmt->leftson->rightbrother->rightbrother->rightbrother->rightbrother->rightbrother != NULL){
            //if lp exp rp stmt1 else stmt2
            char* label1 = newlabel();
            char* label2 = newlabel();
            char* label3 = newlabel();
            InterCodes* code1 = translate_cond(stmt->leftson->rightbrother->rightbrother,label1,label2);
            InterCodes *code2 = translate_stmt(stmt->leftson->rightbrother->rightbrother->rightbrother->rightbrother);
            InterCodes *code3 = translate_stmt(stmt->leftson->rightbrother->rightbrother->rightbrother->rightbrother->rightbrother->rightbrother);
            Operand op1 = newop("LABEL",label1);
            Operand op2 = newop("LABEL",label2);
            Operand op3 = newop("LABEL",label3);
            InterCodes* c1 = newcode("iLABEL",op1,0,0,0);
            InterCodes* c2 = newcode("iLABEL",op2,0,0,0);
            InterCodes* c3 = newcode("iLABEL",op3,0,0,0);
            InterCodes* c4 = newcode("GOTO",op3,0,0,0);
            return link(code1,link(c1,link(code2,link(c4,link(c2,link(code3,c3))))));

        }
        else{
            //if lp exp rp stmt1
            char* label1 = newlabel();
            char* label2 = newlabel();
            InterCodes* code1 = translate_cond(stmt->leftson->rightbrother->rightbrother,label1,label2);
            InterCodes* code2 = translate_stmt(stmt->leftson->rightbrother->rightbrother->rightbrother->rightbrother);
            Operand op1 = newop("LABEL",label1);
            Operand op2 = newop("LABEL",label2);
            InterCodes* c1 = newcode("iLABEL" , op1,0,0,0);
            InterCodes* c2 = newcode("iLABEL" , op2,0,0,0);
            return link(code1,link(c1,link(code2 , c2)));

        }
    }
    else if(strcmp(stmt->leftson->name , "WHILE") == 0){
        //while lp exp rp stmt1
        char* label1 = newlabel();
        char* label2 = newlabel();
        char* label3 = newlabel();
        InterCodes *code1 = translate_cond(stmt->leftson->rightbrother->rightbrother,label2,label3);
        InterCodes *code2 = translate_stmt(stmt->leftson->rightbrother->rightbrother->rightbrother->rightbrother);

        Operand op1 = newop("LABEL",label1);
        Operand op2 = newop("LABEL",label2);
        Operand op3 = newop("LABEL",label3);
        InterCodes* c1 = newcode("iLABEL",op1,0,0,0);
        InterCodes* c2 = newcode("iLABEL",op2,0,0,0);
        InterCodes* c3 = newcode("iLABEL",op3,0,0,0);
        InterCodes* c4 = newcode("GOTO",op1,0,0,0);
        return link(c1,link(code1,link(c2,link(code2,link(c4,c3)))));
    }
}

InterCodes* translate_args(struct syntax_tree* Args){
	InterCodes *code1 = 0, *code2 = 0;
	struct syntax_tree* exp = Args->leftson;
	while(exp != 0){
		char* t1 = newvar();
		InterCodes* temp1 = translate_exp(exp, t1);
		code1 = link(code1, temp1);
		Operand op1 = newop("VARIABLE", t1);
		InterCodes* temp2 = newcode("ARG", op1, 0, 0, 0);
		code2 = link(temp2, code2);

		if(exp->rightbrother == 0)
			exp = exp->rightbrother;
		else
			exp = exp->rightbrother->rightbrother->leftson;
	}
	return link(code1, code2);
}

InterCodes* translate_FunDec(struct syntax_tree* FunDec){

	FuncNode* sym = findFuncTab(FunDec->leftson->value.idval);
	char* fName = sym->fName;
	VariableNode* param = sym->args;
	Operand op1 = newop("FUNC", fName);
	InterCodes* code = newcode("FUNCTION", op1, 0, 0, 0);
	while(param != 0){
        //char* v = newvar();
		Operand op2 = newop("VARIABLE", param->vName);
		InterCodes* code1 = newcode("PARAM", op2, 0, 0, 0);
		code = link(code, code1);
		param = param->next;
	}
	return code;
}


InterCodes* translate_Dec(struct syntax_tree* Dec){
	struct syntax_tree* VarDec = Dec->leftson;
	if(VarDec->rightbrother == 0){	//Dec => VarDec
		if(strcmp(VarDec->leftson->name, "VarDec") == 0){	//VarDec => VarDec LB INT RB
			struct syntax_tree* son = VarDec->leftson;
			int size = 4 * son->rightbrother->rightbrother->value.intval;
			if (strcmp(son->leftson->name, "VarDec") == 0){
				// son = son->leftson;
				// size = size * son->rightbrother->rightbrother->value.intval;
                printf("Can not translate the code: Contain multidimensional array and function parameters of array type!\n");
                return NULL;
			}
			char* varName = son->leftson->value.idval;
			Operand op1 = newop("VARIABLE", varName);
			Operand op2 = newop_const(size);
			InterCodes* code = newcode("MEM_DEC", op1, op2, 0, 0);
			return code;
		}
        else {
            //ID
            char* t1 = newvar();
            return translate_exp(VarDec , t1);
        }
	}
	else{									//Dec => VarDec ASSIGNOP Exp
		if(strcmp(VarDec->leftson->name, "ID") == 0){

            VariableNode* var = findVarTab(VarDec->leftson->value.idval);
            if (isbasic(var->varType)) {
                char* t1 = newvar();
                InterCodes* code1 = translate_exp(VarDec->rightbrother->rightbrother, t1);
                Operand op1 = newop("VARIABLE", VarDec->leftson->value.idval);
                Operand op2 = newop("VARIABLE", t1);
                InterCodes* code2 = newcode("ASSIGN", op1, op2, 0, 0);
                code1 = link(code1, code2);
                return code1;
            } else {
                translate_Str(VarDec->leftson);
                // int size = typesize(var->type);

                //FieldList vList = var->type->u.structure;

                //while (vList) {

                //    char* t1 = newvar();
                //    InterCodes* code1 = translate_exp(VarDec->rightbrother->rightbrother, t1);

                //    // int os = offset(vList, vList->name);

                //    Operand* op1 = newop("VARIABLE", vList->name);
                //    // Operand* op2 = newop_const(offset);
                //    Operand* op2 = newop("VARIABLE", t1);
                //    vList = vList->tail;
                //    InterCodes* code2 = newcode("ASSIGN", op1, op2, 0, 0);
                //    code1 = link(code1, code2);
                //}

            }
            // char* t1 = newvar();
            // InterCodes* code1 = translate_exp(VarDec->rightbrother->rightbrother, t1);
            // Operand* op1 = newop("VARIABLE", VarDec->leftson->value.idval);
            // Operand* op2 = newop("VARIABLE", t1);
            // InterCodes* code2 = newcode("ASSIGN", op1, op2, 0, 0);
            // code1 = link(code1, code2);
            // return code1;
		}
	}
}



// InterCodes* translate_Str(struct syntax_tree* Str){
//
// 	// VariableNode* var = findVarTab(Str->leftson->rightbrother->leftson->value.idval);
//     // if (var->varType->kind == structrue ) {
//     //     FieldList fl = var->varType->u.structure;
//     //     if (fl->tail == NULL) {
//     //     printf("structrue\n");
//     //     }
//     // }
//
// 	VariableNode* var = findVarTab(Str->value.idval);
//
//     int tem_size = str_size;
//     InterCodes* code1 = NULL;
//
//     char* t1 = newvar();
//     char* t2 = newvar();
//     // char* t3 = newvar();
//
//     while (str_size >= 0) {
//
//         if (tem_size == str_size) {
//             Operand op1 = newop("VARIABLE", var->vName);
//             Operand op2 = newop("VARIABLE", t2);
//             code1 = newcode("ASSIGN", op1, op2, 0, 0);
//
//         } else {
//
//             int offset = tem_size - str_size;
//
//             Operand op1 = newop("VARIABLE", var->vName);
//             Operand op2 = newop("VARIABLE", t2);
//             Operand op3 = newop("VARIABLE" , "+");
//             Operand op4 = newop_const(offset);
//
//             InterCodes* code2 = newcode("ADD", op1, op2, op3, op4);
//             code1 = link(code1, code2);
//
//             Operand op5 = newop("VARIABLE", t2);
//             InterCodes* code3 = newcode("ASSIGN", op5, op1, 0, 0);
//
//             code1 = link(code1, code3);
//
//         }
//
//         str_size -= 4;
//
//         // int os = offset(vList, vList->name);
//         // Operand* op1 = newop("VARIABLE", vList->name);
//         // Operand* op2 = newop_const(os);
//         // InterCodes* code2 = newcode("ASSIGN", op1, op2, 0, 0);
//         // code1 = link(code1, code2);
//         // vList = vList->tail;
//
//
//     }
//
//     return code1;
//
// }
//


// VariableNode* var = findVarTab(Str->leftson->rightbrother->leftson->value.idval);
// if (var->varType->kind == structrue ) {
//     FieldList fl = var->varType->u.structure;
//     if (fl->tail == NULL) {
//         printf("structrue\n");
//     }
// }

InterCodes* translate_Str(struct syntax_tree* Str){
    VariableNode* var1 = findVarTab(Str->leftson->rightbrother->leftson->value.idval);
    printf("%s\n", var1->vName);
    if (var1->varType->kind == structrue ) {
        FieldList fl = var1->varType->u.structure;
        if (fl == NULL) {
            printf("structrue\n");
        } else {
            printf("ljllllllll\n");
            printf("%s\n", fl->name);
        }
    }
}

InterCodes* translate_Dow(struct syntax_tree* Dow){


    VariableNode* var = findVarTab(Dow->value.idval);

    printf("%s\n", var->varType->u.structure->name);


    FieldList vList = var->varType->u.structure;

    FieldList pre = vList;
    FieldList head = vList;

    InterCodes* code1 = NULL;
    while (vList) {

        if (vList == head) {
            char* t1 = newvar();
            Operand op1 = newop("VARIABLE", t1);
            Operand op2 = newop("VARIABLE", vList->name);
            code1 = newcode("ASSIGN", op1, op2, 0, 0);

        } else {
            int os = offset(pre, vList->name);

            Operand op1 = newop("VARIABLE", vList->name);
            Operand op2 = newop("VARIABLE", pre->name);
            Operand op3 = newop("VARIABLE" , "+");
            Operand op4 = newop_const(os);

            InterCodes* code2 = newcode("ADD", op1, op2, op3, op4);
            code1 = link(code1, code2);

            char* t2 = newvar();
            Operand op5 = newop("VARIABLE", t2);
            InterCodes* code3 = newcode("ASSIGN", op5, op1, 0, 0);

            code1 = link(code1, code3);

            pre = vList;
            vList = vList->tail;
        }

        // int os = offset(vList, vList->name);
        // Operand* op1 = newop("VARIABLE", vList->name);
        // Operand* op2 = newop_const(os);
        // InterCodes* code2 = newcode("ASSIGN", op1, op2, 0, 0);
        // code1 = link(code1, code2);
        // vList = vList->tail;


    }

    return code1;
}


void translate(struct syntax_tree* head)
{
    struct syntax_tree* child;
    int i;
    if(head == NULL)
        return ;
    if (head->name != NULL) {
        if (strcmp(head->name, "FunDec") == 0) {
            InterCodes* code = translate_FunDec(head);
            insertir(code);
        }

        if (strcmp(head->name, "Stmt") == 0) {
            InterCodes* code = translate_stmt(head);
            insertir(code);
            translate(head->rightbrother);
            return;
        }

        if (strcmp(head->name, "Dec") == 0) {
            InterCodes* code = translate_Dec(head);
            insertir(code);
        }

        // if (strcmp(head->name, "StructSpecifier") == 0) {
        //     InterCodes* code = translate_Str(head);
        //    insertir(code);
        // }

        if (head->leftson != NULL) {
            translate(head->leftson);
        }

        if (head->rightbrother != NULL) {
            translate(head->rightbrother);
        }
    }
}
