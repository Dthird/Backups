#ifndef GUARD_SEMANTIC_TRAVERSE
#define GUARD_SEMANTIC_TRAVERSE

extern void semantic_traverse();

#endif
