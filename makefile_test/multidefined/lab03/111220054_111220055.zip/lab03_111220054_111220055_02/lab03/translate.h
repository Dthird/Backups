#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "syntax_tree.h"
#include "symbol_table.h"
typedef struct Operand_* Operand;
struct Operand_ {
    enum {VARIABLE , CONSTANT ,OP,LABEL,FUNC} kind;
    union{
        int var_no;
        int value;
        char* var_name;
        char* op;
    }u;
};

struct InterCode{
    enum {ASSIGN , ADD , SUB , MUL,IFGOTO,CALL,ARG,DEC , iLABEL ,FUNCTION ,GOTO,RETURN,READ,WRITE , PARAM,ADDR,STAR,MINUS,_DEV, DOT}kind;
    union{
        struct {Operand op1,op2,op3,op4;}ops;
    }u;
};
typedef struct InterCodes{
    struct InterCode code;
    struct InterCodes *prev,*next;
}InterCodes;
/*
 *global irtree
 * */
struct InterCodes* irtree;//head
struct InterCodes* treetail;
void treeinit();
void insertir(struct InterCodes *inco);
void deleteir();

/*
 *printfunc
 * */
void printfunc();
void printoprand(Operand op);
InterCodes* link(InterCodes* i1 , InterCodes* i2);
