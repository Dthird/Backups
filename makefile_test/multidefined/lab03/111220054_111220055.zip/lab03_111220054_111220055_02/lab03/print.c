#include "translate.h"
#include <assert.h>
extern InterCodes* link(InterCodes* i1 , InterCodes* i2);
/*
 * printfunctions
 */
void printoprand(Operand op){
    if(op->kind == VARIABLE){
        printf("%s ",op->u.var_name);
    }
    else if(op->kind == CONSTANT){
        printf("#%d " , op->u.value);
    }
    else if(op->kind == FUNC){
        printf("%s " , op->u.var_name);
    }
    else if(op->kind == OP){
        char* a = op->u.op;
        a[2] = '\0';
        printf("%s " , op->u.op);
    }
    else if(op->kind == LABEL){
        printf("labe%s ",op->u.var_name);
    }
    else printf("op print wrong\n");
}

void printfunc(){
    struct InterCodes *ic = irtree;
    Operand buf[20];
    Operand top = buf;
    memset(buf , 0 , 20*4);
    do {
        if(ic->code.kind == ASSIGN){
            printoprand(ic->code.u.ops.op1);
            printf(":= ");
            printoprand(ic->code.u.ops.op2);
        }
        else if(ic->code.kind == ADD){
            printoprand(ic->code.u.ops.op1);
            printf(":= ");
            printoprand(ic->code.u.ops.op2);
            printf("+ ");
            printoprand(ic->code.u.ops.op4);
        }
        else if(ic->code.kind == SUB){
            printoprand(ic->code.u.ops.op1);
            printf(":= ");
            printoprand(ic->code.u.ops.op2);
            printf("- ");
            printoprand(ic->code.u.ops.op4);
        }
        else if(ic->code.kind == MUL){
            printoprand(ic->code.u.ops.op1);
            printf(":= ");
            printoprand(ic->code.u.ops.op2);
            printf("* ");
            printoprand(ic->code.u.ops.op4);
        }
        else if(ic->code.kind == _DEV){
            printoprand(ic->code.u.ops.op1);
            printf(":= ");
            printoprand(ic->code.u.ops.op2);
            printf("/ ");
            printoprand(ic->code.u.ops.op4);
        }
        else if(ic->code.kind == CALL){
            printoprand(ic->code.u.ops.op1);
            printf(":= ");
            printf("CALL ");
            printoprand(ic->code.u.ops.op2);
        }
        else if(ic->code.kind == IFGOTO){
            printf("IF ");
            printoprand(ic->code.u.ops.op1);
            printoprand(ic->code.u.ops.op2);
            printoprand(ic->code.u.ops.op3);
            printf("GOTO ");
            printoprand(ic->code.u.ops.op4);
        }
        else if(ic->code.kind == FUNCTION){
            printf("FUNCTION ");
            printoprand(ic->code.u.ops.op1);
            printf(" :");
        }
        else if(ic->code.kind == GOTO){
            printf("GOTO ");
            printoprand(ic->code.u.ops.op1);
        }
        else if(ic->code.kind == ARG){
            printf("ARG ");
            printoprand(ic->code.u.ops.op1);
        }
        else if(ic->code.kind == MINUS){
            printoprand(ic->code.u.ops.op3);
            printf(":= ");
            printoprand(ic->code.u.ops.op2);
            printf("- ");
            printoprand(ic->code.u.ops.op1);
        }
        else if(ic->code.kind == RETURN){
            printf("RETURN ");
            printoprand(ic->code.u.ops.op1);
        }
        else if(ic->code.kind == READ){
            printf("READ ");
            printoprand(ic->code.u.ops.op1);
        }
        else if(ic->code.kind == WRITE){
            printf("WRITE ");
            printoprand(ic->code.u.ops.op1);
        }
        else if(ic->code.kind == PARAM){
            printf("PARAM ");
            printoprand(ic->code.u.ops.op1);
        }
        else if(ic->code.kind == iLABEL){
            printf("LABEL ");
            printoprand(ic->code.u.ops.op1);
            printf(":");

        }
        else if(ic->code.kind == DOT){
            printf(" . ");
            printoprand(ic->code.u.ops.op1);
            printf(":=");
        }
        printf("\n");
        ic = ic->next;
    } while(ic != irtree);
}

/*
 *tree funcs
 * */
void treeinit(){
    irtree = NULL;
    treetail = irtree;
}
void insertir(struct InterCodes* inco){
    if(irtree == NULL){
        irtree = inco;
        return;
    }
    link(irtree,inco);
    assert(inco != NULL);
    assert(irtree!= NULL);
}
/*
void insertir(struct InterCodes *inco){
    if(irtree == NULL){
        irtree = inco;
        treetail = inco;
        irtree->next = irtree;
        irtree->prev = irtree;
    }
    else{*//*
        struct InterCodes *p = irtree->prev;
        irtree->prev->next = inco;
        if(inco == NULL){
            printf("1\n");
        }
        else if(inco->prev == NULL)
            printf("2\n");
        else if(inco->prev->next == NULL)
            printf("3\n");
        else printf("fuck\n");
        printf("\n");
        printf("1:%x\n" , inco->prev);
        printf("2:%x\n" , inco->prev->next);
        inco->prev->next = irtree;
        irtree->prev = inco->prev;
        inco->prev = p;*//*
        link(irtree,inco);
    }
}*/
InterCodes* link(InterCodes* i1 , InterCodes* i2){
    if(i1 == NULL){
        assert(i2 != NULL);
        return i2;
    }
    if(i2 == NULL)
        return i1;
    InterCodes *p = i2->prev;
    i1->prev->next = i2;
    i2->prev->next = i1;
    i2->prev = i1->prev;
    i1->prev = p;
    assert(i1 != NULL);
    assert(i2 != NULL);
    return i1;
}
