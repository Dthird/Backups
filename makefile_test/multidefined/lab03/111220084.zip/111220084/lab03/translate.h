typedef struct Operand_* Operand;
typedef struct InterCodes_ InterCodes;
typedef struct Arg_list_ Arg_list;

typedef struct InterCode_
{
	enum { ASSIGN, BINOP, IFOP, GOTO, LABELINC, RETURNINC, READ, WRITE, ARG, FUNCTION, PARAM, DEC} kind;
	union {
		struct { Operand right, left; } assign;
		struct { int kind; Operand result, op1, op2; } binop;
		struct { int kind; Operand op1, op2, op3; } relop;
		struct { int size; Operand op;}dec;
		Operand op;
	}u;
}InterCode;

struct InterCodes_{
	InterCode code;
	InterCodes *prev, *next;
};

struct Arg_list_{
	int kind;
	char name[20];
	Arg_list *next;
};

struct Operand_{
	enum {CONSTANT, VARIABLE, ADDRESS, SSTAR, CALL, ARGS, PARAMS} kind;
	union {
		Arg_list *args;
		char name[20];
		int value;
	}u;
};

InterCodes *InstructionList;
Arg_list *arg_list;
int VariableCount = 0; 
int TempCount = 0;
int LabelCount = 0;
int figure = 0; //decimal of exp 
int LineNo = 0; 
