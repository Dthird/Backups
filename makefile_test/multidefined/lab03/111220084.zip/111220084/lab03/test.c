int main()
{
int n;
n = 1;
}

