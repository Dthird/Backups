#include "type.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern struct Node* root;
extern void exp_tra(struct Node* t);


void tableInit(){
    tableHead = NULL;
    tableTail = tableHead;
    funcHead = NULL;
    funcTail = funcHead;
}
/*
int handle(struct Node *p , int depth){
    if(p == NULL) return;
    int i;
    struct Node *temp = p;
    if(!p->isToken){
        if(strcmp(p->type , "ExtDef") == 0){
            temp = p->firstChild;
            if(strcmp(temp->type , "Specifier") == 0){
               if(strcmp(temp->nextSibling.type , "ExtDefList") == 0){//@1


               }
            }
        }
        else if(strcmp(p->type . "Def") == 0){

        }
    }
}*/

/*
 * 针对变量表插入新的节点，在ExtDef和Def处使用
 *
 * */
void insertVarTable(char* name , Type type){


#ifndef debuf
                printf("insearting to var table\n");
#endif
    struct varNode* newnode = (struct varNode*)malloc(sizeof(struct varNode));
    char* p = (char*)malloc(strlen(name)+1);
    newnode->name = p;
    strcpy(newnode->name , name);
    newnode->next = NULL;
    newnode->type = type;
    if(tableHead == NULL){
        tableHead = newnode;
        tableTail = newnode;
    }
    else{
        tableTail->next = newnode;
        tableTail = newnode;
    }
}


/*
 *在变量表内搜索，若未搜索到则返回NULL
 * */


struct varNode* searchVarTable(char* name){
    struct varNode *p = tableHead;
    while(p!=NULL){
        if(strcmp(p->name , name) == 0){
            return p;//same name
        }
        p = p->next;
    }
    return NULL;
}

/*
 *函数表插入
 * */


void insertFuncTable(char* fname , Type returnType , varNode_* args){
#ifndef debuf
                printf("insearting to func table\n");

#endif
    struct funcNode* newnode = (struct funcNode*)malloc(sizeof(struct funcNode));
    if(newnode == NULL){
        printf("fuck!!!!!!!\n");
    }
#ifndef debuf
                printf("now ok insert\n");
#endif

    char* namebuf = (char*)malloc(strlen(fname)+1);
    memcpy(namebuf , fname , strlen(fname)+1);
    newnode->fname = namebuf;
    if(namebuf == NULL){
        printf("fucku !!!!!\n");
    }
#ifndef debuf
                printf("now ok insert2\n");
#endif


    newnode->args = args;
    strncpy(newnode->fname , fname , strlen(fname));
    newnode->fname[strlen(fname)] = '\0';
    newnode->returnType = returnType;



    if(funcHead == NULL){
        funcHead = newnode;
        funcTail = newnode;
    }
    else {
        funcTail->next = newnode;
        funcTail = newnode;
    }

#ifndef debuf
                printf("insearting ok\n");
#endif
}

/*
 *函数表搜索

 * */


struct funcNode* searchFuncTable(char* fName){
    struct funcNode* p = funcHead;
    while(p != NULL){
        if(strcmp(fName , p->fname) == 0){
            return p;
        }
        p = p->next;
    }
    return NULL;

}

/*
 *check type equal or not
 * */

int type_equal(Type t1, Type t2){
	if(t1 == 0 || t2 == 0)
		return 0;
	if(t1->kind != t2->kind)
		return 0;
	if(t1->kind == BASIC)
		return (t1->u.basic == t2->u.basic);
	else if(t1->kind == ARRAY){
		return (type_equal(t1->u.array.elem, t2->u.array.elem));
	}
    else if(t1->kind == STRUCTURE){
        if(t1->u.structure->tail!= NULL && t2->u.structure->tail != NULL){
            if(t1->u.structure->tail!= NULL || t2->u.structure->tail != NULL)
                return 0;
            return type_equal(t1->u.structure->type , t2->u.structure->type);

        }
    }
	return 0;
}

/*
 *arg_table
 *
 * */


/*
 *handle Exp
 *
 * */
void exp_tra(struct Node *t){
    if(t == NULL || strcmp(t->type , "Exp") != 0){
        return ;
    }


    //ID

    else if(strcmp(t->firstChild->type , "ID") == 0 && (t->firstChild->nextSibling!= NULL && strcmp(t->firstChild->nextSibling->type , "LP") != 0)){
#ifndef debug
        printf("handle:find ID\n");
#endif

        struct varNode* newnode = searchVarTable(t->firstChild->text);
        if(newnode == NULL){
            printf("Error type 1 at line %d: Undefined variable lalala\"%s\".\n" ,t->line, t->firstChild->text);
        }
        else t->exp_type = newnode->type;
    }

    //INT

    else if(strcmp(t->firstChild->type , "INT") == 0){
#ifndef debug
        printf("handle:find int \n");
#endif
        t->exp_type = (Type)malloc(sizeof(struct Type_));
        t->exp_type->kind = BASIC;
        t->exp_type->u.basic = 1;
    }
    //FLOAT

    else if(strcmp(t->firstChild->type , "FLOAT") == 0){
#ifndef debug
        printf("handle:find float\n");
#endif
        t->exp_type = (Type)malloc(sizeof(struct Type_));
        t->exp_type->kind = BASIC;
        t->exp_type->u.basic = 2;

    }



    //EXP ASSIGNOP EXP
    else if(strcmp(t->firstChild->type , "Exp") == 0 && strcmp(t->firstChild->nextSibling->type , "ASSIGNOP") == 0){
#ifndef debug
        printf("handle:find EXP ASSIGNOP EXP\n");
#endif
        exp_tra(t->firstChild);
        exp_tra(t->firstChild->nextSibling->nextSibling);
        printf("type !!!!%s\n",t->firstChild->type);
        if(strcmp(t->firstChild->type , "ID") !=0){
            if(t->firstChild->firstChild == NULL)
                printf("1Error type 6 at line %d: The left-hand side of an assignment must be a variable", t->line);
            else if(strcmp(t->firstChild->firstChild->type , "ID") != 0)
                printf("1Error type 6 at line %d: The left-hand side of an assignment must be a variable", t->line);
        }
        if(t->firstChild->exp_type != 0 && t->firstChild->nextSibling->nextSibling->exp_type != 0 && !type_equal(t->firstChild->exp_type , t->firstChild->nextSibling->nextSibling->exp_type))
            printf("Error type 5 at line %d: Assignop type mismatched.\n" , t->line);
        //左值？
        else if(strcmp(t->firstChild->nextSibling->type , "AND") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "OR") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "RELOP") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "PLUS") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "MINUS") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "STAR") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "DIV") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "INT") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "FLOAT") == 0
                ){
            printf("2Error type 6 at line %d: The left-hand side of an assignment must be a variable\n",t->line);
        }
    }

    //exp and|or|relop|plus|minus|star|div
    else if(strcmp(t->firstChild->type , "Exp") == 0 &&(
            strcmp(t->firstChild->nextSibling->type,"AND") == 0||
            strcmp(t->firstChild->nextSibling->type,"OR") == 0||
            strcmp(t->firstChild->nextSibling->type,"RELOP") == 0
            )
           ){

#ifndef debug
        printf("handle:find and or relop \n");
#endif

        if(!strcmp(t->firstChild->type , "INT") || !strcmp(t->firstChild->nextSibling->nextSibling->type , "INT")){
            printf("Error type 7 at line %d: Operands type mismatched\n",t->line);
        }

    }
    else if(
                strcmp(t->firstChild->nextSibling->type , "PLUS") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "MINUS") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "STAR") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "DIV") == 0

           ){

#ifndef debug
        printf("handle: find +- \n");
#endif
        if(type_equal(t->firstChild->exp_type , t->firstChild->nextSibling->nextSibling->exp_type) == 0){

            printf("Error type 7 at line %d: Operands type mismatched\n" , t->line);

        }
        if(!strcmp(t->firstChild->type , "INT") && !strcmp(t->firstChild->type , "FLOAT")|| !strcmp(t->firstChild->nextSibling->nextSibling->type , "INT") && !strcmp(t->firstChild->nextSibling->nextSibling->type , "FLOAT")){
            printf("Error type 7 at line %d: Operands type mismatched\n" , t->line);
        }

    }


    //LP EXP RP
    else if(strcmp(t->firstChild->type , "LP") == 0 && strcmp(t->firstChild->nextSibling->type , "Exp") == 0){

#ifndef debug
        printf("handle:find LP EXP RP \n");
#endif
        exp_tra(t->firstChild->nextSibling);
        t->exp_type = t->firstChild->nextSibling->exp_type;
    }

    //MINUS EXP

    else if(strcmp(t->firstChild->type , "MINUX") == 0 && strcmp(t->firstChild->nextSibling->type , "Exp") == 0 ){

#ifndef debug
        printf("handle:find  MINUS\n");
#endif

        exp_tra(t->firstChild->nextSibling);
        if(t->firstChild->nextSibling->exp_type->kind != BASIC){
            printf("Error type 7 at line %d: Operand type mismatched.\b ", t->line);
        }
        else t->exp_type = t->firstChild->nextSibling->exp_type;
    }

    //NOT EXP


    else if(strcmp(t->firstChild->type , "NOT") == 0 && strcmp(t->firstChild->nextSibling->type , "Exp") == 0 ){


#ifndef debug
        printf("handle:find NOT \n");
#endif

        exp_tra(t->firstChild->nextSibling);
        if(t->firstChild->nextSibling->exp_type->kind != BASIC){
            printf("Error type 7 at line %d: Operand type mismatched.\b ", t->line);
        }
        else t->exp_type = t->firstChild->nextSibling->exp_type;
    }


    //ID LP ARGS RP  or ID LP RP
    else if(strcmp(t->firstChild->type , "ID") == 0 && strcmp(t->firstChild->nextSibling->type , "LP") == 0){


#ifndef debug
        printf("handle:find LD LP ARGS RP OR ID LP RP \n");
#endif

        struct funcNode *func = searchFuncTable(t->firstChild->text);
        if(func == NULL){
            if(searchVarTable(t->firstChild->text) == 0)
                printf("Error type 2 at line %d: Function undefined.\n" , t->line);
            else printf("Error type 11 at line %d: Apply () to normal Variable.\n" , t->line);
        }
        else {
            struct varNode *args = func->args;
            if(args == NULL && strcmp(t->firstChild->nextSibling->nextSibling->type , "RP") == 0){
                printf("Error type 9 at line %d: Function args mismatched.\n" , t->line);
            }
            else {
                struct Node *targs = t->firstChild->nextSibling->nextSibling;
                while(targs !=NULL && args != NULL){
                    exp_tra(targs);
                    if(!type_equal(args->type , targs->exp_type)){
                        printf("Error type 9 at line %d: Function args mismatched.\n" , t->line);
                        break;

                    }
                    args = args->next;
                    if((targs->nextSibling == NULL && args!=NULL)|| (targs->nextSibling !=NULL && args == NULL)){
                        printf("Error type 9 at line %d: Function args mismatched.\n" , t->line);
                        break;
                    }
                    targs = targs->nextSibling->nextSibling->firstChild;

                }



            }

        }
        if(t->exp_type != NULL && func->returnType != NULL)
            t->exp_type = func->returnType;

    }

    //ID LP RP
    //
    /*
    else if(strcmp(t->firstChild->type , "ID") == 0 && strcmp(t->firstChild->nextSibling->type , "Exp") == 0){

    }*/

    //EXP LB EXP RB

    else if(strcmp(t->firstChild->type , "Exp") == 0 && strcmp(t->firstChild->nextSibling->type , "LB") == 0 && strcmp(t->firstChild->nextSibling->nextSibling->type , "Exp") == 0){
#ifndef debuf
        printf("{EXP LB EXP RB}\n");
#endif
        /*exp_tra(t->firstChild);
        exp_tra(t->firstChild->nextSibling->nextSibling);*/

        struct Node* p = t->firstChild;
        for(; p!= NULL && strcmp(p->firstChild->type , "ID") != 0 ; p = p->firstChild);//找名字
        if(searchVarTable(p->firstChild->text) == 0){
            printf("Error type 1 at line %d: Variable undefined.\n" ,t->line);
        }
        if(strcmp(t->firstChild->nextSibling->nextSibling->type , "INT") != 0){
        printf("Error type 12 at line %d: Exp in [] is not integer.\n" , t->line);
        }
        if(t->firstChild->exp_type != NULL && t->firstChild->exp_type->kind != ARRAY){
            printf("%s\n", t->firstChild->text);
            printf("Error type 10 at line %d: \"%s\" must be an array.\n",t->line, t->firstChild->text);
        }

        else if(t->firstChild->exp_type != NULL){
            t->exp_type = t->firstChild->exp_type->u.array.elem;
        }


    }

    //Exp DOT ID

    else if(strcmp(t->firstChild->type , "Exp") == 0 && strcmp(t->firstChild->nextSibling->type , "DOT") == 0 && strcmp(t->firstChild->nextSibling->nextSibling->type , "ID") == 0){

#ifndef debug
        printf("handle: find EXP DOT ID\n");
#endif


        if(strcmp(t->firstChild->firstChild->type , "STRUCT")!=0){
            printf("Error type 13 at line %d: Illigal use of \" .\"\n",t->line);
        }
        else {
            struct varNode *newnode = searchVarTable(t->firstChild->firstChild->nextSibling->type);//find id
            if(newnode != NULL && newnode ->type->kind != STRUCTURE){
                printf("Error type 13 at line %d: Illigal use of \".\"\n" , t->line);

            }


        }
        if(t->firstChild->nextSibling->nextSibling->exp_type != NULL){//?
            t->exp_type = t->firstChild->nextSibling->nextSibling->exp_type;
        }
    }

/*
    //ID

    else if(strcmp(t->firstChild->type , "ID") == 0){
        varNode* newnode = searchVarTable(t->firstChild->text);
        if(newnode == NULL){
            printf("Error type 1 at line %d: Variable undefined.\n" ,t->line);
        }
        else t->exp_type = newnode->type;
    }

    //INT

    else if(strcmp(t->firstChild->type , "INT") == 0){
        t->exp_type = (Type)malloc(sizeof(Type_));
        t->exp_type->kind = basic;
        t->exp_type->u.basic = 1;
    }
    //FLOAT

    else if(strcmp(t->firstChild->type , "FLOAT") == 0){
        t->exp_type = (Type)malloc(sizeof(Type_));
        t->exp_type->kind = basic;
        t->exp_type->u.basic = 2;

    }

*/


}

void tra(struct Node* t)
{
    if (t == NULL) {
        printf("T is NULL...\n");
        return;
    }

#ifndef debug
    printf("hahahhah\n");

    if(t->firstChild!= NULL)
    printf("leftchild : %s\n" , t->firstChild->type);
    if(t != NULL)printf("t : %s\n" , t->type);
    printf("compire:%d\n" , strcmp(t->type , "ExtDef"));
#endif

    if (strcmp(t->type, "ExtDef") == 0) { //Extdef
        printf("ExtDef\n");
        if (strcmp(t->firstChild->nextSibling->type, "ExtDecList") == 0) { //Extdef -> Specifier ExtDecList SEMI

            struct Node* ext_dec_list = t->firstChild->nextSibling;

            Type newtype = 0;
            if (strcmp(t->firstChild->firstChild->type, "TYPE") == 0) { //basic type
#ifndef debuf
                printf("basic type here\n");
#endif
                struct Node* isType = t->firstChild->firstChild;
                newtype = (Type)malloc(sizeof(struct Type_));
                newtype->kind = BASIC;
                newtype->u.basic = isType->value.intval;
            } else if (strcmp(t->firstChild->firstChild->type, "StructSpecifier") == 0) {
                tra(t->firstChild->firstChild);
            }

            struct Node* p;
            p = ext_dec_list->firstChild;

            while (p != 0) {
                if (strcmp(p->firstChild->type, "ID")) { //VarDec -> ID
                    if (searchVarTable(p->firstChild->text) == NULL) {
                        insertVarTable(p->firstChild->text, newtype);
                    } else {
                        printf("Error type 3 at line %d: Redefined variable \"%s\".\n", p->line, p->firstChild->text);
                    }
                } else if (strcmp(p->firstChild->type, "VarDec") == 0) { //VarDec -> VarDec LB INT RB
                    struct Node* q;
                    q = p->firstChild;
                    for ( ; strcmp(q->type, "ID") != 0; q = q->firstChild);

                    if (searchVarTable(q->text) == NULL) {
                        q = p->firstChild;

                        while (strcmp(q->type, "VarDec") == 0) {
                            Type newtype2 = (Type)malloc(sizeof(struct Type_));
                            newtype2->kind = ARRAY;
                            newtype2->u.array.elem = newtype;
                            newtype2->u.array.size = q->nextSibling->nextSibling->value.intval;
                            newtype = newtype2;
                            q = q->firstChild;
                        }

                        insertVarTable(q->text, newtype);

                    } else {
                        printf("Error type 3 at line %d: Redefined variable\"%s\".\n", p->line, q->text);
                    }
                }

                if (p->nextSibling == 0) {
                    p = 0;
                } else {
                    p = p->nextSibling->nextSibling->firstChild;
                }
            }
        }


        if (strcmp(t->firstChild->nextSibling->type, "FunDec") == 0) { //ExtDef -> Specifier FunDec CompSt
#ifndef debug
            printf("FunDec\n");
#endif
            struct Node* specifier = t->firstChild;
            struct Node* fundec = specifier->nextSibling;
            Type returnType = 0;
            struct varNode* argList = 0;
            char* fName = fundec->firstChild->text;

#ifndef debuf
                printf("now ok 1\n");
                printf("fName : %s and %s\n" ,fName,fundec->firstChild->text);
#endif
            if (searchFuncTable(fName) != NULL) {
                printf("Error type 4 at line %d: Functix_on redefined.\n", t->line);
                fName = "_DEFAUL_FUNC_NAME";
            }

            if (strcmp(specifier->firstChild->type, "TYPE") == 0) {
                returnType = (Type)malloc(sizeof(struct Type_));
                returnType->kind = BASIC;
                returnType->u.basic = specifier->firstChild->value.intval;
            }
            else if (strcmp(specifier->firstChild->type, "StructSpecifier") == 0) {
                tra(specifier->firstChild);
            }
#ifndef debuf
                printf("now ok 2\n");
#endif

            if (strcmp(fundec->firstChild->nextSibling->nextSibling->type, "VarList") == 0) { //Func -> ID LP VarList RP
                struct Node* paramDec = fundec->firstChild->nextSibling->nextSibling->firstChild;

                while (paramDec != 0) {
                    Type varType = 0;
                    char* varName;
                    struct Node* varDec = paramDec->firstChild->nextSibling->firstChild;  //may be a VarDec or an ID
#ifndef debuf
                printf("now ok 3\n");
#endif
                    if(strcmp(paramDec->firstChild->firstChild->type, "TYPE") == 0){
                        varType = (Type)malloc(sizeof(struct Type_));
                        varType->kind = BASIC;
                        varType->u.basic = paramDec->firstChild->firstChild->value.intval;
                    }

                    // the same?
                    for ( ; strcmp(varDec->type, "VarDec") == 0; varDec = varDec->firstChild) {
                        Type newType = (Type)malloc(sizeof(struct Type_));
                        newType->kind = ARRAY;
                        newType->u.array.elem = varType;
                        newType->u.array.size = varDec->nextSibling->nextSibling->value.intval;
                        varType = newType;
                    }

                    varName = varDec->text;

                    if (searchVarTable(varName) == NULL) {
                        insertVarTable(varName, varType);
                    } else {
                        printf("Error type 3 at line %d: Redefined variable \"%s\" .\n", t->line, varName);
                    }

                    struct varNode* newArg = (struct varNode*)malloc(sizeof(struct varNode));
                    newArg->name = (char *)malloc(strlen(varName) + 1);
                    strcpy(newArg->name, varName);
                    newArg->type = varType;
                    newArg->next = 0;

                    if (argList == 0) {
                        argList = newArg;
                    } else {
                        struct varNode *p = argList;
                        for ( ; p->next != 0; p = p->next);
                        p->next = newArg;
                    }

                    if (paramDec->nextSibling == 0) {
                        paramDec = 0;
                    } else {
                        paramDec = paramDec->nextSibling->nextSibling->firstChild;
                    }
                }
            }

            insertFuncTable(fName, returnType, argList);
        }
    }


    // if (strcmp(t->type, "CompSt")) { //CompSt
    //     if (strcmp(t->firstChild->nextSibling->type, "DefList") == 0) {
    //                 printf("dddddddddddddddddddddddd\n");
    //         struct Node* defList = t->firstChild->nextSibling;

    //         while (defList != NULL) {
    //             struct Node* def = defList->firstChild;
    //             Type newtype = 0;
    //             if (strcmp(def->firstChild->firstChild->type, "TYPE") == 0) {
    //                 struct Node* isType = def->firstChild->firstChild;
    //                 newtype = (Type)malloc(sizeof(struct Type_));
    //                 newtype->kind = BASIC;
    //                 newtype->u.basic = isType->value.intval;
    //                 struct Node* p;
    //                 p = def->firstChild->nextSibling->firstChild; //p is Dec;

    //                 while(p != 0){
    //                     struct Node* var_dec = p->firstChild;
    //                     for ( ; strcmp(var_dec->type, "ID") != 0; var_dec = var_dec->firstChild);
    //                     if(searchVarTable(var_dec->text) == NULL){

    //                         var_dec = p->firstChild->firstChild;
    //                         while(strcmp(var_dec->type, "VarDec") == 0){

    //                             Type newtype2 = (Type)malloc(sizeof(struct Type_));
    //                             newtype2->kind = ARRAY;
    //                             newtype2->u.array.elem = newtype;
    //                             newtype2->u.array.size = var_dec->nextSibling->nextSibling->value.intval;
    //                             newtype = newtype2;
    //                             var_dec = var_dec->firstChild;
    //                         }

    //                         insertVarTable(var_dec->text, newtype);

    //                     } else {
    //                         printf("Error type 3 at line %d: Redefined variable lalal\"%s\".\n", p->line, var_dec->text);
    //                     }

    //                     // Todo
    //                     if (p->firstChild->nextSibling != 0){  //Dec => VarDec ASSIGNOP Exp/a.........................................
    //                         exp_tra(p->firstChild->nextSibling->nextSibling);
    //                         if(p->firstChild->nextSibling->nextSibling->firstChild->exp_type != 0 && !type_equal(newtype, p->firstChild->nextSibling->nextSibling->exp_type)){
    //                             printf("oh!Error type 5 at line %d: Type mismatched laf.\n", p->line);
    //                         }
    //                     }


    //                     if (p->nextSibling == 0) {
    //                         p = 0;
    //                     }
    //                     else {
    //                         p = p->nextSibling->nextSibling->firstChild;
    //                     }
    //                 }
    //             }

    //             // Struct ......
    //             else if(strcmp(t->firstChild->firstChild->nextSibling->type, "StructSpecifier") == 0) {
    //                 struct Node* isStruct = t->firstChild->firstChild->nextSibling;
    //                 // newtype = (Type)malloc(sizeof(struct Type_));
    //                 // newtype->kind = STRUCTURE;
    //                 tra(isStruct);
    //             }

    //             if (defList->firstChild->nextSibling == NULL) {
    //                 defList = NULL;
    //             } else {
    //                 defList = defList->firstChild->nextSibling;
    //             }

    //         }



    //     }
    //     if(strcmp(t->firstChild->nextSibling->nextSibling->type, "StmtList")) {
    //         printf("stmtlisttttttttttttttt\n");
    //         struct Node* stmtlist = t->firstChild->nextSibling->nextSibling;

    //         while (stmtlist != NULL) {

    //             if (strcmp(stmtlist->firstChild->type, "Stmt")) {
    //                 tra(stmtlist->firstChild);
    //             }

    //             if (stmtlist->firstChild->nextSibling == NULL) {
    //                 stmtlist = NULL;
    //             } else {
    //                 stmtlist = stmtlist->firstChild->nextSibling;
    //             }
    //         }

    //     }
    // }

    if(strcmp(t->type, "Def") == 0){ //Def;
#ifndef debug
        printf("def:\n");
#endif
        Type newtype = 0;
        if (strcmp(t->firstChild->firstChild->type, "TYPE") == 0) {
            struct Node* isType = t->firstChild->firstChild;
            newtype = (Type)malloc(sizeof(struct Type_));
            newtype->kind = BASIC;
            newtype->u.basic = isType->value.intval;
            struct Node* p;
            p = t->firstChild->nextSibling->firstChild; //p is Dec;

            while(p != 0){
                struct Node* var_dec = p->firstChild;
                for ( ; strcmp(var_dec->type, "ID") != 0; var_dec = var_dec->firstChild);
                if(searchVarTable(var_dec->text) == NULL){

                    var_dec = p->firstChild->firstChild;
                    while(strcmp(var_dec->type, "VarDec") == 0){

                        Type newtype2 = (Type)malloc(sizeof(struct Type_));
                        newtype2->kind = ARRAY;
                        newtype2->u.array.elem = newtype;
                        newtype2->u.array.size = var_dec->nextSibling->nextSibling->value.intval;
                        newtype = newtype2;
                        var_dec = var_dec->firstChild;
                    }

                    insertVarTable(var_dec->text, newtype);

                } else {
                    printf("Error type 3 at line %d: Redefined variable lalal\"%s\".\n", p->line, var_dec->text);
                }

                // Todo
                if (p->firstChild->nextSibling != 0){  //Dec => VarDec ASSIGNOP Exp/a.........................................
                    exp_tra(p->firstChild->nextSibling->nextSibling);
                    if(p->firstChild->nextSibling->nextSibling->firstChild->exp_type != 0 && !type_equal(newtype, p->firstChild->nextSibling->nextSibling->exp_type)){
                        printf("oh!Error type 5 at line %d: Type mismatched laf.\n", p->line);
                    }
                }


                if (p->nextSibling == 0) {
                    p = 0;
                }
                else {
                    p = p->nextSibling->nextSibling->firstChild;
                }
            }
        }

        // Struct ......
        else if(strcmp(t->firstChild->firstChild->nextSibling->type, "StructSpecifier") == 0) {
            struct Node* isStruct = t->firstChild->firstChild->nextSibling;
            // newtype = (Type)malloc(sizeof(struct Type_));
            // newtype->kind = STRUCTURE;
            tra(isStruct);
        }

    }

    if(strcmp(t->type, "Stmt") == 0){ // Stmt
        struct Node* tmp = t->firstChild;
        for ( ;tmp != 0; tmp = tmp->nextSibling){
            exp_tra(tmp);
        }

        if (strcmp(t->firstChild->type, "RETURN") == 0){ //Stmt -> RETURN Exp SEMI
            if(t->firstChild->nextSibling->exp_type != 0 && type_equal(funcTail->returnType, t->firstChild->nextSibling->exp_type)){
                printf("Error type 8 at line %d: Return type mismatched.\n", t->line);
            }
        }
    }


    if (strcmp(t->type, "StructSpecifier") == 0) { //StructSpecifier;

        // tra(t->nextSibling);
        // return;
        // newtype = (Type)malloc(sizeof(struct Type_));
        // newtype->kind = STRUCTURE;

        Type newtype = 0;
        newtype = (Type)malloc(sizeof(struct Type_));

        if (strcmp(t->firstChild->nextSibling->type, "OptTag") == 0) {

            newtype->kind = STRUCTURE;
            newtype->u.structure = (FieldList)malloc(sizeof(struct FieldList_));

            struct Node* optTag = t->firstChild->nextSibling;

            if (strcmp(optTag->firstChild->type, "ID") == 0) {
                if (searchVarTable(optTag->firstChild->text) == NULL) {
                    newtype->u.structure->name = optTag->firstChild->text;
                    newtype->u.structure->type = NULL;
                    newtype->u.structure->tail = NULL;

                    insertVarTable(optTag->firstChild->text, newtype);
                } else {
                    printf("Error Type 16 at line %d: Duplicated name \"%s\" .\n", optTag->line, optTag->firstChild->text);
                }
            }


            struct Node* defList = optTag->nextSibling->nextSibling;
            while (defList != NULL) {
                struct Node* def = defList->firstChild;
                Type type_temp = (Type)malloc(sizeof(struct Type_));

                if (strcmp(def->firstChild->firstChild->type, "TYPE") == 0) {

                    printf("in TYPE\n");
                    struct Node* isType = def->firstChild->firstChild;
                    type_temp->kind = BASIC;
                    type_temp->u.basic = isType->value.intval;


                    struct Node* DecList = def->firstChild->nextSibling;
                        printf("doing here~~\n");

                    do {

                        struct Node* vardec = DecList->firstChild->firstChild;
                        FieldList newField = (FieldList)malloc(sizeof(struct FieldList_));
                        newField->type = (Type)malloc(sizeof(struct Type_));

                        if( strcmp(vardec->firstChild->type, "ID" ) != 0 ){
                            printf("maybe an ARRAY\n");

                            struct Node* temp = vardec->firstChild;
                            for ( ; strcmp(temp->type, "ID") != 0; temp = temp->firstChild);

                            if (searchVarTable(temp->text) == NULL) {
                                Type elemType = (Type)malloc(sizeof( struct Type_ ));

                                elemType->kind = type_temp->kind;
                                if (type_temp->kind == BASIC) {
                                    elemType->u.basic = type_temp->u.basic;
                                }

                                Type arrayType;
                                temp = vardec->firstChild;

                                while( strcmp(temp->type, "ID") != 0 ){
                                    arrayType = (Type)malloc(sizeof( struct Type_ ));
                                    arrayType->kind = ARRAY;
                                    arrayType->u.array.elem = elemType;
                                    arrayType->u.array.size = temp->nextSibling->nextSibling->value.intval;
                                    elemType = arrayType;
                                    temp = temp->firstChild;
                                }
                                newField->type = arrayType;
                                newField->tail = NULL;

                                insertVarTable(temp->text, newField->type);
                            } else {
                                printf("Error type 15 at line %d: Redefined field \"%s\" .\n", vardec->firstChild->line, temp->text);
                            }


                        } else {
                            printf("!!\n");
                            if (searchVarTable(vardec->firstChild->text) == NULL) {
                                newField->tail = NULL;
                                newField->type->kind = type_temp->kind;
                                if (type_temp->kind == BASIC) {
                                    newField->type->u.basic = type_temp->u.basic;
                                }
                                insertVarTable(vardec->firstChild->text, newField->type);
                            } else {
                                printf("Error type 15 at line %d: Redefined field \"%s\".\n", vardec->firstChild->line, vardec->firstChild->text);
                            }
                        }

                        FieldList fl = newtype->u.structure;
                        while (fl->tail != NULL) {
                            fl = fl->tail;
                        }

                        fl->tail = newField;

                        if( DecList->firstChild->nextSibling == NULL) {
                            DecList = NULL;
                        } else {
                            DecList = DecList->firstChild->nextSibling->nextSibling;
                        }

                    } while (DecList != NULL);


                } else if (strcmp(def->firstChild->firstChild->type, "StructSpecifier") == 0) {

                    printf("lalllllllllllllllllllllllllllllllllllllllllll\n");

                    FieldList newField = (FieldList)malloc(sizeof(struct FieldList_));
                    newField->type = (Type)malloc(sizeof(struct Type_));

                    newField->type->kind = STRUCTURE;

                    tra(def->firstChild->firstChild);

                    FieldList fl = newtype->u.structure;
                    while (fl->tail != NULL) {
                        fl = fl->tail;
                    }
                    fl->tail = newField;
                }



                if (defList->firstChild->nextSibling == NULL) {
                    defList = NULL;
                } else {
                    defList = defList->firstChild->nextSibling;
                }
            }


        }

        if (strcmp(t->firstChild->nextSibling->type, "Tag") == 0) {
            newtype->kind = STRUCTURE;
            newtype->u.structure = (FieldList)malloc(sizeof(struct FieldList_));

            struct Node* Tag = t->firstChild->nextSibling;
            if (strcmp(Tag->firstChild->type, "ID")) {
                if (searchVarTable(Tag->firstChild->text) == NULL) {
                    insertVarTable(Tag->firstChild->text, newtype);
                } else {
                    printf("Error type 3 at line %d: Redefined variable \"%s\".\n", Tag->line, Tag->firstChild->text);
                }
            }

        }
    }

    if (t->firstChild != NULL) {
        tra(t->firstChild);
    }
    if (t->nextSibling != NULL) {
        tra(t->nextSibling);
    }
}


void senmantic_tra(struct Node* r)
{
    tableInit();
    tra(r);
}

// void exp_tra(struct Node* t)
// {
//     return 0;
// }
//
//
//
//
//
