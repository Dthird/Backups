#include "type.h"

void tableInit(){
    tableHead = NULL;
    tableTail = tableHead;
    funcHead = NULL;
    funcTail = funcHead;
}
/*
int handle(struct Node *p , int depth){
    if(p == NULL) return;
    int i;
    struct Node *temp = p;
    if(!p->isToken){
        if(strcmp(p->type , "ExtDef") == 0){
            temp = p->firstChild;
            if(strcmp(temp->type , "Specifier") == 0){
               if(strcmp(temp->nextSibling.type , "ExtDefList") == 0){//@1


               }
            }
        }
        else if(strcmp(p->type . "Def") == 0){

        }
    }
}*/

/*
 * 针对变量表插入新的节点，在ExtDef和Def处使用
 *
 * */
void insertVarTable(char* name , Type type){
    struct varNode* newnode = (struct varNode*)malloc(sizeof(struct varNode));
    char* p = (char*)malloc(strlen(name)+1);
    newnode->name = p;
    strcpy(newnode->name , name);
    newnode->next = NULL;
    newnode->type = type;
    if(tableHead == NULL){
        tableHead = newnode;
        tableTail = newnode;
    }
    else{
        tableTail->next = newnode;
        tableTail = newnode;
    }
}


/*
 *在变量表内搜索，若未搜索到则返回NULL
 * */


struct varNode* searchVarTable(char* name){
    struct varNode *p = tableHead;
    while(p!=NULL){
        if(strcmp(p->name , name) == 0){
            return p;//same name
        }
        p = p->next;
    }
    return NULL;
}

/*
 *函数表插入
 * */


void insertFuncTable(char* fname , Type returnType , varNode_* args){
    struct funcNode* newnode = (struct funcNode*)malloc(sizeof(struct funcNode));
    char* namebuf = (char*)malloc(strlen(fname)+1);
    newnode->fname = namebuf;
    newnode->args = args;
    strcpy(newnode->fname , fname);
    newnode->returnType = returnType;
    if(funcHead == NULL){
        funcHead = newnode;
        funcTail = newnode;
    }
    else {
        funcTail->next = newnode;
        funcTail = newnode;
    }
}

/*
 *函数表搜索

 * */


struct funcNode* searchFuncTable(char* fName){
    struct funcNode* p = funcHead;
    while(p != NULL){
        if(strcmp(fName , p->fname) == 0){
            return p;
        }
        p = p->next;
    }
    return NULL;

}

/*
 *check type equal or not
 * */

int type_equal(Type t1, Type t2){
	if(t1 == 0 || t2 == 0)
		return 0;
	if(t1->kind != t2->kind)
		return 0;
	if(t1->kind == BASIC)
		return (t1->u.basic == t2->u.basic);
	else if(t1->kind == ARRAY){
		return (type_equal(t1->u.array.elem, t2->u.array.elem));
	}
    else if(t1->kind == STRUCTURE){
        if(t1->u.structure->tail!= NULL && t2->u.structure->tail != NULL){
            if(t1->u.structure->tail!= NULL || t2->u.structure->tail != NULL)
                return 0;
            return type_equal(t1->u.structure->type , t2->u.structure->type);

        }
    }
	return 0;
}

/*
 *arg_table
 *
 * */


/*
 *handle Exp
 *
 * */
void exp_tra(struct Node *t){
    if(t == NULL || strcmp(t->type , "Exp") != 0){
        return ;
    }


    //ID

    else if(strcmp(t->firstChild->type , "ID") == 0){
        struct varNode* newnode = searchVarTable(t->firstChild->value.idval);
        if(newnode == NULL){
            printf("Error type 1 at line %d: Variable undefined.\n" ,t->line);
        }
        else t->exp_type = newnode->type;
    }

    //INT

    else if(strcmp(t->firstChild->type , "INT") == 0){
        t->exp_type = (Type)malloc(sizeof(struct Type_));
        t->exp_type->kind = BASIC;
        t->exp_type->u.basic = 1;
    }
    //FLOAT

    else if(strcmp(t->firstChild->type , "FLOAT") == 0){
        t->exp_type = (Type)malloc(sizeof(struct Type_));
        t->exp_type->kind = BASIC;
        t->exp_type->u.basic = 2;

    }



    //EXP ASSIGNOP EXP
    else if(strcmp(t->firstChild->type , "Exp") == 0 && strcmp(t->firstChild->nextSibling->type , "ASSIGNOP") == 0){
        exp_tra(t->firstChild);
        exp_tra(t->firstChild->nextSibling->nextSibling);

        if(t->firstChild->exp_type != 0 && t->firstChild->nextSibling->nextSibling->exp_type != 0 && !type_equal(t->firstChild->exp_type , t->firstChild->nextSibling->nextSibling->exp_type))
            printf("Error type 5 at line %d: Assignop type mismatched.\n" , t->line);
        //左值？
        else if(strcmp(t->firstChild->nextSibling->type , "AND") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "OR") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "RELOP") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "PLUS") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "MINUS") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "STAR") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "DIV") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "INT") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "FLOAT") == 0
                ){
            printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n",t->line);
        }
    }

    //exp and|or|relop|plus|minus|star|div
    else if(strcmp(t->firstChild->type , "Exp") == 0 &&(
            strcmp(t->firstChild->nextSibling->type,"AND") == 0||
            strcmp(t->firstChild->nextSibling->type,"OR") == 0||
            strcmp(t->firstChild->nextSibling->type,"RELOP") == 0
            )
            ){
        if(!strcmp(t->firstChild->type , "INT") || !strcmp(t->firstChild->nextSibling->nextSibling->type , "INT")){
            printf("Error type 7 at line %d: Operands type mismatched\n",t->line);
        }

    }
    else if(
                strcmp(t->firstChild->nextSibling->type , "PLUS") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "MINUS") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "STAR") == 0 ||
                strcmp(t->firstChild->nextSibling->type , "DIV") == 0

           ){

        if(!strcmp(t->firstChild->type , "INT") || !strcmp(t->firstChild->nextSibling->nextSibling->type , "INT")){
            printf("Error type 7 at line %d: Operands type mismatched\n" , t->line);
        }

    }


    //LP EXP RP
    else if(strcmp(t->firstChild->type , "LP") == 0 && strcmp(t->firstChild->nextSibling->type , "Exp") == 0){

        exp_tra(t->firstChild->nextSibling);
        t->exp_type = t->firstChild->nextSibling->exp_type;
    }

    //MINUS EXP
    else if(strcmp(t->firstChild->type , "MINUX") == 0 && strcmp(t->firstChild->nextSibling->type , "Exp") == 0 ){
        exp_tra(t->firstChild->nextSibling);
        if(t->firstChild->nextSibling->exp_type->kind != BASIC){
            printf("Error type 7 at line %d: Operand type mismatched.\b ", t->line);
        }
        else t->exp_type = t->firstChild->nextSibling->exp_type;
    }

    //NOT EXP
    else if(strcmp(t->firstChild->type , "MINUS") == 0 && strcmp(t->firstChild->nextSibling->type , "Exp") == 0 ){
        exp_tra(t->firstChild->nextSibling);
        if(t->firstChild->nextSibling->exp_type->kind != BASIC){
            printf("Error type 7 at line %d: Operand type mismatched.\b ", t->line);
        }
        else t->exp_type = t->firstChild->nextSibling->exp_type;
    }


    //ID LP ARGS RP  or ID LP RP
    else if(strcmp(t->firstChild->type , "ID") == 0 && strcmp(t->firstChild->nextSibling->type , "LP") == 0){
        struct funcNode *func = searchFuncTable(t->firstChild->value.idval);
        if(func == NULL){
            if(searchVarTable(t->firstChild->value.idval) == 0)
                printf("Error type 2 at line %d: Function undefined.\n" , t->line);
            else printf("Error type 11 at line %d: Apply () to normal Variable.\n" , t->line);
        }
        else {
            struct varNode *args = func->args;
            if(args == NULL && strcmp(t->firstChild->nextSibling->nextSibling->type , "RP") == 0){
                printf("Error type 9 at line %d: Function args mismatched.\n" , t->line);
            }
            else {
                struct Node *targs = t->firstChild->nextSibling->nextSibling;
                while(targs !=NULL && args != NULL){
                    exp_tra(targs);
                    if(!type_equal(args->type , targs->exp_type)){
                        printf("Error type 9 at line %d: Function args mismatched.\n" , t->line);
                        break;

                    }
                    args = args->next;
                    if((targs->nextSibling == NULL && args!=NULL)|| (targs->nextSibling !=NULL && args == NULL)){
                        printf("Error type 9 at line %d: Function args mismatched.\n" , t->line);
                        break;
                    }
                    targs = targs->nextSibling->nextSibling->firstChild;

                }



            }

        }

        t->exp_type = func->returnType;

    }

    //ID LP RP
    //
    /*
    else if(strcmp(t->firstChild->type , "ID") == 0 && strcmp(t->firstChild->nextSibling->type , "Exp") == 0){

    }*/

    //EXP LB EXP RB

    else if(strcmp(t->firstChild->type , "Exp") == 0 && strcmp(t->firstChild->nextSibling->type , "LB") == 0 && strcmp(t->firstChild->nextSibling->nextSibling->type , "Exp") == 0){
#ifndef debuf
        printf("{EXP LB EXP RB}\n");
#endif
        exp_tra(t->firstChild);
        exp_tra(t->firstChild->nextSibling->nextSibling);
        struct Node* p = t->firstChild;
        for(; p!= NULL && strcmp(p->firstChild->type , "ID") != 0 ; p = p->firstChild);//找名字
        if(searchVarTable(p->firstChild->value.idval) == 0){
            printf("Error type 1 at line %d: Variable undefined.\n" ,t->line);
        }
        if(t->firstChild->nextSibling->nextSibling->exp_type!=0 &&(t->firstChild->nextSibling->nextSibling->exp_type->kind != BASIC || t->firstChild->nextSibling->nextSibling->exp_type->u.basic !=1)){
        printf("Error type 12 at line %d: Exp in [] is not integer.\n" , t->line);
        }
        if(t->firstChild->exp_type != NULL && t->firstChild->exp_type->kind != ARRAY){
            printf("Error type 10 at line %d: [] can't be applied to variable which is not an array.\n",t->line);
        }

        else if(t->firstChild->exp_type != NULL){
            t->exp_type = t->firstChild->exp_type->u.array.elem;
        }


    }

    //Exp DOT ID

    else if(strcmp(t->firstChild->type , "Exp") == 0 && strcmp(t->firstChild->nextSibling->type , "DOT") == 0 && strcmp(t->firstChild->nextSibling->nextSibling->type , "ID") == 0){
        if(strcmp(t->firstChild->firstChild->type , "STRUCT")!=0){
            printf("Error type 13 at line %d: Illigal use of \" .\"\n",t->line);
        }
        else {
            struct varNode *newnode = searchVarTable(t->firstChild->firstChild->nextSibling->type);//find id
            if(newnode != NULL && newnode ->type->kind != STRUCTURE){
                printf("Error type 13 at line %d: Illigal use of \".\"\n" , t->line);

            }


        }
        if(t->firstChild->nextSibling->nextSibling->exp_type != NULL){//?
            t->exp_type = t->firstChild->nextSibling->nextSibling->exp_type;
        }
    }

/*
    //ID

    else if(strcmp(t->firstChild->type , "ID") == 0){
        varNode* newnode = searchVarTable(t->firstChild->value.idval);
        if(newnode == NULL){
            printf("Error type 1 at line %d: Variable undefined.\n" ,t->line);
        }
        else t->exp_type = newnode->type;
    }

    //INT

    else if(strcmp(t->firstChild->type , "INT") == 0){
        t->exp_type = (Type)malloc(sizeof(Type_));
        t->exp_type->kind = basic;
        t->exp_type->u.basic = 1;
    }
    //FLOAT

    else if(strcmp(t->firstChild->type , "FLOAT") == 0){
        t->exp_type = (Type)malloc(sizeof(Type_));
        t->exp_type->kind = basic;
        t->exp_type->u.basic = 2;

    }

*/


}



/*
varNode* check1(char *node){//检查变量是否定义过
    varNode* temp = tableHead;
    for(; strcmp(temp->name , node)!=0 && temp!=NULL; temp=temp->next);
    if(temp == NULL){
        //printf("error type 1\n");
        return NULL;//没有定义过
    }
    else return temp;//定义过
}

funcNode* check2(char* node){//函数是否定义过
    funcNode* temp = funcHead;
    for(; strcmp(temp->fname , node)!=0 && temp!=NULL; temp=temp->next);
    if(temp == NULL){
       // printf("error type 2\n");
        return NULL;//没有定义过
    }

    else return temp;//定义过
}


int check3(char* node){//变量重复定义
    return check1(node);
}
int check4(){//函数重复定义
    return check2(node);
}
int check5(Type t1 , Type t2){//赋值号两边类型不匹配
    return type_equal(t1 , t2);
}
int check6(){//赋值号左边出现只有右值的表达式

}
int check7(Type type , Node* node){//操作数类型不匹配
    //type_equal
}
int check8(){//return类型
    //type_equal
}
int check9(){//参数数目类型
    //type_equal &&
    //搜索func表，找到该名字对应的returnType:w
    //
}
int check10(){//对非数组【】

}
int check11(){//对普通变量进行函数操作

}
int check12(){//【】中出现非int

}
int check13(){//对非结构体 .操作

}
int check14(){//访问结构体中未定义过的域

}
int check15(){//结构替中域名重复定义，或者进行了初始化

}
int check16(){//结构体名重复

}
int check17(){//使用未定义过的结构体定义变量

}
int check18(){

}*/
