int main(){
    int i = 0
    int j = ~1;
    return 0;
}
