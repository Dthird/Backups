#ifndef TYPE_H
#include <stdio.h>

#define FLOAT 4
#define INT 4

typedef struct Type_* Type;
typedef struct FieldList_* FieldList;

typedef struct Node{
    int isToken;
    union{
        int intval;//该结点如果是基本类型，这里存储它的值
        float floval;
        char* idval;
    }value;
	int line;
	char type[20];
	char text[64];
	struct Node *firstChild;
	struct Node *nextSibling;
};


struct Type_{
    enum {BASIC , ARRAY , STRUCTURE} kind;
    union{
        //basic type
        int basic;//1:int 2:float

        //array
        struct {Type elem ; int size;} array;
        FieldList structure;
    }u;
};

struct FieldList_{
    char* name;
    Type type;
    FieldList tail;
};

typedef struct funcNode{//函数表节点
    char* fname;//函数名
    varNode* args;//参数表
    Type returnType;//返回值
    funcNode* next;//下一节点
};
typedef struct varNode{
    char* name;//变量表节点
    Type type;//变量类型
    tableNode *next;
};

varNode* tableHead;//变量表头
varNode* tableTail;
funcNode* funcHead;//函数表头
funcNode* funcTail;

void tableInit();//包含变量表和函数表

int handle(struct node *p, int depth);

void insertVarTable(char* name , Type type);//type = 0:basic  1:array 2:structure 
varNode* searchVarTable(char* name);//搜索变量表，若未搜索到返回NULL

void insertFuncTabel(char* fname , Type returnType , varNode* args);//插入函数表

funcNode* searchFuncTable(char* fName);//搜索函数表,若未搜索到返回NULL

int type_equal(Type t1 , Type t2);//相等返回1 ， 不相等返回0


#endif
