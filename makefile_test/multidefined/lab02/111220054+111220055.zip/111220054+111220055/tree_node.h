typedef struct Node{
    int isToken;
    union{
        int intval;//该结点如果是基本类型，这里存储它的值
        float floval;
        char* idval;
    }value;
	int line;
	char type[20];
	char text[64];
	struct Node *firstChild;
	struct Node *nextSibling;
    struct Type_* exp_type;
}Node_;

// struct Node{
//     int isToken;
//     int line;
//     char type[20];
//     char text[64];
//     struct Node *firstChild;
//     struct Node *nextSibling;
//
//     union {
//         int intval;
//         float floval;
//         char* idval;
//     } value;
// };
