#include <stdio.h>
#include "type.h"

extern FILE* yyin;
extern int yylineno;
extern int isError;
extern struct Node* root;

int main(int argc, char** argv){

    // if(argc > 1){
    //     if(!(yyin = fopen(argv[1],"r")))
    //     {
    //         perror(argv[1]);
    //         return 1;
    //     }
    // }
    // while(yylex()!=0);

    if (argc <= 1) {
        return 1;
    }

    int i;
    for (i = 1; i < argc; i++) {
        root = NULL;
        isError = 0;
        yylineno = 1;

        FILE *f = fopen(argv[1], "r");

        if (!f) {
            perror(argv[1]);
            return 1;
        }

        yyrestart(f);
        yyparse();

        if (root != NULL && isError == 0) {
            printf("root-------------%s", root->type);
            printf("firstChild-------------%s", root->firstChild->type);

            // if (root->firstChild == NULL) {
            //     printf("Fuck\n");
            // }
            print(root, 0);
            senmantic_tra(root);
        }

        printf("++++++++++++++++++++++++++++++++++++++++++");
    }

    return 0;
}
