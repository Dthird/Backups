int myatoi(char *text)
{
    int *p = text;
    if (p[0] == '0' && strlen(text) > 1) {
        if (p[1] == 'x' || p[1] == 'X') {
            return (int)strtoul(text+2, NULL, 16);
        }
        return (int)strtoul(text+1, NULL, 8);
    } else {
        return atoi(text);
    }
}
