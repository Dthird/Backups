#include <stdlib.h>
#include <stdio.h>
#include "syntax.tab.c"
int main(int argc, char** argv)
{
	if (argc <= 1) return 1;
	FILE* f = fopen(argv[1], "r");
	if (!f)
	{
		perror(argv[1]);
		return 1;
	}
	yyrestart(f);
	yyparse();
	//if print this grammar tree
	if(iscorrect==0){
		replacestruct(root);
		createfunlist(root);
		createstalist(root);
		//printlist();
		struct Fun * head = funhead1;
		for(;head!=NULL;head = head->next){
			//printf("*******************************\n");
			syntaxanalysis(head->root,head);//printf("1*******************************\n");
			paranumanalysis(head->root,head);//printf("2*******************************\n");
			funreturnanalysis(head->root);//printf("3*******************************\n");
			
		}
		//funreturnanalysis(root);
		//paranumanalysis(root);
		//syntaxanalysis(root);
		//print(root);
	}
	return 0;
}

