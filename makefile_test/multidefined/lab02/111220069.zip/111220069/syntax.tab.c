/* A Bison parser, made by GNU Bison 2.5.  */

/* Bison implementation for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2011 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.5"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 1



/* Copy the first part of user declarations.  */

/* Line 268 of yacc.c  */
#line 1 "syntax.y"


#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "lex.yy.c"



struct GrammarTree{
	char name[50];//name of node
  	int lineno;//line no
	struct GrammarTree * child[100];//child node
	int childnum;//number of child
	struct GrammarTree * parent;	//parent node
	char type[50];
	int paranum;
	char paratype[10][50];//fun parameter type
	struct Variable * structhead;//used in STRUCT type
};
struct GrammarTree *root;//total root
//create node for tokens
void create(struct GrammarTree **node,char* name,int lineno){
	//copy content
	int i = 0;
	*node = (struct GrammarTree*)malloc(sizeof(struct GrammarTree));
	strcpy((*node)->name, name);
	(*node)->lineno = lineno;
	for(i=0;i<100;i++)
		(*node)->child[i]=NULL;//each node point to NULL
	(*node)->childnum=0;//num of child
	(*node)->parent=NULL;
	if(strncmp(name,"INT",3)==0)
		strcpy((*node)->type,"INT");
	if(strncmp(name,"FLOAT",5)==0)
		strcpy((*node)->type,"FLOAT");
	(*node)->paranum = 0;
}
//add child node to parent
void add(struct GrammarTree *parent,struct GrammarTree *child){
	if(child == NULL) return;//no child
	if(parent->child[parent->childnum] == NULL){
		parent->child[parent->childnum] = (struct GrammarTree*)malloc(sizeof(struct GrammarTree));
		parent->child[parent->childnum] = child;//point to child node
		parent->child[parent->childnum]->lineno = child->lineno;
		parent->child[parent->childnum]->childnum = child->childnum;
		parent->child[parent->childnum]->parent = parent;
		strcpy(parent->child[parent->childnum]->name,child->name);
		(parent->childnum)++;	
		return;
	}
}
//----------------------------------------------------------------------------
struct Variable{	//variable list
	char name[50];	//name of node
  	int lineno;	//line no
	char type[50];
	struct Variable * next;
	int paranum;	//fun parameter number
	char paratype[10][50];//fun parameter type
	int isarray; //if this is array 0 for no ,1 for yes 
};

struct Variable * funhead = NULL;
struct Strhead{
	char name[50];
	int lineno;
	struct Variable * head;
	struct Strhead * next;
};
struct Fun{
	char name[50];
	int lineno;
	struct Fun * next;
	struct GrammarTree * root;
	struct Variable * varhead;
	char type[50];
	int paranum;	//fun parameter number
	char paratype[10][50];//fun parameter type
};
struct Strhead * strhead;
struct Fun *funhead1;
struct Fun *funtail1;
struct Variable * statichead;
//create static variable list
void setstatype(struct GrammarTree* parent,char type[]){
	int i;
	for(i = 0;i < (parent->childnum);i++){
		if(parent->child[i]->childnum == 0){
			if(strncmp(parent->child[i]->name,"ID:",3)==0){
				struct Variable * q = statichead;
				for(;q != NULL;q = q->next)
					if(strncmp(q->name,(parent->child[0]->name)+4,46) == 0)
						break;
				if(q == NULL){
					struct Variable * p = (struct Variable*)malloc(sizeof(struct Variable));
					//p->head = NULL;
					strcpy(p->name,(parent->child[0]->name)+4);//
					p->lineno = parent->child[0]->lineno;
					if(strncmp(type,"TYPE: int",9) == 0)
						strncpy(p->type,"INT",3);
					else if(strncmp(type,"TYPE: float",11) == 0)
						strncpy(p->type,"FLOAT",5);
					else if(strncmp(type,"STR1:",5) == 0)
						strncpy(p->type,type+6,3);
					else if(strncmp(type,"STR2:",5) == 0)
						strncpy(p->type,type+6,3);
					//printf("***-%s-***-%d-***-%s-***\n",p->name,p->lineno,p->type);
					p->next = statichead;
					statichead = p;
					
				}
				else{	//Error type 4
					printf("Error type 3 at line %d: Redefined Variable \"%s\"\n",parent->child[i]->lineno,q->name);
				}
			}
			
		}
		else
			setstatype(parent->child[i],type);
	}
}
void createstalist(struct GrammarTree * parent){
	int i;
	for(i = 0;i < (parent->childnum);i++){
		if(parent->child[i]->childnum == 0){
			if((strncmp(parent->name,"Specifier",9)==0)&&(strncmp(parent->parent->child[1]->name,"ExtDecList",10)==0)){
				setstatype(parent->parent->child[1],parent->child[i]->name);
			}		
		}
		else
			createstalist(parent->child[i]);
	}

}

//create fun list
void createfunlist(struct GrammarTree* parent){
	int i;
	for(i = 0;i < (parent->childnum);i++){
		if(parent->child[i]->childnum == 0){
			if((strncmp(parent->child[i]->name,"LP",2)==0)&&(strncmp(parent->name,"FunDec",6)==0)){
				//record content
				struct Fun * q = funhead1;
				for(;q != NULL;q = q->next)
					if(strncmp(q->name,(parent->child[0]->name)+4,46) == 0)
						break;
				if(q == NULL){
					struct Fun * p = (struct Fun*)malloc(sizeof(struct Fun));
					//p->head = NULL;
					strcpy(p->name,(parent->child[0]->name)+4);//
					p->lineno = parent->child[0]->lineno;
					p->root = parent->parent;
					p->varhead = NULL;
					//funlocaldef(&p->head,parent->parent);
					if(funhead1 == NULL){
						funhead1 = funtail1 = p;p->next = NULL;
					}
					else {
						funtail1->next = p;
						funtail1 = p;p->next = NULL;
					}
					//p->next = funhead1;
					//funhead1 = p;
					
				}
				else{	//Error type 4
					printf("Error type 4 at line %d: Redefined function \"%s\"\n",parent->child[i]->lineno,q->name);
				}
			}
			
		}
		else
			createfunlist(parent->child[i]);
	}

}

//check struct list
void printlist(){
	struct Strhead * p = strhead; 
	for(;p!=NULL;p = p->next){
		printf("Struct name : %s--lineno:%d-------------\n",p->name,p->lineno);
		struct Variable * q = p->head;
		for(;q!=NULL;q = q->next){
			printf("name:%s--lineno:%d--type:%s--isarray:%d\n",q->name,q->lineno,q->type,q->isarray);
		}
		
		printf("----------------------------------------\n");
	}
}
//record STRUCT local definition
void strlocaldef(struct Variable **head,struct GrammarTree * parent){ // parent = DefList
	int i;
	for(i = 0;i< parent->childnum;i ++){
		if(parent->child[i]->childnum == 0){
			if((strncmp(parent->child[i]->name,"ID:",3)==0)&&(strncmp(parent->name,"Tag",3)!=0)){
				struct Variable * temp = (*head);	
				for(;temp!=NULL;temp = temp->next)
					if(strncmp(temp->name,(parent->child[i]->name)+4,46) == 0)
						break;
				if(temp != NULL)
					printf("Error type 15 at line %d: Redefined field \'%s\'\n",parent->child[i]->lineno,(parent->child[i]->name)+4);

				struct Variable * v = (struct Variable*)malloc(sizeof(struct Variable));
				strncpy(v->name,(parent->child[i]->name)+4,46);
				v->lineno = parent->child[i]->lineno;
				//type
				struct GrammarTree * p = parent->parent;
				while(strncmp(p->child[0]->name,"Specifier",9)!=0)
					p = p->parent;
				p = p->child[0];
				if(strncmp(p->child[0]->name,"TYPE: int",9) == 0)
					strncpy(v->type,"INT",3);
				else if(strncmp(p->child[0]->name,"TYPE: float",11) == 0)
					strncpy(v->type,"FLOAT",5);
				else
					strncpy(v->type,(p->child[0]->child[1]->child[0]->name)+4,46);
				
				//is array
				if((parent->parent->childnum>1)&&(strncmp(parent->parent->child[1]->name,"LB",2) == 0))
					v->isarray = 1;
				else
					v->isarray = 0;
				v->next = (*head);
				(*head) = v;
				
			}
			if(strncmp(parent->child[i]->name,"ASSIGNOP",8)==0)
				printf("Error type 15 at line %d: Cannot initialize here\n",parent->child[i]->lineno);
		}
		else{
			strlocaldef(head,parent->child[i]);
		}
		
	}

}
//first replace STRUCT definition with "STRUCTDEF: name" in initial GRAMMAR TREE
void replacestruct(struct GrammarTree* parent){
	int i;
	for(i = 0;i < (parent->childnum);i++){
		if(parent->child[i]->childnum == 0){
			if((strncmp(parent->child[i]->name,"STRUCT",6)==0)&&(parent->childnum == 5)){
				//record content
				struct Strhead * q = strhead;
				for(;q != NULL;q = q->next)
					if(strncmp(q->name,(parent->child[1]->child[0]->name)+4,46) == 0)
						break;
				if(q == NULL){
					struct Strhead * p = (struct Strhead*)malloc(sizeof(struct Strhead));
					p->head = NULL;
					strcpy(p->name,(parent->child[1]->child[0]->name)+4);//
					p->lineno = parent->child[1]->child[0]->lineno;
					strlocaldef(&p->head,parent->child[3]);
					p->next = strhead;
					strhead = p;
					//change initial tree
					struct GrammarTree * newNode = (struct GrammarTree *)malloc(sizeof(struct GrammarTree));
					char nodeName[50] = "STR1: ";
					strcat(nodeName,p->name);
					strcpy(newNode->name,nodeName);
					newNode->childnum = 0;
					newNode->lineno = p->lineno;
					parent->parent->child[0] = newNode;
				}
				else{	//Error type 16
					printf("Error type 16 at line %d: Duplicated name \'%s\'\n",parent->child[i]->lineno,q->name);
				}
			}
			else if((strncmp(parent->child[i]->name,"STRUCT",6)==0)&&(parent->childnum == 4)){
				//record content
				struct Strhead * p = (struct Strhead*)malloc(sizeof(struct Strhead));
				p->head = NULL;
				char nametemp[50];
				nametemp[0] = rand()%20+65;
				nametemp[1] = rand()%20+97;
				nametemp[2] = rand()%20+97;
				strcpy(p->name,nametemp);//
				p->lineno = parent->child[i]->lineno;
				strlocaldef(&p->head,parent->child[2]);
				p->next = strhead;
				strhead = p;
				//change initial tree
				struct GrammarTree * newNode = (struct GrammarTree *)malloc(sizeof(struct GrammarTree));
				char nodeName[50] = "STR2: ";
				strcat(nodeName,p->name);
				strcpy(newNode->name,nodeName);
				newNode->lineno = p->lineno;
				newNode->childnum = 0;
				parent->parent->child[0] = newNode;
				
			}
			else if((strncmp(parent->child[i]->name,"STRUCT",6)==0)&&(parent->childnum == 2)&&(strncmp(parent->parent->parent->name,"ExtDef",6) == 0)){
				struct Strhead * q = strhead;
				for(;q != NULL;q = q->next)
					if(strncmp(q->name,(parent->child[1]->child[0]->name)+4,46) == 0)
						break;
				if(q == NULL)
					printf("Error type 17 at line %d: Undefined struct \"%s\"\n",parent->child[i]->lineno,(parent->child[1]->child[0]->name)+4);
			}
		}
		else
			replacestruct(parent->child[i]);
	}

}
//fun return analysis ------------------------------------------------------Error type 8
void checkfunreturn(char type1[],struct GrammarTree* parent,int number){
	int i;
	for(i = 0;i < (parent->childnum);i++){
		if(parent->child[i]->childnum == 0){//
			if(strncmp(parent->child[i]->name,"RETURN",6)==0){
				if(parent->child[i+1]->childnum == 1)
					if(strncmp(type1,(parent->child[i+1])->child[0]->type,number)!=0){
						//printf("affd--%s---%s\n",type1,(parent->child[i+1])->child[0]->type);
						printf("Error type 8 at line %d: The return type mismatched\n",parent->child[i]->lineno);}
			}
		}
		else
			checkfunreturn(type1,parent->child[i],number);
	}
}
void funreturnanalysis(struct GrammarTree* parent){//parent == ExtDef
	int i;
	//go over each child
	for(i=0;i<parent->childnum;i++){
		if((parent->child[i])->childnum==0){//printf("qqq0\n");
			if(strncmp(parent->child[i]->name,"TYPE:",5) == 0){//type assignment
				char type[50];
				int number;
				if(strncmp(parent->child[i]->name,"TYPE: int",9) == 0){
					strncpy(type,"INT",3);number = 3;}
				else if(strncmp(parent->child[i]->name,"TYPE: float",11) == 0){
					strncpy(type,"FLOAT",5);number = 5;}	
				struct GrammarTree* p = parent->parent;
				if((p->childnum > 1)&&(strncmp(p->child[1]->name,"FunDec",6)==0)){
					strcpy(p->child[1]->type,type);
					//printf("p->child[1]->type = %s---number = %d\n",p->child[1]->type,number);
					checkfunreturn(type,p->child[2],number);//printf("qqq1\n");
				}
			}
			else if(strncmp(parent->child[i]->name,"STR",3) == 0){//printf("qqq121\n");
				char type[50];
				int number;
				struct GrammarTree* p = parent->parent;
				if((p->childnum > 1)&&(strncmp(p->child[1]->name,"FunDec",6)==0)){//printf("qqq122\n");
					strncpy(type,(parent->child[i]->name)+6,3);number = 3;
					strcpy(p->child[1]->type,type);
					checkfunreturn(type,p->child[2],number);//printf("qqq123\n");
				}
			}
		}
		else{
			funreturnanalysis(parent->child[i]);
		}
	}

}
//set variable type
void typevariable(char type1[],struct GrammarTree* parent,int number){
	int i;
	for(i = 0;i < (parent->childnum);i++){
		if(parent->child[i]->childnum == 0){
			if(strncmp(parent->child[i]->name,"ID:",3)==0)//{
				strncpy(parent->child[i]->type,type1,number);//printf("ahhhhh-%s-%s--\n",type1,parent->child[i]->name);}
		}
		else
			typevariable(type1,parent->child[i],number);
	}
}

//fun array parameters check like a[1.5]-------------------------------------Error type 12
void arrayparacheck(struct GrammarTree* parent,struct Fun* head,struct GrammarTree* arrayID){
	int i;
	for(i=0;i<parent->childnum;i++){
		if((parent->child[i])->childnum==0){
			if((strncmp(parent->child[i]->name,"ID:",3) == 0)&&(strcmp(parent->child[i]->name,arrayID->name)!=0)){
				//printf("aqaqaqaqaq---%s---%s\n",parent->child[i]->type,parent->child[i]->name);
				struct Variable* p = head->varhead;
				for(;p!=NULL;p = p->next){
					//printf("---@@@@ %s--%s\n",p->name,p->type);
					if(strncmp(p->name,(parent->child[i]->name)+4,46) == 0)
						break;
				}
				if(p != NULL){//printf("aqaqaqaqaq---%s---%s\n",p->type,parent->child[i]->name);
					if(strncmp(p->type,"FLOAT",5) == 0)
						printf("Error type 12 at line %d: Operands type mistaken\n",parent->child[i]->lineno);
				}
			}
			else if((strncmp(parent->child[i]->name,"FLOAT",5) == 0)&&(strcmp(parent->child[i]->name,arrayID->name)!=0)){
				printf("Error type 12 at line %d: Operands type mistaken\n",parent->child[i]->lineno);
			}
	
		}
		else{
			arrayparacheck(parent->child[i],head,arrayID);
		}
	}

}
//function parameters number analysis----------------------------------------Error Type 9
//set function parameters number
void countparanum(struct GrammarTree* parent,int * count,struct GrammarTree* funID,struct Fun *head){
	int i;
	//go over each child
	for(i=0;i<parent->childnum;i++){
		if((parent->child[i])->childnum==0){
			if(strncmp(parent->child[i]->name,"COMMA",5) == 0)
				(*count) ++;
			else if((strncmp(parent->child[i]->name,"ID:",3) == 0)&&(strcmp(parent->child[i]->name,funID->name)!=0)){
				strcpy(funID->paratype[(*count)-1],parent->child[i]->type);
				//printf("here-count = %d--parent->child[i]->type = %s--\n",(*count)-1,parent->child[i]->type);
				//add  each type to fun table
				struct Fun* p = funhead1;
				for(;p!=NULL;p = p->next)
					if(strncmp(p->name,(funID->name)+4,46) == 0)
						break;
				if(p != NULL){//printf("7----\n");//mistake 1
					strcpy(p->paratype[(*count)-1],parent->child[i]->type);
					p->paranum = (*count);
				}
			}
		}
		else{
			countparanum(parent->child[i],count,funID,head);
		}
	}

}
void countparanum1(struct GrammarTree* parent,int * count,char type[10][50],struct GrammarTree* funID){
	int i;
	//go over each child
	for(i=0;i<parent->childnum;i++){
		if((parent->child[i])->childnum==0){
			if(strncmp(parent->child[i]->name,"COMMA",5) == 0)
				(*count) ++;
			else if((strncmp(parent->child[i]->name,"ID:",3) == 0)&&(strcmp(parent->child[i]->name,funID->name)!=0)){
				strcpy(type[(*count)],parent->child[i]->type);
			}
			else if((strncmp(parent->child[i]->name,"INT",3) == 0)&&(strcmp(parent->child[i]->name,funID->name)!=0)){
				strncpy(type[(*count)],"INT",3);//printf("type int \n");
			}
			else if((strncmp(parent->child[i]->name,"FLOAT",5) == 0)&&(strcmp(parent->child[i]->name,funID->name)!=0)){
				strncpy(type[(*count)],"FLOAT",5);//printf("type float -- count = %d\n",(*count));
			}
		}
		else{
			countparanum1(parent->child[i],count,type,funID);
		}
	}

}
void paranumanalysis(struct GrammarTree* parent,struct Fun* head){
	int i;
	//go over each child
	for(i=0;i<parent->childnum;i++){
		if((parent->child[i])->childnum==0){
			if((strncmp(parent->child[i]->name,"ID:",3) == 0)&&(strncmp(parent->name,"FunDec",6)) == 0){//type assignment
				//printf("parent->child[i]->name = %s--i = %d-\n",parent->child[i]->name,i);
				if(parent->childnum == 3)
					parent->child[i]->paranum = 0;
				else{
					int count = 1;
					countparanum(parent,&count,parent->child[i],head);
					parent->child[i]->paranum = count;
					//printf("count = %d----------\n",count);
				}
				//printf("parent->child[i]->name = %s---parent->child[i]->paranum = %d----\n",parent->child[i]->name,parent->child[i]->paranum);
			}
			else if((strncmp(parent->child[i]->name,"ID:",3) == 0)&&(strncmp(parent->name,"Exp",3) == 0)){
				int paranum = 0;
				char paratype[10][50];
				if((i == 0)&&(parent->childnum == 3))
					paranum = 0;
				else if(parent->childnum == 4){
					countparanum1(parent,&paranum,paratype,parent->child[i]);
					paranum ++;
				}
				struct Fun* p = funhead1;
				for(;p!=NULL;p = p->next)
					if(strncmp(p->name,(parent->child[i]->name)+4,46) == 0)
						break;
				if(p != NULL){//printf("7.1----\n");//mistake 9
					char temp[500]; 
					memset(temp,0,500);
					int tempi;
					for(tempi = 0;tempi < paranum;tempi ++){
						strcat(temp,paratype[tempi]);strcat(temp,",");}
					for(tempi = 0;tempi < 500;tempi ++)
						if(temp[tempi] == 0)
							break;
					temp[tempi-1] = 0;
					for(tempi = 0;tempi < 500;tempi ++)
						temp[tempi] = tolower(temp[tempi]);
					char tempfun[500];
					memset(tempfun,0,500);
					int tempfuni;
					for(tempfuni = 0;tempfuni < p->paranum;tempfuni ++){
						strcat(tempfun,p->paratype[tempfuni]);strcat(tempfun,",");}
					for(tempfuni = 0;tempfuni < 500;tempfuni ++)
						if(tempfun[tempfuni] == 0)
							break;
					tempfun[tempfuni-1] = 0;
					for(tempfuni = 0;tempfuni < 500;tempfuni ++)
						tempfun[tempfuni] = tolower(tempfun[tempfuni]);
					//compare fun num
					if(p->paranum != paranum)
						printf("Error type 9 at line %d: The method \"%s(%s)\" is not applicable for the arguments \"(%s)\"\n",parent->child[i]->lineno,p->name,tempfun,temp);
					//fun num ok then compare fun param
					else{
						int tempj = 0;
						for(;tempj < paranum;tempj ++){
				 			if(strcmp(p->paratype[tempj],paratype[tempj])!=0)
								break;
						}
						if(tempj != paranum)
							printf("Error type 9 at line %d: The method \"%s(%s)\" is not applicable for the arguments \"(%s)\"\n",parent->child[i]->lineno,p->name,tempfun,temp);
					}

	
					//printf("qq---p->paranum = %d--paranum = %d-\n",p->paranum,paranum);
					//printf("qq---p->paratype[0] = %s---p->paratype[1] = %s--\n",p->paratype[0],p->paratype[1]);
				}//The method “func(int)” is not applicable for the arguments “(int, int)”

			}
		}
		else{
			paranumanalysis(parent->child[i],head);
		}
		//printf("====\n");
	}

}
//syntax analysis------------------------------------------------------------------
void syntaxanalysis(struct GrammarTree* parent,struct Fun * head){
	int i;
	//go over each child
	for(i=0;i<parent->childnum;i++){
		if((parent->child[i])->childnum==0){
			//printf("--%s (%d)\n",(parent->child[i]->name),parent->child[i]->lineno);
			if(strncmp(parent->child[i]->name,"TYPE:",5) == 0){//type assignment
				char type[50];
				int number;
				if(strncmp(parent->child[i]->name,"TYPE: int",9) == 0){
					strncpy(type,"INT",3);number = 3;}
				else if(strncmp(parent->child[i]->name,"TYPE: float",11) == 0){
					strncpy(type,"FLOAT",5);number = 5;}
				struct GrammarTree* p = parent->parent;
				if(strncmp(p->child[1]->name,"FunDec",6)!=0)
					typevariable(type,p,number);
				/*else{//Error type 8
					strcpy(p->child[1]->type,type);
					checkfunreturn(type,p->child[2],number);
				}*/
			}
			else if(strncmp(parent->child[i]->name,"STRUCT",6) == 0){//"STRUCT" type assignment
				struct GrammarTree * s = parent->parent->parent;
				if((s->childnum > 1)&&(strncmp(s->child[1]->name,"ExtDecList",10)!=0)){
					struct Strhead * q = strhead;
					for(;q!=NULL;q=q->next)
					if(strncmp(q->name,(parent->child[1]->child[0]->name)+4,46)==0)
						break;
					if(q==NULL){//printf("vvvvvvvv\n");
						printf("Error type 17 at line %d: Undefined struct \"%s\"\n",parent->child[i]->lineno,(parent->child[1]->child[0]->name)+4);}
					else{	
						char type[50];
						strncpy(type,(parent->child[1]->child[0]->name)+4,46);
						typevariable(type,s->child[1],50);
					}
				}

			}
			else if(strncmp(parent->child[i]->name,"ID:",3) == 0){
				//printf("1----\n");
				if(strncmp(parent->name,"VarDec",6) == 0){//Errpr type 3
					//printf("2----\n");
					struct Variable* p = head->varhead;
					for(;p!=NULL;p = p->next)
						if(strncmp(p->name,(parent->child[i]->name)+4,46) == 0)
							break;
					if(p == NULL){//printf("3----\n");
						p = (struct Variable*)malloc(sizeof(struct Variable));
						strcpy(p->name,(parent->child[i]->name)+4);
						strcpy(p->type,parent->child[i]->type);
						//printf("!@!@!@  %s----%s--\n",p->name,p->type);
						p->lineno = parent->child[i]->lineno;
						if((parent->parent)->childnum > 1){
							if(strncmp(((parent->parent)->child[1])->name,"LB",2) == 0)
								p->isarray = 1;
							else	
								p->isarray = 0;
						}
						else
							p->isarray = 0;
						//printf("*_*p->name = %s----p->type = %s----_*_*p->isarray = %d\n",p->name,p->type,p->isarray);
						p->next = head->varhead;
						head->varhead = p;
					}
					else{//printf("4----\n");		
						char temp[50];
						strcpy(temp,(parent->child[i]->name)+4);
						printf("Error type 3 at line %d: Redefined variable \"%s\"\n",parent->child[i]->lineno,temp);

					}
				}
				else if(strncmp(parent->name,"FunDec",6) == 0){//Error type 4
					//printf("2.1----\n");
					struct Fun* p = funhead1;
					for(;p!=NULL;p = p->next)
						if(strncmp(p->name,(parent->child[i]->name)+4,46) == 0)
							break;
					if(p != NULL){//printf("3.1----\n");
						//p = (struct Fun*)malloc(sizeof(struct Fun));
						//strcpy(p->name,(parent->child[i]->name)+4);
						strcpy(p->type,parent->child[i]->type);
						//p->lineno = parent->child[i]->lineno;
						//p->next = funhead;
						//funhead = p;
					}
					/*else{//printf("4.1----\n");		//mistake 4
						char temp[50];
						strcpy(temp,(parent->child[i]->name)+4);
						printf("Error type 4 at line %d: Redefined function \"%s\"\n",parent->child[i]->lineno,temp);

					}*/
				}
				else if((strncmp(parent->name,"Exp",3) == 0)&&(parent->childnum == 1)){//Error type 1 and 10
					//printf("5----\n");
					struct Variable* p = head->varhead;
					for(;p!=NULL;p = p->next)
						if(strncmp(p->name,(parent->child[i]->name)+4,46) == 0)
							break;
					struct Variable* q = statichead;
					for(;q!=NULL;q = q->next)
						if(strncmp(q->name,(parent->child[i]->name)+4,46) == 0)
							break;
					if(p == NULL&&q == NULL){//printf("6----\n");//Error type 1
						char temp[50];
						strcpy(temp,(parent->child[i]->name)+4);
						printf("Error type 1 at line %d: Undefined variable \"%s\"\n",parent->child[i]->lineno,temp);
						
					}
					else{	
						
						strcpy(parent->child[i]->type,p->type);
						//printf("%s---%s ---%s---\n",parent->child[i]->name,parent->child[i]->type,p->type);
						if((parent->parent)->childnum > 1){
							if(strncmp(((parent->parent)->child[1])->name,"LB",2) == 0){//printf("fffff\n");
								/*struct GrammarTree* funID = parent;
								while(funID->childnum != 0)
									funID = funID->child[0];
								if(strcpy(funID->name,parent->child[i]->name) == 0)*/
								if(p->isarray == 0)
									printf("Error type 10 at line %d: \"%s\" must be an array\n",parent->child[i]->lineno,p->name);

							}

						}
					}
					
				}//if(strncmp(parent->name,"Exp",3) == 0)
				else if((strncmp(parent->name,"Exp",3) == 0)&&(parent->childnum > i + 1)&&((strncmp(parent->child[i+1]->name,"LP",2) == 0))){//Error type 2
					//printf("6----\n");
					struct Fun* p = funhead1;
					for(;p!=NULL;p = p->next)
						if(strncmp(p->name,(parent->child[i]->name)+4,46) == 0)
							break;
					struct Variable* q = head->varhead;
					for(;q!=NULL;q = q->next)
						if(strncmp(q->name,(parent->child[i]->name)+4,46) == 0)
							break;
					struct Variable* r = statichead;
					for(;r!=NULL;r = r->next)
						if(strncmp(r->name,(parent->child[i]->name)+4,46) == 0)
							break;
					if((p == NULL)&&(q == NULL)&&(r == NULL)){//printf("7----\n");//mistake 1
						char temp[50];
						strcpy(temp,(parent->child[i]->name)+4);
						printf("Error type 2 at line %d: Undefined function \"%s\"\n",parent->child[i]->lineno,temp);
						
					}
					else if(((q != NULL)||(r != NULL))&&(p == NULL)){
						printf("Error type 11 at line %d: \"%s\" must be a function\n",parent->child[i]->lineno,q->name);
					}
				}				



			}//if(strncmp(parent->child[i]->name,"ID:",3) == 0)

			else if(strncmp(parent->child[i]->name,"DOT",3) == 0){
				if(strncmp(parent->child[0]->child[0]->name,"ID:",3) == 0){
					struct GrammarTree * a = parent->child[0]->child[0];
					struct Variable* p = head->varhead;
					for(;p!=NULL;p = p->next)
						if(strncmp(p->name,(a->name)+4,46) == 0)
							break;
					struct Variable* r = head->varhead;
					for(;r!=NULL;r = r->next)
						if(strncmp(r->name,(a->name)+4,46) == 0)
							break;
					if(p == NULL&& r == NULL){// Error type 13
						printf("Error type 13 at line %d: Illegal use of \".\"\n",a->lineno);
					}
					else{
						if(p != NULL){
							if((strncmp(p->type,"INT",3)==0)||(strncmp(p->type,"FLOAT",5)==0))
								printf("Error type 13 at line %d: Illegal use of \".\"\n",a->lineno);
							else{	
								struct Strhead * q = strhead;
								for(;q!=NULL;q=q->next)
									if(strcmp(q->name,a->type)==0)
										break;
								if(q!=NULL){
									struct Variable * r = q->head;
									for(;r!=NULL;r=r->next)
										if(strncmp(r->name,(parent->child[2]->name)+4,46) == 0)
											break;
									if(r == NULL)
										printf("Error type 14 at line %d: Un-existed field \"%s\"\n",parent->child[i]->lineno,(parent->child[2]->name)+4);

								}
							}
						}
						else if(r != NULL){
							if((strncmp(r->type,"INT",3)==0)||(strncmp(r->type,"FLOAT",5)==0))
								printf("Error type 13 at line %d: Illegal use of \".\"\n",a->lineno);
							else{	
								struct Strhead * q = strhead;
								for(;q!=NULL;q=q->next)
									if(strcmp(q->name,a->type)==0)
										break;
								if(q!=NULL){
									struct Variable * s = q->head;
									for(;s!=NULL;s=s->next)
										if(strncmp(s->name,(parent->child[2]->name)+4,46) == 0)
											break;
									if(s == NULL)
										printf("Error type 14 at line %d: Un-existed field \"%s\"\n",parent->child[i]->lineno,(parent->child[2]->name)+4);

								}
							}
						}

					}
				}


			}
			
			else if((strncmp(parent->child[i]->name,"RB",2) == 0)&&(strncmp(parent->name,"Exp",3) == 0)){//Error type 12
				if(((parent->parent)->childnum >1)&&(strncmp((parent->parent)->child[1]->name,"LB",2) == 0)){}
				else{
					//printf("aaaaaaaaaaa\n");
					struct GrammarTree* arrayID = parent;
					while(arrayID->childnum!=0)
						arrayID = arrayID->child[0];
					if(strncmp(arrayID->name,"ID:",3) == 0)
						arrayparacheck(parent,head,arrayID);
				}

			}
			else if((strncmp(parent->child[i]->name,"PLUS",4) == 0)||(strncmp(parent->child[i]->name,"MINUS",8) == 0)||(strncmp(parent->child[i]->name,"STAR",8) == 0)||(strncmp(parent->child[i]->name,"DIV",8) == 0)){//Error type 7
				if((parent->child[i-1]->childnum == 1)&&(parent->child[i+1]->childnum == 1)){
					if(strcmp((parent->child[i-1])->child[0]->type,(parent->child[i+1])->child[0]->type)!=0)
						printf("Error type 7 at line %d: Operands type mismatched\n",parent->child[i]->lineno);
				}
			}
			else if(strncmp(parent->child[i]->name,"ASSIGNOP",8) == 0){//Error type 5 and 6
				//printf("5.1----\n");
				if((strncmp((parent->child[i-1])->child[0]->name,"INT",3)==0)||(strncmp((parent->child[i-1])->child[0]->name,"FLOAT",5)==0))//6
					printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n",parent->child[i]->lineno);
				else if((strcmp(parent->child[i+1]->name,"Exp")==0)&&(parent->child[i+1]->childnum==1)){//printf("5.2----\n");//5
					if(strcmp((parent->child[i+1])->child[0]->type,(parent->child[i-1])->child[0]->type) != 0){
						if(strncmp((parent->child[i-1])->child[0]->name,"ID:",3)==0){
							struct Variable* p = head->varhead;//look up variable table
							for(;p!=NULL;p = p->next)
								if(strncmp(p->name,((parent->child[i-1])->child[0]->name)+4,46) == 0)
									break;
							if(p != NULL)
								printf("Error type 5 at line %d: Type mismatched\n",parent->child[i]->lineno);
						}
					}
				}
				
			}
			
				
		}
		else{
			syntaxanalysis(parent->child[i],head);
		}
		//printf("====\n");
	}

}

//----------------------------------------------------------------------------
//print each tree node
int tabnum=1;
void print(struct GrammarTree* parent){
	if(parent == root)
		printf("%s (%d)\n",root->name,root->lineno);
	int i,j;
	//go over each child
	for(i=0;i<=parent->childnum;i++){
		if(parent->child[i]!=NULL){
 			for(j=0;j<tabnum;j++)
				printf("  ");
	  		printf("%s",(parent->child[i]->name));
			if(parent->child[i]->childnum!=0)
				printf(" (%d)",parent->child[i]->lineno);
			printf("\n");
			tabnum++;
			print(parent->child[i]);
			tabnum--;
		}
	}
}



/* Line 268 of yacc.c  */
#line 896 "syntax.tab.c"

/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     INT = 258,
     FLOAT = 259,
     ID = 260,
     SEMI = 261,
     COMMA = 262,
     ASSIGNOP = 263,
     RELOP = 264,
     PLUS = 265,
     MINUS = 266,
     STAR = 267,
     DIV = 268,
     AND = 269,
     OR = 270,
     DOT = 271,
     NOT = 272,
     TYPE = 273,
     LP = 274,
     RP = 275,
     LB = 276,
     RB = 277,
     LC = 278,
     RC = 279,
     STRUCT = 280,
     RETURN = 281,
     IF = 282,
     ELSE = 283,
     WHILE = 284,
     ASSIGN = 285,
     SUB = 286,
     ADD = 287,
     MUL = 288
   };
#endif



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{

/* Line 293 of yacc.c  */
#line 826 "syntax.y"

	struct GrammarTree *node;



/* Line 293 of yacc.c  */
#line 971 "syntax.tab.c"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

#if ! defined YYLTYPE && ! defined YYLTYPE_IS_DECLARED
typedef struct YYLTYPE
{
  int first_line;
  int first_column;
  int last_line;
  int last_column;
} YYLTYPE;
# define yyltype YYLTYPE /* obsolescent; will be withdrawn */
# define YYLTYPE_IS_DECLARED 1
# define YYLTYPE_IS_TRIVIAL 1
#endif


/* Copy the second part of user declarations.  */


/* Line 343 of yacc.c  */
#line 996 "syntax.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef EXIT_SUCCESS
#      define EXIT_SUCCESS 0
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined EXIT_SUCCESS \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef EXIT_SUCCESS
#    define EXIT_SUCCESS 0
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined EXIT_SUCCESS && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL \
	     && defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
  YYLTYPE yyls_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE) + sizeof (YYLTYPE)) \
      + 2 * YYSTACK_GAP_MAXIMUM)

# define YYCOPY_NEEDED 1

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

#if defined YYCOPY_NEEDED && YYCOPY_NEEDED
/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif
#endif /* !YYCOPY_NEEDED */

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  13
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   279

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  34
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  22
/* YYNRULES -- Number of rules.  */
#define YYNRULES  66
/* YYNRULES -- Number of states.  */
#define YYNSTATES  126

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   288

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint8 yyprhs[] =
{
       0,     0,     3,     5,     8,     9,    13,    16,    20,    23,
      25,    29,    31,    33,    39,    42,    44,    45,    47,    49,
      54,    59,    63,    66,    70,    72,    75,    80,    83,    86,
      87,    90,    92,    96,   102,   110,   116,   119,   122,   123,
     127,   130,   132,   136,   138,   142,   146,   150,   154,   158,
     162,   166,   170,   174,   178,   181,   184,   189,   193,   198,
     202,   204,   206,   208,   212,   216,   220
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int8 yyrhs[] =
{
      35,     0,    -1,    36,    -1,    37,    36,    -1,    -1,    39,
      38,     6,    -1,    39,     6,    -1,    39,    44,    47,    -1,
       1,     6,    -1,    43,    -1,    43,     7,    38,    -1,    18,
      -1,    40,    -1,    25,    41,    23,    50,    24,    -1,    25,
      42,    -1,     5,    -1,    -1,     5,    -1,     5,    -1,    43,
      21,     3,    22,    -1,     5,    19,    45,    20,    -1,     5,
      19,    20,    -1,     1,    20,    -1,    46,     7,    45,    -1,
      46,    -1,    39,    43,    -1,    23,    50,    48,    24,    -1,
       1,    24,    -1,    49,    48,    -1,    -1,    54,     6,    -1,
      47,    -1,    26,    54,     6,    -1,    27,    19,    54,    20,
      49,    -1,    27,    19,    54,    20,    49,    28,    49,    -1,
      29,    19,    54,    20,    49,    -1,     1,     6,    -1,    51,
      50,    -1,    -1,    39,    52,     6,    -1,     1,     6,    -1,
      53,    -1,    53,     7,    52,    -1,    43,    -1,    43,     8,
      54,    -1,    54,     8,    54,    -1,    54,    14,    54,    -1,
      54,    15,    54,    -1,    54,     9,    54,    -1,    54,    10,
      54,    -1,    54,    11,    54,    -1,    54,    12,    54,    -1,
      54,    13,    54,    -1,    19,    54,    20,    -1,    11,    54,
      -1,    17,    54,    -1,     5,    19,    55,    20,    -1,     5,
      19,    20,    -1,    54,    21,    54,    22,    -1,    54,    16,
       5,    -1,     5,    -1,     3,    -1,     4,    -1,    19,     1,
      20,    -1,    21,     1,    22,    -1,    54,     7,    55,    -1,
      54,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   887,   887,   889,   890,   892,   893,   894,   895,   897,
     898,   900,   901,   903,   904,   906,   907,   909,   911,   912,
     914,   915,   916,   918,   919,   921,   923,   924,   926,   927,
     929,   930,   931,   932,   933,   934,   935,   937,   938,   940,
     941,   943,   944,   946,   947,   949,   950,   951,   952,   953,
     954,   955,   956,   957,   958,   959,   960,   961,   962,   963,
     964,   965,   966,   967,   968,   970,   971
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "INT", "FLOAT", "ID", "SEMI", "COMMA",
  "ASSIGNOP", "RELOP", "PLUS", "MINUS", "STAR", "DIV", "AND", "OR", "DOT",
  "NOT", "TYPE", "LP", "RP", "LB", "RB", "LC", "RC", "STRUCT", "RETURN",
  "IF", "ELSE", "WHILE", "ASSIGN", "SUB", "ADD", "MUL", "$accept",
  "Program", "ExtDefList", "ExtDef", "ExtDecList", "Specifier",
  "StructSpecifier", "OptTag", "Tag", "VarDec", "FunDec", "VarList",
  "ParamDec", "CompSt", "StmtList", "Stmt", "DefList", "Def", "DecList",
  "Dec", "Exp", "Args", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    34,    35,    36,    36,    37,    37,    37,    37,    38,
      38,    39,    39,    40,    40,    41,    41,    42,    43,    43,
      44,    44,    44,    45,    45,    46,    47,    47,    48,    48,
      49,    49,    49,    49,    49,    49,    49,    50,    50,    51,
      51,    52,    52,    53,    53,    54,    54,    54,    54,    54,
      54,    54,    54,    54,    54,    54,    54,    54,    54,    54,
      54,    54,    54,    54,    54,    55,    55
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     2,     0,     3,     2,     3,     2,     1,
       3,     1,     1,     5,     2,     1,     0,     1,     1,     4,
       4,     3,     2,     3,     1,     2,     4,     2,     2,     0,
       2,     1,     3,     5,     7,     5,     2,     2,     0,     3,
       2,     1,     3,     1,     3,     3,     3,     3,     3,     3,
       3,     3,     3,     3,     2,     2,     4,     3,     4,     3,
       1,     1,     1,     3,     3,     3,     1
};

/* YYDEFACT[STATE-NAME] -- Default reduction number in state STATE-NUM.
   Performed when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,    11,    16,     0,     2,     0,     0,    12,     8,
      17,     0,    14,     1,     3,     0,    18,     6,     0,     9,
       0,     0,    22,     0,     5,     0,     0,     0,     0,     7,
       0,     0,     0,     0,    21,     0,     0,    24,    18,    10,
       0,    27,     0,    40,    43,     0,    41,    13,    37,    25,
      20,     0,    19,     0,    61,    62,    60,     0,     0,     0,
       0,     0,     0,     0,    31,     0,     0,     0,     0,    39,
       0,    23,    36,     0,    54,    55,     0,     0,     0,     0,
       0,     0,    26,    28,    30,     0,     0,     0,     0,     0,
       0,     0,     0,     0,     0,    44,    42,    57,    66,     0,
      63,    53,    64,    32,     0,     0,    45,    48,    49,    50,
      51,    52,    46,    47,    59,     0,     0,    56,     0,     0,
      58,    65,    33,    35,     0,    34
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int8 yydefgoto[] =
{
      -1,     4,     5,     6,    18,    31,     8,    11,    12,    19,
      20,    36,    37,    64,    65,    66,    32,    33,    45,    46,
      67,    99
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -72
static const yytype_int16 yypact[] =
{
      21,    14,   -72,    36,    51,   -72,    21,    12,   -72,   -72,
      32,    38,   -72,   -72,   -72,    52,    54,   -72,    69,    31,
       4,    83,   -72,    -6,   -72,    71,    88,    62,    39,   -72,
      91,    71,    75,    39,   -72,    71,    82,    98,   -72,   -72,
      95,   -72,    66,   -72,    28,   104,   113,   -72,   -72,    97,
     -72,   -10,   -72,     1,   -72,   -72,   102,   130,   130,   108,
     122,   130,   105,   107,   -72,   112,    66,   144,   130,   -72,
      71,   -72,   -72,   111,   244,   244,   117,   202,   116,   158,
     130,   130,   -72,   -72,   -72,   130,   130,   130,   130,   130,
     130,   130,   130,   134,   130,   244,   -72,   -72,   173,   120,
     -72,   -72,   -72,   -72,   216,   230,   244,   244,   244,   244,
     244,   258,   244,   244,   -72,   187,   130,   -72,    77,    77,
     -72,   -72,   114,   -72,    77,   -72
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
     -72,   -72,   137,   -72,   119,     3,   -72,   -72,   -72,   -25,
     -72,    94,   -72,   126,    96,   -71,    46,   -72,    78,   -72,
     -57,    45
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -39
static const yytype_int8 yytable[] =
{
      74,    75,    77,     7,    79,    27,    44,    72,     2,     7,
      49,    95,     2,    15,    34,     3,    98,    16,    17,     3,
       9,    -4,     1,   104,   105,    41,    35,    28,   106,   107,
     108,   109,   110,   111,   112,   113,    68,   115,    25,     2,
      30,    10,   -38,   -38,   -38,    44,     3,   122,   123,    26,
     -38,    13,    26,   125,    35,   -15,   -38,     2,   -38,    98,
     -38,    21,   -38,   -38,     3,   -38,   -38,    53,   -38,    54,
      55,    56,    22,    23,    42,    24,    38,    57,    53,    48,
      54,    55,    56,    58,    30,    59,    41,    60,    57,    28,
     -29,    40,    61,    62,    58,    63,    59,    43,    60,    47,
      28,     2,    50,    61,    62,    51,    63,   -38,     3,    76,
      69,    54,    55,    56,    54,    55,    56,    52,    26,    57,
      70,    73,    57,    78,    80,    58,    81,    59,    58,    60,
      59,    97,    60,    54,    55,    56,    82,   100,   102,   114,
     117,    57,   124,    14,    39,    71,    29,    58,    96,    59,
      84,    60,    85,    86,    87,    88,    89,    90,    91,    92,
      93,   121,    83,     0,   103,    94,    85,    86,    87,    88,
      89,    90,    91,    92,    93,     0,     0,     0,     0,    94,
     116,    85,    86,    87,    88,    89,    90,    91,    92,    93,
       0,     0,     0,     0,    94,    85,    86,    87,    88,    89,
      90,    91,    92,    93,     0,     0,     0,     0,    94,   120,
      85,    86,    87,    88,    89,    90,    91,    92,    93,     0,
       0,     0,   101,    94,    85,    86,    87,    88,    89,    90,
      91,    92,    93,     0,     0,     0,   118,    94,    85,    86,
      87,    88,    89,    90,    91,    92,    93,     0,     0,     0,
     119,    94,    85,    86,    87,    88,    89,    90,    91,    92,
      93,     0,     0,     0,     0,    94,    85,    86,    87,    88,
      89,     0,    91,    92,    93,     0,     0,     0,     0,    94
};

#define yypact_value_is_default(yystate) \
  ((yystate) == (-72))

#define yytable_value_is_error(yytable_value) \
  YYID (0)

static const yytype_int8 yycheck[] =
{
      57,    58,    59,     0,    61,     1,    31,     6,    18,     6,
      35,    68,    18,     1,    20,    25,    73,     5,     6,    25,
       6,     0,     1,    80,    81,    24,    23,    23,    85,    86,
      87,    88,    89,    90,    91,    92,     8,    94,     7,    18,
       1,     5,     3,     4,     5,    70,    25,   118,   119,    21,
      11,     0,    21,   124,    51,    23,    17,    18,    19,   116,
      21,    23,    23,    24,    25,    26,    27,     1,    29,     3,
       4,     5,    20,    19,    28,     6,     5,    11,     1,    33,
       3,     4,     5,    17,     1,    19,    24,    21,    11,    23,
      24,     3,    26,    27,    17,    29,    19,     6,    21,    24,
      23,    18,    20,    26,    27,     7,    29,    24,    25,     1,
       6,     3,     4,     5,     3,     4,     5,    22,    21,    11,
       7,    19,    11,     1,    19,    17,    19,    19,    17,    21,
      19,    20,    21,     3,     4,     5,    24,    20,    22,     5,
      20,    11,    28,     6,    25,    51,    20,    17,    70,    19,
       6,    21,     8,     9,    10,    11,    12,    13,    14,    15,
      16,   116,    66,    -1,     6,    21,     8,     9,    10,    11,
      12,    13,    14,    15,    16,    -1,    -1,    -1,    -1,    21,
       7,     8,     9,    10,    11,    12,    13,    14,    15,    16,
      -1,    -1,    -1,    -1,    21,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    -1,    -1,    -1,    -1,    21,    22,
       8,     9,    10,    11,    12,    13,    14,    15,    16,    -1,
      -1,    -1,    20,    21,     8,     9,    10,    11,    12,    13,
      14,    15,    16,    -1,    -1,    -1,    20,    21,     8,     9,
      10,    11,    12,    13,    14,    15,    16,    -1,    -1,    -1,
      20,    21,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    -1,    -1,    -1,    -1,    21,     8,     9,    10,    11,
      12,    -1,    14,    15,    16,    -1,    -1,    -1,    -1,    21
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     1,    18,    25,    35,    36,    37,    39,    40,     6,
       5,    41,    42,     0,    36,     1,     5,     6,    38,    43,
      44,    23,    20,    19,     6,     7,    21,     1,    23,    47,
       1,    39,    50,    51,    20,    39,    45,    46,     5,    38,
       3,    24,    50,     6,    43,    52,    53,    24,    50,    43,
      20,     7,    22,     1,     3,     4,     5,    11,    17,    19,
      21,    26,    27,    29,    47,    48,    49,    54,     8,     6,
       7,    45,     6,    19,    54,    54,     1,    54,     1,    54,
      19,    19,    24,    48,     6,     8,     9,    10,    11,    12,
      13,    14,    15,    16,    21,    54,    52,    20,    54,    55,
      20,    20,    22,     6,    54,    54,    54,    54,    54,    54,
      54,    54,    54,    54,     5,    54,     7,    20,    20,    20,
      22,    55,    49,    49,    28,    49
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  However,
   YYFAIL appears to be in use.  Nevertheless, it is formally deprecated
   in Bison 2.4.2's NEWS entry, where a plan to phase it out is
   discussed.  */

#define YYFAIL		goto yyerrlab
#if defined YYFAIL
  /* This is here to suppress warnings from the GCC cpp's
     -Wunused-macros.  Normally we don't worry about that warning, but
     some users do, and we want to make it easy for users to remove
     YYFAIL uses, which will produce warnings from Bison 2.5.  */
#endif

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value, Location); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (!yyvaluep)
    return;
  YYUSE (yylocationp);
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep, YYLTYPE const * const yylocationp)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep, yylocationp)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
    YYLTYPE const * const yylocationp;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  YY_LOCATION_PRINT (yyoutput, *yylocationp);
  YYFPRINTF (yyoutput, ": ");
  yy_symbol_value_print (yyoutput, yytype, yyvaluep, yylocationp);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, YYLTYPE *yylsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yylsp, yyrule)
    YYSTYPE *yyvsp;
    YYLTYPE *yylsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       , &(yylsp[(yyi + 1) - (yynrhs)])		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, yylsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif


#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into *YYMSG, which is of size *YYMSG_ALLOC, an error message
   about the unexpected token YYTOKEN for the state stack whose top is
   YYSSP.

   Return 0 if *YYMSG was successfully written.  Return 1 if *YYMSG is
   not large enough to hold the message.  In that case, also set
   *YYMSG_ALLOC to the required number of bytes.  Return 2 if the
   required number of bytes is too large to store.  */
static int
yysyntax_error (YYSIZE_T *yymsg_alloc, char **yymsg,
                yytype_int16 *yyssp, int yytoken)
{
  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytoken]);
  YYSIZE_T yysize = yysize0;
  YYSIZE_T yysize1;
  enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
  /* Internationalized format string. */
  const char *yyformat = 0;
  /* Arguments of yyformat. */
  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
  /* Number of reported tokens (one for the "unexpected", one per
     "expected"). */
  int yycount = 0;

  /* There are many possibilities here to consider:
     - Assume YYFAIL is not used.  It's too flawed to consider.  See
       <http://lists.gnu.org/archive/html/bison-patches/2009-12/msg00024.html>
       for details.  YYERROR is fine as it does not invoke this
       function.
     - If this state is a consistent state with a default action, then
       the only way this function was invoked is if the default action
       is an error action.  In that case, don't check for expected
       tokens because there are none.
     - The only way there can be no lookahead present (in yychar) is if
       this state is a consistent state with a default action.  Thus,
       detecting the absence of a lookahead is sufficient to determine
       that there is no unexpected or expected token to report.  In that
       case, just report a simple "syntax error".
     - Don't assume there isn't a lookahead just because this state is a
       consistent state with a default action.  There might have been a
       previous inconsistent state, consistent state with a non-default
       action, or user semantic action that manipulated yychar.
     - Of course, the expected token list depends on states to have
       correct lookahead information, and it depends on the parser not
       to perform extra reductions after fetching a lookahead from the
       scanner and before detecting a syntax error.  Thus, state merging
       (from LALR or IELR) and default reductions corrupt the expected
       token list.  However, the list is correct for canonical LR with
       one exception: it will still contain any token that will not be
       accepted due to an error action in a later state.
  */
  if (yytoken != YYEMPTY)
    {
      int yyn = yypact[*yyssp];
      yyarg[yycount++] = yytname[yytoken];
      if (!yypact_value_is_default (yyn))
        {
          /* Start YYX at -YYN if negative to avoid negative indexes in
             YYCHECK.  In other words, skip the first -YYN actions for
             this state because they are default actions.  */
          int yyxbegin = yyn < 0 ? -yyn : 0;
          /* Stay within bounds of both yycheck and yytname.  */
          int yychecklim = YYLAST - yyn + 1;
          int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
          int yyx;

          for (yyx = yyxbegin; yyx < yyxend; ++yyx)
            if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR
                && !yytable_value_is_error (yytable[yyx + yyn]))
              {
                if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
                  {
                    yycount = 1;
                    yysize = yysize0;
                    break;
                  }
                yyarg[yycount++] = yytname[yyx];
                yysize1 = yysize + yytnamerr (0, yytname[yyx]);
                if (! (yysize <= yysize1
                       && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
                  return 2;
                yysize = yysize1;
              }
        }
    }

  switch (yycount)
    {
# define YYCASE_(N, S)                      \
      case N:                               \
        yyformat = S;                       \
      break
      YYCASE_(0, YY_("syntax error"));
      YYCASE_(1, YY_("syntax error, unexpected %s"));
      YYCASE_(2, YY_("syntax error, unexpected %s, expecting %s"));
      YYCASE_(3, YY_("syntax error, unexpected %s, expecting %s or %s"));
      YYCASE_(4, YY_("syntax error, unexpected %s, expecting %s or %s or %s"));
      YYCASE_(5, YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s"));
# undef YYCASE_
    }

  yysize1 = yysize + yystrlen (yyformat);
  if (! (yysize <= yysize1 && yysize1 <= YYSTACK_ALLOC_MAXIMUM))
    return 2;
  yysize = yysize1;

  if (*yymsg_alloc < yysize)
    {
      *yymsg_alloc = 2 * yysize;
      if (! (yysize <= *yymsg_alloc
             && *yymsg_alloc <= YYSTACK_ALLOC_MAXIMUM))
        *yymsg_alloc = YYSTACK_ALLOC_MAXIMUM;
      return 1;
    }

  /* Avoid sprintf, as that infringes on the user's name space.
     Don't have undefined behavior even if the translation
     produced a string with the wrong number of "%s"s.  */
  {
    char *yyp = *yymsg;
    int yyi = 0;
    while ((*yyp = *yyformat) != '\0')
      if (*yyp == '%' && yyformat[1] == 's' && yyi < yycount)
        {
          yyp += yytnamerr (yyp, yyarg[yyi++]);
          yyformat += 2;
        }
      else
        {
          yyp++;
          yyformat++;
        }
  }
  return 0;
}
#endif /* YYERROR_VERBOSE */

/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep, YYLTYPE *yylocationp)
#else
static void
yydestruct (yymsg, yytype, yyvaluep, yylocationp)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
    YYLTYPE *yylocationp;
#endif
{
  YYUSE (yyvaluep);
  YYUSE (yylocationp);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Location data for the lookahead symbol.  */
YYLTYPE yylloc;

/* Number of syntax errors so far.  */
int yynerrs;


/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.
       `yyls': related to locations.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    /* The location stack.  */
    YYLTYPE yylsa[YYINITDEPTH];
    YYLTYPE *yyls;
    YYLTYPE *yylsp;

    /* The locations where the error started and ended.  */
    YYLTYPE yyerror_range[3];

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;
  YYLTYPE yyloc;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N), yylsp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yyls = yylsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;
  yylsp = yyls;

#if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
  /* Initialize the default location before parsing starts.  */
  yylloc.first_line   = yylloc.last_line   = 1;
  yylloc.first_column = yylloc.last_column = 1;
#endif

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;
	YYLTYPE *yyls1 = yyls;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yyls1, yysize * sizeof (*yylsp),
		    &yystacksize);

	yyls = yyls1;
	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
	YYSTACK_RELOCATE (yyls_alloc, yyls);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;
      yylsp = yyls + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yypact_value_is_default (yyn))
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yytable_value_is_error (yyn))
        goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;
  *++yylsp = yylloc;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];

  /* Default location.  */
  YYLLOC_DEFAULT (yyloc, (yylsp - yylen), yylen);
  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

/* Line 1806 of yacc.c  */
#line 887 "syntax.y"
    {create(&(yyval.node),"Program",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));root=(yyval.node);}
    break;

  case 3:

/* Line 1806 of yacc.c  */
#line 889 "syntax.y"
    {create(&(yyval.node),"ExtDefList",(yylsp[(1) - (2)]).first_line);add((yyval.node),(yyvsp[(1) - (2)].node));add((yyval.node),(yyvsp[(2) - (2)].node));}
    break;

  case 4:

/* Line 1806 of yacc.c  */
#line 890 "syntax.y"
    {(yyval.node)=NULL;}
    break;

  case 5:

/* Line 1806 of yacc.c  */
#line 892 "syntax.y"
    {create(&(yyval.node),"ExtDef",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 6:

/* Line 1806 of yacc.c  */
#line 893 "syntax.y"
    {create(&(yyval.node),"ExtDef",(yylsp[(1) - (2)]).first_line);add((yyval.node),(yyvsp[(1) - (2)].node));add((yyval.node),(yyvsp[(2) - (2)].node));}
    break;

  case 7:

/* Line 1806 of yacc.c  */
#line 894 "syntax.y"
    {create(&(yyval.node),"ExtDef",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 8:

/* Line 1806 of yacc.c  */
#line 895 "syntax.y"
    {}
    break;

  case 9:

/* Line 1806 of yacc.c  */
#line 897 "syntax.y"
    {create(&(yyval.node),"ExtDecList",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 10:

/* Line 1806 of yacc.c  */
#line 898 "syntax.y"
    {create(&(yyval.node),"ExtDecList",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 11:

/* Line 1806 of yacc.c  */
#line 900 "syntax.y"
    {create(&(yyval.node),"Specifier",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 12:

/* Line 1806 of yacc.c  */
#line 901 "syntax.y"
    {create(&(yyval.node),"Specifier",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 13:

/* Line 1806 of yacc.c  */
#line 903 "syntax.y"
    {create(&(yyval.node),"StructSpecifier",(yylsp[(1) - (5)]).first_line);add((yyval.node),(yyvsp[(1) - (5)].node));add((yyval.node),(yyvsp[(2) - (5)].node));add((yyval.node),(yyvsp[(3) - (5)].node));add((yyval.node),(yyvsp[(4) - (5)].node));add((yyval.node),(yyvsp[(5) - (5)].node));}
    break;

  case 14:

/* Line 1806 of yacc.c  */
#line 904 "syntax.y"
    {create(&(yyval.node),"StructSpecifier",(yylsp[(1) - (2)]).first_line);add((yyval.node),(yyvsp[(1) - (2)].node));add((yyval.node),(yyvsp[(2) - (2)].node));}
    break;

  case 15:

/* Line 1806 of yacc.c  */
#line 906 "syntax.y"
    {create(&(yyval.node),"OptTag",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 16:

/* Line 1806 of yacc.c  */
#line 907 "syntax.y"
    {(yyval.node)=NULL;}
    break;

  case 17:

/* Line 1806 of yacc.c  */
#line 909 "syntax.y"
    {create(&(yyval.node),"Tag",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 18:

/* Line 1806 of yacc.c  */
#line 911 "syntax.y"
    {create(&(yyval.node),"VarDec",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 19:

/* Line 1806 of yacc.c  */
#line 912 "syntax.y"
    {create(&(yyval.node),"VarDec",(yylsp[(1) - (4)]).first_line);add((yyval.node),(yyvsp[(1) - (4)].node));add((yyval.node),(yyvsp[(2) - (4)].node));add((yyval.node),(yyvsp[(3) - (4)].node));add((yyval.node),(yyvsp[(4) - (4)].node));}
    break;

  case 20:

/* Line 1806 of yacc.c  */
#line 914 "syntax.y"
    {create(&(yyval.node),"FunDec",(yylsp[(1) - (4)]).first_line);add((yyval.node),(yyvsp[(1) - (4)].node));add((yyval.node),(yyvsp[(2) - (4)].node));add((yyval.node),(yyvsp[(3) - (4)].node));add((yyval.node),(yyvsp[(4) - (4)].node));}
    break;

  case 21:

/* Line 1806 of yacc.c  */
#line 915 "syntax.y"
    {create(&(yyval.node),"FunDec",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 22:

/* Line 1806 of yacc.c  */
#line 916 "syntax.y"
    {}
    break;

  case 23:

/* Line 1806 of yacc.c  */
#line 918 "syntax.y"
    {create(&(yyval.node),"VarList",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 24:

/* Line 1806 of yacc.c  */
#line 919 "syntax.y"
    {create(&(yyval.node),"VarList",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 25:

/* Line 1806 of yacc.c  */
#line 921 "syntax.y"
    {create(&(yyval.node),"ParamDec",(yylsp[(1) - (2)]).first_line);add((yyval.node),(yyvsp[(1) - (2)].node));add((yyval.node),(yyvsp[(2) - (2)].node));}
    break;

  case 26:

/* Line 1806 of yacc.c  */
#line 923 "syntax.y"
    {create(&(yyval.node),"CompSt",(yylsp[(1) - (4)]).first_line);add((yyval.node),(yyvsp[(1) - (4)].node));add((yyval.node),(yyvsp[(2) - (4)].node));add((yyval.node),(yyvsp[(3) - (4)].node));add((yyval.node),(yyvsp[(4) - (4)].node));}
    break;

  case 27:

/* Line 1806 of yacc.c  */
#line 924 "syntax.y"
    {}
    break;

  case 28:

/* Line 1806 of yacc.c  */
#line 926 "syntax.y"
    {create(&(yyval.node),"StmtList",(yylsp[(1) - (2)]).first_line);add((yyval.node),(yyvsp[(1) - (2)].node));add((yyval.node),(yyvsp[(2) - (2)].node));}
    break;

  case 29:

/* Line 1806 of yacc.c  */
#line 927 "syntax.y"
    {(yyval.node)=NULL;}
    break;

  case 30:

/* Line 1806 of yacc.c  */
#line 929 "syntax.y"
    {create(&(yyval.node),"Stmt",(yylsp[(1) - (2)]).first_line);add((yyval.node),(yyvsp[(1) - (2)].node));add((yyval.node),(yyvsp[(2) - (2)].node));}
    break;

  case 31:

/* Line 1806 of yacc.c  */
#line 930 "syntax.y"
    {create(&(yyval.node),"Stmt",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 32:

/* Line 1806 of yacc.c  */
#line 931 "syntax.y"
    {create(&(yyval.node),"Stmt",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 33:

/* Line 1806 of yacc.c  */
#line 932 "syntax.y"
    {create(&(yyval.node),"Stmt",(yylsp[(1) - (5)]).first_line);add((yyval.node),(yyvsp[(1) - (5)].node));add((yyval.node),(yyvsp[(2) - (5)].node));add((yyval.node),(yyvsp[(3) - (5)].node));add((yyval.node),(yyvsp[(4) - (5)].node));add((yyval.node),(yyvsp[(5) - (5)].node));}
    break;

  case 34:

/* Line 1806 of yacc.c  */
#line 933 "syntax.y"
    {create(&(yyval.node),"Stmt",(yylsp[(1) - (7)]).first_line);add((yyval.node),(yyvsp[(1) - (7)].node));add((yyval.node),(yyvsp[(2) - (7)].node));add((yyval.node),(yyvsp[(3) - (7)].node));add((yyval.node),(yyvsp[(4) - (7)].node));add((yyval.node),(yyvsp[(5) - (7)].node));add((yyval.node),(yyvsp[(6) - (7)].node));add((yyval.node),(yyvsp[(7) - (7)].node));}
    break;

  case 35:

/* Line 1806 of yacc.c  */
#line 934 "syntax.y"
    {create(&(yyval.node),"Stmt",(yylsp[(1) - (5)]).first_line);add((yyval.node),(yyvsp[(1) - (5)].node));add((yyval.node),(yyvsp[(2) - (5)].node));add((yyval.node),(yyvsp[(3) - (5)].node));add((yyval.node),(yyvsp[(4) - (5)].node));add((yyval.node),(yyvsp[(5) - (5)].node)); }
    break;

  case 36:

/* Line 1806 of yacc.c  */
#line 935 "syntax.y"
    {}
    break;

  case 37:

/* Line 1806 of yacc.c  */
#line 937 "syntax.y"
    {create(&(yyval.node),"DefList",(yylsp[(1) - (2)]).first_line);add((yyval.node),(yyvsp[(1) - (2)].node));add((yyval.node),(yyvsp[(2) - (2)].node));}
    break;

  case 38:

/* Line 1806 of yacc.c  */
#line 938 "syntax.y"
    {(yyval.node)=NULL;}
    break;

  case 39:

/* Line 1806 of yacc.c  */
#line 940 "syntax.y"
    {create(&(yyval.node),"Def",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 40:

/* Line 1806 of yacc.c  */
#line 941 "syntax.y"
    {}
    break;

  case 41:

/* Line 1806 of yacc.c  */
#line 943 "syntax.y"
    {create(&(yyval.node),"DecList",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 42:

/* Line 1806 of yacc.c  */
#line 944 "syntax.y"
    {create(&(yyval.node),"DecList",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 43:

/* Line 1806 of yacc.c  */
#line 946 "syntax.y"
    {create(&(yyval.node),"Dec",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 44:

/* Line 1806 of yacc.c  */
#line 947 "syntax.y"
    {create(&(yyval.node),"Dec",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 45:

/* Line 1806 of yacc.c  */
#line 949 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 46:

/* Line 1806 of yacc.c  */
#line 950 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 47:

/* Line 1806 of yacc.c  */
#line 951 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 48:

/* Line 1806 of yacc.c  */
#line 952 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 49:

/* Line 1806 of yacc.c  */
#line 953 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 50:

/* Line 1806 of yacc.c  */
#line 954 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 51:

/* Line 1806 of yacc.c  */
#line 955 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 52:

/* Line 1806 of yacc.c  */
#line 956 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 53:

/* Line 1806 of yacc.c  */
#line 957 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 54:

/* Line 1806 of yacc.c  */
#line 958 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (2)]).first_line);add((yyval.node),(yyvsp[(1) - (2)].node));add((yyval.node),(yyvsp[(2) - (2)].node));}
    break;

  case 55:

/* Line 1806 of yacc.c  */
#line 959 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (2)]).first_line);add((yyval.node),(yyvsp[(1) - (2)].node));add((yyval.node),(yyvsp[(2) - (2)].node));}
    break;

  case 56:

/* Line 1806 of yacc.c  */
#line 960 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (4)]).first_line);add((yyval.node),(yyvsp[(1) - (4)].node));add((yyval.node),(yyvsp[(2) - (4)].node));add((yyval.node),(yyvsp[(3) - (4)].node));add((yyval.node),(yyvsp[(4) - (4)].node));}
    break;

  case 57:

/* Line 1806 of yacc.c  */
#line 961 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 58:

/* Line 1806 of yacc.c  */
#line 962 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (4)]).first_line);add((yyval.node),(yyvsp[(1) - (4)].node));add((yyval.node),(yyvsp[(2) - (4)].node));add((yyval.node),(yyvsp[(3) - (4)].node));add((yyval.node),(yyvsp[(4) - (4)].node));}
    break;

  case 59:

/* Line 1806 of yacc.c  */
#line 963 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 60:

/* Line 1806 of yacc.c  */
#line 964 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 61:

/* Line 1806 of yacc.c  */
#line 965 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 62:

/* Line 1806 of yacc.c  */
#line 966 "syntax.y"
    {create(&(yyval.node),"Exp",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;

  case 63:

/* Line 1806 of yacc.c  */
#line 967 "syntax.y"
    {}
    break;

  case 64:

/* Line 1806 of yacc.c  */
#line 968 "syntax.y"
    {}
    break;

  case 65:

/* Line 1806 of yacc.c  */
#line 970 "syntax.y"
    {create(&(yyval.node),"Args",(yylsp[(1) - (3)]).first_line);add((yyval.node),(yyvsp[(1) - (3)].node));add((yyval.node),(yyvsp[(2) - (3)].node));add((yyval.node),(yyvsp[(3) - (3)].node));}
    break;

  case 66:

/* Line 1806 of yacc.c  */
#line 971 "syntax.y"
    {create(&(yyval.node),"Args",(yylsp[(1) - (1)]).first_line);add((yyval.node),(yyvsp[(1) - (1)].node));}
    break;



/* Line 1806 of yacc.c  */
#line 2858 "syntax.tab.c"
      default: break;
    }
  /* User semantic actions sometimes alter yychar, and that requires
     that yytoken be updated with the new translation.  We take the
     approach of translating immediately before every use of yytoken.
     One alternative is translating here after every semantic action,
     but that translation would be missed if the semantic action invokes
     YYABORT, YYACCEPT, or YYERROR immediately after altering yychar or
     if it invokes YYBACKUP.  In the case of YYABORT or YYACCEPT, an
     incorrect destructor might then be invoked immediately.  In the
     case of YYERROR or YYBACKUP, subsequent parser actions might lead
     to an incorrect destructor call or verbose syntax error message
     before the lookahead is translated.  */
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;
  *++yylsp = yyloc;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* Make sure we have latest lookahead translation.  See comments at
     user semantic actions for why this is necessary.  */
  yytoken = yychar == YYEMPTY ? YYEMPTY : YYTRANSLATE (yychar);

  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
# define YYSYNTAX_ERROR yysyntax_error (&yymsg_alloc, &yymsg, \
                                        yyssp, yytoken)
      {
        char const *yymsgp = YY_("syntax error");
        int yysyntax_error_status;
        yysyntax_error_status = YYSYNTAX_ERROR;
        if (yysyntax_error_status == 0)
          yymsgp = yymsg;
        else if (yysyntax_error_status == 1)
          {
            if (yymsg != yymsgbuf)
              YYSTACK_FREE (yymsg);
            yymsg = (char *) YYSTACK_ALLOC (yymsg_alloc);
            if (!yymsg)
              {
                yymsg = yymsgbuf;
                yymsg_alloc = sizeof yymsgbuf;
                yysyntax_error_status = 2;
              }
            else
              {
                yysyntax_error_status = YYSYNTAX_ERROR;
                yymsgp = yymsg;
              }
          }
        yyerror (yymsgp);
        if (yysyntax_error_status == 2)
          goto yyexhaustedlab;
      }
# undef YYSYNTAX_ERROR
#endif
    }

  yyerror_range[1] = yylloc;

  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval, &yylloc);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  yyerror_range[1] = yylsp[1-yylen];
  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (!yypact_value_is_default (yyn))
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;

      yyerror_range[1] = *yylsp;
      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp, yylsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;

  yyerror_range[2] = yylloc;
  /* Using YYLLOC is tempting, but would change the location of
     the lookahead.  YYLOC is available though.  */
  YYLLOC_DEFAULT (yyloc, yyerror_range, 2);
  *++yylsp = yyloc;

  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
    {
      /* Make sure we have latest lookahead translation.  See comments at
         user semantic actions for why this is necessary.  */
      yytoken = YYTRANSLATE (yychar);
      yydestruct ("Cleanup: discarding lookahead",
                  yytoken, &yylval, &yylloc);
    }
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp, yylsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}



/* Line 2067 of yacc.c  */
#line 975 "syntax.y"

yyerror(char* msg){
	iscorrect=1;
    	fprintf(stderr,"Error type B at line %d : %s\n",yylineno,"Syntax error");
}

