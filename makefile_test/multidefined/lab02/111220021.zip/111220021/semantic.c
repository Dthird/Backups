/*
	语义分析相关代码	
*/

typedef int bool;		// bool类型定义
typedef unsigned int Index;	// 散列表访问下标
#define TRUE 1
#define FALSE 0
#define BASIC 0
#define ARRAY 1
#define STRUCTURE 2
#define TABLE_SIZE (1 << 14)		// 散列表大小(2^14)
#define INT_TYPE 0			// 基本类型
#define FLOAT_TYPE 1
#define MAX_NEST_LEVEL 1024		// 顺序栈大小(最大嵌套层次)

#include "tree.h"
#include <stdlib.h>		// malloc()
#include <stdio.h>		// perror(),printf()
#include <string.h>		// strcmp()
#include <assert.h>

unsigned int 
hash_pjw(char* name)
{
	unsigned int val = 0,i;
	for( ; *name; ++name)
	{
		val = (val << 2) + *name;
		if(i = val & ~0x3fff)
			val = (val ^ (i >> 12)) & 0x3fff;
	}
	
	return val;
}

typedef struct Type_* Type;
typedef struct FieldList_* FieldList;
typedef struct FuncEntry_* FuncEntry;
typedef struct LevelList_* LevelList;


FuncEntry  FuncTb[TABLE_SIZE];		// 函数名符号表
FieldList  VarTb[TABLE_SIZE];		// 变量名符号表
FieldList Stack[MAX_NEST_LEVEL];	// 用于处理嵌套层次的栈结构
int top;				// 栈顶指针(即当前所处的嵌套层次)

struct Type_
{
	enum { BASIC_, ARRAY_, STRUCTURE_ }  kind;
	union
	{
		// 基本类型
		int basic;
		// 数组类型信息：元素类型，数组大小
		struct { Type elem; int size; } array;
		// 结构体类型信息是一个链表
		FieldList structure;
	} u;
} ;

struct FieldList_
{
	char *name;		// 域的名字
	Type type;		// 域的类型
	int level;		// 变量定义时所处的嵌套层次
	FieldList tail;		// 下一个域指针
	FieldList next;		// 同嵌套级别的指针
};

struct FuncEntry_
{
	char *name;		// 函数名
	Type retType;		// 返回类型
	int numOfArgs;		// 参数个数
	Type* argsTypes;	// 参数类型
	FuncEntry tail;		// 下一个域指针
	FuncEntry next;
};

Type IntType;		// int常量类型
Type FloatType;		// float常量类型
Type latestRetType;	// 最新定义的函数的返回值类型

Type getType(struct TreeNode* specifier);
Type getType2(struct TreeNode* pSpecifier,struct TreeNode* pVarDec);
Type getExpType(struct TreeNode *pExp);
FuncEntry getFuncEntry(struct TreeNode* pID);

bool isTypesEqual(Type t1,Type t2);
Type typeCopy(Type srcType);		// 结构体类型深度复制
void freeType(Type type);		// 释放申请的内存空间
/*
	全局栈的初始化函数
*/


void
Init()
{
	IntType = (Type)malloc(sizeof(struct Type_));
	FloatType = (Type)malloc(sizeof(struct Type_));
	assert(IntType != NULL && FloatType != NULL);
	IntType->kind = BASIC;
	IntType->u.basic = INT_TYPE;
	FloatType->kind = BASIC;
	FloatType->u.basic = FLOAT_TYPE;
	
	top = 0;	// 栈顶初始化指针
	Stack[top] = NULL;
}


/* 
	变量(int/float, struct ,array)符号表查询
	name: 标识符字符串
	Type: NULL:本层之内有重名
	      否则返回类型
*/
Type 
LookUpVar(char *name)
{
	assert(name != NULL);
	FieldList vp = VarTb[hash_pjw(name)];		// 桶内链表扫描指针
	while(vp != NULL)
	{
		if(strcmp(vp->name,name) == 0)
		{
			assert(vp->type != NULL);
			return vp->type;
		}
		vp = vp->tail;
	}
	
	return NULL;	
}
/*
	
*/
bool
LookUpFunc(char *name)
{
	assert(name != NULL);
	FuncEntry vp = FuncTb[hash_pjw(name)];		// 桶内链表扫描指针
	while(vp != NULL)
	{
		if(strcmp(vp->name,name) == 0)
			return TRUE;
		vp = vp->tail;
	}
	return FALSE;	
}
/*
	取函数返回值类型
*/
Type getRetType(struct TreeNode* pID)
{
	assert(strcmp(pID->nodeType,"ID") == 0);
	FuncEntry vp = FuncTb[hash_pjw(pID->type_string)];		// 桶内链表扫描指针
	while(vp != NULL)
	{
		if(strcmp(vp->name,pID->type_string) == 0)
			return vp->retType;
		vp = vp->tail;
	}
	
	return NULL;	
}

/*
	变量符号表插入
	name:
	type:
	level:嵌套的层次
*/
void 
InsertVar(char *name,Type type,int level)
{
	assert(name != NULL);
	Index index = -1;
	FieldList vp = NULL;
	FieldList newEntry = NULL;
	
	index = hash_pjw(name);
	vp = VarTb[index];
	newEntry = (FieldList)malloc(sizeof(struct FieldList_));	// *************************************
	newEntry->name = (char *)malloc(strlen(name) + 1);	// 注意一个结束字符'\0'
	assert(newEntry != NULL);
	assert(newEntry->name != NULL);
	strcpy(newEntry->name,name);				// 名字拷贝
	newEntry->type = type;						// ************************************浅复制
	newEntry->level = level;
	
	if(vp == NULL)	// 从表头插入
	{
		VarTb[index] = newEntry;
		newEntry->tail = NULL;
	}
	else
	{
		newEntry->tail = VarTb[index]->tail;
		VarTb[index] = newEntry;
	}
	
	if(Stack[top] == NULL)	
	{
		Stack[top] = newEntry;
		newEntry->next = NULL;
	}
	else		// 从栈列表的头部插入
	{
		newEntry->next = Stack[top]->next;
		Stack[top]->next = newEntry;
	}
	//printf("--------------------成功向变量表插入变量[%s],所处的嵌套层次为[%d]\n",name,level);	
}
/*
	进入一个新的嵌套层
*/
void
EnterALevel()
{
	top++;
	assert(top < MAX_NEST_LEVEL);
	Stack[top] = NULL;
}
/*
	退出一个嵌套层
*/
/*
void 
OutALevel(FieldList p)
{
	if(p == NULL)		// 空链表
		return ;
	if(p->next == NULL)	// 只有一个元素
		deleteVar(p);
	else
		OutALevel(p->next);	// 递归删除表头外的节点
	//deleteVar(p);		// 删除头节点
}
*/
/*
	函数符号表插入
*/
void 
InsertFunc(char *name,Type retType,int numOfArgs,Type* argsTypes)
{
	assert(name != NULL);
	FuncEntry newEntry = NULL;
	Index index = hash_pjw(name);
	FuncEntry vp = FuncTb[index];
	
	newEntry = (FuncEntry)malloc(sizeof(struct FuncEntry_));	// *************************************
	newEntry->name = (char *)malloc(strlen(name) + 1);	// 注意一个结束字符'\0'
	assert(newEntry != NULL);
	assert(newEntry->name != NULL);
	strcpy(newEntry->name,name);				// 名字拷贝
	newEntry->retType = retType;
	newEntry->numOfArgs = numOfArgs;
	newEntry->argsTypes = argsTypes;			// ************************************浅复制
				
	if(vp == NULL)	// 从表头插入
	{
		FuncTb[index] = newEntry;
		newEntry->tail = NULL;
	}
	else
	{
		newEntry->tail = FuncTb[index]->tail;
		FuncTb[index] = newEntry;
	}
	
	latestRetType = retType;    // 修改最新的函数的返回值类型
	assert(latestRetType != NULL);
	
	//printf("******************成功向函数名符号表插入函数名[%s]\n",name);
}

/*
	扫描语法树并创建符号表
*/

void 
semanticAnalysis(struct TreeNode *root)
{
	TreeNode *p = NULL, *pName = NULL, *pTemp = NULL,*pVarList,*pID,*pVarDec,*pDecList;
	char *name = NULL;
	Type type;
	int i;
	
	
	if(root == NULL)
		return ;
	if(root->isLeaf)	// 叶子节点直接返回
		return ;
	
	if(root->numOfChilds > 0)	// 非叶子节点,且要产生式体非空
	{
		switch(root->type)
		{
		case EXTDEF:
			//printf("------------------IN EXTDEF------------------\n");
			switch(root->childs[1]->type)	
			{
				case EXTDECLIST:	/* 全局变量的定义：ExtDef -> Specifier ExtDecList SEMI */
					//printf("------------------IN EXTDECLIST------------------\n");
					p = root->childs[1];
					assert(p->type == EXTDECLIST);
					while(1)
					{
						pID = p->childs[0]->childs[0];
						while(strcmp(pID->nodeType,"ID") != 0)
							pID = pID->childs[0];
						//printf("************找到的变量名:[%s]\n",pID->type_string);
						if(LookUpVar(pID->type_string) != NULL)	// 变量重定义
							printf("Error Type 3 at line %d: Redifined variable \"%s\"\n",
								pID->lineno,pID->type_string);
						else		// 新出现的变量插入表中
							InsertVar(pID->type_string,getType(root->childs[0]),top);
						if(p->numOfChilds == 1)
							break;
						p = p->childs[2];
						assert(strcmp(p->nodeType,"ExtDecList") == 0);
					}
					
					break;
				case FUNDEC:	// ExtDef -> Specifier FunDec CompSt 函数的定义
					//printf("------------------IN FUNDEC------------------\n");
					pID = root->childs[1]->childs[0];
					assert(strcmp(root->childs[1]->nodeType,"FunDec") == 0);
					assert(strcmp(pID->nodeType,"ID") == 0);
		
					if(LookUpFunc(pID->type_string))
						printf("Error Type 4 at line %d: Redifined function \"%s\"\n",pID->lineno,pID->type_string);
					else
					{
						int numOfArgs = 0;
						Type *argsTypes = NULL;
						if(root->childs[1]->numOfChilds == 4)	// 函数参数列表非空
						{
							pTemp = pVarList = root->childs[1]->childs[2];
							assert(pVarList->type == VARLIST);
							numOfArgs = 1;
							while(pTemp->numOfChilds == 3)		// 计算函数列表中参数个数
							{
								assert(pTemp->type == VARLIST);
								numOfArgs ++;
								pTemp = pTemp->childs[2];
							}
							//printf("************函数参数个数:[%d]\n",numOfArgs);
							argsTypes = (Type *)malloc(sizeof(Type) * numOfArgs);
							assert(argsTypes != NULL);	
							i = 0;
					
							while(1)	// 计算函数列表中参数类型
							{
								assert(pVarList->type == VARLIST);			
								argsTypes[i] = getType2(pVarList->childs[0]->childs[0],pVarList->childs[0]->childs[1]);
								pVarDec = pVarList->childs[0]->childs[1];
								assert(pVarDec->type == VARDEC);
								while(pVarDec->numOfChilds == 4)
									pVarDec = pVarDec->childs[0];
								assert(strcmp(pVarDec->childs[0]->nodeType,"ID") == 0);
								// 将形式参数列表中的变量定义插入,注意level的设定[NOT FINISHED,没有进行重复性检查]
								InsertVar(pVarDec->childs[0]->type_string,argsTypes[i],top + 1); 
				
								i++;
								if(pVarList->numOfChilds == 1)
									break;
								pVarList = pVarList->childs[2];
							}
				
				
						} // 否则为没有参数的函数
			
						InsertFunc(pID->type_string,getType(root->childs[0]),numOfArgs,argsTypes);
					}
		
					assert(root->childs[2]->type == COMPST);
					semanticAnalysis(root->childs[2]);
					break;
					
				default:	// 结构体定义，忽略Specifier->TYPE
					if(root->childs[0]->childs[0]->type == STRUCTSPECIFIER)
						getType(root->childs[0]);			
			}
			
			break;
		case COMPST:
			//printf("------------------IN COMPST------------------\n");
			/*
				遇到左花括号 [NOT FINISHED]
			*/
			top ++;
			semanticAnalysis(root->childs[1]);		// CompSt中的DefList;
			semanticAnalysis(root->childs[2]);		// CompSt中的StmtList
			/*
				遇到左花括号 [NOT FINISHED]
			*/
			top --;
			break;
		
		case DEF:	// Def -> Specifier DecList SEMI
			//printf("------------------IN DEF------------------\n");
			pDecList = root->childs[1];
			while(1)
			{
				assert(pDecList->type == DECLIST);
				pVarDec = pDecList->childs[0]->childs[0];
				{
					/*
						这里可能有 Dec -> VarDec ASSIGNOP Exp
						[NOT FINISHED]
					*/
				}
				assert(pVarDec->type == VARDEC);
				while(pVarDec->numOfChilds == 4)	/* VarDec-> VarDec LB INT RB */
					pVarDec = pVarDec->childs[0];
				pID = pVarDec->childs[0];		// VarDec -> ID
				assert(strcmp(pID->nodeType,"ID") == 0);
				if(LookUpVar(pID->type_string) != NULL)	// 局部变量重复定
					printf("Error type 3 at line %d: Redifined variable \"%s\"\n",pID->lineno,pID->type_string);
				else
					InsertVar(pID->type_string,getType2(root->childs[0],pDecList->childs[0]->childs[0]),top);
				
				if(pDecList->numOfChilds == 1)
					break;
				else
				{
					assert(pDecList->numOfChilds == 3);
					pDecList = pDecList->childs[2];
				}
				
			}
			break;
		case EXP:
			//printf("------------------IN EXP------------------\n");
			getExpType(root);
			break;
		
		case STMT:	// 函数返回值类型检查[Type 8]
			//printf("------------------IN STMT------------------\n");
			if(root->numOfChilds == 3 && strcmp(root->childs[0]->nodeType,"RETURN") == 0) // Stmt -> RETURN Exp SEMI
			{
				type = getExpType(root->childs[1]);
				if(type == NULL)
					return ;
				if(!isTypesEqual(type,latestRetType))
					printf("Error type 8 at line %d: The return type missmatched\n",root->childs[1]->lineno);
					
				return ;
			}
			else if(root->numOfChilds == 1 && strcmp(root->childs[0]->nodeType,"COMPST") == 0) // Stmt -> CompSt
				semanticAnalysis(root->childs[0]);
			else
			{
				for(i = 0;i < root->numOfChilds;i++)		// 递归处理子节点
					semanticAnalysis(root->childs[i]);
			}
			
			break;
			
		default:
			//printf("------------------IN DEFAULT ------------------\n");
			//printf("NodeType:[%s]\n",root->nodeType);
			for(i = 0;i < root->numOfChilds;i++)		// 递归处理子节点
			{
				semanticAnalysis(root->childs[i]);
			}
			
		}
	}

}

/*
	获取表达式类型
*/
Type getExpType(struct TreeNode *pExp)
{
	//printf("In function [getExpType]\n");
	assert(pExp->type == EXP);
	Type type1,type2,type;
	struct TreeNode *pID,*pTemp;
	char* fieldName;
		
	if(pExp->numOfChilds == 1 && strcmp(pExp->childs[0]->nodeType,"INT") == 0) // Exp -> INT:整形常量
	{
		//printf("Exp -> INT:整形常量\n");
		return IntType;
	}
	else if(pExp->numOfChilds == 1 && strcmp(pExp->childs[0]->nodeType,"FLOAT") == 0)// Exp -> FLOAT:浮点型常量
	{
		//printf("Exp -> FLOAT:浮点型常量\n");
		return FloatType;
	}
	else if(pExp->numOfChilds == 1 && strcmp(pExp->childs[0]->nodeType,"ID") == 0)	// Exp -> ID: 普通变量
	{
		//printf("搜索的变量:%s\n",pExp->childs[0]->type_string);
		pID = pExp->childs[0];
		if((type = LookUpVar(pID->type_string)) == NULL)
			printf("Error type 1 at line %d: Undefined variable \"%s\"\n",pID->lineno,pID->type_string);
		return type;
	}
	else if(pExp->numOfChilds >= 3 && strcmp(pExp->childs[0]->nodeType,"ID") == 0) // Exp -> ID LP RP: 函数调用(无参)
	{
		
		pID = pExp->childs[0];
		if(!LookUpFunc(pID->type_string))
		{
			if(LookUpVar(pID->type_string) == NULL)
				printf("Error type 2 at line %d: Undefined function \"%s\"\n",pID->lineno,pID->type_string);
			else
				printf("Error type 11 at line %d: \"%s\" must be a function\n",pID->lineno,pID->type_string);
			return NULL;
		}
		else
		{
			FuncEntry pEntry = getFuncEntry(pID);
			assert(pEntry != NULL);
			int numOfArgs = 0;
			if(pExp->numOfChilds == 4)	// 含参调用
			{
				numOfArgs = 1;
				pTemp = pExp->childs[2];
				assert(pTemp->type == ARGS);
				while(pTemp->numOfChilds == 3)
				{
					numOfArgs ++;
					pTemp = pTemp->childs[2];
				}
			}
			if(numOfArgs != pEntry->numOfArgs)	// 参数个数不匹配
				printf("Error type 9 at line %d: Num of arguments not matched\n",pExp->childs[2]->lineno);
			
			else if(numOfArgs != 0)				// 参数类型逐个检查
			{
				int i = 0;
				pTemp = pExp->childs[2];
				assert(pTemp->type == ARGS);
				while(pTemp->numOfChilds == 3)
				{
					if(!isTypesEqual(pEntry->argsTypes[i],getExpType(pTemp->childs[0]))) // Args -> Exp COMMA Args
					{
						printf("Error type 9 at line %d: Argument type not matched\n",pTemp->lineno);
						break;
					}
					pTemp = pTemp->childs[2];
					i++;
				}
				if(!isTypesEqual(pEntry->argsTypes[i],getExpType(pTemp->childs[0])))  // Args -> Exp
					printf("Error type 9 at line %d: Argument type not matched\n",pTemp->lineno);
			}
			
		}
		return getRetType(pExp->childs[0]);		// 返回 函数的返回值类型
	}
	else if(pExp->numOfChilds == 3 && strcmp(pExp->childs[1]->nodeType,"ASSIGNOP") == 0) // Exp -> Exp ASSIGNOP EXP
	{
		//printf(" Exp -> Exp ASSIGNOP EXP\n");
		pTemp = pExp->childs[0];
		// 左值检查 
		if(!((pTemp->numOfChilds == 1 && strcmp(pTemp->childs[0]->nodeType,"ID") == 0)	//ID
		     || (pTemp->numOfChilds == 4 && strcmp(pTemp->childs[1]->nodeType,"LB") == 0)  //Exp LB Exp RB
		     || (pTemp->numOfChilds == 3 && strcmp(pTemp->childs[1]->nodeType,"DOT") == 0))) // Exp Dot ID
		{
			printf("Error type 6 at line %d: The left-hand side of an assignment must be L-value\n",pTemp->lineno);
			return NULL;
		}
		
		//赋值号两边类型检查[假设赋值号两边仅出现INT/FLOAT类型]
		type1 = getExpType(pExp->childs[0]);
		type2 = getExpType(pExp->childs[2]);
		
		if(type1 == NULL || type2 == NULL)	// 底层若出错，则本层不再检查
			return NULL;
		
		if(type1->kind == BASIC && type2->kind == BASIC && type1->u.basic == type2->u.basic)
			return type1;
			
		printf("Error type 5 at line %d: Type missmatched\n",pExp->lineno);
		return NULL;	
		
	}
	else if((pExp->numOfChilds == 2 && strcmp(pExp->childs[0]->nodeType,"MINUS") == 0)	// Exp -> MINUS Exp,算术运算符：取负,+/-/*/除
		|| pExp->numOfChilds == 3 && (strcmp(pExp->childs[1]->nodeType,"PLUS") == 0 	// Exp -> EXP PLUS EXP
					   || strcmp(pExp->childs[1]->nodeType,"MINUS") == 0	// Exp -> EXP MINUS EXP 
					   || strcmp(pExp->childs[1]->nodeType,"STAR") == 0	// Exp -> EXP STAR EXP
					   || strcmp(pExp->childs[1]->nodeType,"DIV") == 0)) 	// Exp -> EXP DIV EXP
	{
		/* 只有int和float类型才能执行算术运算[根据假设2] */
		//printf("算术运算操作\n");
		if(pExp->numOfChilds == 2)	// Exp -> MINUS Exp
		{
			type = getExpType(pExp->childs[1]);
			if(type == NULL)
				return NULL;
			if(type->kind == BASIC)
				return type;	
					
			printf("Error type 7 at line %d: Operands type missmatched\n",pExp->childs[1]->lineno);
			return NULL;
		}
		
		type1 = getExpType(pExp->childs[0]);
		type2 = getExpType(pExp->childs[2]);
	
		if(type1 == NULL || type2 == NULL)	// 底层若出错，则本层不再检查
			return NULL;
			
		if(type1->kind == BASIC && type2->kind == BASIC && type1->u.basic == type2->u.basic)
			return type1;
		
		printf("Error type 7 at line %d: Operands type missmatched\n",pExp->lineno);
		return NULL;
	}
	else if(pExp->numOfChilds == 4 && strcmp(pExp->childs[1]->nodeType,"LB") == 0) // Exp -> Exp LB Exp RB,数组访问
	{
		//printf("Exp -> Exp LB Exp RB\n");
		type1 = getExpType(pExp->childs[0]);
		type2 = getExpType(pExp->childs[2]);
		
		if(type1 == NULL || type2 == NULL)	// 底层若出错，则本层不再检查
			return NULL;
		
		if(type1->kind == ARRAY && type2->kind == BASIC && type2->u.basic == INT_TYPE)
			return type1->u.array.elem;			// [注意 :降一个维度]
			
		if(type1->kind != ARRAY)
			printf("Error type 10 at line %d: Illegal use of \"[]\"\n",pExp->childs[0]->lineno);
		
		if(!(type2->kind == BASIC && type2->u.basic == INT_TYPE))
			printf("Error type 12 at line %d: Operands type mistaken\n",pExp->childs[2]->lineno);	
		
		return 	NULL;
	}
	else if(pExp->numOfChilds == 3 && strcmp(pExp->childs[1]->nodeType,"DOT") == 0) // Exp -> Exp DOT ID,结构体访问
	{
		//printf("Exp -> Exp DOT ID\n");
		
		type1 = getExpType(pExp->childs[0]);
		if(type1 == NULL)		// 底层若出错，则本层不再检查
			return NULL;
			
		if(type1->kind != STRUCTURE)
		{																								
			printf("Error type 13 at line %d: Illegal use of \".\"\n",pExp->childs[1]->lineno);
			return NULL;
		}
		fieldName = pExp->childs[2]->type_string;
		FieldList p = type1->u.structure;
		
		while(p != NULL)
		{
			if(strcmp(p->name,fieldName) == 0)
				return p->type;
			p = p->tail;
		}
		
		printf("Error type 14 at line %d: Unexisted field \"%s\"\n",pExp->childs[2]->lineno,fieldName);
		return NULL;
	}
	else if(pExp->numOfChilds == 3 && strcmp(pExp->childs[1]->nodeType,"RELOP") == 0) // Exp -> Exp RELOP Exp 关系操作符
	{
		/* 这里应该不会到来*/
		//printf("Exp -> Exp RELOP Exp\n");
		type1 = getExpType(pExp->childs[0]);
		type2 = getExpType(pExp->childs[2]);
		
		if(type1 == NULL || type2 == NULL)
			return NULL;
		
		return type1;
	}
	else if(pExp->numOfChilds == 3 && strcmp(pExp->childs[0]->nodeType,"LP") == 0) // Exp -> LP Exp RP 括号
	{
		return getExpType(pExp->childs[1]);
	}
	else if(pExp->numOfChilds >= 2 && (strcmp(pExp->childs[1]->nodeType,"AND") == 0  // Exp -> Exp AND Exp 逻辑操作符[假设2]
					|| strcmp(pExp->childs[1]->nodeType,"OR")	 // Exp -> Exp OR Exp 
					|| strcmp(pExp->childs[0]->nodeType,"NOT")))	 // Exp -> NOT Exp 
	{
		if(pExp->numOfChilds == 3)	// &&,||
		{
			type1 = getExpType(pExp->childs[0]);
			type2 = getExpType(pExp->childs[2]);
			
			if(type1 == NULL || type2 == NULL)	// 底层若出错，则本层不再检查
				return NULL;
			
			if(type1->kind == BASIC && type2->kind == BASIC && type1->u.basic == INT_TYPE && type2->u.basic == INT_TYPE)
				return type1;
	
			printf("Error type 7 at line %d: Operands type missmatched\n",pExp->lineno);
			return NULL;
		}
		else	 // Exp -> NOT Exp 
		{
			type = getExpType(pExp->childs[1]);
			if(type == NULL)
				return NULL;
				
			if(type->kind == BASIC || type->u.basic == INT_TYPE)
				return type;
				
			printf("Error type 7 at line %d: Operands type missmatched\n",pExp->lineno);
			return NULL;
		}
	}
	
	printf("Program wrong ,here should never be reached!\n");
	assert(0);
}
/*
	取函数的参数列表
*/
FuncEntry
getFuncEntry(struct TreeNode* pID)
{
	assert(strcmp(pID->nodeType,"ID") == 0);
	FuncEntry vp = FuncTb[hash_pjw(pID->type_string)];		// 桶内链表扫描指针
	while(vp != NULL)
	{
		if(strcmp(vp->name,pID->type_string) == 0)
			return vp;
		vp = vp->tail;
	}
	
	return NULL;
}
/*
	计算数据类型
	Specifier的可能来源：
	ExtDef -> Specifier ExtDecList SEMI 	// 全局变量定义
		｜Specifier SEMI		// 结构体定义
		｜Specifier FunDec CompSt	// 函数返回值定义(可以顺带定义结构体类型)
	ParamDec -> Specifier VarDec		// 函数形参定义列表(可以顺带定义结构体类型)
	Def ->	Specifier DecList SEMI		// 局部变量定义
	
*/
Type getType(struct TreeNode* specifier)
{
	//printf("***************In Function getType***************\n");
	assert(specifier->type == SPECIFIER);
	struct TreeNode *p,*pTemp,*pDefList,*pDecList,*pDec,*pVarDec,*pID,*pSpecifier;
	FieldList pField = NULL;	// 结构体域扫描指针
	Type pArray = NULL;
	char *name = NULL;
	Type type = (Type)malloc(sizeof(struct Type_));
	assert(type != NULL);
	if(strcmp(specifier->childs[0]->nodeType,"TYPE") == 0)	// Specifier -> TYPE
	{
		type->kind = BASIC;
		type->u.basic = (strcmp(specifier->childs[0]->type_string,"int") == 0) ? INT_TYPE : FLOAT_TYPE;
		return type;
	}
	
	assert(specifier->childs[0]->type == STRUCTSPECIFIER);	// Specifier ->StructSpecifier
	p = specifier->childs[0];	// p == StructSpecifier
	if(p->numOfChilds == 2)	// StructSpecifier -> STRUCT Tag; [注：这中写法在定义时也是可以的(域为空，但是这种情况没有意义)]
	{			// 所以一律将这种情况看作结构类型的使用
		p = p->childs[1]->childs[0];
		assert(strcmp(p->nodeType,"ID") == 0);
		type = LookUpVar(p->type_string);
		if(type == NULL)	//使用的结构类型没有定义
			printf("Error Type 17 at line %d: Undefined struct \'%s\'\n",p->lineno,p->type_string);
		else			//否则返回已定义的结构体类型[返回的是新的私有的地址空间]
			return typeCopy(type);		
	}
	else	// StructSpecifier -> STRUCT OptTag LC DefList RC; 结构体类型的定义
	{
		if(p->childs[1]->numOfChilds == 1) // OptTag -> ID
		{
			pTemp = p->childs[1]->childs[0];
			assert(strcmp(pTemp->nodeType,"ID") == 0);
			if(LookUpVar(pTemp->type_string) != NULL)
				printf("Error Type 16 at line %d: Dulplicated name \'%s\'\n",pTemp->lineno,pTemp->type_string);							
			else	
				name = pTemp->type_string;	// 新结构体的名字
		}
		
		/*下面填写结构体的类型*/				
		type->kind = STRUCTURE;
		pDefList = p->childs[3];
		assert(pDefList->type == DEFLIST);
		if(pDefList->numOfChilds == 0)	/*DefList -> 空 结构体的域为空*/
		{
			//printf("结构体\'%s\'(at line %d)的域为空\n",pTemp->type_string,pTemp->lineno);
			type->u.structure = NULL;
			if(p->childs[1]->numOfChilds == 1 && name != NULL) // OptTag -> ID:非匿名结构体,加入符号表[注意：当结构体重名时不插入符号表]
				InsertVar(name,type,top);
			return type;
			
		}
		
		/* 以下处理结构体域非空： DefList -> Def DefList */
	
		type->u.structure = NULL;		// 初始化
	
		while(pDefList->numOfChilds == 2)	// DefList -> Def DefList
		{
			pSpecifier = pDefList->childs[0]->childs[0];
			pDecList = pDefList->childs[0]->childs[1];	
			assert(pDecList->type == DECLIST && pSpecifier->type == SPECIFIER);
			while(1)
			{
				if(type->u.structure == NULL)
				{
					type->u.structure = (FieldList)malloc(sizeof(struct FieldList_));
					pField = type->u.structure;	// pField指向当前处理的结构体域
				}
				else
				{
					pField->tail = (FieldList)malloc(sizeof(struct FieldList_));
					pField = pField->tail;
				}
				pField->tail = NULL;
				
				assert(pField != NULL);
				
				pDec = pDecList->childs[0];
				assert(pDec->type == DEC);
				if(pDec->numOfChilds == 3) // Dec -> VarDec ASSIGNOP EXP
					printf("Error Type 15 at line %d: Structure filed can't be initialized when during structure's definition\n",pDec->lineno);
								
				pVarDec = pDec->childs[0];
				assert(pVarDec->type == VARDEC);
				
				pField->type = getType2(pSpecifier,pVarDec);	// 计算每个结构体域的类型
				
				while(pVarDec->numOfChilds == 4)
					pVarDec = pVarDec->childs[0];
					
				pID = pVarDec->childs[0];
				
				FieldList t = type->u.structure;
				while(t->tail != NULL)
				{
					if(strcmp(t->name,pID->type_string) == 0)
					{
						printf("Error Type 15 at line %d: Redifined field \'%s\'\n",pID->lineno,pID->type_string);
						break;
					}
					t = t->tail;
				}
				
				assert(strcmp(pID->nodeType,"ID") == 0);
				pField->name = (char *)malloc(strlen(pID->type_string) + 1);
				assert(pField->name != NULL);																	
				strcpy(pField->name,pID->type_string);
				
				/* 将结构体中定义的变量插入符号表 */
				// InsertVar(pField->name,pField->type,top + 1); // [注意：这里插入如何处理]
				
				if(pDecList->numOfChilds == 1) // DecList -> Dec
					break;
				
				pDecList = pDecList->childs[2]; // DecList -> Dec COMMA DECLIST
				assert(pDecList->type == DECLIST);
			}
		
			pDefList = pDefList->childs[1];
		}
		
		if(p->childs[1]->numOfChilds == 1 && name != NULL) // 向符号表插入新的有名字的结构体类型
			InsertVar(name,type,top);		
			
		
		return type;
			
	}	
}
/*
	使用已经定义的结构体类型定义变量时，
	深度拷贝已定义结构体变量的类型。
	srcType: 拷贝类型的源
	
*/
Type 
typeCopy(Type srcType)
{
	Type dstType = (Type)malloc(sizeof(struct Type_));
	FieldList pSrc,pDst;
	assert(dstType != NULL);
	if(srcType->kind == BASIC)
	{
		dstType->kind = BASIC;
		dstType->u.basic = srcType->u.basic;
		return dstType;
	}
	
	if(srcType->kind == ARRAY)
	{
		dstType->kind = ARRAY;
		dstType->u.array.size = srcType->u.array.size;
		dstType->u.array.elem = typeCopy(srcType->u.array.elem);	// 递归调用自身解决高维数组的类型
		return dstType;
	}
	
	assert(srcType->kind == STRUCTURE);
	dstType->kind = STRUCTURE;
	dstType->u.structure = NULL;	// 初始化
	pSrc = srcType->u.structure;
	while(pSrc != NULL)
	{
		if(dstType->u.structure == NULL)
		{
			pDst = (FieldList)malloc(sizeof(struct FieldList_));
			dstType->u.structure = pDst;
		}
		else
		{
			pDst->tail = (FieldList)malloc(sizeof(struct FieldList_));
			pDst = pDst->tail;
		}
		assert(pDst != NULL);
		
		pDst->name = (char *)malloc(strlen(pSrc->name) + 1);
		assert(pDst->name != NULL);
		strcpy(pDst->name,pSrc->name);
		
		pDst->type = typeCopy(pSrc->type);	// 递归调用解决结构体域的变量定义
		
		pSrc = pSrc->tail;
	}
	pDst->tail = NULL;	// 置链表结尾标记
	
	return dstType;
}
/*
	释放申请的内存空间
*/
void 
freeType(Type type)
{
	if(type->kind == BASIC)
	{
		freeType(type);
		return ;
	}
	
	if(type->kind == ARRAY)
	{
		freeType(type->u.array.elem);	//递归释放数组申请的空间
		freeType(type);
		return ;
	}
	
	assert(type->kind == STRUCTURE);
	FieldList p = type->u.structure;
	while(p != NULL)
	{
		free(p->name);
		freeType(p->type);
		p = p->tail;
	}
	freeType(type);
}
/*
	pSpecifier:
	pVarDec:	
*/
Type getType2(struct TreeNode* pSpecifier,struct TreeNode* pVarDec)
{
	//printf("**************In function getType2****************\n");
	assert(pVarDec->type == VARDEC && pSpecifier->type == SPECIFIER);
	if(pVarDec->numOfChilds == 1)	// VarDec -> ID
	{
		assert(strcmp(pVarDec->childs[0]->nodeType,"ID") == 0);
		//InsertVar(pVarDec->childs[0]->type_string,type);		// 注意，这里插入的可能是函数参数列表内的局部变量
		return getType(pSpecifier);
	}
	else				// VarDec -> VarDec LB INT RB
	{
		Type type = (Type)malloc(sizeof(struct Type_));
		assert(type != NULL);
		type->kind = ARRAY;
		assert(strcmp(pVarDec->childs[2]->nodeType,"INT") == 0);
		type->u.array.size = pVarDec->childs[2]->type_int;
		
		type->u.array.elem = getType2(pSpecifier,pVarDec->childs[0]);		// 递归调用,解决高维数组的定义
		
		return type;
	}
	
}
/*
	判断两个类型是否等价
	返回值:true:等价； falase：不等价
*/
bool
isTypesEqual(Type t1,Type t2)
{
	if(t1 == NULL && t2 == NULL)
		return TRUE;
	if((t1 == NULL && t2 != NULL) || (t1 != NULL && t2 == NULL))
		return FALSE;
	if(t1->kind != t2->kind)
		return FALSE;
	if(t1->kind == BASIC)
		return (t1->u.basic == t2->u.basic);
	if(t1->kind == STRUCTURE)
		return (t1->u.structure == t2->u.structure);
	
	assert(t1->kind == ARRAY);
	return isTypesEqual(t1->u.array.elem,t2->u.array.elem);	// 递归调用
		
}
// 符号表释放
void
destroy()
{
}










