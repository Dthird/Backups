#include "symbol_table.h"
//hash
struct sym_node* table[HASH_LENGTH];
struct sym_node* stack[STACK_LENGTH];
struct typ_node* intTyp;
struct typ_node* floatTyp;
struct typ_node* errorTyp;

unsigned int hash_pjw(char* name)
{
	unsigned int val = 0, i; 
	for ( ; *name; ++name) 
	{ 
		val = (val << 2) + *name; 
		if ( i = val & ~0x3fff)
			val = (val ^ (i >> 12)) & 0x3fff; 
	} 
	return val; 
}

struct sym_node* newSym()
{
	struct sym_node* n = malloc(sizeof(struct sym_node));
	n->left=NULL;
	n->prev=NULL;
	n->right=NULL;
	n->next=NULL;
	return n;
}

struct sym_node* findSymInStack(int lvl,char* name,int kind)
{
	struct sym_node* p = stack[lvl];
	for(;p;p=p->next)
		if (strcmp(p->name, name) == 0&&p->kind == kind)
			return p;
	return NULL;
}

struct sym_node* findSym(int lvl,char* name,int kind)
{
	int i;
	for(i=lvl;i>=0;i--)
	{
		struct sym_node* p=findSymInStack(i,name,kind);
		if(p!=NULL)
			return p;
	}
	return NULL;
}

struct sym_node* addSym(int lvl,char* name, struct typ_node* type,int kind)
{
	struct sym_node* p= newSym();
	p->name = name;
	p->kind = kind;
	p->type = type;
	int t=hash_pjw(name);
	//link
	p->right = table[t];
	p->left = NULL;
	table[t] = p;
	if (p->right)
		p->right->left = p;

	//stack
	p->next = stack[lvl];
	p->prev = NULL;
	stack[lvl] = p;
	if (p->next)
		p->next->prev = p;
	return p;
}

void delSymInStack(int lvl)
{
	struct sym_node* cur=stack[lvl];	
	while (cur)
	{
		struct sym_node* next = cur->next;
		if(cur->left)
			cur->left->right = cur->right;
		if (cur->right)
			cur->right->left = cur->left;
		cur = next;
	}
	stack[lvl]=NULL;
}

/*typ_node start from here*/
struct typ_node* newTyp(int kind)	//Use for 1 int and 2 float, or 0 err
{
	struct typ_node* n = malloc(sizeof(struct typ_node));
	n->kind = kind;
	return n;
}

struct typ_node* newArrTyp(struct typ_node* ele,int size)
{
	struct typ_node* n=newTyp(3);
	n->Array=malloc(sizeof(struct arr));
	n->Array->size=size;
	n->Array->type=ele;
	return n;
}

struct typ_node* newStructTyp(struct fld* field)
{
	struct typ_node* n = newTyp(4);
	n->Field = field;
	return n;
}

struct fld* newFld(struct typ_node* n, char* name, struct fld* next)
{
	struct fld* f = malloc(sizeof(struct fld));
	f->name = name;
	f->type = n;
	f->next = next;
	return f;
}
struct fld* newFldByStack(int lvl)
{
	struct sym_node* n=stack[lvl];
	struct fld* p=NULL;
	struct fld* q;
	while (n)
	{
		q=newFld(n->type,n->name,p);
		p=q;
		n=n->next;
	}
	return p;
}
struct fun* newFun(struct typ_node* ret, struct fld* para, int isDefined,int line)
{
	struct fun* f = malloc(sizeof(struct fun));
	f->ret = ret;
	f->para = para;
	f->isDefined = isDefined;
	f->line=line;
	return f;
}

struct typ_node* newFunTyp(struct fun* f)
{
	struct typ_node* n = newTyp(5);
	n->Func = f;
	return n;
}

//judgment
int typCmp(struct typ_node* a, struct typ_node* b)
{
	if (a==b)
		return 0;
	if (a->kind !=b->kind)
		return 1;
	if (a->kind==3)
	{
		if(a->Array->size!=b->Array->size)
			return 1;
		else
			return typCmp(a->Array->type,b->Array->type);
	}
	if (a->kind==4)
		return fldCmp(a->Field,b->Field);
	if(a->kind==5)
		return funCmp(a->Func,b->Func);
}

int fldCmp(struct fld* a, struct fld* b)
{
	if(a==NULL&&b==NULL)
		return 0;
	if(a&&b&&!typCmp(a->type,b->type))
		return fldCmp(a->next,b->next);
	return 1;
}

int funCmp(struct fun* a, struct fun* b)
{
	if (typCmp(a->ret,b->ret) != 0)
		return 1;
	if (fldCmp(a->para, b->para) != 0)
		return 1;
	return 0;
}
struct fld* find_field(struct fld* field, char* name)
{
	for(;field;field = field->next)
		if (strcmp(name, field->name) == 0)
			return field;
	return NULL; 
}
//INIT
void initTable()
{
	int i;
	for (i = 0; i < HASH_LENGTH; i++)
		table[i]= NULL;
	for(i=0;i<STACK_LENGTH;i++)
		stack[i]=NULL;
	errorTyp = newTyp(0);
	intTyp = newTyp(1);
	floatTyp = newTyp(2);
}
