#include <stdlib.h>
#include <stdio.h>
#include "tree.h"
#include "symbol_table.c"

int curStack=0;

void printSemErr(int eID,struct node* cur,char *cont)
{
	printf("Error type %d at line %d:%s\n",eID,cur->line,cont);
	cur->varTyp = errorTyp;
}

void semanticAnalyse(struct node* cur, struct node* parent)
{
	struct sym_node* n;
	struct fld* f;
	if(!strcmp(cur->type_name,"Program"))
	{
		semanticAnalyse(cur->children[0], cur);
		n = stack[curStack];
		while (n)
		{
			if (n->kind == 2 && n->type->kind == 5 &&n->type->Func->isDefined == 0)
				printf("Error type %d at line %d:Undefined Function '%s'\n", 18, n->type->Func->line, n->name);
			n=n->next;
		}
		return ;
	}
	else if(!strcmp(cur->type_name,"ExtDefList")&&cur->cNum>0)
	{
		semanticAnalyse(cur->children[0], cur);
		semanticAnalyse(cur->children[1], cur);
			return ;
	}
	else if(!strcmp(cur->type_name,"ExtDefList"))
		return ;
	else if(!strcmp(cur->type_name,"ExtDef")&&cur->cNum==3&&!strcmp(cur->children[1]->type_name,"ExtDecList"))
	{
		semanticAnalyse(cur->children[0],cur);
		cur->varTyp = cur->children[0]->varTyp;
		semanticAnalyse(cur->children[1],cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"ExtDef")&&cur->cNum==2&&!strcmp(cur->children[1]->type_name,"SEMI"))
	{
		semanticAnalyse(cur->children[0],cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"ExtDef")&&cur->cNum==3&&!strcmp(cur->children[2]->type_name,"CompSt"))
	{
		curStack++;
		semanticAnalyse(cur->children[0],cur);
		cur->returnType = cur->children[0]->varTyp;
		semanticAnalyse(cur->children[1],cur);
		if (cur->children[1]->name != NULL && cur->children[1]->varTyp != errorTyp &&cur->children[0]->varTyp != errorTyp) 
		{
			if (n = findSym(curStack,cur->children[1]->name, 2))
			{
				if (n->type->Func->isDefined)
					printSemErr(4,cur,"Redefined function");
				else if (typCmp(n->type->Func->ret, cur->returnType) != 0 ||fldCmp(n->type->Func->para, cur->children[1]->field) != 0)
					printSemErr(19,cur,"Inconsistent declaration of function");
				else
					n->type->Func->isDefined = 1;
			}
			else
			addSym(curStack-1,cur->children[1]->name,newFunTyp(newFun(cur->returnType,cur->children[1]->field,1,cur->line)),2);
		}
		semanticAnalyse(cur->children[2], cur);
		delSymInStack(curStack);
		curStack--;
		return ;
	}

	else if (!strcmp(cur->type_name,"ExtDef")&&cur->cNum==3&&!strcmp(cur->children[1]->type_name,"FunDec")&&!strcmp(cur->children[2]->type_name,"SEMI"))
	{		
		curStack++; 
		semanticAnalyse(cur->children[0], cur);
		cur->returnType = cur->children[0]->varTyp;
		semanticAnalyse(cur->children[1], cur);
		if (cur->children[1]->name != NULL && cur->children[1]->varTyp != errorTyp &&cur->children[0]->varTyp != errorTyp) 
		{
			if (n = findSym(curStack,cur->children[1]->name, 2)) 
			{
				if (typCmp(n->type->Func->ret, cur->returnType)!=0 ||fldCmp(n->type->Func->para, cur->children[1]->field)!=0)
					printSemErr(19,cur,"Inconsistent declaration of function");
			}
			else
			addSym(curStack-1,cur->children[1]->name,newFunTyp(newFun(cur->returnType,cur->children[1]->field,0,cur->line)),2);
		}
		delSymInStack(curStack);
		curStack--;
		return ;
	}

	else if(!strcmp(cur->type_name,"ExtDecList")&&cur->cNum==1)
	{
		cur->varTyp = parent->varTyp; 
		semanticAnalyse(cur->children[0], cur);
		if (findSymInStack(curStack,cur->children[0]->name,2))
			printSemErr(3,cur,"Redefined variable");
		else
			addSym(curStack,cur->children[0]->name,cur->varTyp,2);
		return ;
	}
	else if(!strcmp(cur->type_name,"ExtDecList")&&cur->cNum==3)
	{
		cur->varTyp = parent->varTyp;
		semanticAnalyse(cur->children[0],cur);
		if (findSymInStack(curStack,cur->children[0]->name,2))
			printSemErr(3,cur,"Redefined variable");
		else
			addSym(curStack,cur->children[0]->name,cur->varTyp,2);
		semanticAnalyse(cur->children[2],cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"Specifier")&&cur->cNum==1&&!strcmp(cur->children[0]->type_name,"TYPE"))
	{
		if (strcmp(cur->children[0]->type_cont,"int") == 0)
			cur->varTyp = intTyp;
		else if (strcmp(cur->children[0]->type_cont,"float") == 0)
			cur->varTyp = floatTyp;
		return ;
	}
	else if(!strcmp(cur->type_name,"Specifier")&&cur->cNum==1&&!strcmp(cur->children[0]->type_name,"StructSpecifier"))
	{
		semanticAnalyse(cur->children[0], cur);
		cur->varTyp = cur->children[0]->varTyp;
		return ;
	}

	else if(!strcmp(cur->type_name,"StructSpecifier")&&cur->cNum==5)
	{
		semanticAnalyse(cur->children[1], cur);
		curStack++;
		cur->inStructDef = 1;
		semanticAnalyse(cur->children[3], cur);
		f = newFldByStack(curStack);
		delSymInStack(curStack);
		curStack--;
		cur->varTyp = newStructTyp(f);
		if (cur->children[1]->name != NULL) 
		{
			if (findSymInStack(curStack,cur->children[1]->name, 1))
				printSemErr(16,cur,"Duplicated struct name");
			else
				addSym(curStack,cur->children[1]->name,cur->varTyp,1);
		}
		return ;
	}
	
	else if(!strcmp(cur->type_name,"StructSpecifier")&&cur->cNum==2)
	{
		semanticAnalyse(cur->children[1], cur);
		if (n = findSym(curStack,cur->children[1]->name, 1)) 
			cur->varTyp = n->type;
		else 
			printSemErr(17,cur,"Undefined struct");
		return ;
	}
	else if(!strcmp(cur->type_name,"OptTag")&&cur->cNum==1)
	{
		cur->name = cur->children[0]->type_cont;
		return ;
	}
	else if(!strcmp(cur->type_name,"OptTag")&&cur->cNum==0)
	{
		cur->name = NULL;
		return ;
	}
	else if(!strcmp(cur->type_name,"Tag"))
	{
		cur->name = cur->children[0]->type_cont;
		return ;
	}
	else if(!strcmp(cur->type_name,"VarDec")&&cur->cNum==1)
	{
		cur->name = cur->children[0]->type_cont;
		cur->varTyp = parent->varTyp;
		return ;
	}
	else if(!strcmp(cur->type_name,"VarDec")&&cur->cNum==4)
	{
		cur->varTyp = newArrTyp(parent->varTyp, cur->children[2]->type_int);
		semanticAnalyse(cur->children[0],cur);
		cur->name = cur->children[0]->name;
		cur->varTyp = cur->children[0]->varTyp;
		return ;
	}
	else if(!strcmp(cur->type_name,"FunDec")&&cur->cNum==4)
	{
		cur->name = cur->children[0]->type_cont;
		semanticAnalyse(cur->children[2], cur);
		cur->field = cur->children[2]->field;
		f = cur->field;
		return ;
	}
	else if(!strcmp(cur->type_name,"FunDec")&&cur->cNum==3)
	{
		cur->name = cur->children[0]->type_cont;
		cur->field = NULL;
		return ;
	}
	else if(!strcmp(cur->type_name,"VarList")&&cur->cNum==3)
	{
		semanticAnalyse(cur->children[0], cur);
		semanticAnalyse(cur->children[2], cur);
		cur->field = newFld(cur->children[0]->varTyp, cur->children[0]->name, cur->children[2]->field);
		return ;
	}
	else if(!strcmp(cur->type_name,"VarList")&&cur->cNum==1)
	{
		semanticAnalyse(cur->children[0], cur);
		cur->field = newFld(cur->children[0]->varTyp, cur->children[0]->name, NULL);
		return ;
	}

	else if(!strcmp(cur->type_name,"ParamDec"))
	{
		semanticAnalyse(cur->children[0],cur);
		cur->varTyp = cur->children[0]->varTyp;
		semanticAnalyse(cur->children[1],cur);
		cur->name = cur->children[1]->name;
		cur->varTyp = cur->children[1]->varTyp;
		if (findSymInStack(curStack,cur->name, 2))
			printSemErr(3,cur,"Redefined variable");
		else
			addSym(curStack,cur->name,cur->varTyp,2);
		return ;
	}

	else if(!strcmp(cur->type_name,"CompSt"))
	{
		cur->returnType = parent->returnType; 
		if (strcmp(parent->type_name,"ExtDef")) 
			curStack++; 
		semanticAnalyse(cur->children[1], cur);
		semanticAnalyse(cur->children[2], cur);
		if (strcmp(parent->type_name,"ExtDef"))
		{
			delSymInStack(curStack);
			curStack--;
		}
		return ;
	}

	else if(!strcmp(cur->type_name,"StmtList")&&cur->cNum==2)
	{
		cur->returnType = parent->returnType; 
		semanticAnalyse(cur->children[0], cur);
		semanticAnalyse(cur->children[1], cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"StmtList")&&cur->cNum==0)
	{
		return ;
	}
	else if(!strcmp(cur->type_name,"Stmt")&&cur->cNum==2)
	{
		cur->returnType = parent->returnType; 
		semanticAnalyse(cur->children[0], cur);
		return ;
	}

	else if(!strcmp(cur->type_name,"Stmt")&&cur->cNum==1)
	{
		cur->returnType = parent->returnType;
		semanticAnalyse(cur->children[0], cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"Stmt")&&cur->cNum==3)
	{
		cur->returnType = parent->returnType;
		semanticAnalyse(cur->children[1], cur);
		if (typCmp(cur->returnType, cur->children[1]->varTyp)) 
			printSemErr(8,cur,"The return type mismatched");
		return ;
	}
	else if(!strcmp(cur->type_name,"Stmt")&&cur->cNum==5&&!strcmp(cur->children[0]->type_name,"IF"))
	{
		cur->returnType = parent->returnType;
		semanticAnalyse(cur->children[2],cur);
		semanticAnalyse(cur->children[4],cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"Stmt")&&cur->cNum==7)
	{
		cur->returnType = parent->returnType;
		semanticAnalyse(cur->children[2], cur);
		semanticAnalyse(cur->children[4], cur);
		semanticAnalyse(cur->children[6], cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"Stmt")&&cur->cNum==5&&!strcmp(cur->children[0]->type_name,"WHILE"))
	{
		cur->returnType = parent->returnType;
		semanticAnalyse(cur->children[2], cur);
		semanticAnalyse(cur->children[4], cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"DefList")&&cur->cNum==2)
	{
		cur->inStructDef = parent->inStructDef;
		semanticAnalyse(cur->children[0], cur);
		semanticAnalyse(cur->children[1], cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"DefList")&&cur->cNum==0)
	{
		return ;
	}
	else if(!strcmp(cur->type_name,"Def")&&cur->cNum==3)
	{
		cur->inStructDef = parent->inStructDef;
		semanticAnalyse(cur->children[0], cur);
		cur->varTyp = cur->children[0]->varTyp;
		semanticAnalyse(cur->children[1], cur);
		return ;
	}

	else if(!strcmp(cur->type_name,"DecList")&&cur->cNum==1)
	{
		cur->inStructDef = parent->inStructDef;
		cur->varTyp = parent->varTyp;
		semanticAnalyse(cur->children[0], cur);
		cur->name = cur->children[0]->name;
		if (cur->children[0]->varTyp != errorTyp)
		{
			if (findSymInStack(curStack,cur->name, 2)!= NULL)
			{
				if (cur->inStructDef)
					printSemErr(15,cur,"Redefined or invalid defined field");
				else
					printSemErr(3,cur,"Redefined variable");
			}
			else 
				addSym(curStack,cur->name,cur->children[0]->varTyp,2);
		}
		return ;
	}
	else if(!strcmp(cur->type_name,"DecList")&&cur->cNum==3)
	{
		cur->inStructDef = parent->inStructDef;
		cur->varTyp = parent->varTyp;
		semanticAnalyse(cur->children[0], cur);
		cur->name = cur->children[0]->name;
		if (cur->children[0]->varTyp->kind != 0)
		{
			if (findSymInStack(curStack,cur->name, 2))
			{
				if (cur->inStructDef)
					printSemErr(15,cur,"Redefined or invalid defined field");
				else
					printSemErr(3,cur,"Redefined variable");
			}
			else
				addSym(curStack,cur->name,cur->children[0]->varTyp,2);
		}
		semanticAnalyse(cur->children[2], cur);
		return ;
	}
	else if(!strcmp(cur->type_name,"Dec")&&cur->cNum==1)
	{
		cur->varTyp = parent->varTyp;
		semanticAnalyse(cur->children[0], cur);
		cur->varTyp = cur->children[0]->varTyp;
		cur->name = cur->children[0]->name;
		return ;
	}
	else if(!strcmp(cur->type_name,"Dec")&&cur->cNum==3)
	{
		cur->inStructDef = parent->inStructDef;
		if (cur->inStructDef)
		{
			printSemErr(15,cur,"Redefined or invalid defined field");
			return ;
		}
		cur->varTyp = parent->varTyp;
		semanticAnalyse(cur->children[0], cur);
		cur->varTyp = cur->children[0]->varTyp;
		cur->name = cur->children[0]->name;
		semanticAnalyse(cur->children[2], cur);
		if (typCmp(cur->varTyp, cur->children[2]->varTyp))
			printSemErr(5,cur,"Type mismatched");
		return ;
	}

	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==3&&!strcmp(cur->children[1]->type_name,"ASSIGNOP"))
	{
		semanticAnalyse(cur->children[0], cur);
		semanticAnalyse(cur->children[2], cur);
		//printf("%d %d \n",cur->children[0]->varTyp->kind,cur->children[2]->varTyp->kind);
		if (cur->children[0]->varTyp->kind == 0||cur->children[2]->varTyp->kind == 0)
		{
			cur->varTyp = errorTyp;
			return ;
		}
		if (cur->children[0]->hasLeftValue==0)
			printSemErr(6,cur,"The left-hand side of an assignment must be a variable");
		if (typCmp(cur->children[0]->varTyp,cur->children[2]->varTyp))
			printSemErr(5,cur,"Type mismatched");
		if (cur->varTyp != errorTyp)
		{
			cur->hasLeftValue = cur->children[0]->hasLeftValue;
			cur->varTyp = cur->children[0]->varTyp;
		}	
		return ;
	}
	
	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==3&&!strcmp(cur->children[2]->type_name,"Exp"))
	{	
		semanticAnalyse(cur->children[0], cur);
		semanticAnalyse(cur->children[2], cur);
		if (cur->children[0]->varTyp->kind>2||cur->children[2]->varTyp->kind>2||cur->children[2]->varTyp->kind != cur->children[0]->varTyp->kind)
		{ 
			if(cur->children[0]->varTyp->kind!=0&&cur->children[2]->varTyp->kind!=0)
				printSemErr(7,cur,"Operands type mismatched");
			else 
				cur->varTyp=errorTyp;
			return ; 
		} 
		else 
		{	cur->hasLeftValue = 0;
			cur->varTyp = cur->children[0]->varTyp;
		}
		return ;
	}
	
	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==3&&!strcmp(cur->children[0]->type_name,"LP"))
	{
		semanticAnalyse(cur->children[1], cur);
		cur->hasLeftValue = cur->children[1]->hasLeftValue;
		cur->varTyp = cur->children[1]->varTyp;
		return ;
	}
	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==2&&!strcmp(cur->children[0]->type_name,"MINUS"))
	{
		semanticAnalyse(cur->children[1], cur);
		cur->hasLeftValue = 0;
		cur->varTyp = cur->children[1]->varTyp;
		return ;
	}
	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==2&&!strcmp(cur->children[0]->type_name,"NOT"))
	{
		semanticAnalyse(cur->children[1],cur);
		cur->hasLeftValue = 0;
		cur->varTyp = cur->children[1]->varTyp;
		return ;
	}

	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==4&&!strcmp(cur->children[0]->type_name,"ID"))
	{
		cur->name = cur->children[0]->type_cont;
		if (!(n = findSym(curStack,cur->name, 2)))
			printSemErr(2,cur,"Undefined function");
		else if (n->type->kind != 5)
		{
			printSemErr(11,cur,"The var isn't a function");		
		}
		else
		{
			cur->field = n->type->Func->para;
			semanticAnalyse(cur->children[2], cur);
			cur->hasLeftValue = 0;
			cur->varTyp = n->type->Func->ret;
		}
		return ;
	}
	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==3&&!strcmp(cur->children[0]->type_name,"ID"))
	{
		cur->name = cur->children[0]->type_cont;
		if (!(n = findSym(curStack,cur->name,2)))
			printSemErr(2,cur,"Undefined function");
		else if (n->type->kind != 5)
			printSemErr(11,cur,"The var isn't a function");
		else
		{
			if(n->type->Func->para!=NULL)
				printSemErr(9,cur,"Function arguments not matched");
			else
			{	
				cur->hasLeftValue = 0;
				cur->varTyp = n->type->Func->ret;
			}
		}
		return ;
	}

	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==4&&!strcmp(cur->children[0]->type_name,"Exp"))
	{
		semanticAnalyse(cur->children[0], cur);
		semanticAnalyse(cur->children[2], cur);
		cur->varTyp = cur->children[0]->varTyp;
		if (cur->varTyp->kind != 0)
		{
			if (cur->varTyp->kind != 3)
				printSemErr(10,cur,"The var isn't an array");
			else if (cur->children[2]->varTyp->kind != 1)
				printSemErr(12,cur,"Operands type mistaken");
			else
			{
				cur->varTyp = cur->children[0]->varTyp->Array->type; 
				if (cur->varTyp->kind == 3)
					cur->hasLeftValue = 0;
				else
					cur->hasLeftValue = 1;
			}
		}
		return ;
	}

	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==3&&!strcmp(cur->children[0]->type_name,"Exp"))
	{
		semanticAnalyse(cur->children[0],cur);
		cur->varTyp = cur->children[0]->varTyp;
		if (cur->varTyp->kind != 0) 
		{
			if (cur->varTyp->kind != 4)
				printSemErr(13,cur,"Illegal use of '.'");
			else if ((f = find_field(cur->varTyp->Field,cur->children[2]->type_cont)) == NULL)
				printSemErr(14,cur,"Un-existed field");
			else
			{
				cur->varTyp = f->type;
				if(cur->varTyp->kind==3)
					cur->hasLeftValue=0;
				else 
					cur->hasLeftValue=1;
			}
		}
		return ;
	}

	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==1&&!strcmp(cur->children[0]->type_name,"ID"))
	{
		cur->name = cur->children[0]->type_cont;
		cur->hasLeftValue=1;
		if((n = findSym(curStack,cur->name,2))!=NULL)
			cur->varTyp = n->type;
		else
			printSemErr(1,cur,"Undefined variable");
		return ;
	}
	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==1&&!strcmp(cur->children[0]->type_name,"INT"))
	{
		cur->varTyp = intTyp;
		cur->hasLeftValue=0;
		return ;
	}
	else if(!strcmp(cur->type_name,"Exp")&&cur->cNum==1&&!strcmp(cur->children[0]->type_name,"FLOAT"))
	{
		cur->varTyp = floatTyp;
		cur->hasLeftValue=0;
		return;
	}
	else if(!strcmp(cur->type_name,"Args")&&cur->cNum==3)
	{
		semanticAnalyse(cur->children[0], cur);
		cur->field = parent->field; 
		if (cur->field == NULL)
			printSemErr(9,cur,"Function arguments not matched");
		else if (typCmp(cur->field->type,cur->children[0]->varTyp))
			printSemErr(9,cur,"Function arguments not matched");
		else
		{
			cur->field = cur->field->next;
			semanticAnalyse(cur->children[2],cur);
			cur->field = parent->field;
		}
		return ;
	}
	else if(!strcmp(cur->type_name,"Args")&&cur->cNum==1)
	{
		semanticAnalyse(cur->children[0],cur);
		cur->field = parent->field; 
		if (cur->field == NULL)
			printSemErr(9,cur,"Function arguments not matched");
		else if (cur->field->next != NULL) 
			printSemErr(9,cur,"Function arguments not matched");
		else if (typCmp(cur->field->type,cur->children[0]->varTyp))
			printSemErr(9,cur,"Function arguments not matched");
		return ;
	}
}

void semantic_parse(struct node* root)
{
	initTable();
	semanticAnalyse(root, NULL);
}
