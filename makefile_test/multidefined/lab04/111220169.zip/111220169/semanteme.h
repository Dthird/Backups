#include "SymbolTable.h"
#include "tree_operation.h"

void print_error(int error_type, int lineno);
FieldList add_VarDec(Node* VarDec, char* type, int flag);
FieldList add_VarDec_in_def_Struct(Node* VarDec, char* type, int if_alarm);
void visit_Def_in_def_Struct(Node *ntr, FieldList curF, char* struct_name);
FieldList store_structure(Node* StructSpecifier);
char* check_type(Node* specifier);
int visit_ParamDec(Node* ParamDec, FieldList curF, int flag);
FieldList dec_def_function(Node* fID, char* type, int dec_def);
void visit_CompSt(Node* CompSt, Node* fID);
void visit_ExtDef(Node *ntr);
char* get_ID_from_Exp(Node* Exp);
int get_array_div_from_Exp(Node* Exp);
int visit_Args(Node* fID, Node* Args);
int handle_uncertain_ASSIGN_Exp_type(Node* Exp, char* struct_name, int type);
int handle_uncertain_other_Exp_type(Node* Exp, char* struct_name);
int visit_Exp(Node* Exp);
void visit_Stmt(Node* Stmt, Node* fID);
void visit_StmtList(Node* StmtList, Node* fID);
void visit_tree(Node* root);