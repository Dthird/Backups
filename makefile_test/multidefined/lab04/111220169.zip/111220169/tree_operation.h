#ifndef TREE_OPERATION_H
#define TREE_OPERATION_H

#include <stdlib.h>
#include <string.h>

typedef struct tree_node
{
	int type;			//lexical=0，syntax=1，error=2
	char name[20];
	char data[32];
	int lineno;
	struct tree_node* child;
	struct tree_node* sibling;
} Node;

void init_node(Node** ptr, int t, char* n, int ln, char* d);
void add_child(Node* parent, Node* child);
void add_sibling(Node* src, Node* sib);

#endif