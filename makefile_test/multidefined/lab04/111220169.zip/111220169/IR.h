#include <stdio.h>

typedef struct Operand_* Operand;
typedef struct InterCode_* InterCode;
typedef struct InterCodes_* InterCodes;
typedef struct ArgList_Node ANode;

struct Operand_{
	enum{ VARIABLE_O, CONSTANT_O, ADDR_O, TEMP_O, LABEL_O,
		  RELOP_O, FUNCTION_O, ARG_O, SIZE_O, DEREF_O, POINTER_O
		} kind;
	union{
		int value;
		char* str;
	} u;
};

struct InterCode_{
	enum{ LABEL_I, RETURN_I, GOTO_I, READ_I, WRITE_I, ARG_I, FUNCTION_I, PARAM_I,
		  CALL_I, ASSIGN_I, DEC_I,
		  ADD_I, SUB_I, MUL_I, DIV_I,
		  IF_I
		} kind;
	union{
		struct{
			Operand result;
		} single;
		struct{
			Operand left, right;
		} binop;
		struct{
			Operand result, op1, op2;
		} triop;
		struct{
			Operand op1, relop, op2, label_true;
		} if_op;
	} u;
};

struct InterCodes_{
	InterCode code;
	InterCodes prev, next;
};

struct ArgList_Node{
	int temp_no;
	struct ArgList_Node* next;
};

InterCodes head, tail;

int temp_no;
int var_no;
int label_no;
int pointer_no;

char* var_array[50];
char* pointer_array[50];

void init_inter();
void translate_tree();
void output_inters(FILE* fp);