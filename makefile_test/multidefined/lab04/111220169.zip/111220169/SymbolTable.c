#include <stdio.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include "SymbolTable.h"

unsigned int BKDRhash(char* str){
	unsigned int seed = 131;
	unsigned int hash = 0;
	unsigned char *p = (unsigned char *) str;
	while(*p)
		hash = hash * seed + (*p++);
	return (hash % 131);
}

void init_HT(){
	for(int i = 0; i < 131; i++)
		ht[i] = NULL;

	FieldList read_f = (FieldList)malloc(sizeof(struct FieldList_));
	strcpy(read_f->name, "read");
	read_f->type = (Type)malloc(sizeof(struct Type_));
	read_f->type->kind = function;
	read_f->type->u.function.arg = NULL;
	read_f->type->u.function.arg_num = 0;
	strcpy(read_f->type->u.function.return_type, "int");
	read_f->type->u.function.dec_def = 2;
	read_f->type->u.function.first_lineno = -1;
	read_f->tail = NULL;
	ht[BKDRhash("read")] = read_f;

	FieldList write_f = (FieldList)malloc(sizeof(struct FieldList_));
	strcpy(write_f->name, "write");
	write_f->type = (Type)malloc(sizeof(struct Type_));
	write_f->type->kind = function;
	FieldList write_arg = (FieldList)malloc(sizeof(struct FieldList_));
	strcpy(write_arg->name, "output");
	write_arg->type = (Type)malloc(sizeof(struct Type_));
	write_arg->type->kind = basic;
	write_arg->type->u.basic = 0;
	write_arg->tail = NULL;
	write_f->type->u.function.arg = write_arg;
	write_f->type->u.function.arg_num = 1;
	strcpy(write_f->type->u.function.return_type, "int");
	write_f->type->u.function.dec_def = 2;
	write_f->type->u.function.first_lineno = -1;
	write_f->tail = NULL;
	ht[BKDRhash("write")] = write_f;
}

void insert_HT(FieldList p){
	int hash = BKDRhash(p->name);
	if(ht[hash] == NULL)
			ht[hash] = p;
	else{
		FieldList cur = ht[hash];
		while(cur->tail != NULL)
			cur = cur->tail;
		cur->tail = p;
	}
}

FieldList get_loc(char* str, int kind){
	FieldList cur = ht[BKDRhash(str)];
	if(cur == NULL)
		return NULL;
	while((cur != NULL) && (cur->type->kind != kind || strcmp(cur->name, str) != 0))
		cur = cur->tail;
	if(cur == NULL)
		return NULL;
	return cur;
}

int check_var_struct(char* str){
	//查询str是否已经被声明、定义为basic, array, structure, struct_var
	//0为未定义且未声明，1为已经声明(struct)，2为已定义
	FieldList cur = ht[BKDRhash(str)];
	if(cur == NULL)
		return 0;
	while((cur != NULL) && ((cur->type->kind == function) || (strcmp(cur->name, str) != 0)))
		cur = cur->tail;
	if(cur != NULL){
		if((cur->type->kind == structure) && (cur->type->u.structure == NULL))
			return 1;
		else
			return 2;
	}
	else
		return 0;
	printf("Error in check_var_struct()!!\n");
	return -1;
}

int check_array(char* str){
	FieldList cur = get_loc(str, array);
	if(cur == NULL)
		return 0;
	else
		return 1;
}

int check_attr(char* struct_str, char* attr_str){
	//查询str是否已经被声明、定义为attribute
	//0为未定义且未声明，2为已定义
	FieldList cur = get_loc(attr_str, attribute);
	if(cur == NULL || strcmp(struct_str, cur->type->u.attribute.struct_name) != 0)
		return 0;
	else
		return 2;
	printf("Error in check_attr()!!\n");
	return -1;
}

int check_function(char* str){	
	//0为未定义且未声明，1为声明但未定义，2为已定义
	FieldList cur = ht[BKDRhash(str)];
	if(cur == NULL)
		return 0;
	assert(cur->type != NULL);
	while((cur != NULL) && ((cur->type->kind != function) || (strcmp(cur->name, str) != 0)))
		cur = cur->tail;
	if(cur != NULL)
		return cur->type->u.function.dec_def;
	else
		return 0;
	printf("Error in check_function()!!\n");
	return -1;
}

int get_struct_attr_type(char* struct_str, char* element_str){
	FieldList attrF = get_loc(element_str, attribute);
	if(attrF == NULL)
		return 0;
	FieldList varF = get_loc(struct_str, struct_var);
	Type T = NULL;
	if(varF == NULL){
		FieldList temp = get_loc(struct_str, attribute);
		if(temp == NULL || temp->type->u.attribute.property->kind != struct_var)
			return 0;
		T = temp->type->u.attribute.property;
	}
	else
		T = varF->type;
	if(strcmp(attrF->type->u.attribute.struct_name, T->u.struct_name) != 0)
		return 0;
	Type curT = attrF->type->u.attribute.property;
	if(curT->kind == basic)
		return curT->u.basic-2;
	else if(curT->kind == array){
		curT = curT->u.array.arg.elem;
		while((curT->kind == array) && (curT->u.array.arg.elem != NULL))
			curT = curT->u.array.arg.elem;
		assert(curT->kind == basic);
		return curT->u.basic+1;
	}
	else if(curT->kind == struct_var)
		return -4;

	printf("Error in get_struct_element_type\n");
	return 0;
}

int get_function_return_type(char* str){
	FieldList cur = get_loc(str, function);
	if(cur != NULL){
		char* type = cur->type->u.function.return_type;
		if(strcmp(type, "int") == 0)
			return 5;
		if(strcmp(type, "float") == 0)
			return 6;
		else
			return 7;
	}
	else
		return -10;
}

int get_function_arg_num(char* str){
	FieldList cur = get_loc(str, function);
	assert(cur != NULL);
	return cur->type->u.function.arg_num;
}

int get_function_arg_type(char* str, int arg_pos){
	//找第arg_pos个参数的类型
	FieldList cur = get_loc(str, function);
	assert(cur != NULL);
	cur = cur->type->u.function.arg;
	for(int count = 1; count < arg_pos; count++)
		cur = cur->tail;
	if(cur->type->kind == basic)
		return cur->type->u.basic-2;
	if(cur->type->kind == array){
		Type curT = cur->type;
		while(curT->kind == array)
			curT = curT->u.array.arg.elem;
		if(curT->kind == basic)
			return curT->u.basic + 1;
	}
	if(cur->type->kind == struct_var)
		return -4;
	printf("Error in get_function_arg_type\n");
	return -10;
}

char* get_struct_type(char* var_str){
	FieldList cur = get_loc(var_str, struct_var);
	if(cur != NULL)
		return cur->type->u.struct_name;
	cur = get_loc(var_str, attribute);
	if(cur == NULL || cur->type->u.attribute.property->kind != struct_var)
		return NULL;
	return cur->type->u.attribute.property->u.struct_name;
}

int get_array_div(char* str){
	FieldList cur = get_loc(str, array);
	int result = 1;
	Type curT = cur->type->u.array.arg.elem;
	while(curT != NULL && curT->kind == array){
		result++;
		curT = curT->u.array.arg.elem;
	}
	return result;
}

int get_array_type(char* str){
	FieldList cur = get_loc(str, array);
	if(cur == NULL)
		return -10;
	Type curT = cur->type->u.array.arg.elem;
	while(curT->kind == array)
		curT = curT->u.array.arg.elem;
	if(curT->kind == basic)
		return curT->u.basic-2;
	else
		return -4;
}

int get_ID_type(char* str){
	FieldList cur = ht[BKDRhash(str)];
	if(cur == NULL)
		return -10;
	while(cur != NULL && strcmp(cur->name, str) != 0)
		cur = cur->tail;
	if(cur == NULL)
		return -10;
	assert(cur->type != NULL);
	if(cur->type->kind == basic)
		return cur->type->u.basic-2;
	else if(cur->type->kind == array){
		Type curT = cur->type->u.array.arg.elem;
		while(curT->kind == array)
			curT = curT->u.array.arg.elem;
		if(curT->kind == basic)
			return cur->type->u.basic+1;
		else if(curT->kind == structure)
			return 4;
	}
	else if(cur->type->kind == function)
		return get_function_return_type(str);
	else if(cur->type->kind == structure)
		return 3;
	else if(cur->type->kind == struct_var)
		return -4;
	printf("Error in get_ID_type\n");
	exit(-1);
}



int check_func_multi_dec(FieldList prev_dec, FieldList cur_dec){
	assert(prev_dec != NULL && cur_dec != NULL);
	assert(strcmp(prev_dec->name, cur_dec->name) == 0);
	Type prevT = prev_dec->type;
	Type curT = cur_dec->type;
	if(strcmp(prevT->u.function.return_type, curT->u.function.return_type) != 0)
		return 0;
	if(prevT->u.function.arg_num != curT->u.function.arg_num)
		return 0;
	FieldList prevF = prevT->u.function.arg;
	FieldList curF = curT->u.function.arg;
	while(curF != NULL){
		if(prevF->type->kind != curF->type->kind)
			return 0;
		if(curF->type->kind == array){
			if(prevF->type->u.array.arg.size != curF->type->u.array.arg.size)
				return 0;
			Type prev_array = prevF->type->u.array.arg.elem;
			Type cur_array = curF->type->u.array.arg.elem;
			while(prev_array->kind == array && cur_array->kind == array){
				if(prev_array->u.array.arg.size != cur_array->u.array.arg.size)
					return 0;
				prev_array = prev_array->u.array.arg.elem;
				cur_array = cur_array->u.array.arg.elem;
			}
			if(prev_array->kind != cur_array->kind)
				return 0;
			assert(cur_array->kind != array);
			if((cur_array->kind == basic) && (prev_array->u.basic != cur_array->u.basic))
				return 0;
			assert(cur_array->kind == struct_var);
			if(strcmp(prev_array->u.struct_name, cur_array->u.struct_name) != 0)
				return 0;
		}
		else if(curF->type->kind == basic){
			if(prevF->type->u.basic != curF->type->u.basic)
				return 0;
		}
		else if(curF->type->kind == struct_var){
			if(strcmp(prevF->type->u.struct_name, curF->type->u.struct_name) != 0)
				return 0;
		}
		prevF = prevF->tail;
		curF = curF->tail;
	}
	assert(curF == NULL && prevF == NULL);
	return 1;
}

int get_array_size(char* id, int level){
	FieldList cur = get_loc(id, array);
	assert(cur != NULL);
	Type curT = cur->type;
	int t = curT->u.array.length - level + 1;
	for(int i = 1; i <= t; i++)
		curT = curT->u.array.arg.elem;
	int count = 1;
	while(curT->kind == array){
		count *= curT->u.array.arg.size;
		curT = curT->u.array.arg.elem;
	}
	return count;
}

void check_undef_func(){
	for(int i = 0; i < 131; i++){
		if(ht[i] != NULL){
			FieldList cur = ht[i];
			while(cur != NULL){
				if(cur->type->kind == function && cur->type->u.function.dec_def == 1)
					printf("Error type 18 at line %d: Undefined function \"%s\"\n", cur->type->u.function.first_lineno, cur->name);
				cur = cur->tail;
			}
		}
	}
}

void print_HT(){
	for(int i = 0; i < 131; i++){
		if(ht[i] != NULL){
			FieldList cur = ht[i];
			while(cur != NULL){
				printf("loc:%d, name:%s\n", i, cur->name);
				Type curT = cur->type;
				if(curT->kind == array){
					printf("array\n");
					while((curT->kind == array) && (curT->u.array.arg.elem != NULL)){
						printf("array size:%d\n", curT->u.array.arg.size);
						curT = curT->u.array.arg.elem;
					}
					printf("array type:%u\n", curT->u.basic);
					printf("\n");
				}
				else if(curT->kind == basic){
					printf("basic:%u\n\n", curT->u.basic);
				}
				else if(curT->kind == structure){
					printf("structure\n");
					FieldList curF = curT->u.structure;
					while(curF != NULL){
						printf("field name:%s, field type:%d\n", curF->name, curF->type->kind);
						curF = curF->tail;
					}
					printf("\n");
				}
				else if(curT->kind == struct_var){
					printf("struct_var\n");
					printf("struct_name:%s\n", curT->u.struct_name);
					printf("\n");
				}
				else if(curT->kind == function){
					FieldList p = curT->u.function.arg;
					printf("function\narg_num:%d return_type:%s ", curT->u.function.arg_num, curT->u.function.return_type);
					printf("dec_def:%d first_lineno:%d\n", curT->u.function.dec_def, curT->u.function.first_lineno);
					while(p != NULL){
						printf("arg_name:%s, arg_type:%d\n", p->name, p->type->kind);
						p = p->tail;
					}
					printf("\n");
				}
				else if(curT->kind == attribute){
					printf("attribute\n");
					printf("struct_name:%s\n", curT->u.attribute.struct_name);
					printf("attribute_property:%d\n", curT->u.attribute.property->kind);
					printf("\n");
				}
				cur = cur->tail;
			}
		}
	}
}