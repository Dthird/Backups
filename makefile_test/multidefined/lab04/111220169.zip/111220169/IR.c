#include <assert.h>
#include <stdlib.h>
#include "IR.h"
#include "SymbolTable.h"
#include "tree_operation.h"

InterCodes translate_Cond(Node* Exp, int label_true, int label_false);
InterCodes translate_Args(Node* Args, ANode** arg_list);
InterCodes translate_CompSt(Node* CompSt);
int translate_array(Node* Exp, int level);
void print_inters();

void init_inter(){
	head = NULL;
	tail = NULL;
	temp_no = 1;
	var_no = 0;
	label_no = 1;
	pointer_no = 0;
	for(int i = 0; i < 50; i++){
		var_array[i] = NULL;
		pointer_array[i] = NULL;
	}
}

int new_temp(){
	return temp_no++;
}

void insert_var(char* str){
	var_array[var_no] = (char*)malloc(sizeof(char)*20);
	strcpy(var_array[var_no], str);
	var_no++;
}

void insert_pointer(char *str){
	pointer_array[var_no] = (char*)malloc(sizeof(char)*20);
	strcpy(pointer_array[var_no], str);
	pointer_no++;
}

int new_label(){
	return label_no++;
}

int check_var(char* str){
	for(int i = 0; i < 50; i++){
		if(var_array[i] != NULL && strcmp(var_array[i], str) == 0)
			return 1;
	}
	return 0;
}

int check_pointer(char* str){
	for(int i = 0; i < 50; i++){
		if(pointer_array[i] != NULL && strcmp(pointer_array[i], str) == 0)
			return 1;
	}
	return 0;
}

int lookup_var(char* str){
	for(int i = 0; i < 50; i++){
		if(var_array[i] != NULL && strcmp(var_array[i], str) == 0)
			return i+1;
	}
	insert_var(str);
	return var_no;
}

int lookup_pointer(char* str){
	for(int i = 0; i < 50; i++){
		if(pointer_array[i] != NULL && strcmp(pointer_array[i], str) == 0)
			return i+1;
	}
	insert_pointer(str);
	return pointer_no;
}

InterCodes insert_inter(InterCode inter){
	InterCodes inters = (InterCodes)malloc(sizeof(struct InterCodes_));
	inters->code = inter;
	inters->prev = NULL;
	inters->next = NULL;
	if(head == NULL){
		head = inters;
		tail = inters;
	}
	else{
		tail->next = inters;
		inters->prev = tail;
		tail = inters;
		tail->next = head;
		head->prev = tail;
	}
	return inters;
}

void insert_arg_list(ANode** arg_list, int t){
	ANode* node = (ANode*)malloc(sizeof(ANode));
	node->temp_no = t;
	node->next = NULL;
	if(*arg_list == NULL)
		*arg_list = node;
	else{
		ANode* p = *arg_list;
		while(p->next != NULL)
			p = p->next;
		p->next = node;
	}
}

Operand new_Operand(int kind, int value){
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = kind;
	op->u.value = value;
	return op;
}

Operand new_Operand_char(int kind, char* str){
	assert(str != NULL);
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = kind;
	op->u.str = (char*)malloc(sizeof(char)*20);
	strcpy(op->u.str, str);
	return op;
}

InterCode new_InterCode(int kind, Operand result, Operand op1, Operand op2){
	InterCode inter = (InterCode)malloc(sizeof(struct InterCode_));
	inter->kind = kind;
	if(kind == LABEL_I || kind == RETURN_I || kind == GOTO_I ||
	   kind == READ_I || kind == WRITE_I || kind == ARG_I ||
	   kind == FUNCTION_I || kind == PARAM_I){
		inter->u.single.result = result;
	}
	else if(kind == ASSIGN_I || kind == CALL_I || kind == DEC_I){
		inter->u.binop.left = result;
		inter->u.binop.right = op1;
	}
	else if(kind == ADD_I || kind == SUB_I || kind == MUL_I || kind == DIV_I){
		inter->u.triop.result = result;
		inter->u.triop.op1 = op1;
		inter->u.triop.op2 = op2;
	}
	else if(kind == IF_I){
		inter->u.if_op.op1 = result;
		inter->u.if_op.relop = op1;
		inter->u.if_op.op2 = op2;
	}
	else{
		printf("Error in new_InterCode!!\n");
		return NULL;
	}
	return inter;
}

InterCodes insert_label(int label){
	Operand result = new_Operand(LABEL_O, label);
	InterCode inter = new_InterCode(LABEL_I, result, NULL, NULL);
	return insert_inter(inter);
}

InterCodes insert_return(int temp){
	Operand result = new_Operand(TEMP_O, temp);
	InterCode inter = new_InterCode(RETURN_I, result, NULL, NULL);
	return insert_inter(inter);
}

InterCodes insert_goto(int label){
	Operand result = new_Operand(LABEL_O, label);
	InterCode inter = new_InterCode(GOTO_I, result, NULL, NULL);
	return insert_inter(inter);
}

InterCodes insert_read(int place){
	Operand result = new_Operand(TEMP_O, place);
	InterCode inter = new_InterCode(READ_I, result, NULL, NULL);
	return insert_inter(inter);
}

InterCodes insert_write(int temp){
	Operand result = new_Operand(TEMP_O, temp);
	InterCode inter = new_InterCode(WRITE_I, result, NULL, NULL);
	return insert_inter(inter);
}

InterCodes insert_arg(int temp){
	Operand result = new_Operand(TEMP_O, temp);
	InterCode inter = new_InterCode(ARG_I, result, NULL, NULL);
	return insert_inter(inter);
}

InterCodes insert_function(char* str){
	assert(str != NULL);
	Operand result = new_Operand_char(FUNCTION_O, str);
	InterCode inter = new_InterCode(FUNCTION_I, result, NULL, NULL);
	return insert_inter(inter);
}

InterCodes insert_param(Operand result){
	InterCode inter = new_InterCode(PARAM_I, result, NULL, NULL);
	return insert_inter(inter);
}

InterCodes insert_call(int place, char* str){
	Operand left = new_Operand(TEMP_O, place);
	Operand right = new_Operand_char(FUNCTION_O, str);
	InterCode inter = new_InterCode(CALL_I, left, right, NULL);
	return insert_inter(inter);
}

InterCodes insert_assign(Operand left, Operand right){
	InterCode inter = new_InterCode(ASSIGN_I, left, right, NULL);
	return insert_inter(inter);
}

InterCodes insert_dec(int variable, int size){
	Operand left = new_Operand(VARIABLE_O, variable);
	Operand right = new_Operand(SIZE_O, size);
	InterCode inter = new_InterCode(DEC_I, left, right, NULL);
	return insert_inter(inter);
}

InterCodes insert_triop(int kind, Operand result, Operand op1, Operand op2){
	InterCode inter = new_InterCode(kind, result, op1, op2);
	return insert_inter(inter);
}

InterCodes insert_if(Operand op1, int relop, Operand op2, int label){
	Operand op = new_Operand(RELOP_O, relop);
	InterCode inter = new_InterCode(IF_I, op1, op, op2);
	Operand label_op = new_Operand(LABEL_O, label);
	inter->u.if_op.label_true = label_op;
	return insert_inter(inter);
}

int get_relop(Node* RELOP){
	assert(strcmp(RELOP->name, "RELOP") == 0);
	if(strcmp(RELOP->data, ">") == 0)
		return 1;
	if(strcmp(RELOP->data, "<") == 0)
		return 2;
	if(strcmp(RELOP->data, ">=") == 0)
		return 3;
	if(strcmp(RELOP->data, "<=") == 0)
		return 4;
	if(strcmp(RELOP->data, "==") == 0)
		return 5;
	if(strcmp(RELOP->data, "!=") == 0)
		return 6;
	printf("Error in get_relop!!!\n");
	return -1;
}

int get_ele(ANode* list, int pos){
	assert(list != NULL);
	ANode* cur = list;
	for(int i = 1; i < pos; i++){
		assert(cur != NULL);
		cur = cur->next;
	}
	return cur->temp_no;
}

int get_var(Node* VarDec){
	Node* cur = VarDec;
	while(strcmp(cur->name, "ID") != 0)
		cur = cur->child;
	return lookup_var(cur->data);
}

int get_size(Node* VarDec){
	int size = 1;
	for(Node* cur = VarDec; cur->sibling != NULL; cur = cur->child)
		size *= atoi(cur->sibling->sibling->data);
	return size;
}

char* get_id(Node* Exp){
	Node* cur = Exp;
	while(strcmp(cur->name, "ID") != 0)
		cur = cur->child;
	return cur->data;
}

int length(ANode* list){
	int count = 0;
	for(ANode* cur = list; cur != NULL; cur = cur->next)
		count++;
	return count;
}

InterCodes translate_Exp(Node* Exp, int place){
	if(strcmp(Exp->name, "INT") == 0){
		Operand right = new_Operand(CONSTANT_O, atoi(Exp->data));
		Operand left = new_Operand(TEMP_O, place);
		return insert_assign(left, right);
	}
	else if(strcmp(Exp->name, "ID") == 0 && (Exp->sibling == NULL)){
		int id_no = lookup_var(Exp->data);
		Operand right = NULL;
		if(check_array(Exp->data) == 1)
			right = new_Operand(ADDR_O, id_no);
		else
			right = new_Operand(VARIABLE_O, id_no);
		Operand left = new_Operand(TEMP_O, place);
		return insert_assign(left, right);
	}
	else if(strcmp(Exp->sibling->name, "ASSIGNOP") == 0){
		int t1 = new_temp();
		InterCodes code1 = translate_Exp(Exp->sibling->sibling->child, t1);
		Operand left2 = NULL;
		if(strcmp(Exp->child->name, "ID") == 0){
			int id_no = lookup_var(Exp->child->data);
			left2 = new_Operand(VARIABLE_O, id_no);
		}
		else if(strcmp(Exp->child->sibling->name, "LB") == 0){
			int addr = translate_array(Exp->child, 1);
			left2 = new_Operand(DEREF_O, addr);
		}
		Operand right2 = new_Operand(TEMP_O, t1);
		InterCodes code2 = insert_assign(left2, right2);
		return code1;
	}
	else if(strcmp(Exp->sibling->name, "PLUS") == 0 ||
			strcmp(Exp->sibling->name, "MINUS") == 0 ||
			strcmp(Exp->sibling->name, "STAR") == 0 ||
			strcmp(Exp->sibling->name, "DIV") == 0){
		int t1 = new_temp();
		int t2 = new_temp();
		InterCodes code1 = translate_Exp(Exp->child, t1);
		InterCodes code2 = translate_Exp(Exp->sibling->sibling->child, t2);
		Operand op1 = new_Operand(TEMP_O, t1);
		Operand op2 = new_Operand(TEMP_O, t2);
		Operand result = new_Operand(TEMP_O, place);
		InterCodes code3 = NULL;
		if(strcmp(Exp->sibling->name, "PLUS") == 0)
			code3 = insert_triop(ADD_I, result, op1, op2);
		else if(strcmp(Exp->sibling->name, "MINUS") == 0)
			code3 = insert_triop(SUB_I, result, op1, op2);
		else if(strcmp(Exp->sibling->name, "STAR") == 0)
			code3 = insert_triop(MUL_I, result, op1, op2);
		else if(strcmp(Exp->sibling->name, "DIV") == 0)
			code3 = insert_triop(DIV_I, result, op1, op2);
		else
			printf("Error in translate_Exp->plus minus star div\n");
		return code1;
	}
	else if(strcmp(Exp->name, "MINUS") == 0){
		int t1 = new_temp();
		InterCodes code1 = translate_Exp(Exp->sibling->child, t1);
		Operand op1 = new_Operand(CONSTANT_O, 0);
		Operand op2 = new_Operand(TEMP_O, t1);
		Operand result = new_Operand(TEMP_O, place);
		InterCodes code2 = insert_triop(SUB_I, result, op1, op2);
		return code1;
	}
	else if(strcmp(Exp->name, "LP") == 0)
		return translate_Exp(Exp->sibling->child, place);
	else if(strcmp(Exp->sibling->name, "RELOP") == 0 ||
			strcmp(Exp->name, "NOT") == 0 ||
			strcmp(Exp->sibling->name, "AND") == 0 ||
			strcmp(Exp->sibling->name, "OR") == 0){
		int label1 = new_label();
		int label2 = new_label();
		Operand left0 = new_Operand(TEMP_O, place);
		Operand right0 = new_Operand(CONSTANT_O, 0);
		InterCodes code0 = insert_assign(left0, right0);
		InterCodes code1 = translate_Cond(Exp, label1, label2);
		InterCodes code2_1 = insert_label(label1);
		Operand right2_2 = new_Operand(CONSTANT_O, 1);
		Operand left2_2 = new_Operand(TEMP_O, place);
		InterCodes code2_2 = insert_assign(left2_2, right2_2);
		assert(code2_1->next == code2_2 && code2_2->prev == code2_1);
		InterCodes code3 = insert_label(label2);
		assert(code2_2->next == code3 && code3->prev == code2_2);
		return code0;
	}
	else if(strcmp(Exp->name, "ID") == 0){
		if(strcmp(Exp->sibling->sibling->name, "Args") != 0){
			if(strcmp(Exp->data, "read") == 0){
				return insert_read(place);
			}
			return insert_call(place, Exp->data);
		}
		else{
			ANode* arg_list = NULL;
			InterCodes code1 = translate_Args(Exp->sibling->sibling->child, &arg_list);
			if(strcmp(Exp->data, "write") == 0){
				assert(arg_list != NULL);
				InterCodes code2 = insert_write(get_ele(arg_list, 1));
				return code1;
			}
			for(int i = 1; i <= length(arg_list); i++)
				insert_arg(get_ele(arg_list, i));
			insert_call(place, Exp->data);
			return code1;
		}
	}
	else if(strcmp(Exp->sibling->name, "LB") == 0){
		int addr = translate_array(Exp, 1);
		Operand right = new_Operand(DEREF_O, addr);
		Operand left = new_Operand(TEMP_O, place);
		InterCodes code = insert_assign(left, right);
		return code;
	}
	printf("%s\n", Exp->sibling->name);
	printf("Error in translate_Exp!!!\n");
	return NULL;
}

InterCodes translate_Stmt(Node* Stmt){
	assert(strcmp(Stmt->name, "Stmt") != 0);
	if(strcmp(Stmt->name, "Exp") == 0)
		return translate_Exp(Stmt->child, -1);
	else if(strcmp(Stmt->name, "CompSt") == 0)
		return translate_CompSt(Stmt->child);
	else if(strcmp(Stmt->name, "RETURN") == 0){
		int t1 = new_temp();
		InterCodes code1 = translate_Exp(Stmt->sibling->child, t1);
		InterCodes code2 = insert_return(t1);
		return code1;
	}
	else if(strcmp(Stmt->name, "IF") == 0){
		int label1 = new_label();
		int label2 = new_label();
		Node* Exp = Stmt->sibling->sibling;
		InterCodes code1 = translate_Cond(Exp->child, label1, label2);
		InterCodes code2 = insert_label(label1);
		InterCodes code3 = translate_Stmt(Exp->sibling->sibling->child);
		int label3;
		if(Exp->sibling->sibling->sibling != NULL){
			label3 = new_label();
			InterCodes go_inter = insert_goto(label3);
		}
		InterCodes code4 = insert_label(label2);
		if(Exp->sibling->sibling->sibling != NULL){
			InterCodes code5 = translate_Stmt(Exp->sibling->sibling->sibling->sibling->child);
			InterCodes code6 = insert_label(label3);
		}
		return code1;
	}
	else if(strcmp(Stmt->name, "WHILE") == 0){
		int label1 = new_label();
		int label2 = new_label();
		int label3 = new_label();
		InterCodes code1 = insert_label(label1);
		InterCodes code2 = translate_Cond(Stmt->sibling->sibling->child, label2, label3);
		InterCodes code3 = insert_label(label2);
		InterCodes code4 = translate_Stmt(Stmt->sibling->sibling->sibling->sibling->child);
		InterCodes code5 = insert_goto(label1);
		InterCodes code6 = insert_label(label3);
		return code1;
	}
	printf("Error in translate_Stmt!!\n");
	return NULL;
}

InterCodes translate_Cond(Node* Exp, int label_true, int label_false){
	if(strcmp(Exp->sibling->name, "RELOP") == 0){
		int t1 = new_temp();
		int t2 = new_temp();
		InterCodes code1 = translate_Exp(Exp->child, t1);
		InterCodes code2 = translate_Exp(Exp->sibling->sibling->child, t2);
		Operand op1 = new_Operand(TEMP_O, t1);
		Operand op2 = new_Operand(TEMP_O, t2);
		InterCodes code3 = insert_if(op1, get_relop(Exp->sibling), op2, label_true);
		InterCodes code4 = insert_goto(label_false);
		return code1;
	}
	else if(strcmp(Exp->name, "NOT") == 0)
		return translate_Cond(Exp->sibling->child, label_false, label_true);
	else if(strcmp(Exp->sibling->name, "AND") == 0){
		int label1 = new_label();
		InterCodes code1 = translate_Cond(Exp->child, label1, label_false);
		InterCodes code2 = insert_label(label1);
		InterCodes code3 = translate_Cond(Exp->sibling->sibling->child, label_true, label_false);
		return code1;
	}
	else if(strcmp(Exp->sibling->name, "OR") == 0){
		int label1 = new_label();
		InterCodes code1 = translate_Cond(Exp->child, label_true, label1);
		InterCodes code2 = insert_label(label1);
		InterCodes code3 = translate_Cond(Exp->sibling->sibling->child, label_true, label_false);
		return code1;
	}
	else{
		int t1 = new_temp();
		InterCodes code1 = translate_Exp(Exp, t1);
		Operand op1 = new_Operand(TEMP_O, t1);
		Operand op2 = new_Operand(CONSTANT_O, 0);
		InterCodes code2 = insert_if(op1, 6, op2, label_true);
		InterCodes code3 = insert_goto(label_false);
		return code1;
	}
}

InterCodes translate_Args(Node* Args, ANode** arg_list){
	assert(strcmp(Args->name, "Args") != 0);
	if(strcmp(Args->name, "Exp") == 0){
		int t1 = new_temp();
		InterCodes code1 = translate_Exp(Args->child, t1);
		insert_arg_list(arg_list, t1);
		if(Args->sibling == NULL)
			return code1;
		InterCodes code2 = translate_Args(Args->sibling->sibling->child, arg_list);
		return code1;
	}
	printf("Error in translate_Args!!\n");
	return NULL;
}

InterCodes translate_param(Node* ParamDec){
	Node* ID_VD = ParamDec->sibling->child;
	if(strcmp(ID_VD->name, "ID") == 0){
		Operand op = new_Operand(VARIABLE_O, lookup_var(ID_VD->data));
		return insert_param(op);
	}
	else if(strcmp(ID_VD->name, "VarDec") == 0){
		assert(strcmp(ID_VD->child->name, "ID") == 0);
		Operand op = new_Operand(POINTER_O, lookup_pointer(ID_VD->child->data));
		return insert_param(op);
	}
	printf("Error in translate_param!\n");
	return NULL;
}

InterCodes translate_VarList(Node* VarList){
	InterCodes result = NULL;
	do{
		InterCodes temp = translate_param(VarList->child);
		if(result == NULL && temp != NULL)
			result = temp;
		VarList = VarList->sibling;
		if(VarList != NULL)
			VarList = VarList->sibling->child;
	} while(VarList != NULL);
	return result;
}

InterCodes translate_FunDec(Node* FunDec){
	assert(strcmp(FunDec->name, "FunDec") != 0);
	InterCodes code1 = insert_function(FunDec->data);
	InterCodes code2 = NULL;
	if(strcmp(FunDec->sibling->sibling->name, "VarList") == 0)
		code2 = translate_VarList(FunDec->sibling->sibling->child);
	return code1;
}

InterCodes translate_Def(Node* node, int place){
	if(node == NULL)
		return NULL;
	InterCodes code1 = NULL;
	if(strcmp(node->name, "VarDec") == 0 && node->sibling == NULL)
		return insert_dec(get_var(node->child), get_size(node->child)*4);
	else if(node->sibling != NULL && strcmp(node->sibling->name, "ASSIGNOP") == 0){
		if(strcmp(node->child->name, "ID") == 0){
			int t1 = new_temp();
			int id_no = lookup_var(node->child->data);
			code1 = translate_Exp(node->sibling->sibling->child, t1);
			Operand right2 = new_Operand(TEMP_O, t1);
			Operand left2 = new_Operand(VARIABLE_O, id_no);
			InterCodes code2 = insert_assign(left2, right2);
			place = new_temp();
		}
	}
	InterCodes code3 = translate_Def(node->child, place);
	InterCodes code4 = translate_Def(node->sibling, place);
	if(code1 == NULL && code3 == NULL && code4 != NULL)
		return code4;
	else if(code1 == NULL && code3 != NULL)
		return code3;
	else if(code1 != NULL)
		return code1;
	else
		return NULL;
}

InterCodes translate_DefList(Node* Def){
	InterCodes result = NULL;
	while(1){
		InterCodes temp = translate_Def(Def->child, 0);
		if(result == NULL && temp != NULL)
			result = temp;
		if(Def->sibling != NULL)
			Def = Def->sibling->child;
		else break;
	}
	return result;
}

InterCodes translate_StmtList(Node* Stmt){
	InterCodes result = NULL;
	while(1){
		InterCodes temp = translate_Stmt(Stmt->child);
		if(result == NULL && temp != NULL)
			result = temp;
		if(Stmt->sibling != NULL)
			Stmt = Stmt->sibling->child;
		else break;
	}
	return result;
}

InterCodes translate_CompSt(Node* CompSt){
	InterCodes code1 = NULL;
	InterCodes code2 = NULL;
	if(strcmp(CompSt->sibling->name, "DefList") == 0){
		code1 = translate_DefList(CompSt->sibling->child);
		if(strcmp(CompSt->sibling->sibling->name, "StmtList") == 0)
			code2 = translate_StmtList(CompSt->sibling->sibling->child);
	}
	else if(strcmp(CompSt->sibling->name, "StmtList") == 0)
		code2 = translate_StmtList(CompSt->sibling->child);
	if(code1 == NULL && code2 != NULL)
		return code2;
	else if(code1 != NULL)
		return code1;
	else
		return NULL;
}

int translate_array(Node* Exp, int level){
	if(strcmp(Exp->name, "ID") == 0){
		int lp = check_pointer(Exp->data);
		if(lp == 1)
			return lp;
		return lookup_var(Exp->data);
	}
	int addr = translate_array(Exp->child, level+1);
	int temp = new_temp();
	Operand result = new_Operand(TEMP_O, temp);
	Operand op1 = NULL;
	if(strcmp(Exp->child->name, "ID") == 0){
		if(check_var(Exp->child->data) == 1){
			op1 = new_Operand(ADDR_O, addr);
		}
		else{
			assert(check_pointer(Exp->child->data) == 1);
			op1 = new_Operand(POINTER_O, addr);
		}
	}
	else if(strcmp(Exp->child->name, "Exp") == 0)
		op1 = new_Operand(TEMP_O, addr);
	else{
		printf("Error in translate_array!!!!\n");
		return -1;
	}
	Node* Arg = Exp->sibling->sibling->child;
	int num = 0;
	if(strcmp(Arg->name, "INT") == 0){
		int offset = atoi(Arg->data) * get_array_size(get_id(Exp->child), level) * 4;
		Operand op2 = new_Operand(CONSTANT_O, offset);
		InterCode inter = new_InterCode(ADD_I, result, op1, op2);
		insert_inter(inter);
	}
	else if(strcmp(Arg->name, "ID") == 0){
		int t1 = new_temp();
		Operand opa = NULL;
		if(check_pointer(Arg->data) == 1)
			opa = new_Operand(POINTER_O, lookup_pointer(Arg->data));
		else if(check_var(Arg->data) == 1)
			opa = new_Operand(VARIABLE_O, lookup_var(Arg->data));
		Operand opb = new_Operand(CONSTANT_O, get_array_size(get_id(Exp->child), level) * 4);
		Operand res = new_Operand(TEMP_O, t1);
		InterCode intera = new_InterCode(MUL_I, res, opa, opb);
		insert_inter(intera);
		Operand op2 = new_Operand(TEMP_O, t1);
		InterCode interb = new_InterCode(ADD_I, result, op1, op2);
		insert_inter(interb);
	}
	else{
		assert(strcmp(Arg->name, "Exp") == 0);
		int t1 = new_temp();
		translate_Exp(Arg, t1);
		Operand opa = new_Operand(TEMP_O, t1);
		Operand opb = new_Operand(CONSTANT_O, get_array_size(get_id(Exp->child), level) * 4);
		int t2 = new_temp();
		Operand res = new_Operand(TEMP_O, t2);
		InterCode intera = new_InterCode(MUL_I, res, opa, opb);
		insert_inter(intera);
		Operand op2 = new_Operand(TEMP_O, t2);
		InterCode interb = new_InterCode(ADD_I, result, op1, op2);
		insert_inter(interb);
	}
	return temp;
}

void output_operand(FILE* fp, Operand op){
	switch(op->kind){
		case VARIABLE_O :
			fprintf(fp, "v%d", op->u.value);
			break;
		case CONSTANT_O :
			fprintf(fp, "#%d", op->u.value);
			break;
		case TEMP_O :
			fprintf(fp, "t%d", op->u.value);
			break;
		case RELOP_O :
			switch(op->u.value){
				case 1 :
					fprintf(fp, ">");
					break;
				case 2 :
					fprintf(fp, "<");
					break;
				case 3 :
					fprintf(fp, ">=");
					break;
				case 4 :
					fprintf(fp, "<=");
					break;
				case 5 :
					fprintf(fp, "==");
					break;
				case 6 :
					fprintf(fp, "!=");
					break;
			}
			break;
		case ADDR_O :
			fprintf(fp, "&v%d", op->u.value);
			break;
		case DEREF_O :
			fprintf(fp, "*t%d", op->u.value);
			break;
		case POINTER_O :
			fprintf(fp, "p%d", op->u.value);
			break;
		default:
			printf("Error in output_operand!!\n");
	}
}

void output_inters(FILE* fp){
	if(head == NULL)
		return;
	InterCodes cur = head;
	do{
		InterCode code = cur->code;
		switch(code->kind){
			case LABEL_I :
				fprintf(fp, "LABEL label%d :\n", code->u.single.result->u.value);
				break;
			case RETURN_I :
				fprintf(fp, "RETURN t%d\n", code->u.single.result->u.value);
				break;
			case GOTO_I :
				fprintf(fp, "GOTO label%d\n", code->u.single.result->u.value);
				break;
			case READ_I :
				fprintf(fp, "READ t%d\n", code->u.single.result->u.value);
				break;
			case WRITE_I :
				fprintf(fp, "WRITE t%d\n", code->u.single.result->u.value);
				break;
			case ARG_I :
				fprintf(fp, "ARG t%d\n", code->u.single.result->u.value);
				break;
			case FUNCTION_I :
				fprintf(fp, "FUNCTION %s :\n", code->u.single.result->u.str);
				break;
			case PARAM_I :
				fprintf(fp, "PARAM ");
				output_operand(fp, code->u.single.result);
				fprintf(fp, "\n");
				break;
			case CALL_I :
				fprintf(fp, "t%d := CALL %s\n", code->u.binop.left->u.value, code->u.binop.right->u.str);
				break;
			case ASSIGN_I :
				output_operand(fp, code->u.binop.left);
				fprintf(fp, " := ");
				output_operand(fp, code->u.binop.right);
				fprintf(fp, "\n");
				break;
			case DEC_I :
				fprintf(fp, "DEC v%d %d\n", code->u.binop.left->u.value, code->u.binop.right->u.value);
				break;
			case ADD_I :
				output_operand(fp, code->u.triop.result);
				fprintf(fp, " := ");
				output_operand(fp, code->u.triop.op1);
				fprintf(fp, " + ");
				output_operand(fp, code->u.triop.op2);
				fprintf(fp, "\n");
				break;
			case SUB_I :
				fprintf(fp, "t%d := t%d - t%d\n", code->u.triop.result->u.value, code->u.triop.op1->u.value, code->u.triop.op2->u.value);
				break;
			case MUL_I :
				output_operand(fp, code->u.triop.result);
				fprintf(fp, " := ");
				output_operand(fp, code->u.triop.op1);
				fprintf(fp, " * ");
				output_operand(fp, code->u.triop.op2);
				fprintf(fp, "\n");
				break;
			case DIV_I :
				fprintf(fp, "t%d := t%d / t%d\n", code->u.triop.result->u.value, code->u.triop.op1->u.value, code->u.triop.op2->u.value);
				break;
			case IF_I :
				fprintf(fp, "IF t%d ", code->u.if_op.op1->u.value);
				output_operand(fp, code->u.if_op.relop);
				fprintf(fp, " t%d GOTO label%d\n", code->u.if_op.op2->u.value, code->u.if_op.label_true->u.value);
				break;
		}
		cur = cur->next;
	} while(cur != head);
}

void translate_ExtDef(Node* ExtDef){
	if(strcmp(ExtDef->sibling->name, "FunDec") == 0){
		translate_FunDec(ExtDef->sibling->child);
		translate_CompSt(ExtDef->sibling->sibling->child);
	}
	else
		printf("Error in translate_ExtDef!!!!!!\n");
}

void pre_process(Node* root){
	Node* cur = root;
	if(cur == NULL)
		return;
	if(strcmp(cur->name, "StructSpecifier") == 0){
		printf("Cannot translate the code: Contain structure and function parameters of struct type\n");
		exit(-1);
	}
	pre_process(root->child);
	pre_process(root->sibling);
}

void translate_tree(Node* root){
	pre_process(root);
	Node* ExtDef = root->child->child;
	if(ExtDef == NULL)
		return;
	while(1){
		translate_ExtDef(ExtDef->child);
		if(ExtDef->sibling == NULL)
			return;
		ExtDef = ExtDef->sibling->child;
	}
}