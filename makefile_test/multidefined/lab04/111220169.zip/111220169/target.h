int offset_sum;
int arg_num;
int max_offset;
int* offset_record;
FILE* f2;

void transit_code();