#include "IR.h"
#include "target.h"
#include <assert.h>
#include <stdlib.h>

void debug(){
	for(int i = 0; i < (temp_no+var_no+pointer_no); i++){
		if(offset_record[i] != -1)
			printf("%d, %d\n", i, offset_record[i]);
	}
	printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
}

void pre_transit(){
	offset_sum = 1;
	arg_num = 0;
	max_offset = 0;
	offset_record = (int*)malloc(sizeof(int)*offset_sum);
	for(int i = 0; i < (temp_no+var_no+pointer_no); i++)
		offset_record[i] = -1;

	fprintf(f2, ".data\n_prompt: .asciiz \"Enter an integer:\"\n_ret: .asciiz \"\\n\"\n.globl main\n");
	fprintf(f2, ".text\n");
	fprintf(f2, "read:\n\tli $v0, 4\n\tla $a0, _prompt\n\tsyscall\t\n\tli $v0, 5\n\tsyscall\n\tjr $ra\n\n");
	fprintf(f2, "write:\n\tli $v0, 1\n\tsyscall\n\tli $v0, 4\n\tla $a0, _ret\n\tsyscall\n\tmove $v0, $0\n\tjr $ra\n\n");
}

int get_offset(Operand op){
	//debug();
	int num = 0;
	if(op->kind == TEMP_O || op->kind == DEREF_O)
		num =op->u.value - 1;
	else if(op->kind == VARIABLE_O || op->kind == ADDR_O)
		num = op->u.value + temp_no - 1;
	else if(op->kind == POINTER_O)
		num = op->u.value + temp_no + var_no - 1;
	else{
		printf("Error in get_offset()!!\n");
		return -1;
	}
	if(offset_record[num] == -1){
		int offset = (offset_sum++) * 4;
		offset_record[num] = offset;
		if(max_offset < offset){
			fprintf(f2, "\taddi $sp, $sp, -%d\n", offset - max_offset);
			max_offset = offset;
		}
		return offset;
	}
	else
		return offset_record[num];
}

void transit_op(Operand op){
	switch(op->kind){
		case CONSTANT_O:
			fprintf(f2, "\tli $t0, %d\n", op->u.value);
			break;
		case ADDR_O:
			fprintf(f2, "\tmove $t1, $fp\n");
			fprintf(f2, "\taddi $t1, $t1, -%d\n", get_offset(op));
			fprintf(f2, "\tmove $t0, $t1\n");
			break;
		case DEREF_O:
			fprintf(f2, "\tlw $t1, -%d($fp)\n", get_offset(op));
			fprintf(f2, "lw $t0, 0($t1)\n");
			break;
		default:
			fprintf(f2, "\tlw $t0, -%d($fp)\n", get_offset(op));
			break;
	}
}

void transit_left_op(Operand op){
	if(op->kind == DEREF_O){
		fprintf(f2, "\tlw $t1, -%d($fp)\n", get_offset(op));
		fprintf(f2, "\tsw $t0, 0($t1)\n");
	}
	else{
		fprintf(f2, "\tsw $t0, -%d($fp)\n", get_offset(op));
	}
}

void transit_arithmatic(InterCode code){
	transit_op(code->u.triop.op1);
	fprintf(f2, "\tmove $t1, $t0\n");
	transit_op(code->u.triop.op2);
	switch(code->kind){
		case ADD_I:
			fprintf(f2, "\tadd $t0, $t0, $t1\n");
			break;
		case SUB_I:
			fprintf(f2, "\tsub $t0, $t1, $t0\n");
			break;
		case MUL_I:
			fprintf(f2, "\tmul $t0, $t0, $t1\n");
			break;
		case DIV_I:
			fprintf(f2, "\tdiv $t1, $t0\n");
			fprintf(f2, "\tmflo $t0\n");
			break;
		default:
			fprintf(f2, "Error in transit_arithmatic()!!\n");
	}
	transit_left_op(code->u.triop.result);
}

void transit(InterCodes cur){
	InterCode code = cur->code;
	switch(code->kind){
		case LABEL_I:
			fprintf(f2, "label%d:\n", code->u.single.result->u.value);
			break;
		case RETURN_I:
			fprintf(f2, "\tlw $v0, -%d($fp)\n", get_offset(code->u.single.result));
			fprintf(f2, "\tmove $sp, $fp\n");
			fprintf(f2, "\tjr $ra\n");
			arg_num = 0;
			break;
		case GOTO_I:
			fprintf(f2, "\tj label%d\n", code->u.single.result->u.value);
			break;
		case READ_I:
			fprintf(f2, "\taddi $sp, $sp, -4\n");
			fprintf(f2, "\tsw $ra, 0($sp)\n");
			fprintf(f2, "\tjal read\n");
			fprintf(f2, "\tlw $ra, 0($sp)\n");
			fprintf(f2, "\taddi $sp, $sp, 4\n");
			fprintf(f2, "\tsw $v0, -%d($fp)\n", get_offset(code->u.single.result));
			break;
		case WRITE_I:
			fprintf(f2, "\tlw $a0, -%d($fp)\n", get_offset(code->u.single.result));
			fprintf(f2, "\taddi $sp, $sp, -4\n");
			fprintf(f2, "\tsw $ra, 0($sp)\n");
			fprintf(f2, "\tjal write\n");
			fprintf(f2, "\tlw $ra, 0($sp)\n");
			fprintf(f2, "\taddi $sp, $sp, 4\n");
			break;
		case ARG_I:
			if(arg_num < 4)
				fprintf(f2, "\tlw $a%d, -%d($fp)\n", arg_num, get_offset(code->u.single.result));
			else{
				//参数大于4个的情况				
			}
			arg_num++;
			break;
		case FUNCTION_I:
			fprintf(f2, "%s:\n", code->u.single.result->u.str);
			fprintf(f2, "\tmove $fp, $sp\n");
			max_offset = 0;
			break;
		case PARAM_I:
			if(arg_num < 4)
				fprintf(f2, "\tsw $a%d, -%d($fp)\n", arg_num, get_offset(code->u.single.result));
			else{
				//参数大于4个
			}
			arg_num++;
			break;
		case CALL_I:
			fprintf(f2, "\tli $s1, %d\n", max_offset);
			fprintf(f2, "\taddi $sp, $sp, -8\n");
			fprintf(f2, "\tsw $fp, 8($sp)\n");
			fprintf(f2, "\tsw $s1, 4($sp)\n");
			fprintf(f2, "\tsw $ra, 0($sp)\n");
			fprintf(f2, "\tjal %s\n", code->u.binop.right->u.str);
			fprintf(f2, "\tlw $ra, 0($sp)\n");
			fprintf(f2, "\tlw $s1, 4($sp)\n");
			fprintf(f2, "\tlw $fp, 8($sp)\n");
			fprintf(f2, "\tsw $v0, -%d($fp)\n", get_offset(code->u.binop.left));
			fprintf(f2, "\taddi $sp, $sp, 8\n");
			break;
		case ASSIGN_I:
			transit_op(code->u.binop.right);
			assert(code->u.binop.left->kind != ADDR_O);
			transit_left_op(code->u.binop.left);
			break;
		case DEC_I:{
			int num = code->u.binop.left->u.value + temp_no - 1;
			assert(offset_record[num] == -1);
			int offset = offset_sum * 4;
			offset_record[num] = offset;
			offset_sum += (code->u.binop.right->u.value/4);
			if(offset_sum*4 > max_offset){
				fprintf(f2, "\taddi $sp, $sp, -%d\n", offset_sum*4 - max_offset);
				max_offset = offset_sum * 4;
			}
			break;
		}
		case ADD_I:
			transit_arithmatic(code);
			break;
		case SUB_I:
			transit_arithmatic(code);
			break;
		case MUL_I:
			transit_arithmatic(code);
			break;
		case DIV_I:
			transit_arithmatic(code);
			break;
		case IF_I:
			fprintf(f2, "\tlw $t0, -%d($fp)\n", get_offset(code->u.if_op.op1));
			fprintf(f2, "\tlw $t1, -%d($fp)\n", get_offset(code->u.if_op.op2));
			switch(code->u.if_op.relop->u.value){
				case 1:
					fprintf(f2, "\tbgt $t0, $t1, label%d\n", code->u.if_op.label_true->u.value);
					break;
				case 2:
					fprintf(f2, "\tblt $t0, $t1, label%d\n", code->u.if_op.label_true->u.value);
					break;
				case 3:
					fprintf(f2, "\tbge $t0, $t1, label%d\n", code->u.if_op.label_true->u.value);
					break;
				case 4:
					fprintf(f2, "\tble $t0, $t1, label%d\n", code->u.if_op.label_true->u.value);
					break;
				case 5:
					fprintf(f2, "\tbeq $t0, $t1, label%d\n", code->u.if_op.label_true->u.value);
					break;
				case 6:
					fprintf(f2, "\tbne $t0, $t1, label%d\n", code->u.if_op.label_true->u.value);
					break;
			}
			break;
	}
}

void transit_code(){
	pre_transit();
	InterCodes cur = head;
	do{
		transit(cur);
		cur = cur->next;
	}while(cur != head);
}