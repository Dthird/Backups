#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SyntaxTree.h"
#include "semantic.h"
#include "translate.h"

void translate_Exp(Node *p, char place[20], int flag);
void translate_Args(Node* p, int flag);
void translate_Cond(Node *p, Operand correct, Operand wrong, int flag);
void translate_DecList(Node *p, int flag);
void translate_VarList(Node *p);
void translate_FunDec(Node *p);
void translate_CompSt(Node *p, int flag);
void translate_Stmt(Node *p, int flag);
void translate_VarDec(Node *p, int flag);
void translate_DefList(Node *p, int flag);
void WriteInOperand(Operand op, FILE *f);

int VariableCount = 0; 
int TempCount = 0;
int LabelCount = 0;
int figure = 0; //decimal of exp 
int LineNo = 0; 

void new_temp(char name[20])
{
	TempCount++;
	printf("new temp %d\n",TempCount);
	strcpy(name,"t");
	sprintf(name+1, "%d", TempCount);	
}

void new_variable(char name[20])
{
	VariableCount++;
	printf("new var %d\n",VariableCount);
	strcpy(name,"v");
	sprintf(name+1, "%d", VariableCount);	
}

void new_label(char name[20])
{
	LabelCount++;
	printf("new label %d\n",LabelCount);
	strcpy(name, "label");
	sprintf(name+5, "%d", LabelCount);	
}

Operand NewConstOperand(int value) //constant
{
	Operand op = (Operand)malloc(sizeof(Operand));
	op->kind = CONSTANT;
	op->u.value = value;
	return op;
}
Operand NewVarOperand(int kind, char name[20]) //variable address sstar
{
	Operand op = (Operand)malloc(sizeof(Operand));
	op->kind = kind;
	strcpy(op->u.name, name);
	return op;
}
Operand NewListOperand(int kind) // all list
{
	Operand op = (Operand)malloc(sizeof(Operand));
	op->kind = kind;
	op->u.args = (Arg_list *)malloc(sizeof(Arg_list));
	op->u.args = arg_list;
	return op;
}

void NewDecInc(Operand op, int size)  //dec
{
	printf("new dec inc\n");
	InterCodes* inc = (InterCodes*)malloc(sizeof(InterCodes));
	inc->code.kind = DEC;
	inc->code.u.dec.size = size;
	inc->code.u.dec.op = op;
	if(InstructionList == NULL)
	{
		InstructionList = inc;
		InstructionList->prev = InstructionList;
		InstructionList->next = InstructionList;
	}
	else
	{
		InterCodes* temp = InstructionList->prev;
		temp->next = inc;
		inc->prev = temp;
		inc->next = InstructionList;
		InstructionList->prev = inc;
	}
}


void NewAssignInc(Operand r, Operand l) //assigment exp
{
	printf("new assign inc\n");
	InterCodes *inc = (InterCodes*)malloc(sizeof(InterCodes));
	inc->code.kind = ASSIGN;
	inc->code.u.assign.right = r;
	inc->code.u.assign.left = l;
	if(InstructionList == NULL)
	{
		InstructionList = inc;
		InstructionList->prev = InstructionList;
		InstructionList->next = InstructionList;
	}
	else
	{
		InterCodes* temp = InstructionList->prev;
		temp->next = inc;
		inc->prev = temp;
		inc->next = InstructionList;
		InstructionList->prev = inc;
	}
}

void NewRelopInc(int kind, int kind1, Operand op1, Operand op2, Operand op3) //if while
{
	printf("new relop inc\n");
	InterCodes *inc = (InterCodes*)malloc(sizeof(struct InterCodes_));
	inc->code.kind = kind;
	if(kind == BINOP)
	{
		inc->code.u.binop.kind = kind1;
		inc->code.u.binop.op1 = op1;
		inc->code.u.binop.op2 = op2;
		inc->code.u.binop.result = op3;
	}
	else
	{
		inc->code.u.relop.kind = kind1;
		inc->code.u.relop.op1 = op1;
		inc->code.u.relop.op2 = op2;
		inc->code.u.relop.op3 = op3;
	}
	if(InstructionList == NULL)
	{
		InstructionList = inc;
		InstructionList->prev = InstructionList;
		InstructionList->next = InstructionList;
	}
	else
	{
		InterCodes* temp = InstructionList->prev;
		temp->next = inc;
		inc->prev = temp;
		inc->next = InstructionList;
		InstructionList->prev = inc;
	}
}
void NewOtherInc(int kind, Operand op) //GOTO，LABEL，RETURN，READ，WRITE，ARG,FUNCTION,PARAM
{
	printf("new other inc\n");
	InterCodes *inc = (InterCodes *)malloc(sizeof(struct InterCodes_));
	inc->code.kind = kind;
	inc->code.u.op = op;
	if(InstructionList == NULL)
	{
		InstructionList = inc;
		InstructionList->prev = InstructionList;
		InstructionList->next = InstructionList;
	}
	else
	{
		InterCodes* temp = InstructionList->prev;
		temp->next = inc;
		inc->prev = temp;
		inc->next = InstructionList;
		InstructionList->prev = inc;
	}
}

/**look up function**/
FieldList lookup(char name[20])
{
	printf("look up\n");
	FieldList temp=VariableHead;
	for(;temp!=NULL;temp=temp->next)
	{
		if(strcmp(temp->name,name)==0)
		{
			return temp;
		}
	}
	FieldList temp1=StructureHead;
	for(;temp1!=NULL;temp1=temp1->next)
	{
		if(strcmp(temp1->name,name)==0)
		{
			return temp1;
		}
	}
	return NULL;
}

/**compute the size of type int**/
int GetIntSize(int number)
{
	int len = 0;
	if(number=0 || number < 0)
	{
		len=1;
		number = -number;
	}
	while(number > 0)
	{
		len++;
		number = number/10;
	}
	return len;
}

/**compute the size of type struct**/
int GetStructSize(Type t)
{
	int length = 0;
	if(t->kind == BASIC)
	{
		length += 4;
	}
	if(t->kind == ARRAY)
	{
		length += t->array.size * GetStructSize(t->array.elem);
	}
	if(t->kind == STRUCTURE)
	{
		FieldList list = t->structure;
		while(list!=NULL)
		{
			length += GetStructSize(list->type);
			list=list->next;
		}
	}
	return length;
}



/**compute the offset**/
int offset(Node *p, char t[20], int flag)
{
	printf("offset compute\n");
	int size = 0;
	if(strcmp(p->children[0]->name, "ID")==0)
	{
		return 0;
	}
	if(strcmp(p->children[1]->name, "LB") == 0) //[]
	{
		FieldList a = lookup(p->word);
		int size1 = GetStructSize(a->type);
		if(strcmp(p->children[2]->children[0]->name, "INT") == 0) //VarDec LB INT RB
		{
			size += size1 * p->children[2]->children[0]->number;
			size += offset(p->children[0], t, flag);
		}
		if(strcmp(p->children[2]->children[0]->name, "ID") == 0) //Exp LB Exp RB -> Exp:ID
		{
			char v[20],t1[20],t2[20]; 
			Operand op;
			FieldList id = lookup(p->children[2]->children[0]->word);
			if(strlen(id->temp) == 0)
			{
				new_variable(v);
				strcpy(id->temp, v);
			}
			op = NewVarOperand(VARIABLE, v);
			if(strlen(t)==0)
			{
				new_temp(t);
				if(size1 == 0)
				{
					NewAssignInc(op, NewVarOperand(VARIABLE,t));
				}
				if(size1 > 0)
				{
					NewRelopInc(BINOP,2, op, NewConstOperand(size1),NewVarOperand(VARIABLE,t));
				}
				size += offset(p->children[0], t, flag);
			}
			if(strlen(t) > 0)
			{
				new_temp(t1);
				new_temp(t2);
				if(size1 == 0)
				{
					NewAssignInc(op, NewVarOperand(VARIABLE,t1));
				}
				if(size1 > 0)
				{
					NewRelopInc(BINOP,2, op, NewConstOperand(size1),NewVarOperand(VARIABLE,t1));
				}
				NewRelopInc(BINOP,0,NewVarOperand(VARIABLE,t),NewVarOperand(VARIABLE,t1),NewVarOperand(VARIABLE,t2));
				size = size+offset(p->children[0], t2, flag);
			}		
		}
		if(strcmp(p->children[2]->children[0]->name, "Exp") == 0) //Exp LB Exp RB -> Exp:Exp
		{
			char t1[20],t11[20],t12[20];
			Operand op;
			translate_Exp(p->children[2], t1, flag);
			op = NewVarOperand(VARIABLE, t1);
			if(strlen(t) > 0)
			{
				new_temp(t11);
				new_temp(t12);
				if(size1 == 0)
				{
					NewAssignInc(op, NewVarOperand(VARIABLE,t11));
				}
				if(size1 > 0)
				{
					NewRelopInc(BINOP,2, op, NewConstOperand(size1),NewVarOperand(VARIABLE,t11));
				}
				NewRelopInc(BINOP,0,NewVarOperand(VARIABLE,t),NewVarOperand(VARIABLE,t11),NewVarOperand(VARIABLE,t12));
				size = size + offset(p->children[0], t12, flag);
			}
			if(strlen(t)==0)
			{
				new_temp(t);
				if(size1 == 0)
				{
					NewAssignInc(op, NewVarOperand(VARIABLE,t));
				}
				if(size1 > 0)
				{
					NewRelopInc(BINOP,2, op, NewConstOperand(size1),NewVarOperand(VARIABLE,t));
				} 
				size = size + offset(p->children[0], t, flag);
			}
		}
		
	}
	return size;
}

/**Translate_exp**/
void translate_Exp(Node *p, char place[20], int flag)
{
	printf("translate_exp\n");
	Node *first=p->children[0];
	if(strcmp(first->name, "INT") == 0)
	{
		figure = first->number;
	}
	if(strcmp(first->name, "LP") == 0)
	{
		first=p->children[1]->children[0];
	}
	if(strcmp(first->name, "ID") == 0)
	{
		if(p->count==1) //ID
		{
			char var[20];
			FieldList node = lookup(first->word);
			if(strlen(node->temp) == 0)
			{
				new_variable(var);
				strcpy(node->temp, var);
				strcpy(place, node->temp);
			}
			if(strlen(node->temp) != 0)
			{
				strcpy(place, node->temp);
			}
		}
		if(p->count==3) 
		{//函数
			new_temp(place);
			if(strcmp(first->word, "read") == 0)
			{
				NewOtherInc(READ, NewVarOperand(VARIABLE, place));
			}
			else
			{	
				NewAssignInc(NewVarOperand(CALL, first->word), NewVarOperand(VARIABLE, place));
			}
		}
		if(p->count==4)
		{
			translate_Args(p->children[2], flag);
			if(strcmp(first->word, "write") == 0)
			{
				if(arg_list->kind==0)
				{
					NewOtherInc(WRITE, NewConstOperand(atoi(arg_list->name)));
				}
				if(arg_list->kind==1)
				{
					NewOtherInc(WRITE, NewVarOperand(VARIABLE, arg_list->name));
				}
				if(arg_list->kind==2)
				{
					NewOtherInc(WRITE, NewConstOperand(atoi(arg_list->name)));
				}
			}
			else
			{
				new_temp(place);
				NewOtherInc(ARG, NewListOperand(ARGS));
				NewAssignInc(NewVarOperand(CALL, first->word), NewVarOperand(VARIABLE, place));
			}
			arg_list = NULL;
		}
	}
	if(strcmp(first->name, "MINUS") == 0)
	{
		char t2[20];
		t2[0]='\0';
		new_temp(place);
		translate_Exp(p->children[1], t2, flag);
		Operand op;
		if(strlen(t2) == 0)
		{
			op = NewConstOperand(-figure);
			NewAssignInc(op, NewVarOperand(VARIABLE, place));
		}
		if(strlen(t2)>0)
		{
			op = NewVarOperand(VARIABLE, t2);
			NewRelopInc(BINOP, 1, NewConstOperand(0), op, NewVarOperand(VARIABLE, place));
		}
	}
	if(strcmp(first->name, "Exp")==0 || strcmp(first->name, "NOT")==0)
	{
		if(strcmp(p->children[1]->name, "LB") == 0 || strcmp(p->children[1]->name, "DOT") == 0)
		{
			char t[20], t1[20];
			t[0]='\0';
			t1[0]='\0';		
			FieldList node = lookup(first->word);
			if(strcmp(p->children[1]->name, "LB") == 0)
			{
				LineNo=1;
				return;
			}
			Operand op;
			if(flag == 1)
			{
				op = NewVarOperand(VARIABLE, node->temp);
			}
			if(flag == 0)
			{
				op = NewVarOperand(ADDRESS, node->temp);
			}
			int size = offset(p, t, flag);
			if(strlen(t) == 0)
			{
				if(size > 0)
				{
					new_temp(t1);
					new_temp(place);
					NewRelopInc(BINOP,0, op, NewConstOperand(size), NewVarOperand(VARIABLE, t1));
					NewAssignInc(NewVarOperand(SSTAR, t1), NewVarOperand(VARIABLE, place));
				}
				if(size == 0)
				{
					new_temp(place);
					if(flag == 1)
					{
						NewAssignInc(NewVarOperand(SSTAR, node->temp), NewVarOperand(VARIABLE, place));
					}
					if(flag == 0)
					{
						NewAssignInc(NewVarOperand(VARIABLE, node->temp), NewVarOperand(VARIABLE, place));
					}
				}
			}
			else
			{
				InterCodes* last = InstructionList->prev;
				char tt[20];
				if(last->code.kind == ASSIGN)
				{
					strcpy(tt, last->code.u.assign.left->u.name);
				}
				if(last->code.kind == BINOP)
				{
					strcpy(tt, last->code.u.binop.result->u.name);
				}
				if(size > 0)
				{
					char t2[20];
					new_temp(place);
					new_temp(t1);
					new_temp(t2);
					NewRelopInc(BINOP,0, NewVarOperand(VARIABLE,tt), NewConstOperand(size), NewVarOperand(VARIABLE, t1));
					NewRelopInc(BINOP,0, op, NewVarOperand(VARIABLE, t1), NewVarOperand(VARIABLE, t2));
					NewAssignInc(NewVarOperand(SSTAR, t2), NewVarOperand(VARIABLE, place));
				}
				if(size == 0)
				{
					new_temp(place);
					new_temp(t1);
					NewRelopInc(BINOP,0, op, NewVarOperand(VARIABLE, tt), NewVarOperand(VARIABLE, t1));
					NewAssignInc(NewVarOperand(SSTAR, t1), NewVarOperand(VARIABLE, place));
				}
			}
		}
		if(strcmp(p->children[1]->name,"RELOP")==0 || strcmp(p->children[1]->name,"AND")==0 || strcmp(p->children[1]->name,"OR")==0 || strcmp(first->name,"NOT")==0)
		{
			char l1[20], l2[20];
			new_label(l1); 
			new_label(l2);
			new_temp(place);
			Operand label1 = NewVarOperand(VARIABLE, l1);
			Operand label2 = NewVarOperand(VARIABLE, l2);
			NewAssignInc(NewConstOperand(0), NewVarOperand(VARIABLE, place));
			translate_Cond(p, label1, label2, flag);
			NewOtherInc(LABELINC, label1);
			NewAssignInc(NewConstOperand(1), NewVarOperand(VARIABLE, place));	
			NewOtherInc(LABELINC, label2);
		}
		if(strcmp(p->children[1]->name,"PLUS")==0 || strcmp(p->children[1]->name,"MINUS")==0 || strcmp(p->children[1]->name,"STAR")==0 || strcmp(first->name,"DIV")==0)
		{
			char t1[20], t2[20];
			t1[0]='\0';
			t2[0]='\0';
			Operand op1,op2,op3;
			translate_Exp(first, t1, flag);
			if(strlen(t1) == 0)
			{
				op1 = NewConstOperand(figure);
			}
			if(strlen(t1) > 0)
			{
				op1 = NewVarOperand(VARIABLE, t1);
			}
			translate_Exp(p->children[2], t2, flag);
			if(strlen(t2) == 0)
			{
				op2 = NewConstOperand(figure);
			}
			if(strlen(t2) > 0) 
			{
				op2 = NewVarOperand(VARIABLE, t2);
			}
			new_temp(place);
			op3= NewVarOperand(VARIABLE, place);
			if(strcmp(p->children[1]->name, "PLUS")==0)
			{
				NewRelopInc(BINOP, 0, op1, op2, op3);
			}
			if(strcmp(p->children[1]->name, "MINUS")==0)
			{
				NewRelopInc(BINOP, 1, op1, op2, op3);
			}
			if(strcmp(p->children[1]->name, "STAR")==0)
			{
				NewRelopInc(BINOP, 2, op1, op2, op3);
			}
			if(strcmp(p->children[1]->name, "DIV")==0)
			{
				NewRelopInc(BINOP, 3, op1, op2, op3);
			}
		}
		if(strcmp(p->children[1]->name, "ASSIGNOP") == 0)
		{
			char t[20],var[20];
			t[0]='\0';
			translate_Exp(p->children[2], t, flag);
			Operand op;
			if(strlen(t) == 0)
			{
				op = NewConstOperand(figure);
			}
			if(strlen(t) > 0)
			{
				op = NewVarOperand(VARIABLE, t);
			}
			FieldList node = lookup(first->word);
			if(strlen(node->temp) == 0)
			{
				new_variable(var);
				strcpy(node->temp, var);
			}
			if(strcmp(first->children[0]->name, "ID") == 0) //Exp:ID
			{
				NewAssignInc(op, NewVarOperand(VARIABLE, node->temp));
			}
			if(strcmp(first->children[0]->name, "Exp") == 0) 
			{
				char ttt[20], t1[20];
				ttt[0]='\0';t1[0]='\0';
				int size = offset(first, ttt, flag);
				first = first->children[0];
				if(strcmp(p->children[1]->name, "LB") == 0) //array
				{
					LineNo=1;
					return;
				}
				Operand op1;
				if(flag == 0)
				{
					op1 = NewVarOperand(ADDRESS, node->temp);
				}
				if(flag == 1)
				{
					op1 = NewVarOperand(VARIABLE, node->temp);
				}
				new_temp(t1);
				if(strlen(ttt) == 0)
				{
					if(size == 0)
					{
						NewAssignInc(op1, NewVarOperand(VARIABLE, t1));
					}
					if(size > 0) 
					{
						NewRelopInc(BINOP,0, op1, NewConstOperand(size), NewVarOperand(VARIABLE, t1));
					}
					NewAssignInc(op, NewVarOperand(SSTAR, t1));		
				}
				if(strlen(ttt) > 0)
				{
					InterCodes* last = InstructionList->prev;
					char tt[20], t11[20], t12[20];
					if(last->code.kind == ASSIGN)
					{
						strcpy(tt, last->code.u.assign.left->u.name);
					}
					if(last->code.kind == BINOP)
					{
						strcpy(tt, last->code.u.binop.result->u.name);
					}
					new_temp(t11);
					if(size == 0)
					{
						NewRelopInc(BINOP,0, op1, NewVarOperand(VARIABLE, tt), NewVarOperand(VARIABLE, t11));
						NewAssignInc(op, NewVarOperand(SSTAR, t11));
					}
					if(size > 0)
					{
						new_temp(t12);
						NewRelopInc(BINOP,0,NewVarOperand(VARIABLE, tt), NewConstOperand(size), NewVarOperand(VARIABLE, t11));
						NewRelopInc(BINOP,0, op1, NewVarOperand(VARIABLE, t11), NewVarOperand(VARIABLE, t12));
						NewAssignInc(op, NewVarOperand(SSTAR, t12));
					}
				}
			}
			if(place != NULL)
			{
				new_temp(place);
				NewAssignInc(NewVarOperand(VARIABLE, node->temp), NewVarOperand(VARIABLE, place));
			}
		}
	}
	
}

/**Arglist**/
void translate_Args(Node* p, int flag)
{
	printf("translate_args\n");
	char t[20];
	t[0]='\0';
	translate_Exp(p->children[0], t, flag);
	Arg_list *al = (Arg_list *)malloc(sizeof(Arg_list));
	FieldList node=lookup(p->children[0]->word);
	if(node->type->kind==ARRAY || node->type->kind==STRUCTURE)
	{
		if(flag==0)
		{
			al->kind = 2;
		}		
		if(flag==1)
		{
			al->kind = 1;
		}
	}
	else 
	{
		al->kind = 1;
	}
	if(strlen(t)==0)
	{
		al->kind = 0;
		sprintf(al->name, "%d", figure);
	}
	if(strlen(t) > 0) 
	{
		strcpy(al->name, t);
	}
	al->next = arg_list;  //add to arg_list
	arg_list = al;
	/**recursion**/
	if(p->count!=1 && strcmp(p->children[1]->name,"COMMA")==0)
	{
		translate_Args(p->children[2], flag);
	}
}

void Relop()
{
	InterCodes *last = InstructionList->prev;
	if(last->code.kind==IFOP)
	{
		if(last->code.u.relop.kind % 2 !=0)
		{
			last->code.u.relop.kind--;
		}
		if(last->code.u.relop.kind % 2 ==0)
		{
			last->code.u.relop.kind++;
		}
	}
}

/**translate_cond**/
void translate_Cond(Node *p, Operand correct, Operand wrong, int flag)
{
	printf("translate_cond\n");
	Node* first = p->children[0];
	char t[20];
	t[0]='\0';
	if(strcmp(first->name, "LP") == 0)
	{
		first = p->children[1]->children[0];
	}
	if(strcmp(p->children[1]->name, "RELOP") == 0)
	{
		char t1[20], t2[20];
		t1[0]='\0';
		t2[0]='\0';
		Operand op1;
		Operand op2;
		translate_Exp(first, t1, flag);
		if(strlen(t1) == 0)
		{
			op1 = NewConstOperand(figure);
		}
		if(strlen(t1) > 0)
		{
			op1 = NewVarOperand(VARIABLE, t1);
		}
		translate_Exp(p->children[2], t2, flag);
		if(strlen(t2) == 0)
		{
			op2 = NewConstOperand(figure);
		}
		if(strlen(t2) > 0)
		{
			op2 = NewVarOperand(VARIABLE, t2);
		}
		if(strcmp(p->children[1]->word, ">")==0)
		{
			NewRelopInc(IFOP, 1, op1, op2, wrong);
		}
		if(strcmp(p->children[1]->word, "<")==0)
		{
			NewRelopInc(IFOP, 2, op1, op2, wrong);
		}
		if(strcmp(p->children[1]->word, ">=")==0)
		{
			NewRelopInc(IFOP, 3, op1, op2, wrong);
		}
		if(strcmp(p->children[1]->word, "<=")==0)
		{
			NewRelopInc(IFOP, 4, op1, op2, wrong);
		}
		if(strcmp(p->children[1]->word, "==")==0)
		{
			NewRelopInc(IFOP, 5, op1, op2, wrong);
		}
		if(strcmp(p->children[1]->word, "!=")==0)
		{
			NewRelopInc(IFOP, 6, op1, op2, wrong);
		}
		Relop();
	}
	if(strcmp(p->children[1]->name,"AND")==0)
	{
		translate_Cond(first, correct, wrong, flag);
		translate_Cond(p->children[2], correct, wrong, flag);
	}
	if(strcmp(p->children[1]->name,"OR")==0)
	{
		translate_Cond(first, wrong, correct, flag);
		Relop();
		translate_Cond(p->children[2], correct, wrong, flag);
		NewOtherInc(LABELINC, correct);
	}
	if(strcmp(p->children[1]->name, "NOT") == 0)
	{
		translate_Cond(p->children[1], wrong, correct, flag);
	}
	else
	{
		Operand op;
		translate_Exp(p, t, flag);
		if(strlen(t) == 0)
		{
			op = NewConstOperand(figure);
		}
		if(strlen(t) > 0)
		{
			op = NewVarOperand(VARIABLE, t);
		}
		NewRelopInc(IFOP, 1, op, NewConstOperand(0), correct);
		NewOtherInc(GOTO, wrong);
	}
}

/**vardec**/
void translate_VarDec(Node *p, int flag)
{
	printf("translate_vardec\n");
	Node *var = p->children[0];
	while(strcmp(var->name,"ID")!=0)
	{
		if(strcmp(var->name, "VarDec")==0)
		{
			var->name="Exp";
		}
		 var=var->children[0];
	}
	translate_Exp(p, NULL, flag);
}



/**declist**/
void translate_DecList(Node *p, int flag)
{
	printf("translate_declist\n");
	char v[20]; 
	Node *ID = p->children[0]->children[0]->children[0];
	FieldList node = lookup(ID->word);
	if(node->type->kind == STRUCTURE || node->type->kind==ARRAY)
	{
		new_variable(v);
		strcpy(node->temp, v);
		NewDecInc(NewVarOperand(VARIABLE,v), GetStructSize(node->type));
	}
	if(p->children[0]->count > 1)
	{
		translate_VarDec(p->children[0], flag);
	}
	if(p->count > 1 && strcmp(p->children[1]->name,"COMMA")==0)
	{
		translate_DecList(p->children[2], flag);
	}
}

/**DefList**/
void translate_DefList(Node *p, int flag)
{
	printf("translate_deflist\n");
	Node *declist=p;
	while(declist != NULL)
	{
		declist = declist->children[0]->children[1];
		translate_DecList(declist, flag);
	}
}

/**translate_varlist**/
void translate_VarList(Node *p)
{
	printf("translate_varlist\n");
	Node *ID = p->children[1]->children[0];
	char v[20];
	Arg_list *al = (Arg_list *)malloc(sizeof(struct Arg_list_)); 
	new_variable(v);
	FieldList node  = lookup(ID->word);
	strcpy(node->temp, v);
	strcpy(al->name, v);
	if(arg_list == NULL)
	{
		al->next = arg_list; 
		arg_list = al;
	}
	if(arg_list != NULL)
	{
		Arg_list *temp = arg_list;
		while(temp->next!=NULL)
		{
			temp=temp->next;
		}
		temp->next = al;
	}
	/**recurse**/
	if(p->count > 1 && strcmp(p->children[1]->name,"COMMA")==0)
	{
		translate_VarList(p->children[2]);
	}
}

/**function**/
void translate_FunDec(Node *p)
{
	printf("function\n");
	NewOtherInc(FUNCTION, NewVarOperand(VARIABLE, p->children[0]->word));
	printf("function1\n");
	if(strcmp(p->children[2]->name, "RP") != 0)
	{
		translate_VarList(p->children[2]);
		NewOtherInc(PARAM, NewListOperand(PARAMS));
		arg_list = NULL;
	}
}

/**compst**/
void translate_CompSt(Node *p, int flag)
{
	Node *deflist = p->children[1];
	Node *stmt = p->children[2];
	if(strcmp(deflist->name, "DefList") == 0)
	{
		translate_DefList(deflist, flag);
	}
	if(strcmp(deflist->name, "DefList") != 0)
	{
		stmt = deflist;
	}
	while(stmt != NULL)
	{
		Node *temp=stmt->children[0];
		translate_Stmt(temp, flag);
		stmt = stmt->children[1];
	}
}

/**stmt**/
void translate_Stmt(Node *p, int flag)
{
	Node *child = p->children[0];
	char t[20],l1[20], l2[20], l3[20];;
	t[0]='\0';
	if(strcmp(p->children[0]->name, "Exp") == 0)
	{
		translate_Exp(p->children[0], NULL, flag);
	}
	if(strcmp(p->children[0]->name, "CompSt") == 0)
	{
		translate_CompSt(p->children[0], flag);
	}
	if(strcmp(p->children[0]->name, "RETURN") == 0)
	{
		Operand op;
		translate_Exp(p->children[1], t, flag);
		if(strlen(t) == 0)
		{
			op = NewConstOperand(figure);
		}
		if(strlen(t) > 0)
		{
			op = NewVarOperand(VARIABLE, t);
		}
		NewOtherInc(RETURNINC, op);
	}
	if(strcmp(p->children[0]->name, "WHILE") == 0)
	{
		new_label(l1); 
		new_label(l2); 
		new_label(l3);
		Operand label1,label2,label3;
		label1 = NewVarOperand(VARIABLE, l1);
		label2 = NewVarOperand(VARIABLE, l2);
		label3 = NewVarOperand(VARIABLE, l3);
		NewOtherInc(LABELINC, label1);
		translate_Cond(p->children[2], label2, label3, flag);
		translate_Stmt(p->children[4], flag);
		NewOtherInc(GOTO, label1);
		NewOtherInc(LABELINC, label3);
	}
	if(strcmp(p->children[0]->name, "IF") == 0)
	{
		new_label(l1);
		new_label(l2);
		Operand label1,label2,label3;
		label1 = NewVarOperand(VARIABLE, l1);
		label2 = NewVarOperand(VARIABLE, l2);
		label3 = NULL;
		translate_Cond(p->children[2], label1, label2, flag);
		translate_Stmt(p->children[4], flag);
		if(p->count > 5)
		{
			new_label(l3);
			label3 = NewVarOperand(VARIABLE, l3);
			NewOtherInc(GOTO, label3);
		}
		NewOtherInc(LABELINC, label2);
		if(p->count > 5)
		{
			translate_Stmt(p->children[7], flag);
			NewOtherInc(LABELINC, label3);
		}
	}
}



/**进行分析，产生指令**/
void TreeAnalysis(Node *p)
{
	printf("analysis\n");
	if(LineNo==1)
	{
		return;
	}
	if(p!=NULL)
	{
		if(strcmp(p->name, "ExtDef") != 0)
		{
			int i=0;
			Node *temp = p->children[0];
			while(temp!=NULL)
			{
				TreeAnalysis(temp);
				i++;
				temp=p->children[i];
			}
		}
		if(strcmp(p->name, "ExtDef") == 0 && strcmp(p->children[1]->name, "FunDec") == 0)
		{
			translate_FunDec(p);
			if(strcmp(p->children[2]->name, "CompSt") == 0)
			{
				if(strcmp(p->children[1]->children[0]->word, "main")==0)
					translate_CompSt(p->children[2], 0);
				else
					translate_CompSt(p->children[2], 1);
			}
		}
	}
}

void WriteInOperand(Operand op, FILE *f)
{
	char* buf = (char*) malloc(1000);
	int length = 0;
	if(op->kind == CONSTANT)
	{
		memcpy(buf+length, "#", 1);
		length ++;
		sprintf(buf+length, "%d", op->u.value);
		length = length+GetIntSize(op->u.value);
	}
	if(op->kind == VARIABLE)
	{
		memcpy(buf+length, op->u.name, strlen(op->u.name));
		length = length+strlen(op->u.name);
	}
	if(op->kind == ADDRESS)
	{
		memcpy(buf+length, "&", 1);
		length ++;
		memcpy(buf+length, op->u.name, strlen(op->u.name));
		length = length+strlen(op->u.name);
	}
	if(op->kind == CALL)
	{
		memcpy(buf+length, "CALL ", 5);
		length = length+5;
		memcpy(buf+length, op->u.name, strlen(op->u.name));
		length = length+strlen(op->u.name);
	}
	if(op->kind == SSTAR)
	{
		memcpy(buf+length, "*", 1);
		length ++;
		memcpy(buf+length, op->u.name, strlen(op->u.name));
		length = length+strlen(op->u.name);
	}
	if(op->kind == ARGS)
	{
		Arg_list *al = op->u.args;
		memcpy(buf+length, "ARG ", 4);
		length =length+4;
		if(al->kind==0)
		{
			memcpy(buf+length, "#", 1);
			length ++;
		}
		if(al->kind==2)
		{
			memcpy(buf+length, "&", 1);
			length ++;
		}
		memcpy(buf+length, al->name, strlen(al->name));
		length = length+strlen(al->name);
		al = al->next;
		for(;al != NULL; al = al->next)
		{
			memcpy(buf+length, "\n", 1);
			length ++;
			memcpy(buf+length, "ARG ", 4);
			length = length+4;
			if(al->kind==0)
			{
				memcpy(buf+length, "#", 1);
				length ++;
			}
			if(al->kind==2)
			{
				memcpy(buf+length, "&", 1);
				length ++;
			}
			memcpy(buf+length, al->name, strlen(al->name));
			length = length+strlen(al->name);
		}
	}
	if(op->kind==PARAMS)
	{
		Arg_list *al = op->u.args;
		memcpy(buf+length, "ARG ", 4);
		length = length+4;
		memcpy(buf+length, "PARAM ", 6);
		length = length+6;
		memcpy(buf+length, al->name, strlen(al->name));
		length = length+strlen(al->name);
		al = al->next;
		for(;al != NULL; al = al->next)
		{
			memcpy(buf+length, "\n", 1);
			length = length+1;
			memcpy(buf+length, "ARG ", 4);
			length = length+4;
			memcpy(buf+length, "PARAM ", 6);
			length = length+6;
			memcpy(buf+length, al->name, strlen(al->name));
			length = length+strlen(al->name);
		}
	}
	fwrite(buf, length, 1, f);
	free(buf);
}

void WriteIn(InterCodes* current, FILE *f)
{
	if(current->code.kind==ASSIGN)
	{
		WriteInOperand(current->code.u.assign.left, f);
		fwrite(" := ", 4, 1, f);
		WriteInOperand(current->code.u.assign.right, f);
	}
	if(current->code.kind==BINOP)
	{
		WriteInOperand(current->code.u.binop.result, f);
		fwrite(" := ", 4, 1, f);
		WriteInOperand(current->code.u.binop.op1, f);
		//+-*/
		if(current->code.u.binop.kind==0)
		{
			fwrite(" + ", 3, 1, f);
		}
		if(current->code.u.binop.kind==1)
		{
			fwrite(" - ", 3, 1, f);
		}
		if(current->code.u.binop.kind==2)
		{
			fwrite(" * ", 3, 1, f);
		}
		if(current->code.u.binop.kind==3)
		{
			fwrite(" / ", 3, 1, f);
		}
		WriteInOperand(current->code.u.binop.op2, f);
	}
	if(current->code.kind==IFOP)
	{
		fwrite("IF ", 3, 1, f);
		WriteInOperand(current->code.u.relop.op1, f);
		//relop 
		if(current->code.u.relop.kind==1)
		{
			fwrite(" >", 3, 1, f);
		}
		if(current->code.u.relop.kind==2)
		{
			fwrite(" < ", 3, 1, f);
		}
		if(current->code.u.relop.kind==3)
		{
			fwrite(" >= ", 4, 1, f);
		}
		if(current->code.u.relop.kind==4)
		{
			fwrite(" <= ", 4, 1, f);
		}
		if(current->code.u.relop.kind==5)
		{
			fwrite(" == ", 4, 1, f);
		}
		if(current->code.u.relop.kind==6) 
		{
			fwrite(" != ", 4, 1, f);
		}
		WriteInOperand(current->code.u.relop.op2, f);
		fwrite(" GOTO ", 6, 1, f);
		WriteInOperand(current->code.u.relop.op3, f);
	}
	if(current->code.kind==GOTO)
	{
		fwrite("GOTO ", 5, 1, f);
		WriteInOperand(current->code.u.op, f);
	}
	if(current->code.kind==LABELINC)
	{
		fwrite("LABEL ", 6, 1, f);
		WriteInOperand(current->code.u.op, f);
		fwrite(" : ", 3, 1, f);
	}
	if(current->code.kind==RETURNINC)
	{
		fwrite("RETURN ", 7, 1, f);
		WriteInOperand(current->code.u.op, f);
	}
	if(current->code.kind==READ)
	{
		fwrite("READ ", 5, 1, f);
		WriteInOperand(current->code.u.op, f);
	}
	if(current->code.kind==WRITE)
	{
		fwrite("WRITE ", 6, 1, f);
		WriteInOperand(current->code.u.op, f);
	}
	if(current->code.kind==ARG)
	{
		WriteInOperand(current->code.u.op, f);
	}
	if(current->code.kind==FUNCTION)
	{
		fwrite("FUNCTION ", 9, 1, f);
		WriteInOperand(current->code.u.op, f);
		fwrite(" :", 2, 1, f);
	}
	if(current->code.kind==PARAM)
	{
		WriteInOperand(current->code.u.op, f);
	}
	if(current->code.kind==DEC)
	{
		fwrite("DEC ", 4, 1, f);
		WriteInOperand(current->code.u.dec.op, f);
		char buf[10];
		sprintf(buf, " %d", current->code.u.dec.size);
		int len = GetIntSize(current->code.u.dec.size);
		fwrite(buf, len+1, 1, f);
	}
	fwrite("\n",1,1,f);
}

void AllWriteIn(FILE *f)
{
	printf("write in\n");
	if(LineNo==1)
	{
		printf("Can not translate the code: Contain multidimensional array and function parameters of array type!\n");
		return;
	}
	if(InstructionList!=NULL)
	{
		WriteIn(InstructionList, f);
		InterCodes* current = InstructionList->next;
		while(current!=InstructionList)
		{
			WriteIn(current, f);
			current=current->next;
		}
	}
	fclose(f);
}

