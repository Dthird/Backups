#ifndef _SYNTAXTREE_H_
#define _SYNTAXTREE_H_
#include <stdarg.h>

typedef struct Node_
{
	char* type;
	char* name;
	int lineno;
	int count;   //to count its children
	struct Node_ *children[10];
	union{
		int number;
      		float decimal;
      		char word[20];
	};
}Node;



#endif
