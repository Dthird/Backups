#ifndef _SEMANTICS_H_
#define _SEMANTICS_H_


typedef struct Type_* Type;
typedef struct FieldList_* FieldList;
typedef struct FunctionList_* FunctionList;


struct Type_
{
	enum { BASIC, ARRAY, STRUCTURE,R,W} kind;
	union
	{
	// 基本类型
	int basic;
	// 数组类型信息包括元素类型与数组大小构成
	struct { Type elem; int size; } array;
	// 结构体类型信息是一个链表
	FieldList structure;
	} ;
};

//
struct FieldList_ 
{
	char* name;// 域的名字
	char* temp;
	Type type; // 域的类型
	FieldList next; // 下一个域
};

struct FunctionList_
{
	char* name;			// 
	int num;			// 
	FieldList parameter;
	Type type;	//
	FunctionList next;
};

FieldList VariableHead;	// 
FieldList StructureHead;	// 
FunctionList FunctionHead;	// 

#endif

