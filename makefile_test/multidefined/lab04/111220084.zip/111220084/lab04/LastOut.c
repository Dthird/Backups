#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "translate.h"

int sp=-20; //to count the offset 
int numbersCount=0;  //to count the numbers in vardec or param

int GetOffset(Operand op);
void push(Operand op, FILE *f);
void IncOut(InterCodes *inc, FILE *file);
void LastOut(FILE *file);

/**push into the stack**/
void push(Operand op, FILE *f)
{
	int offset = GetOffset(op);
	if(offset != -1)
	{
		fprintf(f, "sw $t1, %d($sp)\n", offset);
	}
	if(offset==-1)
	{
		//先开辟新栈然后再store		
		stack *s = (stack *)malloc(sizeof(stack));
		s->offset = sp;
		s->op = op;
		fprintf(f, "sw $t1, %d($sp)\n", sp);
		s->next = StackList;
		StackList = s;
		sp = sp-4;
	}
}

//get the offset of operand
int GetOffset(Operand op)
{
	stack *s = StackList;
	while(s!=NULL)
	{
		if( s->op->kind==op->kind && strcmp( s->op->u.name,op->u.name)==0)
			return  s->offset;
		else if(( s->op->kind == ADDRESS|| s->op->kind==SSTAR) && strcmp( s->op->u.name,op->u.name)==0) 
			return  s->offset;
		else if((op->kind == ADDRESS||op->kind==SSTAR) && strcmp( s->op->u.name,op->u.name)==0)
			return  s->offset;
		else
			s=s->next;
	}
	return -1;
}

//instruction out
void IncOut(InterCodes *inc, FILE *file)
{
	stack *s;
	InterCodes *temp;
	if(inc == NULL)
	{
		return;
	}	
	if(inc->code.kind==ASSIGN)
	{
		if(inc->code.u.assign.left->kind==VARIABLE)
		{
			if(inc->code.u.assign.right->kind==CONSTANT)
			{
				fprintf(file,"li $t1, %d\n",inc->code.u.assign.right->u.value);
			}
			if(inc->code.u.assign.right->kind==VARIABLE)
			{
				fprintf(file,"lw $t1, %d($sp)\n", GetOffset(inc->code.u.assign.right));
			}
			if(inc->code.u.assign.right->kind==ADDRESS)
			{
				fprintf(file,"la $t1, %d($sp)\n", GetOffset(inc->code.u.assign.right));
			}
			if(inc->code.u.assign.right->kind==SSTAR)
			{
				fprintf(file,"lw $t2, %d($sp)\n", GetOffset(inc->code.u.assign.right));
				fprintf(file,"lw $t1, 0($t2)\n");
			}
			if(inc->code.u.assign.right->kind == CALL)
			{
				int i=0;
				fprintf(file,"sw $ra, 0($sp)\n");
				fprintf(file,"jal %s\n", inc->code.u.assign.right->u.name);
				fprintf(file,"lw $ra, 0($sp)\n");
				while(i<numbersCount)
				{
					fprintf(file,"lw $a%d, %d($sp)\n",i,-(4*i)-4);
					i++;
				}
				numbersCount = 0;
				fprintf(file,"addi $sp, $sp, 2048\n");
				fprintf(file,"move $t1, $v0\n");
			}
			push(inc->code.u.assign.left, file);
		}
		if(inc->code.u.assign.left->kind==SSTAR)
		{
			fprintf(file,"lw $t1, %d($sp)\n", GetOffset(inc->code.u.assign.left));
			if(inc->code.u.assign.right->kind==CONSTANT)
			{
				fprintf(file,"li $t2, %d\n",inc->code.u.assign.right->u.value);
				fprintf(file,"sw $t2, 0($t1)\n");
			}
			if(inc->code.u.assign.right->kind!=CONSTANT)
			{
				fprintf(file,"lw $t2, %d($sp)\n", GetOffset(inc->code.u.assign.right));
				fprintf(file,"sw $t2, 0($t1)\n");
			}
		}
	}
	if(inc->code.kind==BINOP)
	{
		if(inc->code.u.binop.op1->kind==CONSTANT)
		{
			fprintf(file,"li $t2, %d\n",inc->code.u.binop.op1->u.value);
		}
		if(inc->code.u.binop.op1->kind==VARIABLE)
		{
			fprintf(file,"lw $t2, %d($sp)\n", GetOffset(inc->code.u.binop.op1));
		}
		if(inc->code.u.binop.op1->kind==ADDRESS)
		{
			fprintf(file,"la $t2, %d($sp)\n", GetOffset(inc->code.u.binop.op1));
		}
		if(inc->code.u.binop.op1->kind==SSTAR)
		{
			fprintf(file,"lw $t3, %d($sp)\n", GetOffset(inc->code.u.assign.right));
			fprintf(file,"lw $t2, 0($t3)\n");
		}
		if(inc->code.u.binop.kind==0)//+
		{
			if(inc->code.u.binop.op2->kind==CONSTANT)
			{
				if(inc->code.u.binop.op1->kind==ADDRESS)
				{
					fprintf(file,"addi $t1, $t2, -%d\n", inc->code.u.binop.op2->u.value);
				}
				if(inc->code.u.binop.op1->kind!=ADDRESS)
				{
					fprintf(file,"addi $t1, $t2, %d\n", inc->code.u.binop.op2->u.value);
				}
			}
			if(inc->code.u.binop.op2->kind!=CONSTANT)
			{
				fprintf(file,"lw $t3, %d($sp)\n", GetOffset(inc->code.u.binop.op2));
				if(inc->code.u.binop.op1->kind==ADDRESS)
				{
					fprintf(file,"sub $t1, $t2, $t3\n");
				}
				if(inc->code.u.binop.op1->kind!=ADDRESS) 
				{
					fprintf(file,"add $t1, $t2, $t3\n");
				}
			}
		}
		if(inc->code.u.binop.kind==1)//-
		{
			if(inc->code.u.binop.op2->kind==CONSTANT)
			{
				fprintf(file,"addi $t1, $t2, -%d\n", inc->code.u.binop.op2->u.value);
			}			
			if(inc->code.u.binop.op2->kind!=CONSTANT)
			{
				fprintf(file,"lw $t3, %d($sp)\n", GetOffset(inc->code.u.binop.op2));
				fprintf(file,"sub $t1, $t2, $t3\n");
			}
		}
		if(inc->code.u.binop.kind==2)//*
		{
			if(inc->code.u.binop.op2->kind==CONSTANT)
			{
				fprintf(file,"li $t3, %d\n", inc->code.u.binop.op2->u.value);
				fprintf(file,"mul $t1, $t2, $t3\n");
			}
			if(inc->code.u.binop.op2->kind!=CONSTANT)
			{
				fprintf(file,"lw $t3, %d($sp)\n", GetOffset(inc->code.u.binop.op2));
				fprintf(file,"mul $t1, $t2, $t3\n");
			}	
		}
		if(inc->code.u.binop.kind==3)// /
		{
			if(inc->code.u.binop.op2->kind==CONSTANT)
			{
				fprintf(file,"li $t3, %d\n", inc->code.u.binop.op2->u.value);
				fprintf(file,"div $t2, $t3\n");
				fprintf(file,"mflo $t1\n");
			}
			if(inc->code.u.binop.op2->kind!=CONSTANT)
			{
				fprintf(file,"lw $t3, %d($sp)\n", GetOffset(inc->code.u.binop.op2));
				fprintf(file,"div $t2, $t3\n");
				fprintf(file,"mflo $t1\n");
			}				
		}
		push(inc->code.u.binop.result, file);
	}
	if(inc->code.kind==IFOP)
	{
		if(inc->code.u.relop.op1->kind==CONSTANT)
		{
			fprintf(file,"li $t1, %d\n%s\n",inc->code.u.relop.op1->u.value, inc->code.u.relop.op3->u.name);
		}
		if(inc->code.u.relop.op1->kind!=CONSTANT)
		{
			fprintf(file,"lw $t1, %d($sp)\n%s\n", GetOffset(inc->code.u.relop.op1), inc->code.u.relop.op3->u.name);
		}	
		if(inc->code.u.relop.op2->kind==CONSTANT)
		{
			fprintf(file,"li $t2, %d\n%s\n",inc->code.u.relop.op2->u.value, inc->code.u.relop.op3->u.name);
		}
		if(inc->code.u.relop.op2->kind!=CONSTANT)
		{
			fprintf(file,"lw $t2, %d($sp)\n%s\n", GetOffset(inc->code.u.relop.op2), inc->code.u.relop.op3->u.name);
		}
		if(inc->code.u.relop.kind == 1) //>
		{
			fprintf(file,"bgt $t1, $t2, %s\n", inc->code.u.relop.op3->u.name);		
		}
		if(inc->code.u.relop.kind == 2)  //<
		{
			fprintf(file,"blt $t1, $t2, %s\n", inc->code.u.relop.op3->u.name);		
		}
		if(inc->code.u.relop.kind == 3)  //>=
		{
			fprintf(file,"bge $t1, $t2, %s\n", inc->code.u.relop.op3->u.name);
		}	
		if(inc->code.u.relop.kind == 4)  //<=
		{
			fprintf(file,"ble $t1, $t2, %s\n", inc->code.u.relop.op3->u.name);	
		}
		if(inc->code.u.relop.kind == 5)  //==
		{
			fprintf(file,"beq $t1, $t2, %s\n", inc->code.u.relop.op3->u.name);
		}
		if(inc->code.u.relop.kind == 6)  //!=
		{
			fprintf(file,"bne $t1, $t2, %s\n", inc->code.u.relop.op3->u.name);
		}
	}
	if(inc->code.kind==GOTO)
	{
		fprintf(file, "j %s\n", inc->code.u.op->u.name);
	}
	if(inc->code.kind==LABELINC)
	{
		fprintf(file, "%s:\n", inc->code.u.op->u.name);
	}
	if(inc->code.kind==RETURNINC)
	{
		if(inc->code.u.op->kind==CONSTANT)
		{
			fprintf(file,"li $t1, %d\n",inc->code.u.op->u.value);
			fprintf(file,"move $v0, $t1\n");
			fprintf(file,"jr $ra\n");
		}
		if(inc->code.u.op->kind==VARIABLE)
		{
			fprintf(file,"lw $t1, %d($sp)\n", GetOffset(inc->code.u.op));
			fprintf(file,"move $v0, $t1\n");
			fprintf(file,"jr $ra\n");
		}
		if(inc->code.u.op->kind==SSTAR)
		{
			fprintf(file,"la $t2, %d($sp)\n", GetOffset(inc->code.u.op));
			fprintf(file,"lw $t1, 0($t2)\n");
			fprintf(file,"move $v0, $t1\n");
			fprintf(file,"jr $ra\n");
		}
	}
	if(inc->code.kind==READ)
	{
		fprintf(file,"sw $ra, 0($sp)\njal read\nlw $ra, 0($sp)\nmove $t1, $v0\n");
		push(inc->code.u.op, file);
	}
	if(inc->code.kind==WRITE)
	{
		if(inc->code.u.op->kind==CONSTANT)
		{
			fprintf(file,"li $t1, %d\n",inc->code.u.op->u.value);
			fprintf(file,"move $a0, $t1\n");
			fprintf(file,"addi $sp, $sp, -2048\n");
			fprintf(file,"sw $a0, -4($sp)\n");
			fprintf(file,"sw $ra, 0($sp)\njal write\nlw $ra, 0($sp)\n");
			fprintf(file,"lw $a0, -4($sp)\n");
			fprintf(file,"addi $sp, $sp, 2048\n");
		}
		if(inc->code.u.op->kind==VARIABLE)
		{
			fprintf(file,"lw $t1, %d($sp)\n", GetOffset(inc->code.u.op));
			fprintf(file,"move $a0, $t1\n");
			fprintf(file,"addi $sp, $sp, -2048\n");
			fprintf(file,"sw $a0, -4($sp)\n");
			fprintf(file,"sw $ra, 0($sp)\njal write\nlw $ra, 0($sp)\n");
			fprintf(file,"lw $a0, -4($sp)\n");
			fprintf(file,"addi $sp, $sp, 2048\n");
		}
		if(inc->code.u.op->kind==SSTAR)
		{
			fprintf(file,"la $t2, %d($sp)\n", GetOffset(inc->code.u.op));
			fprintf(file,"lw $t1, 0($t2)\n");
			fprintf(file,"move $a0, $t1\n");
			fprintf(file,"addi $sp, $sp, -2048\n");
			fprintf(file,"sw $a0, -4($sp)\n");
			fprintf(file,"sw $ra, 0($sp)\njal write\nlw $ra, 0($sp)\n");
			fprintf(file,"lw $a0, -4($sp)\n");
			fprintf(file,"addi $sp, $sp, 2048\n");
		}
	}
	if(inc->code.kind==ARG)
	{
		if(inc->code.u.op->kind==CONSTANT)
		{
			fprintf(file,"li $t1, %d\n",inc->code.u.op->u.value);
			fprintf(file,"move $a%d, $t1\n",numbersCount);
		}
		if(inc->code.u.op->kind!=CONSTANT)
		{
			fprintf(file,"lw $t1, %d($sp)\n", GetOffset(inc->code.u.op));
			fprintf(file,"move $a%d, $t1\n",numbersCount);
		}
		if(inc->next->code.kind!=ARG)
		{
			fprintf(file,"addi $sp, $sp, -2048\n");
		}
		fprintf(file,"sw $a%d, %d($sp)\n",numbersCount,-(4*numbersCount)-4);
		numbersCount++;
	}
	if(inc->code.kind==FUNCTION)
	{
		fprintf(file,"\n%s:\n", inc->code.u.op->u.name);
		if(strcmp(inc->code.u.op->u.name,"main")==0)
		{
			fprintf(file,"addi $sp, $sp, -2048\n");
		}
	}
	if(inc->code.kind==PARAM)
	{
		fprintf(file,"move $t1, $a%d\n",numbersCount);
	}
	if(inc->code.kind==DEC)
	{
		s = (stack *)malloc(sizeof(stack));
		s->op = inc->code.u.dec.op;
		s->offset = sp;
		fprintf(file,"li $t1, %d\n",sp);
		fprintf(file,"sw $t1, %d($sp)\n",sp);
		s->next = StackList;
		StackList = s;
		sp = sp - inc->code.u.dec.size;
	}		
}

void LastOut(FILE *file)
{
	//printf("lastout\n");
	fprintf(file, ".data\n_prompt: .asciiz \"Enter an integer:\"\n_ret: .asciiz \"\\n\"\n.globl main\n.text\n");
	//printf("lastout\n");
	fprintf(file, "\n");
	fprintf(file, "read:\nli $v0, 4\nla $a0, _prompt\nsyscall\nli $v0, 5\nsyscall\njr $ra\n");
	fprintf(file, "\n");
	fprintf(file, "write:\nli $v0, 1\nsyscall\nli $v0, 4\nla $a0, _ret\nsyscall\nmove $v0, $0\njr $ra\n");
	IncOut(InstructionList, file);
	InterCodes *inc = InstructionList->next;
	while(inc!=InstructionList)
	{
		//printf("incout relop\n");
		IncOut(inc, file);
		inc=inc->next;
	}
	fclose(file);
}

