#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "SyntaxTree.h"
#include "semantic.h"

extern Type GetExpType(Node *p);
extern void GetFields(Node *p,Type init,FieldList list);
extern FunctionList GetFunction(char *name);
extern FieldList GetStructure(char *name);
extern Type GetVariableType(char* name);


void AddVariable(FieldList variable,int line)
{		
	Type temp=GetVariableType(variable->name);
	if(temp==NULL)  //不重名则向变量链表中添加变量
	{
		variable->next=VariableHead;
		VariableHead=variable;
		FieldList t = VariableHead;
	}
	else
	{
		printf("Error type 3 at line %d: Redefined variable '%s' \n", line,variable->name);
	}
}


void AddStructure(FieldList structure,int line)
{
	structure->next=StructureHead;
	StructureHead=structure;
}

//根据结构名称找到该结构
FieldList GetStructure(char *name)
{
	FieldList temp=StructureHead;
	for(;temp!=NULL;temp=temp->next)
	{
		for(;temp->type->structure!=NULL;temp->type->structure=temp->type->structure->next)
		{
			if(strcmp(temp->type->structure->name,name)==0)
			{
				return temp;
			}
		}
	}
	return NULL;
}


void AddFunction(FunctionList function,int line)
{
	
	FunctionList temp=GetFunction(function->name);
	//不重名则向结构链表中添加该结构
	if(temp==NULL)
	{
		function->next=FunctionHead;
		FunctionHead=function;
	}
	else
	{
		printf("Error type 4 at line %d: Redefined function '%s' \n", line,function->name);
	}
} 

//根据函数名找到该函数
FunctionList GetFunction(char *name)
{
	FunctionList temp=FunctionHead;
	for(;temp!=NULL;temp=temp->next)
	{
		if(strcmp(temp->name,name)==0)
		{
			return temp;
		}
	}
	return NULL;
}	
//查找目的变量的类型
Type GetVariableType(char* name) 
{
	
	Type type=(Type)malloc(sizeof(struct Type_));
	type =NULL;
	FieldList temp=VariableHead;
	for(;temp!=NULL;temp=temp->next)
	{
		if(strcmp(temp->name,name)==0)
		{
			//printf("temp %d\n",temp->type->basic);	
			type=temp->type;
			break;
		}
	}
	return type;
}

//查找目的结构的类型
Type GetStructureType(char *name)
{
	Type type=NULL;
	FieldList temp1=StructureHead;
	for(;temp1!=NULL;temp1=temp1->next)
	{
		if(strcmp(temp1->name,name)==0)
		{	
			type=temp1->type;
			break;
		}
	}
	return type;
}

//获取所有定义语句的类型
Type GetDefType(Node *p,Type init)
{	
	Node *temp=p;
	Type type=(Type)malloc(sizeof(struct Type_));
	for(;temp!=NULL;temp=temp->children[0])
	{
		if(strcmp(temp->name,"Specifier")==0)
		{
			temp=temp->children[0];
			/*Type*/
			
			if(strcmp(temp->name,"TYPE")==0)
			{
		
				if(strcmp(temp->word,"int")==0)
				{
					type->kind=BASIC;
					type->basic=0;
				}
				if(strcmp(temp->word,"float")==0)
				{
					
					type->kind=BASIC;
					
					type->basic=1;
				}
			}
			/*StructSpecifier*/
			else
			{
				if(temp->count==2) //STRUCT Tag
				{
					
					temp=temp->children[1];//Tag
					type=GetStructureType(temp->children[0]->word);
					if(type==NULL)
					{
						printf("Error type 17 at line %d: Undefined struct ‘%s’\n", temp->lineno,temp->children[0]->word);
						return NULL;
					}
				}
				else  //Struct OptTag { DefList } 
				{ 
					type->kind=STRUCTURE;
					FieldList l=(FieldList)malloc(sizeof(struct FieldList_));
					
					GetFields(temp->children[3],init,l); //DefList

					type->structure=l;
					temp=temp->children[1];	//OptTag
					FieldList t=(FieldList)malloc(sizeof(struct FieldList_));
					t->name=temp->children[0]->word;
					t->type=type;
					AddStructure(t,temp->lineno);
					
				}
			}
		}
		if(strcmp(temp->name,"VarDec")==0)  
		{
			if(temp->count!=1)  //VarDec [ int ]
			{
				type->kind=ARRAY;
				type->array.elem=init;
				type->array.size=temp->children[2]->number;
			}
		}
		
	}
	return type;			
}

//从尾部插入节点并返回其头节点
FieldList InsertNode(FieldList head,FieldList list)
{
	if(head->name==NULL)
	{
		head=list;
	}
	else 
	{	
		FieldList a=head;
		for(;a!=NULL;a=a->next){}
		a->next=list;
	}
	return head;
}
	
//获取结构中的变量（即其type->structure的内容）
void GetFields(Node *p,Type init,FieldList list)
{
	if(strcmp(p->name,"DefList")==0)
	{
		
		if(p->count!=0)
		{	
			/*Def*/
			GetFields(p->children[0],init,list);
			/*DefList*/
			if(p->children[1]!=NULL){
				GetFields(p->children[1],init,list);
			}
		}
	}
	if(strcmp(p->name,"Def")==0){
		Type type=GetDefType(p->children[0],init);
		/*DecList*/
		GetFields(p->children[1],type,list);
	}
	if(strcmp(p->name,"DecList")==0)
	{
	
		/*Dec*/
		GetFields(p->children[0],init,list);
		if(p->count!=1)
		{
		
		/*DecList*/
			GetFields(p->children[2],init,list);
		}
	}
	if(strcmp(p->name,"Dec")==0)
	{
		if(p->count==1)
		{	
			/*VarDec*/
			GetFields(p->children[0],init,list);
		}
		else 
		{
			printf("Error type 15 at line %d: %s can't be initialized\n",p->children[0]->lineno,p->children[0]->children[0]->word);
		}
	}
	if(strcmp(p->name,"VarDec")==0)
	{
		
		Type type=GetDefType(p,init);
		FieldList temp=(FieldList)malloc(sizeof(struct FieldList_));
		
		//temp->next=NULL;
		FieldList temp1=list;
		int Is_Exist=0;
		for(;temp1->name!=NULL;temp1=temp1->next)
		{
			if(strcmp(p->children[0]->word,temp1->name)==0)
			{
				printf("Error type 15 at line %d: redifined field '%s'\n",p->children[0]->lineno,p->children[0]->word);
				Is_Exist=1;
				break;
			}
		}
		if(Is_Exist==0)
		{
			//printf("lala \n");
			temp->name=p->children[0]->word; //ID
			temp->type=type;
			temp->next=list;
			list=temp;
		}
	}
			
}

//获取函数的所有参数
FieldList GetParameters(Node *p,Type type)
{
	FieldList head=(FieldList)malloc(sizeof(struct FieldList_));
	if ( strcmp(p->name, "VarList") == 0 ) 
	{ 
		if(p->count==1)
		{
			Node *temp = p->children[0]; //ParamDec
			type = GetDefType(temp->children[0], type); //Specifier
			FieldList t=(FieldList)malloc(sizeof(struct FieldList_));
			t->name=temp->children[1]->children[0]->word;  //VarDec -> ID
			t->type=type;
			head=InsertNode(head,t);
		}
		else
		{
			//GetFields(temp->children[1], type);//VarDec
			head=InsertNode(head,GetParameters(p->children[2],type));// VarList
		}
	}
	return head;
}

//获取调用函数时的实参类型
void DivideArgs(Node *p,FieldList list)
{
		if(strcmp(p->name,"Args")==0)
		{
			Node *temp=p->children[0];
			FieldList l=(FieldList)malloc(sizeof(struct FieldList_));
			if(ExpJudge(temp)==0&&p->count==1)
			{
				Type type=GetExpType(p->children[0]);
				l->name=NULL;
				l->type=type;
				l->next=list;
				list=l;
			}
			if(ExpJudge(temp)==0&&p->count!=1)
			{
				Type type=GetExpType(temp);
				l->name=NULL;
				l->type=type;
				l->next=list;
				list=l;
				DivideArgs(p->children[2],list);
			}
		}
}

//判断函数的实参与形参是否匹配
int FieldJudge(FieldList a,FieldList b)
{
	if(a==NULL&&b==NULL)
	{
		return 0;
	}
	else if((a==NULL&&b!=NULL)|| (b==NULL&&a!=NULL))
	{	
		return 1;
	}	
	else if(TypeJudge(a->type,b->type)!=0)
	{	
		return 1;
	}	
	else
	{
		return(FieldJudge(a->next,b->next));
	}
}

//判断type是否相同（可适用于多种情况）
int TypeJudge(Type a,Type b)
{
	if(a!=NULL&&b!=NULL)
	{
		if(a->kind==BASIC && b->kind==BASIC)
		{
			if(a->basic==b->basic)
			{
				return 0;
			}
			if(a->basic!=b->basic)
			{
				return 1;
			}
		}
		if(a->kind==STRUCTURE && b->kind==STRUCTURE)
		{
			int same=1;
			for(;a->structure!=NULL&&b->structure!=NULL;a->structure=a->structure->next,b->structure=b->structure->next)
			{
				if(TypeJudge(a->structure->type,b->structure->type)!=0)
				{
					same=0;
					return 1;
				}
			}
			if(same==1)
			{
				return 0;
			}
		}
		if(a->kind==ARRAY && b->kind==ARRAY)
		{
			if(a->array.size==b->array.size)
			{
				return TypeJudge(a->array.elem,b->array.elem);
			}
		}
	}
	return 1;
			
}

//获取表达式的类型
Type GetExpType(Node *p)
{
		
	Type type=(Type)malloc(sizeof(struct Type_));	
	if(strcmp(p->type,"INT")==0)
	{
			
		type->kind=BASIC;
		type->basic=0;
		return type;
		
	}
	if(strcmp(p->type,"FLOAT")==0)
	{
		type->kind=BASIC;
		type->basic=1;
		return type;
	}
	if(strcmp(p->name,"ID")==0)
	{
		type=GetVariableType(p->word);
		return type;
	}
	if(strcmp(p->type,"NES")==0)
	{
		if(p->count==1)
		{
			type=GetExpType(p->children[0]);
		}
		if(p->count==2)
		{
			type=GetExpType(p->children[1]);
		}
		if(p->count==3)
		{
			if(p->children[0]->name=="ID") //ID..
			{
				FunctionList func=GetFunction(p->children[0]->word);
				if(func==NULL)
				{
					return NULL;
				}
				if(func!=NULL)
				{
					type=func->type;
				}
			}
			else if(p->children[2]->name=="ID") //exp.ID
			{
				FieldList stru=GetStructure(p->children[2]->word);
				if(stru==NULL)
				{
					printf("Error type 14 at line %d:Undefined field '%s'\n",p->children[2]->lineno,p->children[2]->word);
					return NULL;
				}
				if(stru!=NULL)
				{
					type=stru->type;
				}
			}
			else
			{
				type=GetExpType(p->children[0]);
			}
		}
		if(p->count==4) 
		{
			if(p->children[0]->name=="ID") //ID(...)
			{
				FunctionList func=GetFunction(p->children[0]->word);
				if(func==NULL)
				{
					return NULL;
				}
				if(func!=NULL)
				{
					type=func->type;
				}
			}
			else   //Exp[Exp]
			{
				Node *temp=p->children[0];
				//int i=0,j=0;
				for(;temp->name!="ID";temp=temp->children[0])
				{
					//i++;
				}
				type=GetExpType(temp);
				if(type->kind!=ARRAY)
				{
					printf("Error type 10 at line %d: '%s' is not an array \n",temp->lineno,temp->word);
					return NULL;
				}
			}	
		}
	}
	return type;
	
}

//判断操作数以及操作符是否匹配
int ExpJudge(Node *p)
{	
	if(strcmp(p->type,"NES")!=0) //minus exp |not exp | ID...
	{
		return 0;
	}
	if(strcmp(p->type,"NES")==0)
	{
		if(strcmp(p->name,"Exp")==0)
		{
			if(p->count==1)
			{
				if(strcmp(p->children[0]->name,"ID")==0) //变量
				{
					Type a=GetVariableType(p->children[0]->word);
					if(a==NULL)
					{
						printf("Error type 1 at line %d: Undefined variable '%s'\n",p->children[0]->lineno,p->children[0]->word);
						return 1;
					}
				}
			}
			if(p->count==3) //Exp-Exp||(Exp)||Exp()
			{
				if(strcmp(p->children[1]->type,"ES")==0)
				{
					if(strcmp(p->children[1]->name,"ASSIGNOP")==0) //=
					{
						Node *left=p->children[0];
						Node *right=p->children[2];
						if(left->count==1)
						{
							if(strcmp(left->children[0]->name,"ID")!=0)
							{
								printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable",left->children[0]->lineno);
								return 1;
							}
						}
						else
						{
							printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n",left->children[0]->lineno);
							return 1;
						}
						if(ExpJudge(left)==0&&ExpJudge(right)==0)
						{
							Type t1=GetExpType(left);
							Type t2=GetExpType(right);
							if(TypeJudge(t1,t2)!=0)
							{
								printf("Error type 5 at line %d:Type mismatched\n",left->lineno);
								return 1;
							}
						}
						else {return 1;}	
					}

					if((strcmp(p->children[1]->name,"AND")==0)||(strcmp(p->children[1]->name,"OR")==0)||(strcmp(p->children[1]->name,"PLUS")==0)||(strcmp(p->children[1]->name,"RELOP")==0)||(strcmp(p->children[1]->name,"MINUS")==0)||(strcmp(p->children[1]->name,"STAR")==0)||(strcmp(p->children[1]->name,"DIV")==0))
					{	
						Node *left=p->children[0];
						Node *right=p->children[2];
						if(ExpJudge(left)==0&&ExpJudge(right)==0)
						{
							Type t1=GetExpType(left);
							Type t2=GetExpType(right);
							//printf("   %d %d\n",t1->basic,t2->basic);
							if(TypeJudge(t1,t2)!=0)
							{
								printf("Error type 7 at line %d:Operands type mismatched\n",left->lineno);
								return 1;
							}
						}
						else {return 1;}
					} 

					if(strcmp(p->children[1]->name,"LP")==0)//Exp()
					{
						if(strcmp(p->children[0]->word,"read")==0)
						{
							FunctionList func=(FunctionList)malloc(sizeof(struct FunctionList_));
							func->type->kind=R;
							func->name=p->children[0]->word;
							func->next=NULL;
							func->parameter=NULL;
							func->num=0;
							AddFunction(func,p->lineno);		
						}
						FunctionList func=GetFunction(p->children[0]->word);
						Type type=GetVariableType(p->children[0]->word);
						Type type1=GetStructureType(p->children[0]->word);
						if(func==NULL&&type==NULL&&type1==NULL)
						{
							printf("Error type 2 at line %d:Undefined function '%s'\n",p->children[0]->lineno,p->children[0]->word);
							return 1;
						}
						if((func==NULL&&type!=NULL)||(func==NULL&&type1!=NULL))
						{
							printf("Error type 11 at line %d:'%s' must be a function\n",p->children[0]->lineno,p->children[0]->word);
							return 1;					
						}
						if(func->num!=0)
						{
							printf("Error type 9 at line %d:Function '%s' has no parmeter\n",p->lineno,func->name);
							return 1;
						}
					}

					if(strcmp(p->children[1]->name,"DOT")==0)//Exp.id	
					{
						Node *left=p->children[0];
						Node *right=p->children[2];
						Type t1=GetExpType(left);
						Type t2=GetExpType(right);
						if(t1!=NULL&&t1->kind!=STRUCTURE)
						{
							printf("Error type 13 at line %d: Illegal use of '.'\n",left->lineno);
							return 1;
						}
						if(t2==NULL)
						{	
							return 1;
						}			
					}
				}
				else
				{
					return ExpJudge(p->children[1]); //(Exp)
				}
			}
			if(p->count==4)  //ID(args)||Exp[Exp]
			{
				Node *left=p->children[0];
				if(strcmp(p->children[0]->word,"write")==0)
				{
					FunctionList func=(FunctionList)malloc(sizeof(struct FunctionList_));
					func->type->kind=W;
					func->name=p->children[0]->word;
					func->next=NULL;
					func->parameter=NULL;
					func->num=0;
					AddFunction(func,p->lineno);	
				}
				if(strcmp(left->name,"ID")==0) //function
				{
					FunctionList func=GetFunction(p->children[0]->word);
					Type type=GetVariableType(p->children[0]->word);
					Type type1=GetStructureType(p->children[0]->word);
						
					if(func==NULL&&type==NULL&&type1==NULL)
					{
						printf("Error type 2 at line %d:Undefined function '%s'\n",p->children[0]->lineno,p->children[0]->word);
						return 1;
					}
					if((func==NULL&&type!=NULL)||(func==NULL&&type1!=NULL))
					{
						printf("Error type 11 at line %d:'%s' must be a function\n",p->children[0]->lineno,p->children[0]->word);
						return 1;					
					}				
					FieldList temp=(FieldList)malloc(sizeof(struct FieldList_));
					DivideArgs(p->children[2],temp);
					if(FieldJudge(temp,func->parameter)!=0)
					{
						printf("Error type 9 at line %d: Parameters are mismatched\n",p->lineno);
						return 1;
					}
				}
				else  //array
				{
					if(ExpJudge(p->children[2])==0)
					{
						Type t=GetExpType(p->children[2]);
						if(t->kind==BASIC&&t->basic!=0)
						{
							printf("Error type 12 at line %d: Operands type mistaken\n",p->lineno);
							return 1;
						}
						if(ExpJudge(p->children[0])==0)
						{
							Type t1=GetExpType(p->children[0]);
							if(t1!=NULL&&t1->kind!=ARRAY)
							{
								printf("Error type 10 at line %d: it's not an array\n",p->lineno);
								return 1;
							}
						}
						if(ExpJudge(p->children[0])!=0)
							return 1;
					}
					else 
						return 1;
				}
			}
		}
	}
	return 0;
}

//遍历
void TraverseTree(Node *p,Type type)
{
	/*FieldList temp = VariableHead;
	while ( temp != NULL ){
		//printf("hello 2\n");
		printf("variable: %s %d\n",temp->name,temp->type->basic);
		temp=temp->next;
	}*/

	/*FieldList temp1 = StructureHead;
	while ( temp1 != NULL ){
		printf("structure: %s : %s: %s\n",temp1->name,temp1->type->structure->name,temp1->type->structure->next->name);
		temp1 = temp1->next;
	}

	FunctionList temp2 = FunctionHead;
	while ( temp2 != NULL ){
		printf("0\n");
		printf("function: %s:%d\n",temp2->name,temp2->type->kind);
		temp2 = temp2->next;
	}*/
	if(p==NULL)
	{		
		return;
	}	
	if(strcmp(p->type,"ID")==0&&strcmp(p->name,"ID")==0)
	{
		FieldList temp=(FieldList)malloc(sizeof(struct FieldList_));
		temp->name=p->word;
		//printf("add %d\n",type->basic);
		temp->type=type;
		temp->next=NULL;
		AddVariable(temp,p->lineno);
	}

	if(strcmp(p->type,"NES")==0)
	{
		if(strcmp(p->name,"Specifier")==0)
		{
			return;
		}
		if(strcmp(p->name,"StructSpecifier")==0)
		{
			//type=GetDefType(p,type);
			return;		
		}
		if(strcmp(p->name,"Exp")==0) 
		{
			ExpJudge(p);
			return;
		}
		type=GetDefType(p,type);
		if(strcmp(p->name,"Dec")==0)
		{
			if(p->count==3)
			{
				Type t1=type;
				Type t2=GetExpType(p->children[2]);
				if(TypeJudge(t1,t2)!=0)
				{
					printf("Error type 5 at line %d:Type mismatched\n",p->lineno);
				}
			}				
		}
		if(strcmp(p->name,"FunDec")==0) //function
		{	
			FunctionList func=(FunctionList)malloc(sizeof(struct FunctionList_));
			func->type=type;
			func->name=p->children[0]->word;
			func->next=NULL;
			if(p->count==3&&strcmp(p->children[0]->name,"ID")==0)  //函数没有参数
			{
				func->num=0;
				func->parameter=NULL;
			}
			/*else if(p->count==3&&p->children[2]->type=="ES") //函数声明
			{
				char *name=p->children[1]->children[0]->word;
				FunctionList a=GetFunction(name);
				if(a==NULL)
				{
					printf("Error type 18 at line %d: Undefined function '%s'\n",p->lineno,name);
				}
				else 
				{
					FieldList l=(FieldList)malloc(sizeof(struct FieldList_));
					Type t=(Type)malloc(sizeof(struct Type_));
					GetParameters(p->children[2],t,l);
					if(FieldJudge(a->parameter,l)!=0)
					{
						printf("Error type 19 at line %d: Inconsistent declaration of function '%s' \n",p->lineno,name); 
					}		
				}
			}*/
			else   //有参函数
			{
				//FieldList head=(FieldList)malloc(sizeof(struct FieldList_));
				Type t=(Type)malloc(sizeof(struct Type_));
				func->parameter=GetParameters(p->children[2],t);
				//func->parameter=head;
				int num1=0;
				FieldList head=func->parameter;
				for(;head!=NULL;head=head->next)
				{	
					num1++;
				}
				func->num=num1;
			}
			AddFunction(func,p->lineno);
			return;
		}		
		int count1=0;
		for(;count1<p->count;count1++)
		{
			TraverseTree(p->children[count1],type);
		}
	}

}

//判断有返回值的函数返回类型是否与函数类型相匹配
void ReturnTypeJudge(Node *p,Type type)
{
	int count1=0;	
	if(strcmp(p->type,"NES")!=0)
		return;
	if(strcmp(p->name,"Stmt")==0)
	{
		if(p->count==3)
		{
			if(strcmp(p->children[1]->name,"Exp")==0)
			{
				Type temp=GetExpType(p->children[1]);
				if(temp!=NULL&&TypeJudge(type,temp)!=0)
				{
					printf("Error type 8 at line %d:The return type mismatched\n",p->children[1]->lineno);
					return;
				}
			}
		}
	}
	for(;count1<p->count;count1++)
	{
		ReturnTypeJudge(p->children[count1],type);
	}
}


void ReturnJudge(Node *p)
{
	int count1=0;
	if(p->type==NULL)
	{
		return;
	}
	if(strcmp(p->type,"NES")!=0)
	{
		return;
	}
	if((strcmp(p->name,"ExtDef")==0)&&strcmp(p->children[1]->name,"FunDec")==0)
	{
		Type check=GetDefType(p->children[0],NULL);
		ReturnTypeJudge(p->children[2],check);
	}
	for(;count1<p->count;count1++)
	{
		ReturnJudge(p->children[count1]);
	}
}





