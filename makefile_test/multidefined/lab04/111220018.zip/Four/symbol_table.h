#ifndef _SYMBOL_TABLE_H_
#define _SYMBOL_TABLE_H_
#define HASH_LENGTH 16384
#define STACK_LENGTH 30
extern struct sym_node* table[HASH_LENGTH];
extern struct sym_node* stack[STACK_LENGTH];
struct arr
{
	struct typ_node* type; 
	int size;
};

struct fld
{
	char* name;
	struct typ_node* type;
	struct fld* next;
};
struct fun
{
	int isDefined;
	struct fld* para;
	struct typ_node* ret;
	int line;
};
//type node
struct typ_node {
	int kind;	// 1 int 2 float 3 array 4 struct 5 func 0 error 
	struct fun* Func;	
	struct fld* Field;
	struct arr* Array;
	int size;
};
// symbol node
struct sym_node {
	int kind;
	char* name; 
	int vid;
	int optype;
	struct typ_node *type;
	struct sym_node *prev, *next;	
	struct sym_node *left, *right;
};
unsigned int hash_pjw(char* name);

struct sym_node* newSym();

struct sym_node* findSym(int lvl,char* name,int kind);

struct sym_node* findSymInStack(int lvl,char* name,int kind);

struct sym_node* addSym(int lvl,char* name, struct typ_node* type,int kind);

void delSymInStack(int lvl);
struct typ_node* newTyp(int kind);
struct typ_node* newArrTyp(struct typ_node* ele,int size);
struct typ_node* newStructTyp(struct fld* field);
struct fld* newFld(struct typ_node* n, char* name, struct fld* next);
struct fld* newFldByStack(int lvl);
struct fun* newFun(struct typ_node* ret, struct fld* para, int isDefined ,int line);
struct typ_node* newFunTyp(struct fun* f);
//judgment
int typCmp(struct typ_node* a, struct typ_node* b);
int fldCmp(struct fld* a, struct fld* b);
int funCmp(struct fun* a, struct fun* b);
struct fld* find_field(struct fld* field, char* name);
void initTable();
#endif
