#include "IR.h"
#include <stdlib.h>
#include <stdio.h>
FILE *fout;
struct varMem* varHead=NULL;
extern struct InterCode* IC_head;
struct varMem {
	int vno; 
	int len; 
	int offset;
	struct varMem *prev, *next;
};
void printHead()
{
	fprintf(fout,".data\n");
	fprintf(fout,"_prompt: .asciiz \"Enter an integer: \"\n");
	fprintf(fout,"_ret: .asciiz \"\\n\" \n");
	fprintf(fout,".globl main \n");
	fprintf(fout,".text \n");
	fprintf(fout,"read: \n");
	fprintf(fout,"\tli $v0, 4 \n");
	fprintf(fout,"\tla $a0, _prompt \n");
	fprintf(fout,"\tsyscall \n");
	fprintf(fout,"\tli $v0, 5 \n");
	fprintf(fout,"\tsyscall \n");
	fprintf(fout,"\tjr $ra \n");
	fprintf(fout,"write: \n");
	fprintf(fout,"\tli $v0, 1 \n");
	fprintf(fout,"\tsyscall \n");
	fprintf(fout,"\tli $v0, 4 \n");
	fprintf(fout,"\tla $a0, _ret \n");
	fprintf(fout,"\tsyscall\n");
	fprintf(fout,"\tmove $v0, $0\n");
	fprintf(fout,"\tjr $ra\n");
}
struct varMem* find_var(int vno)
{
	struct varMem *n = varHead;
	for(;n!=NULL;n=n->next)
	{
		if (n->vno == vno)
			return n;
	}
	return NULL;
}
struct varMem* new_var(int vno, int offset, int len)
{
	if (find_var(vno))
		return NULL;
	struct varMem *n;
	n = malloc(sizeof(struct varMem));
	n->vno = vno;
	n->offset = offset;
	n->len = len;

	n->next = NULL; 
	if(varHead==NULL)
	{
		varHead=n;
		n->prev=NULL;
		return n;
	}
	struct varMem *t=varHead;
	while(t->next)
		t=t->next;
	t->next=n;
	n->prev=t;
	return n;
}
int get_offset(int vno)
{
	return find_var(vno)->offset;
}

void Generatelw(int reg_dst, int offset, int reg_base)
{
	fprintf(fout, "\tlw $%d, %d($%d)\n", reg_dst, offset, reg_base);
}

void Generatesw(int reg_src, int offset, int reg_base)
{
	fprintf(fout, "\tsw $%d, %d($%d)\n",reg_src, offset, reg_base);
}

void Generateli(int reg, int constant)
{
	fprintf(fout, "\tli $%d, %d\n", reg, constant);
}

void Generateadd(int reg_dst, int reg_src1, int reg_src2)
{
	fprintf(fout, "\tadd $%d, $%d, $%d\n", reg_dst, reg_src1, reg_src2);
}

void Generatesub(int reg_dst, int reg_src1, int reg_src2)
{
	fprintf(fout, "\tsub $%d, $%d, $%d\n", reg_dst, reg_src1, reg_src2);
}

void Generatemul(int reg_dst, int reg_src1, int reg_src2)
{
	fprintf(fout, "\tmul $%d, $%d, $%d\n", reg_dst, reg_src1, reg_src2);
}

void Generatediv(int reg_dst, int reg_src1, int reg_src2)
{
	fprintf(fout, "\tdiv $%d, $%d\n", reg_src1, reg_src2);
	fprintf(fout, "\tmflo $%d\n", reg_dst);
}

void Generatelabel(int label)
{
	fprintf(fout, "LABEL%d:\n", label);
}

void Generatefunlabel(char* fname)
{
	fprintf(fout, "%s:\n", fname); 
}

void Generatej(int label)
{
	fprintf(fout, "\tj LABEL%d\n", label);
}

void Generatejal(char* fname)
{
	fprintf(fout, "\tjal %s\n", fname);
}

void Generatejr()
{
	fprintf(fout, "\tjr $%d\n", 31);
}

void Generateifgoto(int r, int reg1, int reg2, int label)
{
	if (r == 0)
		fprintf(fout, "\tbge $%d, $%d, LABEL%d\n", reg1, reg2, label);
	else if (r == 1)
		fprintf(fout, "\tbgt $%d, $%d, LABEL%d\n", reg1, reg2, label);
	else if (r == 2)
		fprintf(fout, "\tble $%d, $%d, LABEL%d\n", reg1, reg2, label);
	else if (r == 3)
		fprintf(fout, "\tblt $%d, $%d, LABEL%d\n", reg1, reg2, label);
	else if (r == 4)
		fprintf(fout, "\tbne $%d, $%d, LABEL%d\n", reg1, reg2, label);
	else if (r == 5)
		fprintf(fout, "\tbeq $%d, $%d, LABEL%d\n", reg1, reg2, label);
}

void Generatemov(int reg1, int reg2)
{
	fprintf(fout, "\tmove $%d, $%d\n", reg1, reg2);
}

void load_operand(struct Operand* op, int reg)
{
	if (op->kind == 0||op->kind == 2||op->kind == 3)
		Generatelw(reg, get_offset(op->vno), 29);
	else if (op->kind == 1)
		Generateli(reg, op->value);
}
void save_operand(struct Operand* op, int reg)
{
	if (op->kind == 0||op->kind == 2||op->kind == 3)
		Generatesw(reg, get_offset(op->vno), 29);
}
void GeneratePush(int reg)
{
	Generateli(12, 4);
	Generatesub(29, 29, 12);
	Generatesw(reg, 0, 29);
}
void GeneratePop(int reg)
{
	Generatelw(reg, 0, 29);
	Generateli(12, 4);
	Generateadd(29, 29, 12);
}


void GenerateCode(FILE *f)
{
	fout=f;
	struct InterCode *funHead, *nextFun;
	printHead();
	for (funHead = IC_head; funHead != NULL; funHead = nextFun)
	{
		int offset = 0;
		int param_size = 0;
		for(nextFun=funHead->next;nextFun!=NULL;nextFun=nextFun->next)
			if (nextFun->kind == 17)
				break;
		varHead=NULL; 
		Generatefunlabel(funHead->op->name);//fun start!
		struct InterCode *p;
		for (p = funHead->next; p->kind == 14; p = p->next)//param
		{
			offset=offset+4;
			new_var(p->op->vno, offset, 4);
		}
		offset = -4; 
		struct InterCode *paramEnd = p; // End of param
		for (; p != nextFun; p = p->next)// Mem Alloc
		{
			if(p->kind==11)
			{
				offset -= p->dec.width;
				new_var(p->dec.x->vno, offset+4, p->dec.width);
			}
			else if(p->kind==1||p->kind==18||p->kind==6||p->kind==7)
			{
				if (new_var(p->assign.left->vno, offset, 4))
					offset -= 4;
			}
			else if(p->kind==2||p->kind==3||p->kind==4||p->kind==5)
			{
				if (new_var(p->binop.result->vno, offset, 4))
					offset -= 4;
			}
			else if(p->kind==15)
			{
				if (new_var(p->op->vno, offset, 4))
					offset -= 4;
			}
			else if(p->kind==13)
			{
				if (new_var(p->call.x->vno, offset, 4))
					offset -= 4;
			}
		}
		int memLength = - 4 - offset ;
		p = paramEnd; 
		for (; p != nextFun; p = p->next)
		{
			if(p->kind==0)
			{
				Generatelabel(p->label);
			}
			else if(p->kind==1)
			{
				load_operand(p->assign.right, 8);
				save_operand(p->assign.left, 8);
			}
			else if(p->kind==6)
			{
				Generatelw(12, get_offset(p->assign.right->vno), 29);
				Generatelw(8, 0, 12);
				save_operand(p->assign.left, 8);
			}
			else if(p->kind==7)
			{
				load_operand(p->assign.right, 8);
				Generatelw(12, get_offset(p->assign.left->vno), 29);
				Generatesw(8, 0, 12);
			}
			else if(p->kind==18)
			{
				Generateli(12, get_offset(p->assign.right->vno));
				Generateadd(8, 12, 29);
				save_operand(p->assign.left, 8);
			}
			else if(p->kind==2)
			{
				load_operand(p->binop.op1, 8);
				load_operand(p->binop.op2, 9);
				Generateadd(8, 8, 9);
				save_operand(p->binop.result, 8);
			}
			else if(p->kind==3)
			{
				load_operand(p->binop.op1, 8);
				load_operand(p->binop.op2, 9);
				Generatesub(8, 8, 9);
				save_operand(p->binop.result, 8);
			}
			else if(p->kind==4)
			{
				load_operand(p->binop.op1, 8);
				load_operand(p->binop.op2, 9);
				Generatemul(8, 8, 9);
				save_operand(p->binop.result, 8);
			}
			else if(p->kind==5)
			{
				load_operand(p->binop.op1, 8);
				load_operand(p->binop.op2, 9);
				Generatediv(8, 8, 9);
				save_operand(p->binop.result, 8);
			}
			else if(p->kind==8)
			{
				Generatej(p->go.label->label);
			}
			else if(p->kind==9)
			{
				load_operand(p->ifgo.x, 8);
				load_operand(p->ifgo.y, 9);
				Generateifgoto(p->ifgo.relop, 8, 9, p->ifgo.label->label); 
			}
			else if(p->kind==12)
			{
				int temp = 0;
				for (; p->kind == 12; p = p->next)
				{
					load_operand(p->op, 8);
					Generatesw(8, offset - temp, 29);
					temp = temp + 4;
				}
				Generatesw(31, offset - temp, 29);
				Generateli(12, memLength + temp + 4);
				Generatesub(29, 29, 12);
				Generatejal(p->call.name);
				GeneratePop(31);
				Generateli(12, temp);
				Generateadd(29, 29, 12);
				Generateli(12, memLength);
				Generateadd(29, 29, 12);
				save_operand(p->call.x, 2);
			}
			else if(p->kind==13)
			{
				Generateli(12, memLength);
				Generatesub(29, 29, 12);
				GeneratePush(31);
				Generatejal(p->call.name);
				GeneratePop(31);
				Generateli(12, memLength);
				Generateadd(29, 29, 12);
				save_operand(p->call.x, 2);
			}
			else if(p->kind==15)
			{
				Generatemov(8, 31);
				Generatejal("read");
				save_operand(p->op, 2);
				Generatemov(31, 8);
			}
			else if(p->kind==16)
			{
				Generatemov(8, 31);
				load_operand(p->op, 4);
				Generatejal("write");
				Generatemov(31, 8);
			}
			else if(p->kind==10)
			{
				load_operand(p->op, 2);
				Generatejr();
			}
		}
	}
}