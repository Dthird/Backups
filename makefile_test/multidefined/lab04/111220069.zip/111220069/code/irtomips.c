#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "ir.c"

struct OffNode{
    	Operand op;
    	int offset;
    	struct OffNode* next;
};
struct OffNode* listhead;
struct OffNode* listtail;
extern struct InterCodeNode* irhead;
FILE* mipsfile = NULL;

/************************** 函数的声明 ************************************/
void genmipscode(char* outputfile);	//本c文件的主函数
int translate_one_ircode(struct InterCodeNode* ir,struct InterCodeNode** splitfun,int* argnum,int* paranum);//对一条中间代码产生mips机器码
int isequal(Operand t1,Operand t2);			//比较两个Operand指针内容是否相等 是返回1，否返回0
void docleaning();					//清理一些申请的空间，如中间代码用到的
int add_to_list(struct InterCode* ir,int* argnum);	//遇到函数时处理一条ir将offset加入offlist
int insert_to_list(Operand op);				//根据偏移量跟操作数添加节点
int search_list(Operand op);				//获取$sp偏移量
int mem_to_reg(Operand op,int regno);			//保存到内存使寄存器可用
int reg_to_mem(Operand op,int regno);			//从内存中取出数据到寄存器
/*********************************** 产生mips代码 *******************************/
//本c文件的主函数
void genmipscode(char* outputfile){
	assert(outputfile != NULL);
	mipsfile = fopen(outputfile,"w");
	//首先在文件中保存一些string的声明和read write函数的声明
	fprintf(mipsfile,".data\n"
			 "_prompt: .asciiz \"Enter an integer:\"\n"
			 "_ret: .asciiz \"\\n\"\n"
			 ".globl main\n"
			 ".text\n"
			 "read:\n"
			 "    li $v0, 4\n"
			 "    la $a0, _prompt\n"
			 "    syscall\n"
			 "    li $v0, 5\n"
			 "    syscall\n"
			 "    jr $ra\n\n"
			 "write:\n"
			 "    li $v0, 1\n"
			 "    syscall\n"
			 "    li $v0, 4\n"
			 "    la $a0, _ret\n"
			 "    syscall\n"
			 "    move $v0, $0\n"
			 "    jr $ra\n\n");
    	//初始化
    	struct InterCodeNode* irtemp = irhead;
    	struct InterCodeNode* splitfun = irhead;
    	int argnum = 0;
	int paranum = 0;
	//下面遍历每条中间代码进行翻译
    	while(irtemp != NULL){
    		int tempi = translate_one_ircode(irtemp,&splitfun,&argnum,&paranum);
    		if(tempi == 0){
    			printf("This case should not happen!--%s:%d\n",__FILE__,__LINE__);
			docleaning();
			exit(1);
    		}
    		irtemp = irtemp->next;
    	}
    	fclose(mipsfile);
    	/**************** 最后处理--删除一些是用到的空间 *****************/
    	docleaning();
    	
}
//比较两个Operand指针内容是否相等
int isequal(Operand t1,Operand t2){
	if(t1->kind != t2->kind)
		return 0;
	else if(t1->kind == VARIABLE && t2->kind == VARIABLE && t1->u.varnum == t2->u.varnum)
            	return 1;
        else if(t1->kind == CONSTANT && t2->kind == CONSTANT && t1->u.value == t2->u.value)
                return 1;
        else if(t1->kind == TEMP && t2->kind == TEMP && t1->u.tempnum == t2->u.tempnum)
                return 1;
        else if(t1->kind == SIZE && t2->kind == SIZE && t1->u.value == t2->u.value)
                return 1;
        else if(t1->kind == RELOP && t2->kind == RELOP && strncmp(t1->u.relop,t2->u.relop,50) == 0)
                return 1;  	
    	else if(t1->kind == FUNC && t2->kind == FUNC && strncmp(t1->u.funname,t2->u.funname,50) == 0)
                return 1;
        else if(t1->kind == ARGOP && t2->kind == ARGOP && t1->u.argnum == t2->u.argnum)
                return 1;
        else
                return 0;
}
//清理一些申请的空间，如中间代码用到的空间
void docleaning(){
	struct InterCodeNode* temp = irhead;
	irhead = NULL;
	struct InterCodeNode* temp2;
	while(temp != NULL){
		temp2 = temp;
		temp = temp->next;
		free(temp2);
	}
	struct OffNode* offtemp = listhead;
	listhead = listtail = NULL;
	struct OffNode* offtemp2;
	while(offtemp != NULL){
		offtemp2 = offtemp;
		offtemp = offtemp->next;
		free(offtemp2);
	}
}
//对一条中间代码产生mips机器码
int translate_one_ircode(struct InterCodeNode* ircodenode,struct InterCodeNode** splitfun,int* argnum,int *paranum){
	assert(mipsfile != NULL);
	assert(ircodenode != NULL);
	assert(argnum != NULL);
	assert(paranum != NULL);
	
	struct InterCode* ircode = ircodenode->code;
	
	if(ircode->kind == ASSIGN){
		mem_to_reg(ircode->u.assign.right,0);
	    	reg_to_mem(ircode->u.assign.left,0);
	}
	else if(ircode->kind == ADD){
		mem_to_reg(ircode->u.binop.op1,0);
	    	mem_to_reg(ircode->u.binop.op2,1);
	    	fprintf(mipsfile,"    add $t1, $t0, $t1\n");
	    	reg_to_mem(ircode->u.binop.result,1);
	}
	else if(ircode->kind == SUB){
		mem_to_reg(ircode->u.binop.op1,0);
	    	mem_to_reg(ircode->u.binop.op2,1);
	    	fprintf(mipsfile,"    sub $t1, $t0, $t1\n");
	    	reg_to_mem(ircode->u.binop.result,1);
	}
	else if(ircode->kind == MUL){
		mem_to_reg(ircode->u.binop.op1,0);
	    	mem_to_reg(ircode->u.binop.op2,1);
	    	fprintf(mipsfile,"    mul $t1, $t0, $t1\n");
	    	reg_to_mem(ircode->u.binop.result,1);
	}
	else if(ircode->kind == DIVISION){
		mem_to_reg(ircode->u.binop.op1,0);
		mem_to_reg(ircode->u.binop.op2,1);
	    	fprintf(mipsfile,"    div $t0, $t1\n"
	    			 "    mflo $t2\n");
	    	reg_to_mem(ircode->u.binop.result,2);
	}
	else if(ircode->kind == LABEL)
		fprintf(mipsfile,"label%d:\n",(ircode->u.label.labelop)->u.labelnum);
	else if(ircode->kind == GOTO)
		fprintf(mipsfile,"    j label%d\n",(ircode->u.go.labelop)->u.labelnum);
	else if(ircode->kind == CALL){
		fprintf(mipsfile,"    addi $sp, $sp, -4\n    sw $ra, 0($sp)\n"
				 "    jal %s\n",ircode->u.call.op2->u.funname);
		fprintf(mipsfile,"    lw $ra, 0($sp)\n    addi $sp, $sp, 4\n"
				 "    move $t0, $v0\n");
		reg_to_mem(ircode->u.read.arg,0);
	}
	else if(ircode->kind == READ){
		fprintf(mipsfile,"    addi $sp, $sp, -4\n    sw $ra, 0($sp)\n"
				 "    jal read\n"
				 "    lw $ra, 0($sp)\n    addi $sp, $sp, 4\n"
				 "    move $t0, $v0\n");
		reg_to_mem(ircode->u.read.arg,0);
	}	
	else if(ircode->kind == WRITE){
		mem_to_reg(ircode->u.write.arg,0);
		fprintf(mipsfile,"    move $a0, $t0\n"
				 "    addi $sp, $sp, -4\n    sw $ra, 0($sp)\n"
	    			 "    jal write\n"
	    			 "    lw $ra, 0($sp)\n    addi $sp, $sp, 4\n"
	    			 "    move $v0, $0\n");
	}
	else if(ircode->kind == REL){
		mem_to_reg(ircode->u.rel.op1,0);
		mem_to_reg(ircode->u.rel.op2,1);
		if(!strncmp(ircode->u.rel.relop->u.relop,"==",2))
		        fprintf(mipsfile,"    beq $t0, $t1, label%d\n",(ircode->u.rel.labelop)->u.labelnum); 
		else if(!strncmp(ircode->u.rel.relop->u.relop,"!=",2))
		        fprintf(mipsfile,"    bne $t0, $t1, label%d\n",(ircode->u.rel.labelop)->u.labelnum); 
		else if(!strncmp(ircode->u.rel.relop->u.relop,"<=",2))
		        fprintf(mipsfile,"    ble $t0, $t1, label%d\n",(ircode->u.rel.labelop)->u.labelnum); 
		else if(!strncmp(ircode->u.rel.relop->u.relop,">=",2))
		        fprintf(mipsfile,"    bge $t0, $t1, label%d\n",(ircode->u.rel.labelop)->u.labelnum); 
		else if(!strncmp(ircode->u.rel.relop->u.relop,">",1))
		        fprintf(mipsfile,"    bgt $t0, $t1, label%d\n",(ircode->u.rel.labelop)->u.labelnum); 
		else if(!strncmp(ircode->u.rel.relop->u.relop,"<",1))
		        fprintf(mipsfile,"    blt $t0, $t1, label%d\n",(ircode->u.rel.labelop)->u.labelnum);
		else{
			return 0;
		}  
	}
	else if(ircode->kind == PARA){
		if((*paranum) >= 0 && (*paranum) < 5){
			(*paranum) ++;
		        fprintf(mipsfile,"    move $t0, $a%d\n", (*paranum) - 1);              
		        reg_to_mem(ircode->u.para.var,1);
		}
		else{
		    	printf("I did not finish this part.I just think paranum below 4 to use $a0-$a4.\n");
		    	docleaning();
		        exit(1);
		}
	}
	else if(ircode->kind == ARG){
		if((*argnum) > 0 && (*argnum) < 5){
		        mem_to_reg(ircode->u.arg.argop,1);
		        fprintf(mipsfile, "    move $a%d, $t0\n", (*argnum) - 1);
		        (*argnum) --;
		}
		else{
		    	printf("I did not finish this part.I just think argnum below 4 to use $a0-$a4.\n");
		    	docleaning();
		        exit(1);
		}
	}	
	else if(ircode->kind == RETURN_CODE){
		mem_to_reg(ircode->u.ret.returnop,0);
		fprintf(mipsfile,"    move $v0, $t0\n    addi $sp, $sp, %d\n    jr $ra\n",listtail->offset);
	}
	else if(ircode->kind == FUNCTION){
		(*argnum) = (*paranum) = 0;
    		listhead = listtail = NULL;
    		int count = 0;
		while((*splitfun) != NULL){
			if((*splitfun)->code->kind == FUNCTION)
				if(count != 0)
					break;
				else 
					count ++;
			add_to_list((*splitfun)->code,argnum);
			(*splitfun) = (*splitfun)->next;
		}
		fprintf(mipsfile,"\n%s:\n    addi $sp, $sp, %d\n",ircode->u.function.funname->u.funname,-listtail->offset);
	}	
	else{
#ifdef DEBUG
		printf("\ntranslate_one_ircode()--filename:%s,lineno:%d\n",__FILE__,__LINE__);
#endif	
		return 0;
	}
	return 1;
}
//遇到函数时处理一条ir将offset加入offlist
int add_to_list(struct InterCode* ir,int* argnum){
	assert(ir != NULL);
	assert(argnum != NULL);
	
	if(ir->kind == ASSIGN){
		insert_to_list(ir->u.assign.right);
            	insert_to_list(ir->u.assign.left); 
	}
	else if(ir->kind == ADD){
		insert_to_list(ir->u.binop.op2);
            	insert_to_list(ir->u.binop.op1); 
            	insert_to_list(ir->u.binop.result); 
	}
	else if(ir->kind == SUB){
		insert_to_list(ir->u.binop.op2);
            	insert_to_list(ir->u.binop.op1); 
            	insert_to_list(ir->u.binop.result); 
	}
	else if(ir->kind == MUL){
		insert_to_list(ir->u.binop.op2);
            	insert_to_list(ir->u.binop.op1); 
            	insert_to_list(ir->u.binop.result); 
	}
	else if(ir->kind == DIVISION){
		insert_to_list(ir->u.binop.op2);
            	insert_to_list(ir->u.binop.op1); 
            	insert_to_list(ir->u.binop.result);
	}
	else if(ir->kind == REL){
		insert_to_list(ir->u.rel.op2);
            	insert_to_list(ir->u.rel.op1);  
	}
	else if(ir->kind == CALL){
		insert_to_list(ir->u.call.op1);
	}
	else if(ir->kind == READ){
		insert_to_list(ir->u.read.arg);
	}
	else if(ir->kind == WRITE){
		insert_to_list(ir->u.write.arg);
	}
	else if(ir->kind == RETURN_CODE){
		insert_to_list(ir->u.ret.returnop);
	}
	else if(ir->kind == PARA){
		insert_to_list(ir->u.para.var);
	}	
	else if(ir->kind == ARG){
		insert_to_list(ir->u.arg.argop);
		(*argnum)++;
            	Operand op = create_operand(ARGOP,"",(*argnum) - 1);
            	insert_to_list(op);     	
	}
	else{
#ifdef DEBUG
		printf("\nadd_to_list()--filename:%s,lineno:%d\n",__FILE__,__LINE__);
#endif
		return 0;
	}
	return 1;
}
//根据偏移量跟操作数添加节点
int insert_to_list(Operand op){
	assert(op != NULL);
	
    	struct OffNode* offnodetemp = listhead;
    	while(offnodetemp != NULL){
       		if(isequal(offnodetemp->op,op))
            		break;
        	offnodetemp = offnodetemp->next;
    	}
    	
    	int length = 4;
    	if(offnodetemp == NULL){
        	if(listtail == NULL){
			offnodetemp = (struct OffNode *)malloc(sizeof(struct OffNode));
	    		offnodetemp->op = op;
	    		offnodetemp->offset = length;
	    		offnodetemp->next = NULL;
            		listhead = offnodetemp;
            		listtail = offnodetemp;
            		return 1;
        	}
        	else{
			offnodetemp = (struct OffNode *)malloc(sizeof(struct OffNode));
	    		offnodetemp->op = op;
            		offnodetemp->offset = length + listtail->offset;
            		offnodetemp->next = NULL;
            		listtail->next = offnodetemp;
            		listtail = listtail->next;
            		return 1;
        	}
    	}
    	else
    		return 0;
}
//获取$sp偏移量
int search_list(Operand op){
	assert(op != NULL);
	
    	struct OffNode* offtemp = listhead;
    	while(offtemp != NULL){
        	if(isequal(offtemp->op,op))
            		break;
        	offtemp = offtemp->next;
    	}
    	assert(offtemp != NULL);
    	int temp = offtemp->offset;
    	
    	return temp;
}
//保存到内存使寄存器可用
int mem_to_reg(Operand op,int regno){
	assert(mipsfile != NULL);
	assert(op != NULL);
	
	if(op->kind == VARIABLE){
		int temp = search_list(op);
		int temp1 = listtail->offset - temp;
		fprintf(mipsfile,"    lw $t%d, %d($sp)\n",regno,temp1);
		return 1;
	}
	else if(op->kind == CONSTANT){
		fprintf(mipsfile,"    li $t%d, %d\n",regno,op->u.value);
		return 1;
	}
	else if(op->kind == TEMP){
		int temp = search_list(op);
		int temp1 = listtail->offset - temp;
		fprintf(mipsfile,"    lw $t%d, %d($sp)\n",regno,temp1);
		return 1;
	}
	else{
#ifdef DEBUG
		printf("\nmem_to_reg()--filename:%s,lineno:%d\n",__FILE__,__LINE__);
#endif
		return 0;
	}
}
//从内存中取出数据到寄存器
int reg_to_mem(Operand op,int regno){
	assert(mipsfile != NULL);
	assert(op != NULL);
	
	if(op->kind == VARIABLE){
		int temp = search_list(op);
		int temp1 = listtail->offset - temp;
		fprintf(mipsfile,"    sw $t%d, %d($sp)\n",regno,temp1);
		return 1;
	}
	else if(op->kind == TEMP){
		int temp = search_list(op);
		int temp1 = listtail->offset - temp;
		fprintf(mipsfile,"    sw $t%d, %d($sp)\n",regno,temp1);
		return 1;
	}
	else if(op->kind == ARGOP){
		int temp = search_list(op);
		int temp1 = listtail->offset - temp;
		fprintf(mipsfile,"    sw $t%d, %d($sp)\n",regno,temp1);
		return 1;
	}
	else{
#ifdef DEBUG
		printf("\nreg_to_mem()--filename:%s,lineno:%d\n",__FILE__,__LINE__);
#endif
		return 0;
	}
}
