#include <stdlib.h>
#include <stdio.h>
#include "irtomips.c"
//中间代码结构的头指针
struct InterCodeNode* irhead;
int main(int argc, char** argv)
{
	if (argc != 3){
		printf("usage: ./main + inputfile + outputfile\ne.g.   ./main test.cmm out.s\n");
		return 1;
	}
	FILE* f = fopen(argv[1], "r");
	if (!f)
	{
		printf("Can not open this file: %s\n",argv[1]);
		return 1;
	}
	yyrestart(f);
	yyparse();
	//if print this grammar tree
	/********** 语义分析部分--实验二部分 ************/
	if(haveerror == 0){
		ifarrayok(root);//判断是否有高维数组 有的话直接退出--实验三部分
		init_wrfun();//初始化write和read函数
		replacestruct(root);
		createfunlist(root);
		createstalist(root);
		//printlist();
		//printf("\n*************yuyi**************\n");
		struct Fun * head = funhead1;
		for(;head!=NULL;head = head->next){
			if(strcmp(head->name,"read") != 0 && strcmp(head->name,"write") != 0){//printf("funname: %s--",head->name);
				//printf("*******************************\n");
				syntaxanalysis(head->root,head);//printf("1*******************************\n");
				paranumanalysis(head->root,head);//printf("2*******************************\n");
				funreturnanalysis(head->root);//printf("3*******************************\n");
				
				//标注函数的变量中的参数--实验三部分
				markpara(head->root->child[1]->child[2],head->varhead);//printf("ahh\n");
			}
		}
		
	}
	/**************** 中间代码生成--实验三部分 *****************/
	//struct InterCodeNode* irhead;
	if(haveerror == 0){
		//计算struct类型大小
		struct Strhead * head1 = strhead;
		while(head1!=NULL){
			computestrsize(head1);
			head1 = head1->next;
		}
		//printf("11111111111111111\n");
		irhead = genir();
		FILE* ircode = fopen("111220069.ir","w");
		//printf("-------------------------\n");
        	fputsNode(irhead,ircode);  
		fclose(ircode);

	}
	/**************** 中间代码生成--实验四部分 *****************/
	if(haveerror == 0){
		int rsuccess = remove("111220069.ir");//删除中间代码文件
		if(rsuccess != 0)
			printf("remove file:111220069.ir in failure,it is an exception from filename:%s,lineno:%d\n",__FILE__,__LINE__);
			
		//产生mips代码的函数调用
		genmipscode(argv[2]);
	}
	return 0;
}

