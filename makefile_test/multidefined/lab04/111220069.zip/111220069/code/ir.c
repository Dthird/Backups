#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "syntax.tab.c"

int varnum = 1;
int tempnum = 1;
int labelnum = 1;

/***************** data structure definition *************/
typedef struct Operand_* Operand;
struct Operand_{
    	enum{VARIABLE,CONSTANT,ADDRESS,RELOPOP,LABELOP,FUNC,TEMP,SIZE,REFERENCE,ARGOP}kind;
    	union{
		int varnum;
		int value;
		char relop[50];
		int labelnum;
		int tempnum;
		int argnum;
		char funname[50];
	}u;
};
struct OperandNode{
    	Operand op;
    	struct OperandNode* next;
};
struct InterCode{
    	enum{ASSIGN,ADD,SUB,MUL,DIVISION,LABEL,REL,GOTO,READ,WRITE,CALL,FUNCTION,RETURN_CODE,ARG,PARA,DEC} kind;
    	union{
		struct{Operand left,right;} assign;
		struct{Operand result,op1,op2;} binop;
		struct{Operand labelop;} label;
		struct{Operand op1,relop,op2,labelop;} rel;
		struct{Operand labelop;} go;
		struct{Operand arg;} read;
		struct{Operand arg;} write;
		struct{Operand op1,op2;} call;
		struct{Operand funname;} function;
		struct{Operand returnop;} ret;
		struct{Operand argop;} arg;
		struct{Operand var;} para;
		struct{Operand var, size;} dec;
    	}u;
};

struct InterCodeNode{
    	struct InterCode* code;
    	struct InterCodeNode* prev;
    	struct InterCodeNode* next;
};

/********************声明本文件中的部分函数，不然会报错*******************/
struct InterCodeNode* translate_ExtDef(struct Fun* head);
struct InterCodeNode* translate_FunDec(struct GrammarTree* fundec,struct Fun* head);
struct InterCodeNode* translate_CompSt(struct GrammarTree* compst,struct Fun* head);
struct InterCodeNode* translate_DefList(struct GrammarTree* deflist, struct Fun*head);
struct InterCodeNode* translate_DecList(struct GrammarTree* declist,struct Fun* head);
struct InterCodeNode* translate_Dec(struct GrammarTree* dec,struct Fun* head);
struct InterCodeNode* translate_VarDec(struct GrammarTree* vardec,Operand* op,struct Fun* head);
struct InterCodeNode* translate_Exp(struct GrammarTree* exp,Operand* parentop,struct Fun* head);
struct InterCodeNode* translate_Args(struct GrammarTree* args,struct OperandNode** arg_list_addr,struct Fun* head);
struct InterCodeNode* translate_Cond(struct GrammarTree* exp,Operand lbt,Operand lbf,struct Fun* head);
struct InterCodeNode* translate_StmtList(struct GrammarTree* stmtlist,struct Fun* head);
struct InterCodeNode* translate_Stmt(struct GrammarTree* stmt,struct Fun* head);

/********************* fun definition *************************/
//根据operand的类型产生一个operand
Operand create_operand(int kind,char *text,int num){
	Operand op = (Operand)malloc(sizeof(struct Operand_));
    	op->kind = kind;
    	switch(kind){
		case VARIABLE:		op->u.varnum = num;			break;
		case CONSTANT:		op->u.value = num;			break;
		case ADDRESS:		op->u.tempnum = num;			break;
		case TEMP:		op->u.tempnum = num;			break;
		case SIZE:		op->u.value = num;			break;
		case REFERENCE:	op->u.varnum = num;			break;
		case RELOPOP:		strncpy(op->u.relop,text+7,43);		break;
		case FUNC:		{
						if(strncmp(text,"ID: ",4) == 0)
							strncpy(op->u.funname,text+4,46);
						else 
							strncpy(op->u.funname,text,50);
					}					break;
		case ARGOP:		op->u.argnum = num;			break;
    	}
	return op;
}
Operand newtemp(){
    	Operand op = (Operand)malloc(sizeof(struct Operand_));
    	op->kind = TEMP;
    	op->u.tempnum = tempnum;
    	tempnum ++;
    	return op;
}
Operand newlabel(){
    	Operand op = (Operand)malloc(sizeof(struct Operand_));
    	op->kind = LABELOP;
    	op->u.labelnum = labelnum;
    	labelnum ++;
    	return op;
}
//合并两个短的中间代码链表
struct InterCodeNode* jointoirhead(struct InterCodeNode* irhead,struct InterCodeNode* irtemp){
	if(irhead == NULL)
		return irtemp;
	else if(irtemp == NULL)
		return irhead;
	else{
		struct InterCodeNode* ir = irhead;
		while(ir->next!=NULL)
			ir = ir->next;
		ir->next = irtemp;
		irtemp->prev = ir;
		return irhead;
	}

}
/************************ main fun of this ir.c file ******************************/
//first call
struct InterCodeNode* genir(){
	struct InterCodeNode* irhead = NULL;
    	struct Fun* head = funhead1;
	for(;head!=NULL;head = head->next){
		if(strcmp(head->name,"read") != 0 && strcmp(head->name,"write") != 0){
			//printf("*******************************\n");
			struct InterCodeNode* irtemp = NULL;
			irtemp = (struct InterCodeNode*)translate_ExtDef(head);
			irhead = jointoirhead(irhead,irtemp);
		}
	}
	return irhead;
}
//translate ExtDef , just fundec's parent
struct InterCodeNode* translate_ExtDef(struct Fun* head){
	struct GrammarTree* extdef = head->root;
        struct InterCodeNode* irnode1 = (struct InterCodeNode*)translate_FunDec(extdef->child[1],head);//printf("22222222222222222222\n");
        struct InterCodeNode* irnode2 = (struct InterCodeNode*)translate_CompSt(extdef->child[2],head);//compst
        return jointoirhead(irnode1,irnode2);
}
//translate FunDec
struct InterCodeNode* translate_FunDec(struct GrammarTree* fundec,struct Fun* head){
	Operand funop = create_operand(FUNC,fundec->child[0]->name,0);//printf("222222222222222222222221\n");
	struct InterCode* funcode1 = (struct InterCode *)malloc(sizeof(struct InterCode));
	funcode1->kind = FUNCTION;
	funcode1->u.function.funname = funop;
	struct InterCodeNode* funirnode1 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
    	funirnode1->code = funcode1;
    	funirnode1->prev = NULL;
    	funirnode1->next = NULL;
	//printf("33333333333333333333333\n");
	int i;
	struct Variable* vheadtemp = head->varhead;
	for(i = 0;i < head->paranum;i ++){
		Operand para = create_operand(VARIABLE,"",varnum+1);
		varnum ++;
		while(vheadtemp != NULL){
			if(vheadtemp->ispara == 1)
				break;
			else
				vheadtemp = vheadtemp->next;
		}
		assert(vheadtemp!=NULL);
		vheadtemp->varnum = varnum;
		
		struct InterCode* funcode2 = (struct InterCode *)malloc(sizeof(struct InterCode));
		funcode2->kind = PARA;
		funcode2->u.para.var = para;
		struct InterCodeNode* funirnode2 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
    		funirnode2->code = funcode2;
    		funirnode2->prev = NULL;
    		funirnode2->next = NULL;
		funirnode1 = jointoirhead(funirnode1,funirnode2);	    	
	}
	return funirnode1;
}
//translate CompSt
struct InterCodeNode* translate_CompSt(struct GrammarTree* compst,struct Fun* head){//printf("%s--%s--\n",compst->child[1]->name,compst->child[2]->name);
    	struct InterCodeNode* irnode1 = (struct InterCodeNode*)translate_DefList(compst->child[1],head);//printf("CompSt 1\n");
    	struct InterCodeNode* irnode2 = (struct InterCodeNode*)translate_StmtList(compst->child[2],head);
    	return jointoirhead(irnode1,irnode2);
}
//translate DefList
struct InterCodeNode* translate_DefList(struct GrammarTree* deflist, struct Fun*head){
    	if(deflist == NULL)
        	return NULL;
	else{
	   	struct InterCodeNode* irnode1 = (struct InterCodeNode*)translate_DecList(deflist->child[0]->child[1],head);//printf("DefList 1\n");
	    	struct InterCodeNode* irnode2 = translate_DefList(deflist->child[1],head);
	    	return jointoirhead(irnode1,irnode2);
	}
}
//translate DecList
struct InterCodeNode* translate_DecList(struct GrammarTree* declist,struct Fun* head){
    	if(declist->childnum == 1)//DecList->Dec
        	return (struct InterCodeNode*)translate_Dec(declist->child[0],head);
    	else{
        	struct InterCodeNode* irnode1 = (struct InterCodeNode*)translate_Dec(declist->child[0],head);//printf("declist 1\n");
        	struct InterCodeNode* irnode2 = (struct InterCodeNode*)translate_DecList(declist->child[2],head);
        	return jointoirhead(irnode1,irnode2);
    	}
}
//translate Dec
struct InterCodeNode* translate_Dec(struct GrammarTree* dec,struct Fun* head){
   	if(dec->childnum == 1){//Dec->VarDec
		Operand id = newtemp();//printf("dec 0\n");
        	return (struct InterCodeNode*)translate_VarDec(dec->child[0],&id,head);
	}
    	else{//printf("dec 1\n");
		Operand op1 = newtemp();
		struct InterCodeNode* irnode1 = (struct InterCodeNode*)translate_VarDec(dec->child[0],&op1,head);
		
		Operand op2 = newtemp();
		struct InterCodeNode* irnode2 = (struct InterCodeNode*)translate_Exp(dec->child[2],&op2,head);
		irnode1 = jointoirhead(irnode1,irnode2);
		//Assignop
		struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
		ircode3->u.assign.left = op1;
		ircode3->u.assign.right = op2;
		ircode3->kind = ASSIGN;
		struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode3->code = ircode3;
    		irnode3->prev = NULL;
    		irnode3->next = NULL;
    		
		return jointoirhead(irnode1,irnode3);
    	}
}
//translate VarDec
struct InterCodeNode* translate_VarDec(struct GrammarTree* vardec,Operand* op,struct Fun* head){
    	if(vardec->childnum == 1){//e.g. a
		struct Variable *varhead1 = head->varhead;
		while(varhead1!=NULL){
			if(strncmp(varhead1->name,(vardec->child[0]->name)+4,46) == 0)
				break;
			else
				varhead1 = varhead1->next;
		}
		assert(varhead1!=NULL);
		if(strncmp(varhead1->type,"INT",3) == 0 || strncmp(varhead1->type,"FLOAT",5) == 0){
			(*op) = create_operand(VARIABLE,"",varnum);
			varhead1->varnum = varnum;
			varnum ++;
			return NULL;
		}
		else{//struct 类型
			int strsize;
			struct Strhead* strhead1 = strhead;
			while(strhead1!=NULL){
				if(strcmp(varhead1->type,strhead1->name) == 0)
					break;
				strhead1 = strhead1->next;
			}
			assert(strhead1!=NULL);
			strsize = strhead1->size;
			Operand sizeop = create_operand(SIZE,"",strsize*4);
			Operand varop = create_operand(VARIABLE,"",varnum);
			varhead1->varnum = varnum;
			varnum ++;

			struct InterCode* ircode = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode->u.dec.size = sizeop;
			ircode->u.dec.var = varop;
			ircode->kind = DEC;
			struct InterCodeNode* irnode = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode->code = ircode;
    			irnode->prev = NULL;
    			irnode->next = NULL;
			return irnode;
		}	    	
    	}
    	else{//e.g. a[1]
		struct Variable *varhead1 = head->varhead;
		while(varhead1!=NULL){
			if(strncmp(varhead1->name,(vardec->child[0]->child[0]->name)+4,46) == 0)
				break;
			else
				varhead1 = varhead1->next;
		}
		assert(varhead1!=NULL);
		int arraysize = atoi((vardec->child[2]->name)+5);	    	
		Operand sizeop = create_operand(SIZE,"",arraysize*4);
		Operand varop = create_operand(VARIABLE,"",varnum);
		varhead1->varnum = varnum;
		varnum ++;
	
	    	struct InterCode* ircode = (struct InterCode*)malloc(sizeof(struct InterCode));
		ircode->u.dec.size = sizeop;
	    	ircode->u.dec.var = varop;
		ircode->kind = DEC;
		struct InterCodeNode* irnode = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode->code = ircode;
    		irnode->prev = NULL;
    		irnode->next = NULL;
    		
		return irnode;	
    	}
}

//translate Exp
struct InterCodeNode* translate_Exp(struct GrammarTree* exp,Operand* parentop,struct Fun* head){
	/******************************* exp-->childnum = 1 *******************************************************/
    	if(exp->childnum == 1){
		if(strncmp(exp->child[0]->name,"INT: ",5) == 0){//INT
		    	(*parentop) = create_operand(CONSTANT,"",atoi((exp->child[0]->name)+5));//printf("nihao!---%d\n",atoi((exp->child[0]->name)+5));
		    	return NULL;
		}
		else if(strncmp(exp->child[0]->name,"FLOAT: ",7) == 0){//FLOAT
		    	(*parentop) = create_operand(CONSTANT,"",atof((exp->child[0]->name)+7));
		    	return NULL;
		}
        	else if(strncmp(exp->child[0]->name,"ID: ",4) == 0){//ID
			struct Variable* vhead = head->varhead;
			while(vhead!=NULL){
				if(strncmp(vhead->name,(exp->child[0]->name)+4,46)==0)
					break;
				vhead = vhead->next;
			}
			assert(vhead!=NULL);
			(*parentop) = create_operand(VARIABLE,"",vhead->varnum);			
			return NULL;
		}
    	}
	/******************************* exp-->childnum = 2 *******************************************************/
    	else if(exp->childnum == 2){
		if(strncmp(exp->child[0]->name,"MINUS",5) == 0){
			Operand op = (Operand)newtemp();
			struct InterCodeNode* irnode1 = (struct InterCodeNode*)translate_Exp(exp->child[1],&op,head);
			if(op->kind == CONSTANT){
                		(*parentop)->kind = CONSTANT;
                		(*parentop)->u.value = -(op->u.value);
                		return NULL;
            		}
			else{
				struct InterCode* ircode2 = (struct InterCode*)malloc(sizeof(struct InterCode));
				ircode2->u.binop.result = (*parentop);
				ircode2->u.binop.op2 = op;
				ircode2->u.binop.op1 = create_operand(CONSTANT,"",0);
				ircode2->kind = SUB;
				struct InterCodeNode* irnode2 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
				irnode2->code = ircode2;
    				irnode2->prev = NULL;
    				irnode2->next = NULL;
				
				return jointoirhead(irnode1,irnode2);
			}
		}
		else if(strncmp(exp->child[0]->name,"NOT",3) == 0){
			Operand lb1 = newlabel();
		    	Operand lb2 = newlabel();

		    	struct InterCode* ircode1 = (struct InterCode*)malloc(sizeof(struct InterCode));
		    	ircode1->kind = ASSIGN;
		    	ircode1->u.assign.right = create_operand(CONSTANT,"",0);
		    	ircode1->u.assign.left = (*parentop);
		    	struct InterCodeNode* irnode1 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode1->code = ircode1;
    			irnode1->prev = NULL;
    			irnode1->next = NULL;

		    	struct InterCodeNode* irnode2 = translate_Cond(exp,lb1,lb2,head);

		    	struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
		    	ircode3->kind = LABEL;
		    	ircode3->u.label.labelop = lb1;
		    	struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
    			irnode3->prev = NULL;
    			irnode3->next = NULL;

		    	struct InterCode* ircode4 = (struct InterCode*)malloc(sizeof(struct InterCode));
		    	ircode4->kind = ASSIGN;
		    	ircode4->u.assign.right = create_operand(CONSTANT,"",1);
		    	ircode4->u.assign.left = (*parentop);
		    	struct InterCodeNode* irnode4 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode4->code = ircode4;
    			irnode4->prev = NULL;
    			irnode4->next = NULL;

		    	struct InterCode* ircode5 = (struct InterCode*)malloc(sizeof(struct InterCode));
		    	ircode5->kind = LABEL;
		    	ircode5->u.label.labelop = lb2;
		    	struct InterCodeNode* irnode5 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode5->code = ircode5;
    			irnode5->prev = NULL;
    			irnode5->next = NULL;
		    	
		    	irnode1 = jointoirhead(irnode1,irnode2);
		    	irnode1 = jointoirhead(irnode1,irnode3);
		    	irnode1 = jointoirhead(irnode1,irnode4);
		    	irnode1 = jointoirhead(irnode1,irnode5);
		    	return irnode1;
		}
	}
	/******************************* exp-->childnum = 3 *******************************************************/
	else if(exp->childnum == 3){
		if(strncmp(exp->child[1]->name, "ASSIGNOP",8) == 0){
			Operand result = newtemp();
			Operand op = newtemp();
			struct InterCodeNode* irnode1 = translate_Exp(exp->child[0],&result,head);
			struct InterCodeNode* irnode2 = translate_Exp(exp->child[2],&op,head);
			irnode1 = jointoirhead(irnode1,irnode2);
			struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
            		ircode3->kind = ASSIGN;
			ircode3->u.assign.left = result;
			ircode3->u.assign.right = op;
			struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
    			irnode3->prev = NULL;
    			irnode3->next = NULL;
           		(*parentop) = result;
           		
			return jointoirhead(irnode1,irnode3);
		}//(strncmp(exp->child[1]->name, "ASSIGNOP",8) == 0)
		else if(strncmp(exp->child[1]->name,"PLUS",4) == 0){
			Operand op1 = newtemp();
			Operand op2 = newtemp();
			struct InterCodeNode* irnode1 = translate_Exp(exp->child[0],&op1,head);
			struct InterCodeNode* irnode2 = translate_Exp(exp->child[2],&op2,head);
			irnode1 = jointoirhead(irnode1,irnode2);
			struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode3->u.binop.result = (*parentop);
            		ircode3->u.binop.op1 = op1;
            		ircode3->u.binop.op2 = op2;
            		ircode3->kind = ADD;
			struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
    			irnode3->prev = NULL;
    			irnode3->next = NULL;
    			
			return jointoirhead(irnode1,irnode3);
		}//if(strncmp(exp->child[1]->name,"PLUS",4) == 0)
		else if(strncmp(exp->child[1]->name,"MINUS",5) == 0){
			Operand op1 = newtemp();
			Operand op2 = newtemp();
			struct InterCodeNode* irnode1 = translate_Exp(exp->child[0],&op1,head);
			struct InterCodeNode* irnode2 = translate_Exp(exp->child[2],&op2,head);
			irnode1 = jointoirhead(irnode1,irnode2);
			struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode3->u.binop.result = (*parentop);
            		ircode3->u.binop.op1 = op1;
            		ircode3->u.binop.op2 = op2;
            		ircode3->kind = SUB;
			struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
    			irnode3->prev = NULL;
    			irnode3->next = NULL;
    			
			return jointoirhead(irnode1,irnode3);

		}//if(strncmp(exp->child[1]->name,"MINUS",5) == 0)
		else if(strncmp(exp->child[1]->name,"STAR",4) == 0){
			Operand op1 = newtemp();
			Operand op2 = newtemp();
			struct InterCodeNode* irnode1 = translate_Exp(exp->child[0],&op1,head);
			struct InterCodeNode* irnode2 = translate_Exp(exp->child[2],&op2,head);
			irnode1 = jointoirhead(irnode1,irnode2);
			struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode3->u.binop.result = (*parentop);
            		ircode3->u.binop.op1 = op1;
            		ircode3->u.binop.op2 = op2;
            		ircode3->kind = MUL;
			struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
    			irnode3->prev = NULL;
    			irnode3->next = NULL;
    			
			return jointoirhead(irnode1,irnode3);

		}//if(strncmp(exp->child[1]->name,"STAR",4) == 0)
		else if(strncmp(exp->child[1]->name,"DIV",3) == 0){
			Operand op1 = newtemp();
			Operand op2 = newtemp();
			struct InterCodeNode* irnode1 = translate_Exp(exp->child[0],&op1,head);
			struct InterCodeNode* irnode2 = translate_Exp(exp->child[2],&op2,head);
			irnode1 = jointoirhead(irnode1,irnode2);
			struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode3->u.binop.result = (*parentop);
            		ircode3->u.binop.op1 = op1;
            		ircode3->u.binop.op2 = op2;
            		ircode3->kind = DIVISION;
			struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
    			irnode3->prev = NULL;
    			irnode3->next = NULL;
    			
			return jointoirhead(irnode1,irnode3);

		}//if(strncmp(exp->child[1]->name,"DIV",3) == 0)
		else if(strncmp(exp->child[1]->name,"AND",3) == 0){
			struct InterCode* ircode1 = (struct InterCode*)malloc(sizeof(struct InterCode));
		    	ircode1->kind = ASSIGN;
		    	ircode1->u.assign.right = create_operand(CONSTANT,"",0);
		    	ircode1->u.assign.left = (*parentop);
		    	struct InterCodeNode* irnode1 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode1->code = ircode1;
    			irnode1->prev = NULL;
    			irnode1->next = NULL;

			Operand lb1 = newlabel();
			Operand lb2 = newlabel();
			struct InterCodeNode* irnode2 = (struct InterCodeNode*)translate_Cond(exp,lb1,lb2,head);

			struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
            		ircode3->kind = LABEL;
            		ircode3->u.label.labelop = lb1;
	    		struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
    			irnode3->prev = NULL;
    			irnode3->next = NULL;

			struct InterCode* ircode4 = (struct InterCode*)malloc(sizeof(struct InterCode));
        		ircode4->kind = ASSIGN;
            		ircode4->u.assign.right = create_operand(CONSTANT,"",1);
            		ircode4->u.assign.left = (*parentop);
    	    		struct InterCodeNode* irnode4 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode4->code = ircode4;
    			irnode4->prev = NULL;
    			irnode4->next = NULL;
		
			struct InterCode* ircode5 = (struct InterCode*)malloc(sizeof(struct InterCode));
            		ircode5->kind = LABEL;
            		ircode5->u.label.labelop = lb2;
            		struct InterCodeNode* irnode5 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode5->code = ircode5;
    			irnode5->prev = NULL;
    			irnode5->next = NULL;

			irnode1 = jointoirhead(irnode1,irnode2);
			irnode1 = jointoirhead(irnode1,irnode3);
			irnode1 = jointoirhead(irnode1,irnode4);
			irnode1 = jointoirhead(irnode1,irnode5);
			
			return irnode1;
		}//if(strncmp(exp->child[1]->name,"AND",3) == 0)
		else if(strncmp(exp->child[1]->name,"OR",2) == 0){
			struct InterCode* ircode1 = (struct InterCode*)malloc(sizeof(struct InterCode));
		    	ircode1->kind = ASSIGN;
		    	ircode1->u.assign.right = create_operand(CONSTANT,"",0);
		    	ircode1->u.assign.left = (*parentop);
		    	struct InterCodeNode* irnode1 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode1->code = ircode1;
    			irnode1->prev = NULL;
    			irnode1->next = NULL;

			Operand lb1 = newlabel();
			Operand lb2 = newlabel();
			struct InterCodeNode* irnode2 = (struct InterCodeNode*)translate_Cond(exp,lb1,lb2,head);

			struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
            		ircode3->kind = LABEL;
            		ircode3->u.label.labelop = lb1;
	    		struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
    			irnode3->prev = NULL;
    			irnode3->next = NULL;

			struct InterCode* ircode4 = (struct InterCode*)malloc(sizeof(struct InterCode));
        		ircode4->kind = ASSIGN;
            		ircode4->u.assign.right = create_operand(CONSTANT,"",1);
            		ircode4->u.assign.left = (*parentop);
    	    		struct InterCodeNode* irnode4 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode4->code = ircode4;
    			irnode4->prev = NULL;
    			irnode4->next = NULL;
		
			struct InterCode* ircode5 = (struct InterCode*)malloc(sizeof(struct InterCode));
            		ircode5->kind = LABEL;
            		ircode5->u.label.labelop = lb2;
            		struct InterCodeNode* irnode5 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode5->code = ircode5;
    			irnode5->prev = NULL;
    			irnode5->next = NULL;

			irnode1 = jointoirhead(irnode1,irnode2);
			irnode1 = jointoirhead(irnode1,irnode3);
			irnode1 = jointoirhead(irnode1,irnode4);
			irnode1 = jointoirhead(irnode1,irnode5);
			
			return irnode1;
		}//if(strncmp(exp->child[1]->name,"OR",2) == 0)
		else if(strncmp(exp->child[1]->name,"RELOP: ",7) == 0){
			struct InterCode* ircode1 = (struct InterCode*)malloc(sizeof(struct InterCode));
		    	ircode1->kind = ASSIGN;
		    	ircode1->u.assign.right = create_operand(CONSTANT,"",0);
		    	ircode1->u.assign.left = (*parentop);
		    	struct InterCodeNode* irnode1 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode1->code = ircode1;
    			irnode1->prev = NULL;
    			irnode1->next = NULL;

			Operand lb1 = newlabel();
			Operand lb2 = newlabel();
			struct InterCodeNode* irnode2 = (struct InterCodeNode*)translate_Cond(exp,lb1,lb2,head);

			struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
            		ircode3->kind = LABEL;
            		ircode3->u.label.labelop = lb1;
	    		struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
    			irnode3->prev = NULL;
    			irnode3->next = NULL;

			struct InterCode* ircode4 = (struct InterCode*)malloc(sizeof(struct InterCode));
        		ircode4->kind = ASSIGN;
            		ircode4->u.assign.right = create_operand(CONSTANT,"",1);
            		ircode4->u.assign.left = (*parentop);
    	    		struct InterCodeNode* irnode4 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode4->code = ircode4;
    			irnode4->prev = NULL;
    			irnode4->next = NULL;
		
			struct InterCode* ircode5 = (struct InterCode*)malloc(sizeof(struct InterCode));
            		ircode5->kind = LABEL;
            		ircode5->u.label.labelop = lb2;
            		struct InterCodeNode* irnode5 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode5->code = ircode5;
    			irnode5->prev = NULL;
    			irnode5->next = NULL;

			irnode1 = jointoirhead(irnode1,irnode2);
			irnode1 = jointoirhead(irnode1,irnode3);
			irnode1 = jointoirhead(irnode1,irnode4);
			irnode1 = jointoirhead(irnode1,irnode5);
			
			return irnode1;
		}//if(strncmp(exp->child[1]->name,"RELOP: ",7) == 0)
		else if(strncmp(exp->child[0]->name,"LP",2) == 0){
			return translate_Exp(exp->child[1],parentop,head);
		}//if(strncmp(exp->child[0]->name,"LP",2) == 0
		else if(strncmp(exp->child[0]->name,"ID: ",4) == 0){
			struct Fun* fun = funhead1;
			while(fun!=NULL){
				if(strncmp(fun->name,(exp->child[0]->name)+4,46)==0)
					break;
				fun = fun->next;
			}
			assert(fun!=NULL);
			if(strncmp(fun->name,"read",4) == 0){
        			struct InterCode* ircode = (struct InterCode*)malloc(sizeof(struct InterCode));
        			ircode->u.read.arg = (*parentop);
        			ircode->kind = READ;
        			struct InterCodeNode* irnode = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
				irnode->code = ircode;
	    			irnode->prev = NULL;
    				irnode->next = NULL;
				return irnode;
        		}
			else{
				Operand op = create_operand(FUNC,fun->name,0);
        			struct InterCode* ircode = (struct InterCode*)malloc(sizeof(struct InterCode));
        			ircode->u.call.op1 = (*parentop);
        			ircode->u.call.op2 = op;
        			ircode->kind = CALL;
        			struct InterCodeNode* irnode = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
				irnode->code = ircode;
	    			irnode->prev = NULL;
    				irnode->next = NULL;
				return irnode;
			}
		}//if(strncmp(exp->child[0]->name,"ID: ",4) == 0)
		else if(strncmp(exp->child[1]->name,"DOT",3) == 0){
			struct Variable* vhead = head->varhead;
			while(vhead!=NULL){	
				if(strncmp((exp->child[0]->name)+4,vhead->name,46) == 0)
					break;
				vhead = vhead->next;
			}
			if(vhead!=NULL){
				struct Strhead* shead = strhead;
				while(shead!=NULL){
					if(strncmp(vhead->type,(shead->name)+6,44) == 0)
						break;
					shead = shead->next;
				}
				assert(shead!=NULL);
				if(vhead->ispara == 1){
					struct Variable* svhead = shead->head;
					if(strcmp(svhead->name,vhead->name)==0){
						Operand left = newtemp();
						Operand right = create_operand(ADDRESS,"",vhead->varnum);
						struct InterCode* ircode = (struct InterCode*)malloc(sizeof(struct InterCode));
				    		ircode->u.assign.left = left;
				    		ircode->u.assign.right = right;
				    		ircode->kind = ASSIGN;
				    		(*parentop) = create_operand(TEMP,"",left->u.tempnum);
				    		struct InterCodeNode* irnode = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
						irnode->code = ircode;
			    			irnode->prev = NULL;
			    			irnode->next = NULL;
						return irnode;
					}
					else{
						int num = 0;
						while(svhead!=NULL){
							if(strcmp(svhead->name,vhead->name)==0)
								break;
							else{
								num++;
								svhead = svhead->next;
							}
						}
						assert(svhead!=NULL);
						Operand result = newtemp();
						Operand op1 = newtemp();
						op1 = create_operand(VARIABLE,"",op1->u.varnum);
						Operand op2 = create_operand(CONSTANT,"",num*4);
						struct InterCode* ircode1 = (struct InterCode*)malloc(sizeof(struct InterCode));
		            			ircode1->kind = ADD;
		            			ircode1->u.binop.result =result;
		            			ircode1->u.binop.op1 = op1;
		            			ircode1->u.binop.op2 = op2;
		            			struct InterCodeNode* irnode1 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
						irnode1->code = ircode1;
			    			irnode1->prev = NULL;
			    			irnode1->next = NULL;
	
						Operand result1 = create_operand(ADDRESS,"",result->u.tempnum);
					   	Operand left1 = newtemp();
					    	(*parentop) = create_operand(TEMP,"",left1->u.tempnum);
					    	
					    	struct InterCode* ircode2 = (struct InterCode*)malloc(sizeof(struct InterCode));
					    	ircode2->u.assign.left = left1;
					    	ircode2->u.assign.right = result1;
					    	ircode2->kind = ASSIGN;
					    	struct InterCodeNode* irnode2 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
						irnode2->code = ircode2;
			    			irnode2->prev = NULL;
			    			irnode2->next = NULL;
				
						return jointoirhead(irnode1,irnode2);

					}

				}//if(vhead->ispara == 1)	
				else{
					Operand right = newtemp();right = create_operand(REFERENCE,"",vhead->varnum);
					if(strcmp(shead->name,vhead->name)==0){
						Operand left = newtemp();
						struct InterCode* ircode = (struct InterCode*)malloc(sizeof(struct InterCode));
				    		ircode->u.assign.left = left;
				    		ircode->u.assign.right = right;
				    		ircode->kind = ASSIGN;
				    		(*parentop) = create_operand(ADDRESS,"",left->u.tempnum);
				    		struct InterCodeNode* irnode = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
						irnode->code = ircode;
			    			irnode->prev = NULL;
			    			irnode->next = NULL;
						return irnode;
					}
					else{
						int num = 0;
						while(shead!=NULL){
							if(strcmp(shead->name,vhead->name)==0)
								break;
							else{
								num++;
								shead = shead->next;
							}
						}
						assert(shead!=NULL);
						Operand result = newtemp();
						(*parentop) = create_operand(ADDRESS,"",result->u.tempnum);
						Operand op2 = create_operand(CONSTANT,"",num*4);
						struct InterCode* ircode = (struct InterCode*)malloc(sizeof(struct InterCode));
					    	ircode->u.binop.op1 = right;
					    	ircode->u.binop.op2 = op2;
					    	ircode->u.binop.result = result;
					    	ircode->kind = ADD;
						struct InterCodeNode* irnode = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
						irnode->code = ircode;
			    			irnode->prev = NULL;
			    			irnode->next = NULL;
						return irnode;
					}
				}//ispara != 1
			}


		}//if(strncmp(exp->childlist[1]->name,"DOT",3) == 0)
			


	}//if(exp->childnum == 3)
	/*********************************** exp->childnum == 4 *****************************************/
	else if(exp->childnum == 4){
		if(strncmp(exp->child[1]->name,"LP",2) == 0){
			struct Fun* fhead = funhead1;
			while(fhead != NULL){
				if(strncmp(fhead->name,(exp->child[0]->name)+4,46) == 0)
					break;
				fhead = fhead->next;
			}
			assert(fhead!=NULL);
			struct OperandNode* arglist = NULL;
			struct InterCodeNode* irnode1 = (struct InterCodeNode*)translate_Args(exp->child[2],&arglist,head);
			if(strncmp(fhead->name,"write",5) == 0){
				struct InterCode* ircode2 = (struct InterCode*)malloc(sizeof(struct InterCode));
				ircode2->u.write.arg = arglist->op;
				ircode2->kind = WRITE;
				struct InterCodeNode* irnode2 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
				irnode2->code = ircode2;
		    		irnode2->prev = NULL;
		    		irnode2->next = NULL;
				return jointoirhead(irnode1,irnode2);
			}
			else{
				struct InterCodeNode* irnode2 = NULL;
				while (arglist != NULL)
				{
					struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
					ircode3->u.arg.argop = arglist->op;
					ircode3->kind = ARG;
					struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
					irnode3->code = ircode3;
		    			irnode3->prev = NULL;
		    			irnode3->next = NULL;
					irnode2 = jointoirhead(irnode2,irnode3);
					arglist = arglist->next;
				}
				Operand op2 = (Operand)create_operand(FUNC,fhead->name,0);
				struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
        			ircode3->kind = CALL;
                     		if((*parentop) == NULL)
                        		ircode3->u.call.op1 = newtemp();
                    		else{
        				ircode3->u.call.op1 = (*parentop);
        				ircode3->u.call.op2 = op2;
        				struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
					irnode3->code = ircode3;
		    			irnode3->prev = NULL;
		    			irnode3->next = NULL;
					irnode1 = jointoirhead(irnode1,irnode2);
					return jointoirhead(irnode1,irnode3);
				}

			}

		}//if(strncmp(exp->child[2]->name,"Args",4) ==0)
		else if(strncmp(exp->child[1]->name,"LB",2) == 0){//e.g. a[1]
			printf("translate_Exp():I have not finished this part!\n");
			exit(1);
		}



	}//if(exp->childnum == 4)
   	else 
		printf("translate_Exp():this case should not happen!\n");
}
//translate Args
struct InterCodeNode* translate_Args(struct GrammarTree* args,struct OperandNode** arg_list_addr,struct Fun* head){
	if (args->childnum == 1){
		Operand temp = newtemp();
		struct InterCodeNode* irnode1 = translate_Exp(args->child[0],&temp,head);
		
		struct OperandNode* irnode2 = (struct OperandNode*)malloc(sizeof(struct OperandNode));
		irnode2->next = NULL;
		irnode2->op = temp;
		irnode2->next = (*arg_list_addr);
		(*arg_list_addr) = irnode2;
		
		return irnode1;
	}
	else{
		Operand temp = newtemp();
		struct InterCodeNode* irnode1 = translate_Exp(args->child[0],&temp,head);
		
		struct OperandNode* irnode2 = (struct OperandNode*)malloc(sizeof(struct OperandNode));
		irnode2->next = NULL;
		irnode2->op = temp;
		irnode2->next = (*arg_list_addr);
		(*arg_list_addr) = irnode2;
		
		struct InterCodeNode* irnode3 = translate_Args(args->child[2],arg_list_addr,head);
		
		return jointoirhead(irnode1,irnode3);
	}
}
//translate Cond
struct InterCodeNode* translate_Cond(struct GrammarTree* exp,Operand lbt,Operand lbf,struct Fun* head){
	assert(exp->childnum == 3);
        if(strncmp(exp->child[1]->name,"RELOP",5) == 0){
            	Operand op1 = newtemp();
            	Operand op2 = newtemp();

            	struct InterCodeNode* irnode1= translate_Exp(exp->child[0],&op1,head);

            	struct InterCodeNode* irnode2= translate_Exp(exp->child[2],&op2,head);

            	struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
            	ircode3->u.rel.op1 = op1;
            	ircode3->u.rel.op2 = op2;
            	ircode3->u.rel.labelop = lbt;
	    	Operand relop = create_operand(RELOPOP,exp->child[1]->name,0);
            	ircode3->u.rel.relop = relop;
            	ircode3->kind = REL;
            	struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode3->code = ircode3;
		irnode3->prev = NULL;
		irnode3->next = NULL;

            	struct InterCode* ircode4 = (struct InterCode*)malloc(sizeof(struct InterCode));
            	ircode4->u.go.labelop = lbf;
            	ircode4->kind = GOTO;
            	struct InterCodeNode* irnode4 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode4->code = ircode4;
		irnode4->prev = NULL;
		irnode4->next = NULL;
            	
            	irnode1 = jointoirhead(irnode1,irnode2);
            	irnode1 = jointoirhead(irnode1,irnode3);
            	irnode1 = jointoirhead(irnode1,irnode4);
            	return irnode1;
        }
        else if(strncmp(exp->child[1]->type,"AND",3) == 0){
            	Operand lb1 = newlabel();
            	struct InterCodeNode* irnode1= translate_Cond(exp->child[0],lb1,lbf,head);
            
            	struct InterCode* ircode2 = (struct InterCode*)malloc(sizeof(struct InterCode));
            	ircode2->u.label.labelop = lb1;
            	ircode2->kind = LABEL;
            	struct InterCodeNode* irnode2 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode2->code = ircode2;
		irnode2->prev = NULL;
		irnode2->next = NULL;

            	struct InterCodeNode* irnode3= translate_Cond(exp->child[2],lbt,lbf,head);
		
		irnode1 = jointoirhead(irnode1,irnode2);
            	irnode1 = jointoirhead(irnode1,irnode3);
            	return irnode1;
        }
        else if(strncmp(exp->child[1]->name,"OR",2) == 0){
            	Operand lb1 = newlabel();
            	struct InterCodeNode* irnode1= translate_Cond(exp->child[0],lbt,lb1,head);
            
            	struct InterCode* ircode2 = (struct InterCode*)malloc(sizeof(struct InterCode));
            	ircode2->u.label.labelop = lb1;
            	ircode2->kind = LABEL;
            	struct InterCodeNode* irnode2 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode2->code = ircode2;
		irnode2->prev = NULL;
		irnode2->next = NULL;

            	struct InterCodeNode* irnode3= translate_Cond(exp->child[2],lbt,lbf,head);
	
		irnode1 = jointoirhead(irnode1,irnode2);
            	irnode1 = jointoirhead(irnode1,irnode3);
            	return irnode1;
        }
        else{
		   printf("translate_Cond():this case should not happen!\n");
        }
}

/***************************************************************************************************/
//translate StmtList
struct InterCodeNode* translate_StmtList(struct GrammarTree* stmtlist,struct Fun* head){
	if(stmtlist == NULL)
		return NULL;
	else{
		struct InterCodeNode* irnode1 = (struct InterCodeNode*)translate_Stmt(stmtlist->child[0],head);
		struct InterCodeNode* irnode2 = translate_StmtList(stmtlist->child[1],head);
		return jointoirhead(irnode1,irnode2);
    	}
}
//translate Stmt
struct InterCodeNode* translate_Stmt(struct GrammarTree* stmt,struct Fun* head){
	if(stmt->childnum == 2){
		Operand temp = NULL;
		return translate_Exp(stmt->child[0],&temp,head);
	}
	else if(stmt->childnum == 1){
		return translate_CompSt(stmt->child[0],head);
	}
	else if(stmt->childnum == 3){//e.g. return x;
		Operand returnop = newtemp();
		struct InterCodeNode* irnode1 = translate_Exp(stmt->child[1],&returnop,head);//printf("--returnop.kind = %d--\n",returnop->kind);
		struct InterCode* ircode2 = (struct InterCode*)malloc(sizeof(struct InterCode));
		ircode2->u.ret.returnop = returnop;
		ircode2->kind = RETURN_CODE;
		struct InterCodeNode* irnode2 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode2->code = ircode2;
		irnode2->prev = NULL;
		irnode2->next = NULL;
		
		return jointoirhead(irnode1,irnode2);
	}
	else if(stmt->childnum == 5){
		if(strncmp(stmt->child[0]->name,"IF",2) == 0){//e.g. if(a == 1)..
			Operand lb1 = newlabel();
			Operand lb2 = newlabel();
			struct InterCodeNode* irnode1 = translate_Cond(stmt->child[2],lb1,lb2,head);
	
			struct InterCode* ircode2 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode2->u.label.labelop = lb1;
			ircode2->kind = LABEL;
			struct InterCodeNode* irnode2 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode2->code = ircode2;
			irnode2->prev = NULL;
			irnode2->next = NULL;
			
			struct InterCodeNode* irnode3 = translate_Stmt(stmt->child[4],head);
			
			struct InterCode* ircode4 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode4->u.label.labelop = lb2;
			ircode4->kind = LABEL;
			struct InterCodeNode* irnode4 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode4->code = ircode4;
			irnode4->prev = NULL;
			irnode4->next = NULL;
			
			irnode1 = jointoirhead(irnode1,irnode2);
		    	irnode1 = jointoirhead(irnode1,irnode3);
		    	irnode1 = jointoirhead(irnode1,irnode4);
		    	return irnode1;

		}
		else if(strncmp(stmt->child[0]->name,"WHILE",5) == 0){//e.g. while(a==1)..
			Operand lb1 = newlabel();
			Operand lb2 = newlabel();
			Operand lb3 = newlabel();
			
			struct InterCode* ircode1 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode1->u.label.labelop = lb1;
			ircode1->kind = LABEL;
			struct InterCodeNode* irnode1 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode1->code = ircode1;
			irnode1->prev = NULL;
			irnode1->next = NULL;

			struct InterCodeNode* irnode2 = translate_Cond(stmt->child[2],lb2,lb3,head);

			struct InterCode* ircode3 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode3->u.label.labelop = lb2;
			ircode3->kind = LABEL;
			struct InterCodeNode* irnode3 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode3->code = ircode3;
			irnode3->prev = NULL;
			irnode3->next = NULL;

			struct InterCodeNode* irnode4 = translate_Stmt(stmt->child[4],head);

			struct InterCode* ircode5 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode5->u.go.labelop = lb1;
			ircode5->kind = GOTO;
			struct InterCodeNode* irnode5 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode5->code = ircode5;
			irnode5->prev = NULL;
			irnode5->next = NULL;

			struct InterCode* ircode6 = (struct InterCode*)malloc(sizeof(struct InterCode));
			ircode6->u.label.labelop = lb3;
			ircode6->kind = LABEL;
			struct InterCodeNode* irnode6 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
			irnode6->code = ircode6;
			irnode6->prev = NULL;
			irnode6->next = NULL;
			
			irnode1 = jointoirhead(irnode1,irnode2);
		    	irnode1 = jointoirhead(irnode1,irnode3);
		    	irnode1 = jointoirhead(irnode1,irnode4);
		    	irnode1 = jointoirhead(irnode1,irnode5);
		    	irnode1 = jointoirhead(irnode1,irnode6);
		    	return irnode1;
		}
	}
	else if(stmt->childnum == 7){//e.g. if(a==1).. else..
		Operand lb1 = newlabel();
		Operand lb2 = newlabel();
		Operand lb3 = newlabel();
		struct InterCodeNode* irnode1 = translate_Cond(stmt->child[2],lb1,lb2,head);

		struct InterCode* ircode2 = (struct InterCode*)malloc(sizeof(struct InterCode));
		ircode2->u.label.labelop = lb1;
		ircode2->kind = LABEL;
		struct InterCodeNode* irnode2 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode2->code = ircode2;
		irnode2->prev = NULL;
		irnode2->next = NULL;

		struct InterCodeNode* irnode3 = translate_Stmt(stmt->child[4],head);

		struct InterCode* ircode4 = (struct InterCode*)malloc(sizeof(struct InterCode));
		ircode4->u.go.labelop = lb3;
		ircode4->kind = GOTO;
		struct InterCodeNode* irnode4 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode4->code = ircode4;
		irnode4->prev = NULL;
		irnode4->next = NULL;

		struct InterCode* ircode5 = (struct InterCode*)malloc(sizeof(struct InterCode));
		ircode5->u.label.labelop = lb2;
		ircode5->kind = LABEL;
		struct InterCodeNode* irnode5 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode5->code = ircode5;
		irnode5->prev = NULL;
		irnode5->next = NULL;

		struct InterCodeNode* irnode6 = translate_Stmt(stmt->child[6],head);

		struct InterCode* ircode7 = (struct InterCode*)malloc(sizeof(struct InterCode));
		ircode7->u.label.labelop = lb3;
		ircode7->kind = LABEL;
		struct InterCodeNode* irnode7 = (struct InterCodeNode*)malloc(sizeof(struct InterCodeNode));
		irnode7->code = ircode7;
		irnode7->prev = NULL;
		irnode7->next = NULL;
		irnode1 = jointoirhead(irnode1,irnode2);
		irnode1 = jointoirhead(irnode1,irnode3);
		irnode1 = jointoirhead(irnode1,irnode4);
		irnode1 = jointoirhead(irnode1,irnode5);
		irnode1 = jointoirhead(irnode1,irnode6);
		irnode1 = jointoirhead(irnode1,irnode7);
		return irnode1;
	}
	else{
		printf("translate_Stmt():this case should not happen!\n");
	}
}

/********************************** Output Function-->code.ir *************************************************************/
//declare these funs
void fputsOperand(Operand op,FILE* stream);
void fputsCode(struct InterCode* ircode,FILE* stream);
void fputsNode(struct InterCodeNode* irhead,FILE* stream);

//put operand into code.ir
void fputsOperand(Operand op,FILE* stream){
    	switch(op->kind){
        	case VARIABLE:	fprintf(stream,"var%d",op->u.varnum);		break;
		case CONSTANT:	fprintf(stream,"#%d",op->u.value);		break;
		case ADDRESS:	fprintf(stream,"*addr%d",op->u.varnum);		break;
		case RELOPOP:	fprintf(stream,"%s",op->u.relop);		break;
		case LABELOP:	fprintf(stream,"label%d",op->u.labelnum);	break;
		case TEMP:	fprintf(stream,"temp%d",op->u.tempnum);		break;
		case FUNC:	fprintf(stream,"%s",op->u.funname);		break;
		case SIZE:	fprintf(stream,"%d",op->u.value);		break;
		case REFERENCE: fprintf(stream,"&var%d",op->u.varnum);		break;
		case ARGOP:	;						break;
		default:	fprintf(stream,"(Error happened here)");	break;
    	}
}

//put one code into code.ir
void fputsCode(struct InterCode* ircode,FILE* stream){
    	switch(ircode->kind){
        	case ASSIGN:
            		fputsOperand(ircode->u.assign.left,stream);
            		fprintf(stream," := ");
            		fputsOperand(ircode->u.assign.right,stream);
           		break;
        	case ADD:
            		fputsOperand(ircode->u.binop.result,stream);
            		fprintf(stream," := ");
            		fputsOperand(ircode->u.binop.op1,stream);
            		fprintf(stream," + ");
            		fputsOperand(ircode->u.binop.op2,stream);
            		break;
        	case SUB:        
            		fputsOperand(ircode->u.binop.result,stream);
            		fprintf(stream," := ");
            		fputsOperand(ircode->u.binop.op1,stream);
            		fprintf(stream," - ");
            		fputsOperand(ircode->u.binop.op2,stream);
           		break;
        	case MUL:        
			fputsOperand(ircode->u.binop.result,stream);
			fprintf(stream," := ");
			fputsOperand(ircode->u.binop.op1,stream);
			fprintf(stream," * ");
			fputsOperand(ircode->u.binop.op2,stream);
			break;
        	case DIVISION:        
			fputsOperand(ircode->u.binop.result,stream);
			fprintf(stream," := ");
			fputsOperand(ircode->u.binop.op1,stream);
			fprintf(stream," / ");
			fputsOperand(ircode->u.binop.op2,stream);
			break;
        	case LABEL:        
			fprintf(stream,"LABEL ");
			fputsOperand(ircode->u.label.labelop,stream);
			fprintf(stream," :");
			break;
        	case REL:
			fprintf(stream,"IF ");
			fputsOperand(ircode->u.rel.op1,stream);
			fprintf(stream," ");
			fputsOperand(ircode->u.rel.relop,stream);
			fprintf(stream," ");
			fputsOperand(ircode->u.rel.op2,stream);
			fprintf(stream," GOTO ");
			fputsOperand(ircode->u.rel.labelop,stream);
			break;
        	case GOTO:        
			fprintf(stream,"GOTO ");
			fputsOperand(ircode->u.go.labelop,stream);
			break;
        	case READ:
			fprintf(stream,"READ ");
			fputsOperand(ircode->u.read.arg,stream);
			break;
		case WRITE:
			fprintf(stream,"WRITE ");
			fputsOperand(ircode->u.write.arg,stream);
			break; 
        	case CALL:
			fputsOperand(ircode->u.call.op1,stream);
			fprintf(stream," := CALL ");
			fputsOperand(ircode->u.call.op2,stream);
			break;     
        	case FUNCTION:
			fprintf(stream,"FUNCTION ");
			fputsOperand(ircode->u.function.funname,stream);
			fprintf(stream," :");
			break;
		case RETURN_CODE:
			fprintf(stream,"RETURN ");
			fputsOperand(ircode->u.ret.returnop,stream);
			break;
        	case PARA:
			fprintf(stream,"PARAM ");
			fputsOperand(ircode->u.para.var,stream);
			break;
		case ARG:
			fprintf(stream,"ARG ");
			fputsOperand(ircode->u.arg.argop,stream);
			break; 
        	case DEC:
			fprintf(stream,"DEC ");
			fputsOperand(ircode->u.dec.var,stream);
			fprintf(stream," ");
			fputsOperand(ircode->u.dec.size,stream);
			break;
        	default:	
			fprintf(stream,"(Error happened here)");
			break;
    }
}

//put ir nodes into file code.ir
void fputsNode(struct InterCodeNode* irhead,FILE* stream){
    	struct InterCodeNode* irnode;
    	for(irnode = irhead;irnode != NULL;irnode = irnode->next){
        	fputsCode(irnode->code,stream);
		fprintf(stream,"\n");
    	}
}
