#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node{
	int type_int;
	float type_float;
	int line;
	char type_name[12];
	char type_cont[50];
	int cNum;
	struct node* children[10];
};
void printTree(struct node* root);
void addNode(struct node* root,struct node* child);
struct node* createNode(int line,char* cont,char* name);
