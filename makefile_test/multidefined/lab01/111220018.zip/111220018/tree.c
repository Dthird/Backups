#include "tree.h"
int spaceNum;
void printNode(struct node* n)
{
	int i;
	if(strcmp(n->type_name,"")==0)
		return ;
	for(i = 0;i < spaceNum;i++)
		printf("  ");
	if (strcmp(n->type_name,"INT") == 0)
		printf("INT: %d\n",n->type_int);
	else if (strcmp(n->type_name,"FLOAT") == 0)
		printf("FLOAT: %f\n",n->type_float);
	else if (strcmp(n->type_name,"ID") == 0)
		printf("ID: %s\n",n->type_cont);
	else if (strcmp(n->type_name,"TYPE") == 0)
		printf("TYPE: %s\n",n->type_cont);
	else if (n->cNum==0)
		printf("%s\n",n->type_name);	
	else
		printf("%s (%d)\n",n->type_name,n->line);
}
void printTree(struct node* root)
{
	//if(root->line < 1)
		//return 1;
	//printf("HELLO!");
	printNode(root);
	spaceNum ++;
	int i;
	for(i = 0;i < root->cNum;i ++)
		printTree(root->children[i]);
	spaceNum --;
}
void addNode(struct node* root,struct node* child)
{
	root->children[root->cNum] = child;
	root->cNum++;
}
struct node* createNode(int line,char* cont,char* name)
{
	struct node* n = malloc(sizeof(struct node));
	n->line=line;
	n->cNum=0;
	if(cont!=NULL)
		strcpy(n->type_cont,cont);
	if(name!=NULL)
		strcpy(n->type_name,name);
	return n;
}
