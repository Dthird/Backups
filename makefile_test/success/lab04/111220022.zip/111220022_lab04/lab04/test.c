int sum(int a,int b,int c,int d,int e){
	return a + b + c + d + e;
}
int main(){
	int count = sum(1,2,3,4,5);
	write(count);
	return 0;
}
