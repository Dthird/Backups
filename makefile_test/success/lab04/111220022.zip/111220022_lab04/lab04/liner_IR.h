#include "type.h"
#include <stdlib.h>
#include<stdio.h>
typedef struct Operand_* Operand;
typedef struct InterCode InterCode;
typedef struct InterCodes InterCodes;
typedef struct Args Args;
typedef struct DagNode DagNode;
typedef struct dOperand dOperand;
struct Operand_ {
	enum { VARIABLE, CONSTANT,TEMP_VARIABLE, ADDRESS_VARIABLE , ADDRESS_TEMP_VARIABLE, VARIABLE_VALUE,TEMP_VARIABLE_VALUE} kind;
	union {
		int var_no;
		int value;
		int temp_no;
	} u;
};

struct InterCode
{
	enum { ASSIGN, ADD, SUB, MUL, DIV, IF ,GOTO,LABEL,RETURN,CALL,READ,WRITE,ARGS,FUNCTION,PARAM,DEC} kind;
	union {
		struct { Operand right, left; } assign;
		struct { Operand result, op1, op2; } binop;
		struct { Operand op1, op2;int label; char relop[10];} ific;
		struct { int label;} mlabel;
		struct { Operand op;}oneop;
		struct { Operand op;char funcname[32];}funcop;
		struct { Operand op; int size;} structure;
		
		 
	} u;
};

struct InterCodes { 
	InterCode code; 
	struct InterCodes *prev, *next;
};

struct Args { 
	Operand op; 
	struct Args *next;
};



struct DagNode{
	int id;
	int ickind;
	dOperand* dop;
	struct DagNode* left;
	struct DagNode* right;
	struct DagNode* prev;
	struct DagNode* next;
};

struct dOperand{
	Operand op;
	struct dOperand* next;
};




/*
enum opkind{ ASSIGN, ADD, SUB, MUL,IF,GOTO,LABEL,RETURN,CALL};
enum optype{ VARIABLE, CONSTANT,TEMP_VARIABLE, ADDRESS} ;*/
extern InterCodes* head;
extern InterCodes* tail;



InterCodes *translate_Exp(Node *exp, Operand place,boolean foraddress);
InterCodes * translate_Cond(Node *exp,int label_true,int label_false);
InterCodes * translate_Stmt(Node *stmt);
InterCodes * translate_CompSt(Node *compSt);
InterCodes * translate_Args(Node *args, Args** arg_list);
InterCodes * translate_FunDec(Node *fundec);
InterCodes * translate_ExtDef(Node *extdef);
InterCodes * translate_StmtList(Node *stmtlist);
InterCodes * translate_ExtDefList(Node *extdeflist);
InterCodes * translate_VarList(Node *varlist);
InterCodes * translate_ParamDec(Node *paramDec);
InterCodes * translate_VarDec(Node *vardec,int args);
InterCodes * translate_DefList(Node *deflist);
InterCodes * translate_Def(Node *def);
InterCodes * translate_DecList(Node *declist);
InterCodes * translate_Dec(Node *declist);




Operand create_op(int kind,Node *node);
Operand create_op_constant(int kind,int value);

InterCodes* create_ir(int kind,Operand op[]);
InterCodes* create_ir_conf(int kind,Operand op[],int label,char *relop);
InterCodes* create_ir_func(int kind,Operand op,char *name);
InterCodes* create_ir_str(int kind,Operand op,int size);




int create_label();
int lookup(char *id);
char *get_relop(Node *node);
int get_value_int(Node *intnode);
float get_value_float(Node *floatnode);
void IRinit();
void insertIR(InterCodes* ic);
void insert_arg(Args** arg_list, Args* arg);
void connectic(InterCodes* ic[],int num);
void var_copy(Operand place,Operand temp);
boolean ifassign(Operand temp1, Operand temp2);
void replacetemp(Operand to,Operand from,Operand op);
void deal_intercode(InterCodes* ic,Operand to, Operand from);
void delete_tat(InterCodes* head);
boolean ifassigntemp(Operand temp1, Operand temp2);



//优化
Operand directexp(Node *exp);
char * dealrelop(char *relop);
void optimizelabel(InterCodes* head);
void optimizedigital(InterCodes* head);
void  delete_tac(InterCodes* head);


//dag
DagNode *findchild(DagNode** dhead,Operand fop);
DagNode *findfather(DagNode** dhead,Operand fop,DagNode* left,DagNode* right,int ickind);
DagNode* createchild(Operand dop,DagNode** dhead,int* id);
DagNode* createfather(int* id,int ickind,Operand dop,DagNode* left,DagNode* right,DagNode** prev,DagNode* next,DagNode** dhead);
boolean inserticdagnode(InterCodes* ic,DagNode** dhead,int* id);
boolean createdag(InterCodes* head,DagNode** dhead);
InterCodes* dagtoic(DagNode** dhead);



int stmtchild(Node *stmt,Node *tnode[]);
int extdefchild(Node* extdef,Node *tnode[]);
int expchild(Node *exp,Node *tnode[]);
int argschild(Node* args,Node *tnode[]);
int funcdecchild(Node* funcdec,Node *tnode[]);
int varlistchild(Node* args,Node *tnode[]);
int vardecchild(Node* vardec,Node *tnode[]);
int declistchild(Node* varlist,Node *tnode[]);
int decchild(Node* dec,Node *tnode[]);


void display_ir(InterCodes* head,char *filename);
void display_intercode(InterCodes* ic,FILE *fp);
void display_op(FILE *fp,Operand op);


