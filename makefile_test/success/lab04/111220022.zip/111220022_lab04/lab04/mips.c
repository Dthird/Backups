#include "huibian.h"
#include <string.h>


Reg Regarray[32];//全局变量，管理寄存器
MipsCodes* mhead = NULL;
int beiargsnum = 0;
char funcname[32];
Funcargreg* argreghead = NULL;

/*
void display_opp(Operand op){
	int kind = op->kind;
	//printf("kind:%d\n",kind);
	switch(kind){
		case VARIABLE:
			printf("v%d",op->u.var_no);
			break;
		case CONSTANT:
			printf("#%d",op->u.value);
			break;
		case TEMP_VARIABLE:
			printf("t%d",op->u.temp_no);
			break;
		case ADDRESS_VARIABLE:
			printf("*v%d",op->u.temp_no);
			break;
		case ADDRESS_TEMP_VARIABLE:
			printf("*t%d",op->u.temp_no);
			break;
		case TEMP_VARIABLE_VALUE:
			printf("&t%d",op->u.temp_no);
			break;
		case VARIABLE_VALUE:
			printf("&v%d",op->u.temp_no);
			break;
	}
}

*/
void insertfuncarg(char *funcname){
	Funcargreg* fa = (Funcargreg*)malloc(sizeof(struct Funcargreg));
	memset(fa,0,sizeof(struct Funcargreg));
	strcpy(fa->funcname,funcname);
	if(argreghead == NULL){
		argreghead = fa;
	}
	else{
		fa->next = argreghead->next;
		argreghead->next = fa;
	}
}
reg useargreg(char* funcname,Operand op,reg r){
	Funcargreg* p = argreghead;
	//int i = 0;
	for(;p != NULL; p = p->next){
		if(strcmp(p->funcname,funcname) == 0){
			//printf("找到对应函数名，开始设置寄存器\n");
			//for(i =0; i < 4; i ++){
				
					p->argreg[r - $a0].op = op;
					return r;
				
			//}
		}
	}
	return $zero;
}




reg findargreg(char* funcname,Operand op){
	Funcargreg* p = argreghead;
	int i = 0;
	for(;p != NULL; p = p->next){
		if(strcmp(p->funcname,funcname) == 0){
			for(i =0; i < 4; i ++){
				if(p->argreg[i].op != NULL){
					if(ifassign(p->argreg[i].op,op)){
						return $a0 + i;
					}
				}
			}
			
		}
	}
	return $zero;
}
void initreg(){
	int i = 0;
	for(i = 0; i < 32; i ++){
		Regarray[i].op = NULL;	
	}
}



char * regname(reg r){
	char* name = malloc(32);
	switch(r){
		case $zero: strcpy(name,"$zero"); break;
		case $at: strcpy(name,"$at"); break;
		case $v0: strcpy(name,"$v0"); break;
		case $v1: strcpy(name,"$v1"); break;
		case $a0: strcpy(name,"$a0"); break;
		case $a1: strcpy(name,"$a1"); break;
		case $a2: strcpy(name,"$a2"); break;
		case $a3: strcpy(name,"$a3"); break;
		case $t0: strcpy(name,"$t0"); break;
		case $t1: strcpy(name,"$t1"); break;
		case $t2: strcpy(name,"$t2"); break;
		case $t3: strcpy(name,"$t3"); break;
		case $t4: strcpy(name,"$t4"); break;
		case $t5: strcpy(name,"$t5"); break;
		case $t6: strcpy(name,"$t6"); break;
		case $t7: strcpy(name,"$t7"); break;
		case $s0: strcpy(name,"$s0"); break;
		case $s1: strcpy(name,"$s1"); break;
		case $s2: strcpy(name,"$s2"); break;
		case $s3: strcpy(name,"$s3"); break;
		case $s4: strcpy(name,"$s4"); break;
		case $s5: strcpy(name,"$s5"); break;
		case $s6: strcpy(name,"$s6"); break;
		case $s7: strcpy(name,"$s7"); break;
		case $t8: strcpy(name,"$t8"); break;
		case $t9: strcpy(name,"$t9"); break;
		case $k0: strcpy(name,"$k0"); break;
		case $k1: strcpy(name,"$k1"); break;
		case $gp: strcpy(name,"$gp"); break;
		case $sp: strcpy(name,"$sp"); break;
		case $fp: strcpy(name,"$fp"); break;
		case $ra: strcpy(name,"$ra"); break;
		
	}
	return name;
}

void freereg(){
	int i = 0;
	for(i = $t0 ; i <= $t9; i ++){
		Regarray[i].op = NULL;
	}
}
int fp = 0;
int sp = 0;

int paramargnum = 0;
//int argnum = 0;

reg getvaluefromaddress(Operand op,reg r1,MipsCodes** mcs,int flag){
	int i = 0;
	reg r;
	if(op->kind == ADDRESS_VARIABLE || op->kind == ADDRESS_TEMP_VARIABLE){
		for(i = $t0 ; i <= $t9; i ++){
			if(Regarray[i].op == NULL){
				Regarray[i].op = op;
				r = i;
				break;
			}
		}
		if(i > $t9){
			return $zero;
		}
		if(flag == 0){
			*mcs = mipscode_rrc(lw,r,r1,0);
		}
		else if(flag == 1){
			*mcs = mipscode_rrc(sw,r,r1,0);
		}
		return r;
	}
	else{
		return r1;
	}
}
reg choosereg(Operand op,MipsCodes** mcs,int flag){//falg == 0 ,无需分配空间， falg == 1，需要分配空间
	int i = $t0 ;
	reg r;
	MipsCodes* mcss[3];
	int j = 0;
	for(j = 0; j < 3; j ++){
		mcss[j] = NULL;
	}
	
	//先判断该变量是否时参数里的变量，现在还没有考虑变量多余4个的情况！！！！！！！！！！！！！！！！！！！
	if(flag == 2){
		return findargreg(funcname,op);
		/*for(i = $a0 ; i <= $a3; i ++){
			if(Regarray[i].op == NULL){//还没有考虑变量时地址的情况
				Regarray[i].op = op; 
				return i;
			}
		}*/
		
	}
	if(flag == 2){
		return $zero;
	}
	
	
	//先查看是否是参数中的
	if(flag == 4){
			Regarray[i].op = (Operand)malloc(sizeof(struct Operand_));
			return i;
	}
	if((r = findargreg(funcname,op)) != $zero){	
		return r;
	}
	for(i = $t0 ; i <= $t9; i ++){
		if(Regarray[i].op == NULL){
			Regarray[i].op = op;
			r = i;
			break;
		}
	}
	if(i > $t9){
		return $zero;
	}
	
	 if(op->kind == ADDRESS_VARIABLE || op->kind == ADDRESS_TEMP_VARIABLE){
		
			Operand op1 = (Operand)malloc(sizeof(struct Operand_));
			if(op->kind == ADDRESS_VARIABLE){
				op1->kind = VARIABLE;
				op1->u.var_no = op->u.var_no;
			}
			else{
				op1->kind = TEMP_VARIABLE;
				op1->u.temp_no = op->u.temp_no;
			}
			Vindex* vi = findop(op1);
			if(vi != NULL){
				*mcs =  mipscode_rrc(lw,r,$fp,vi->index);
				mcss[0] = *mcs;
				//return r;
					
			}
			else{
				return $zero;
			}
			if(flag ==0 || flag == 1){
				r = getvaluefromaddress(op,r,&(mcss[1]),flag);
			}
			connectmcs(mcss,2);
			
			return r;
	}
	Vindex* vi = findop(op);
	if(vi != NULL ){
		*mcs =  mipscode_rrc(lw,r,$fp,vi->index);
	}
	else if(op->kind == CONSTANT){
		if(op->u.value == 0){
			r = $zero;
		}
		else{
			*mcs =  mipscode_rrc(li,r,$zero,op->u.value);
		}
	}
	
	else{//若没有找到，将变量压入栈中
		if(flag == 1){
			*mcs = mipscode_rrc(addi,$sp,$sp,-4);
			//将变量和其在栈中对应的位置关联起来。以相对于$fp的位置为基准
			int index = sp - fp;//相对于当前fp指针的偏移量
			insertvindex(op,index);
		
		}
		
		
		
	}
	return r;
	
}


//初始化,这里的fp,sp用于管理变量在内存中的偏移，其加减并不影响$sp和$fp的值


FPnode *fptop = NULL;

void freeareg(){
	int i;
	for(i = $a0 ; i <= $a3; i ++){
		Regarray[i].op = NULL;
		
	}
}

FPnode* pushfp(int fp){
	FPnode* fpn = (FPnode*)malloc(sizeof(struct FPnode));
	memset(fpn,0,sizeof(struct FPnode));
	fpn->fp = fp;
	if(fptop == NULL){
		fptop = fpn;
	}
	else{
		fptop->next = fpn;
		fptop = fpn;
	}
	return fpn;
}

void popfp(){
	if(fptop == NULL){
		//printf("栈已经为空\n");
	}
	else{
		fptop = fptop->prev;
	}
}

//用于管理变量及其在内存中的位置的队列
Vindex *vhead = NULL;
Vindex *vlast = NULL;

Vindex* insertvindex(Operand op,int index){
	Vindex* vi = (Vindex*)malloc(sizeof(struct Vindex));
	memset(vi,0,sizeof(struct Vindex));
	vi->index = index;
	vi->op = op;
	if(vhead == NULL){
		vhead = vlast = vi;
	}
	else{
		vlast -> next = vi;
		vi->prev = vlast;
		vlast = vi;
	}
	return vi;
}

//查找某变量之前是否已经在内存中
Vindex* findop(Operand op){
	Vindex* p = vhead;
	for(p = vhead; p != NULL; p = p->next){
		if(ifassign(p->op,op)){
			return p;
		}
	}
	return NULL;
}


MipsCodes* mlast = NULL;
void createmips(InterCodes* head){	
	InterCodes* p = head;
	MipsCodes* mcs[2];
	for(p = head; p!= NULL; p = p->next){
		if(mhead == NULL){
			mhead =  mlast= create_mipscode(p);
		}
		else{
			mcs[0] = mlast;
			mcs[1] = create_mipscode(p);
			connectmcs(mcs,2);
		}
	}
}

void displaymips(MipsCodes* head,FILE *fp){
	MipsCodes* p = head;
	for(p = head; p!= NULL; p = p->next){
		display_mipscode(fp,p);
	}
}

MipsCodes* create_mipscode(InterCodes* ic){
	int kind = ic->code.kind;
	//Operand op;
	int ckind;
	MipsCodes* mcs[30];
	int i = 0;
	for(i = 0; i < 30; i ++){
		mcs[i] = NULL;
	}
	MipsCode* mc1 = NULL;
	InterCodes* p;
	reg r1;
	reg r2;
	reg r3;
	//MipsCode* mc2 = NULL;
	MipsCodes* cos = NULL;
	if(kind != PARAM ){//当不是PRARM时，释放寄存器，以供下次函数调用
		//freeareg();
	}
	if(kind != ARGS){
		beiargsnum = 0;
	}
	int index = 0;
	int argnum = 0;
	int bargs = 0;
	switch(kind){
		case ASSIGN:
	
			
			if(ic->code.u.assign.right->kind == CONSTANT && (ic->code.u.assign.left->kind == VARIABLE || ic->code.u.assign.left->kind == TEMP_VARIABLE)){
				r1 = choosereg(ic->code.u.assign.left,&(mcs[0]),1);
				mcs[1] = mipscode_rrc(li,r1,$zero,ic->code.u.assign.right->u.value);
				//在将一个变量存进内存之前，先判断其是否已在内存中
				mcs[2] = storeop(ic->code.u.assign.left,r1);
				
				cos =  connectmcs(mcs,3);
				freereg();
				return cos;
			
			}
			else if(ic->code.u.assign.right->kind ==  ADDRESS_VARIABLE || ic->code.u.assign.right->kind == ADDRESS_TEMP_VARIABLE){
				
				r1 = choosereg(ic->code.u.assign.left,&(mcs[0]),1);
				r2 = choosereg(ic->code.u.assign.right,&(mcs[1]),5);
				mcs[2] =  mipscode_rrc(lw,r1,r2,0);
				mcs[3] =  storeop(ic->code.u.assign.left,r1);
				freereg();
				return connectmcs(mcs,4);
			}
			else if(ic->code.u.assign.left->kind == ADDRESS_VARIABLE || ic->code.u.assign.left->kind ==ADDRESS_TEMP_VARIABLE){
				
				r2 = choosereg(ic->code.u.assign.right,&(mcs[0]),0);
				r1 = choosereg(ic->code.u.assign.left,&(mcs[1]),5);
				mcs[2] =  mipscode_rrc(sw,r2,r1,0);
				freereg();
				return connectmcs(mcs,3);
			}
			else{
				r1 = choosereg(ic->code.u.assign.left,&(mcs[0]),1);
				r2 = choosereg(ic->code.u.assign.right,&(mcs[1]),0);
				mcs[2] = mipscode_rrr(move,r1,r2,$zero);
				mcs[3] = storeop(ic->code.u.assign.left,r1);				
				MipsCodes* cos = connectmcs(mcs,4);
				freereg();
				return cos;
			}
			break;
		case ADD: case SUB:
			r1 = choosereg(ic->code.u.binop.result,&(mcs[0]),1);
			r2 = choosereg(ic->code.u.binop.op1,&(mcs[1]),0);
			if(ic->code.u.binop.op2->kind == CONSTANT){
				int num;
				if(kind == ADD){
					num = ic->code.u.binop.op2->u.value;
				}
				else{
					num = -ic->code.u.binop.op2->u.value;
				}
				mcs[2] = mipscode_rrc(addi,r1,r2,num);	
				mcs[3] = storeop(ic->code.u.binop.result,r1);
				freereg();
				cos =  connectmcs(mcs,4);
				return cos;
			}
			else{
				r3 = choosereg(ic->code.u.binop.op2,&(mcs[2]),0);
				int okind;
				if(kind == ADD){
					okind = add;
				}
				else{
					okind = sub;
				}
				mcs[3] = mipscode_rrr(okind,r1,r2,r3);
				mcs[4] = storeop(ic->code.u.binop.result,r1);
				freereg();
				return connectmcs(mcs,5);
			}
			break;
		case MUL: 
			//The multiplication, division and conditional jump instructions do not support constant other than 0, so if the IR contains something like “x := y * #7” , the immediate “#7” must be loaded into a register first
			
			r1 = choosereg(ic->code.u.binop.result,&(mcs[0]),1);
			r2 = choosereg(ic->code.u.binop.op1,&(mcs[1]),0);
			r3 = choosereg(ic->code.u.binop.op2,&(mcs[2]),0);
			mcs[3] =  mipscode_rrr(mul,r1,r2,r3);
			mcs[4] = storeop(ic->code.u.binop.result,r1);
			
			cos =  connectmcs(mcs,5);
			freereg();
			return cos;
			
		case DIV:
			r1 = choosereg(ic->code.u.binop.result,&(mcs[0]),1);
			r2 = choosereg(ic->code.u.binop.op1,&(mcs[1]),0);
			r3 = choosereg(ic->code.u.binop.op2,&(mcs[2]),0);
			mcs[3] =  mipscode_rrr(divi,r2,r3,$zero);
			mcs[4] =  mipscode_jump(mflo,r1,$zero,-1,NULL);
			mcs[5] = storeop(ic->code.u.binop.result,r1);
			cos = connectmcs(mcs,6);
			freereg();
			return cos;
			
		case IF:
			//IF t1 op t2 GOTO label_true
			
			if(strcmp(ic->code.u.ific.relop,"GT") == 0){
				ckind = bgt;
			}
			else if(strcmp(ic->code.u.ific.relop,"LT") == 0){
				ckind = blt;
			}
			else if(strcmp(ic->code.u.ific.relop,"GE") == 0){
				ckind = bge;
			}
			else if(strcmp(ic->code.u.ific.relop,"LE") == 0){
				ckind = ble;
			}
			else if(strcmp(ic->code.u.ific.relop,"EQ") == 0){
				ckind = beq;
			}
			else if(strcmp(ic->code.u.ific.relop,"NE") == 0){
				ckind = bne;
			}
			r1 = choosereg(ic->code.u.ific.op1,&(mcs[0]),0);
			r2 = choosereg(ic->code.u.ific.op2,&(mcs[1]),0);
			mcs[2] = mipscode_jump(ckind,r1,r2,ic->code.u.ific.label,NULL);
			freereg();
			return connectmcs(mcs,3);

		case GOTO:
			return mipscode_jump(j,$zero,$zero,ic->code.u.mlabel.label,NULL);
		case LABEL:
			return mipscode_jump(label,$zero,$zero,ic->code.u.mlabel.label,NULL);
		case RETURN:
			mc1 = (MipsCode*)malloc(sizeof(struct MipsCode));
			mc1->kind = move;
			mc1->u.vv.left = $v0;
			mc1->u.vv.right = choosereg(ic->code.u.oneop.op,&(mcs[0]),1);
			mcs[1] = (MipsCodes*)malloc(sizeof(struct MipsCodes));
			mcs[1]->code = mc1;
			mcs[1]->prev = NULL;
			mcs[1]->next = NULL;
			mcs[2] = mipscode_jump(jr,$ra,$zero,-1,NULL);
			return connectmcs(mcs,3);
		case CALL:
			
			argnum = argnumber(funcname);
			mcs[index ++] = mipscode_jump(jal,$zero,$zero,-1,ic->code.u.funcop.funcname);
			mcs[index ++] = mipscode_rrr(move,$sp,$fp,$zero);
			int oldfp;
			
			if(fptop!= NULL){
				oldfp = fptop->fp;
			}
			
			
			mcs[index ++] = mipscode_rrc(lw,$ra,$sp,4 + argnum * 4);
			
			mcs[index ++] = mipscode_rrc(lw,$fp,$sp,argnum * 4);
			int i = 0;
			
			
			for(i = 0; i < argnum ; i ++){
				if(i < 4){
					//printf("将参数load 出来～～～～～～～～～～～～～～～～～～～～～\n");
					mcs[index ++] = mipscode_rrc(lw,$a0 + i,$sp, i * 4);//还没考虑参数的顺序！！！！！
				}
			}
			
			r1 = choosereg(ic->code.u.funcop.op,&(mcs[index ++]),1);
			mcs[index ++] = mipscode_rrr(move,r1,$v0,$zero);
			mcs[index ++] = storeop(ic->code.u.funcop.op,r1);
			//mcs[index ++] = mipscode_rrc(addi,$sp,$sp,oldfp - (sp );
			freereg();
			
			return connectmcs(mcs,index);
		case READ:
			mcs[0] = mipscode_rrc(addi,$sp,$sp,-4);
			mcs[1] = mipscode_rrc(sw,$ra,$sp,0);
			mcs[2] = mipscode_jump(jal,$zero,$zero,-1,"read");
			mcs[3] = mipscode_rrc(lw,$ra,$sp,0);
			mcs[4] = mipscode_rrc(addi,$sp,$sp,4);
			r1 = choosereg(ic->code.u.funcop.op,&(mcs[5]),1);
			mcs[6] = mipscode_rrr(move,r1,$v0,$zero);
			mcs[7] = storeop(ic->code.u.funcop.op,r1);
			freereg();
			return connectmcs(mcs,8);
			
		case WRITE:
			r1 = choosereg(ic->code.u.funcop.op,&(mcs[0]),0); 
			mcs[1] = mipscode_rrr(move,$a0,r1,$zero);
			mcs[2] = mipscode_rrc(addi,$sp,$sp,-4);
			mcs[3] = mipscode_rrc(sw,$ra,$sp,0);
			mcs[4] = mipscode_jump(jal,$zero,$zero,-1,"write");
			mcs[5] = mipscode_rrc(lw,$ra,$sp,0);
			mcs[6] = mipscode_rrc(addi,$sp,$sp,4);
			//这里不确定是否应将write的变量写入内存
			freereg();
			return connectmcs(mcs,7);
			break;
		case ARGS:
			
			index = 0;
			for(p = ic; p->code.kind != CALL; p = p->next);
			bargs = argnumber(p->code.u.funcop.funcname);
			
			if(beiargsnum == 0){
				index = 0;
				
				mcs[index ++] = mipscode_rrc(addi,$sp,$sp,-8);
				mcs[index ++] = mipscode_rrc(sw,$fp,$sp,0);
				argnum = argnumber(funcname);
				//mcs[3] = mipscode_rrc(addi,$sp,$sp,-4);
				mcs[index ++] = mipscode_rrc(sw,$ra,$sp,4);
			
				for(i = 0; i < argnum ; i ++){
					if(i < 4){
						//printf("将原先的参数存进去～～～～～～～～～～～～～～～～～～～～～\n");
						mcs[index ++] = mipscode_rrc(addi,$sp,$sp,-4);
						mcs[index ++] = mipscode_rrc(sw,$a0 + i,$sp,0);//还没考虑参数的顺序！！！！！
					}
				}
			
				
				
				/*mcs[3] = mipscode_rrc(addi,$sp,$sp,-4);
				mcs[4] = mipscode_rrc(sw,$a0,$sp,0);*/
				
			}
			beiargsnum ++;
			//将被调用函数的参数取出
			if(beiargsnum <= 4){
				r1 = choosereg(ic->code.u.funcop.op,&(mcs[index ++]),0); 
				//r2 = useargreg(p->code.u.funcop.funcname,ic->code.u.funcop.op);	
				mcs[index++] = mipscode_rrr(move,$a0 + beiargsnum - 1,r1,$zero);
			}
			//mcs[index++] = mipscode_rrr(move,r2,r1,$zero);
			
			/*else{
				mcs[index ++] =  mipscode_rrr(move,$fp,$sp,0);
			}*/
			if(beiargsnum > 4){
				r1 =choosereg(ic->code.u.funcop.op,&(mcs[index ++]),1);
				mcs[index++] = mipscode_rrc(addi,$sp,$sp,-4);
				mcs[index ++] = mipscode_rrc(sw,r1,$sp,$zero);
			}
			if( beiargsnum == bargs && bargs > 4){
				mcs[index ++] =  mipscode_rrc(addi,$fp,$sp,(beiargsnum - 4) * 4);
			}
			else if(beiargsnum == bargs && bargs < 4){
				mcs[index ++] =  mipscode_rrr(move,$fp,$sp,$zero);
			}
			freereg();
			return connectmcs(mcs,index);
		case FUNCTION:
			//pushfp(fp);
			
			strcpy(funcname,ic->code.u.funcop.funcname);
			insertfuncarg(funcname);
			paramargnum = argnumber(funcname);
			mcs[0] = mipscode_jump(func,$zero,$zero,-1,ic->code.u.funcop.funcname);
		/*	if(strcmp(ic->code.u.funcop.funcname,"main") == 0){*/
			if(paramargnum > 4){
				mcs[1] =  mipscode_rrc(addi,$fp,$sp,(paramargnum - 4) * 4);
			}
			else{
				mcs[1] =  mipscode_rrr(move,$fp,$sp,$zero);
			}
				//fp = sp;
				cos =  connectmcs(mcs,2);
				return cos;
			/*}
			else{
				return mcs[0];
			}*/
		case PARAM:
			if(paramargnum > 4){
				
				//useargreg(funcname,ic->code.u.funcop.op,$zero,-(4 * (paramargnum - 4)));
				insertvindex(ic->code.u.funcop.op,-(4 * (paramargnum - 4)));
				paramargnum --;
			}
			else{
				paramargnum --;
			//	Regarray[$a0 + paramargnum].op = ic->code.u.funcop.op; 
				useargreg(funcname,ic->code.u.funcop.op,$a0 + paramargnum );
			}
			break;
		case DEC:
			mcs[0] = mipscode_rrc(addi,$sp,$sp,-ic->code.u.structure.size);
			r1 = choosereg(NULL,NULL,4);
			mcs[1] = mipscode_rrr(move,r1,$sp,0);
			mcs[2] =  mipscode_rrc(addi,$sp,$sp,-4);
			mcs[3] = mipscode_rrc(sw,r1,$sp,0);	
				
			//将变量和其在栈中对应的位置关联起来。以相对于$fp的位置为基准
			int index = sp - fp;//相对于当前fp指针的偏移量
			Operand op1 = (Operand)malloc(sizeof(struct Operand_));
			op1->kind = VARIABLE_VALUE;
			op1->u.var_no = ic->code.u.structure.op->u.var_no;
			insertvindex(op1,index);
			//mcs[3] = mipscode_rrc(sw,r1,$sp,0);
			//ic->code.u.structure.op->kind = VARIABLE_VALUE;
			//freereg(r1);
			cos = connectmcs(mcs,4);
			return cos;
			
	}
	
	return NULL;
}


MipsCodes* mipscode_rrc(int kind,reg r1,reg r2,int num){
	MipsCode* mc = (MipsCode*)malloc(sizeof(struct MipsCode));
	mc->kind = kind;
	switch(kind){
		case li:
			mc->u.vc.left = r1;
			mc->u.vc.right = num;
			break;
		
		case addi:
			mc->u.vvc.result = r1;
			mc->u.vvc.op1 = r2;
			mc->u.vvc.op2 = num;
			if(r1 == $sp && r2 == $sp){
				sp = sp + num;
			}
			
			if(r1 == $fp && r2 == $sp){//将之前fp指针的值保存，
				
				pushfp(fp);
				fp = sp + num;
				
			}
			else if(r1 == $sp && r2 == $fp){//将之前fp指针的值保存，
				sp = fp + num;
			}
			break;
		case lw: case sw:
			mc->u.vvc.result = r1;
			mc->u.vvc.op1 = r2;
			mc->u.vvc.op2 = num;
			if(kind == lw && r1 == $fp){ //恢复fp指针的值
				fp = fptop->fp;
				popfp();
				
			}
			break;
		
			
	
	}
	MipsCodes* mcs = (MipsCodes*)malloc(sizeof(struct MipsCodes));
	mcs->code = mc;
	mcs->prev = NULL;
	mcs->next = NULL;
	return mcs;
}



MipsCodes* mipscode_rrr(int kind,reg r1,reg r2,reg r3){
	MipsCode* mc = (MipsCode*)malloc(sizeof(struct MipsCode));
	mc->kind = kind;
	switch(kind){
		case move: 
			mc->u.vv.left = r1;
			mc->u.vv.right = r2;
			if(r1 == $fp && r2 == $sp){//将之前fp指针的值保存，
				pushfp(fp);
				fp = sp;
			}
			else if(r1 == $sp && r2 == $fp){//将之前fp指针的值保存，
				sp = fp;
			}
			break;
		case add: case sub: case mul:
			mc->u.vvv.result = r1;
			mc->u.vvv.op1 = r2;
			mc->u.vvv.op2 = r3;
			break;
		case divi:
			mc->u.vvv.result = r1;
			mc->u.vvv.op1 = r2;
			break;
			
	
	}
	MipsCodes* mcs = (MipsCodes*)malloc(sizeof(struct MipsCodes));
	mcs->code = mc;
	mcs->prev = NULL;
	mcs->next = NULL;
	return mcs;
}


MipsCodes* storeop(Operand op,reg r1){
	if(findargreg(funcname,op) != $zero){
		return NULL;
	}
	MipsCodes* mcs[5];
	Vindex* vi = findop(op);
	
		mcs[0] = mipscode_rrc(sw,r1,$fp,vi->index);		
		return mcs[0];
	
}

MipsCodes* connectmcs(MipsCodes* ic[],int num){
	int i = 0;
	int j = 0;
	if(num > 1){
		for(i = 0; i < num; i ++){//将空的ic从数组中删除
			if(ic[i] == NULL){
				//printf("mips %d is NULL\n",i);
				if(i == num - 1){
					
					num --;
				}
				else{
					for(j = i; j < num - 1; j ++){
						ic[j] = ic[j + 1];
					}
					if(ic[0] == NULL){
						//printf("zhe li ne\n");
					}
					//移动后，i处变成了新的语句，需要重新检查
					i --;
					num --;
				}

			}
			
		}
		
		MipsCodes* p = NULL;
		MipsCodes* q = NULL;
		//printf("after num = :%d\n",num);
		if(num > 1){
			for(i = 0; i < num; i ++){
				if(ic[0] == NULL){
					//printf("why?????????????????????????\n");
				}
				if(i > 0){
					for(p = ic[i-1]; p->next!= NULL; p = p->next);//找到ic[i-1]的尾部
				}
				if(i < num){
					for(q = ic[i]; q->next!= NULL; q = q->next);//找到ic[i]的尾部
				}
				if(i == 0){
					q->next = ic[i + 1];
				}
				else if(i == num -1){
					ic[i]->prev = p;
				}
				else{	
					ic[i]->prev = p;
					q->next = ic[i + 1];
				}
			}
			//printf("out num > 1\n");
		}
		
	}
	return ic[0];
}

MipsCodes* mipscode_jump(int kind,reg r1,reg r2,int labe,char * funcname){
	MipsCode* mc = (MipsCode*)malloc(sizeof(struct MipsCode));
	mc->kind = kind;
	switch(kind){
		case label: case j:
			mc->u.c.label = labe;
			break;
		case jr:case mflo:
			mc->u.r.r = r1;
			break;
		case jal:case func:
			strcpy(mc->u.s.funcname,funcname); 
			break;
		case beq: case bne: case bgt: case blt: case bge: case ble:
			mc->u.rrc.result = r1;
			mc->u.rrc.op1 = r2;
			mc->u.rrc.op2 = labe;
			break; 
		
			
		
			
	}
	MipsCodes* mcs = (MipsCodes*)malloc(sizeof(struct MipsCodes));
	mcs->code = mc;
	mcs->prev = NULL;
	mcs->next = NULL;
	return mcs;
}
//li, lw,sw,move, addi, add, sub, mul, divi, mflo,label,j,jr,jal,beq,bne,bgt,blt,bge,ble
void display_mipscode(FILE *fp,MipsCodes* mc){
	int kind = mc->code->kind;
	switch(kind){
		case li:
			fprintf(fp,"	li %s %d\n",regname(mc->code->u.vc.left),mc->code->u.vc.right);
			break;
		case lw:
			fprintf(fp,"	lw %s %d(%s)\n",regname(mc->code->u.vvc.result),mc->code->u.vvc.op2,regname(mc->code->u.vvc.op1));
			break;
		case sw:
			fprintf(fp,"	sw %s %d(%s)\n",regname(mc->code->u.vvc.result),mc->code->u.vvc.op2,regname(mc->code->u.vvc.op1));
			break;
		case move:
			fprintf(fp,"	move %s %s\n",regname(mc->code->u.vv.left),regname(mc->code->u.vv.right));
			break;
		case addi:
			fprintf(fp,"	addi %s %s %d\n",regname(mc->code->u.vvc.result),regname(mc->code->u.vvc.op1),mc->code->u.vvc.op2);
			break;
		case add:
			fprintf(fp,"	add %s %s %s\n",regname(mc->code->u.vvv.result),regname(mc->code->u.vvv.op1),regname(mc->code->u.vvv.op2));
			break;
		case sub:
			fprintf(fp,"	sub %s %s %s\n",regname(mc->code->u.vvv.result),regname(mc->code->u.vvv.op1),regname(mc->code->u.vvv.op2));
			break;
		case mul:
			fprintf(fp,"	mul %s %s %s\n",regname(mc->code->u.vvv.result),regname(mc->code->u.vvv.op1),regname(mc->code->u.vvv.op2));
			break;
		case divi:
			fprintf(fp,"	div %s %s\n",regname(mc->code->u.vvv.result),regname(mc->code->u.vvv.op1));
			break;
		case mflo:
			fprintf(fp,"	mflo %s\n",regname(mc->code->u.r.r));
			break;
		case label:
			fprintf(fp,"label%d:\n",mc->code->u.c.label);
			break;
		case j:
			fprintf(fp,"	j label%d\n",mc->code->u.c.label);
			break;
		case jr:
			fprintf(fp,"	jr %s\n",regname(mc->code->u.r.r));
			break;
		case jal:
			fprintf(fp,"	jal %s\n",mc->code->u.s.funcname);
			break;
		case beq:
			fprintf(fp,"	beq %s %s label%d\n",regname(mc->code->u.vvc.result),regname(mc->code->u.vvc.op1),mc->code->u.vvc.op2);
			break;
		case bne: 	
			fprintf(fp,"	bne %s %s label%d\n",regname(mc->code->u.vvc.result),regname(mc->code->u.vvc.op1),mc->code->u.vvc.op2);
			break;
		case bgt: 	
			fprintf(fp,"	bgt %s %s label%d\n",regname(mc->code->u.vvc.result),regname(mc->code->u.vvc.op1),mc->code->u.vvc.op2);
			break;
		case blt: 
			fprintf(fp,"	blt %s %s label%d\n",regname(mc->code->u.vvc.result),regname(mc->code->u.vvc.op1),mc->code->u.vvc.op2);
			break;
		case bge: 
			fprintf(fp,"	bge %s %s label%d\n",regname(mc->code->u.vvc.result),regname(mc->code->u.vvc.op1),mc->code->u.vvc.op2);
			break;
		case ble:
			fprintf(fp,"	ble %s %s label%d\n",regname(mc->code->u.vvc.result),regname(mc->code->u.vvc.op1),mc->code->u.vvc.op2);
			break;
		case func:
			fprintf(fp,"%s:\n",mc->code->u.s.funcname);
			break;
			
			
	}
}
