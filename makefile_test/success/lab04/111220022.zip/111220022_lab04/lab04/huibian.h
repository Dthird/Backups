#include "liner_IR.h"

typedef struct MipsCode MipsCode;
typedef struct MipsCodes MipsCodes;
typedef struct Reg Reg;
typedef struct FPnode FPnode;
typedef struct Vindex Vindex;
typedef struct Funcargreg Funcargreg;


typedef enum reg {$zero, $at, $v0, $v1, $a0, $a1, $a2,$a3, $t0, $t1, $t2, $t3, $t4, $t5, $t6, $t7, $s0, $s1, $s2, $s3, $s4, $s5, $s6,$s7,$t8,$t9,$k0 ,$k1,$gp , $sp , $fp , $ra } reg;

struct Reg{
	Operand op;
};


struct MipsCode
{
	enum { li, lw,sw,move, addi, add, sub, mul, divi, mflo,label,j,jr,jal,beq,bne,bgt,blt,bge,ble,func} kind;
	union {
		struct { reg left; int right;} vc;
		struct { reg left; reg right;} vv;
		struct { reg result; reg op1; int op2;} vvc;
		struct { reg result; reg op1; int op2;} rrc;
		struct { reg result; reg op1; reg op2;} vvv;
		struct { int label;} c;
		struct { char funcname[32];} s;
		struct { reg r;} r;
		
		 
	} u;
};

struct MipsCodes { 
	MipsCode* code; 
	struct MipsCodes *prev, *next;
};

struct FPnode{
	int fp;
	struct FPnode* prev;
	struct FPnode* next;
};

struct Vindex{
	Operand op;;
	int index;
	struct Vindex* prev;
	struct Vindex* next;
};


struct Funcargreg{
	char funcname[30];
	Reg argreg[4];
	struct Funcargreg* next;
};

MipsCodes* mipscode_rrc(int kind,reg r1,reg r2,int num);
MipsCodes* mipscode_rrr(int kind,reg r1,reg r2,reg r3);

MipsCodes* mipscode_jump(int kind,reg r1,reg r2,int label,char * funcname);


MipsCodes* storeop(Operand op,reg r1);

MipsCodes* connectmcs(MipsCodes* ic[],int num);
Vindex* findop(Operand op);
MipsCodes* create_mipscode(InterCodes* ic);


void initreg();
void displaymips(MipsCodes* head,FILE *fp);
void display_mipscode(FILE *fp,MipsCodes* mc);
Vindex* insertvindex(Operand op,int index);
