//与表达式相关的一些结构的翻译模式
#include "liner_IR.h"

#include<stdio.h>
#include<string.h>
#include <unistd.h>
#include <stdlib.h>


InterCodes* head = NULL;
InterCodes* tail = NULL;
boolean in_ARGS = false;
boolean foraddress = false;
boolean firstarg = true;;
void PreOrder_ir(Node *p,int h){
	
	if(p != NULL){
		h ++;
		
		
		Node *f = p;	
		for(p = p->firstChild; p != NULL; p = p->nextSibing){
			//printf("firstchild:%s\n",p->firstChild->name);
			
			PreOrder_ir(p,h);
		}
		if(strcmp(f->name,"ExtDefList") == 0){	
			head = translate_ExtDefList(f);
		}
		
	}
	else{
		h = 0;
		printf("root = NULL\n");
	}
}





InterCodes* head;
InterCodes* tail;
int var_no = 0;
int temp_no = 0;
int label_no = 0;
InterCodes *translate_Exp(Node *exp, Operand place,boolean foraddress) {
	Node* tnode[4];
	Operand op[4];
	int childtype = expchild(exp,tnode);
	if(childtype == 17){//INT
		op[0] = place;
		op[1] = create_op(CONSTANT,tnode[0]);
		
		InterCodes* ic = create_ir(ASSIGN,op);

		return ic;
	}
	else if(childtype == 2 || childtype == 3 || childtype == 4 || childtype == 11){
		/*label1 = new_label()
		label2 = new_label()
		code0 = [place := #0]
		code1 = translate_Cond(Exp, label1, label2, sym_table)
		code2 = [LABEL label1] + [place := #1]
		return code0 + code1 + code2 + [LABEL label2]
		*/
		InterCodes* ic[5];
		int label1 = create_label();
		int label2 = create_label();
		op[0] = place;
		op[1] = create_op_constant(CONSTANT,0);
		ic[0] = create_ir(ASSIGN,op);
		ic[1] = translate_Cond(exp, label1, label2);
		ic[2] = create_ir_conf(LABEL,NULL,label1,NULL);
		op[1] = create_op_constant(CONSTANT,1);
		ic[3] = create_ir(ASSIGN,op);
		ic[4] = create_ir_conf(LABEL,NULL,label2,NULL);
		connectic(ic,5);
		return ic[0];

	}
	else if(childtype == 16){//ID
		
		/*FieldList var = (FieldList)malloc(sizeof(struct FieldList_));
	
		if(tnode[0]->val->kind != structure ){
			op[1] = create_op(VARIABLE,tnode[0]);
		}
		else if(tnode[0]->val->kind == structure && var->in == inargs){
			printf("不会吧～～～～～～～～～～～～～～～～～～～～～～～～\n");
			op[1] = create_op(VARIABLE_VALUE,tnode[0]);
		}*/
		/*if(in_ARGS == true && tnode[0]->val->kind == structure){
			//printf("((((((((((((((((((((((((((((((((((((((((((tnode[0]->name:%s\n",tnode[0]->name);
			op[1] = create_op(VARIABLE_VALUE,tnode[0]);
			
		}*/
		if(tnode[0]->val->kind == structure){
			//printf("((((((((((((((((((((((((((((((((((((((((((tnode[0]->name:%s\n",tnode[0]->name);
			Operand temp1 = (Operand)malloc(sizeof(struct Operand_));
			var_copy(place,temp1);
			//temp1->u.var_no = place->u.var_no;
			//temp1->kind = place->kind;
			op[0] = temp1;
			op[1] = create_op(VARIABLE_VALUE,tnode[0]);
			
		}
		else{
			//printf("((((((((((((((((((((((((((((((((((((((((((tnode[0]->name:%s~~kind:%d\n",tnode[0]->data.c,tnode[0]->val->kind);			
			op[0] = place;
			op[1] = create_op(VARIABLE,tnode[0]);
		}
		InterCodes* ic = create_ir(ASSIGN,op);
		
		return ic;

	}
	else if(childtype == 1){//{"Exp","ASSIGNOP","Exp"};note!!!!!:当在ASSIGNOP语句中，不能进入到EXP->ID的判断当中去！！否则会引起顺序错误！！！！！！！！！！！！！！！！！！！！！！！！！！！！！！
		/*
		t1 = new_temp()
		variable = lookup(sym_table, Exp1.ID)
		code1 = translate_Exp(Exp2, sym_table, t1)
		code2 = [variable.name := t1] +6 [place := variable.name]
		return code1 + code2
		*/

		Operand temp1 = create_op(TEMP_VARIABLE,NULL);
		InterCodes* ic[3];
		Operand v1 = NULL;
		int index = 0;
		if(tnode[0]->firstChild != NULL && strcmp(tnode[0]->firstChild->name,"ID") == 0 && tnode[0]->firstChild->nextSibing == NULL){
			//printf("tnode[0]->firstChild->data.c:%s\n",tnode[0]->firstChild->data.c);
			
			v1 =  create_op(VARIABLE,tnode[0]->firstChild);
			Operand direct = directexp(tnode[2]);
			Node * tn2[4];
			if( direct == NULL){
				int child2 = expchild(tnode[2],tn2);
				if(child2 == 5 || child2 == 6 || child2 == 7 || child2 == 8){
					ic[index ++ ] = translate_Exp(tnode[2], v1,false);
				}
				else{
					ic[index ++] = translate_Exp(tnode[2], temp1,false);
					op[0] = v1;
					op[1] = temp1;
					ic[index ++] = create_ir(ASSIGN,op);
				}
			}
			else{
				temp1 = direct;
				
				op[0] = v1;
				op[1] = temp1;
				ic[index ++] = create_ir(ASSIGN,op);
			}
		
			op[0] = place;
			op[1] = temp1;
			if(place == NULL){//当参数为空时，无需为其赋值
				connectic(ic,index);
			}
			else{
				/*ic[index ++] = create_ir(ASSIGN,op);	
				connectic(ic,index);*/
				place = v1;
				connectic(ic,index);
			}
		}
		else{
			//printf("暂不考虑这种情况\n");
			index = 0;
			ic[index ++] = translate_Exp(tnode[0], temp1,false);
			Operand temp2 = create_op(TEMP_VARIABLE,NULL);
			Operand direct = directexp(tnode[2]);
			if(direct == NULL){
				ic[index ++] = translate_Exp(tnode[2], temp2,false);
			}
			else{
				temp2 = direct;
			}
			op[0] = temp1;
			op[1] = temp2;
			ic[index ++] = create_ir(ASSIGN,op);
			
			op[0] = place;
			op[1] = temp1;

			if(place == NULL){//当参数为空时，无需为其赋值
				connectic(ic,index);
			}
			else{
				/*ic[index ++] = create_ir(ASSIGN,op);	*/
				place = temp1;
				connectic(ic,index);
			}
		}
		return ic[0];
		
	}
	else if(childtype == 5 || childtype == 6 || childtype == 7 || childtype == 8){//{"Exp","PLUS","Exp"};
		/*t1 = new_temp()
		t2 = new_temp()
		code1 = translate_Exp(Exp1, sym_table, t1)
		code2 = translate_Exp(Exp2, sym_table, t2)
		code3 = [place := t1 + t2]
		return code1 + code2 + code3*/
		//printf("000000000000000000000000000000000expchildtype:%d\n",childtype);
		InterCodes* ic[3];
		Operand temp1 =NULL;
		Operand temp2 =NULL;
		Operand direct1 = directexp(tnode[0]);
		Operand direct2 = directexp(tnode[2]);
		int index = 0;
		if(direct1 == NULL){
			temp1 = create_op(TEMP_VARIABLE,NULL);
			ic[index ++] = translate_Exp(tnode[0], temp1,false);
		}
		else{
			temp1 = direct1;
		}
		
		if(direct2 == NULL){
			temp2 = create_op(TEMP_VARIABLE,NULL);
			ic[index ++] = translate_Exp(tnode[2], temp2,false);
		}
		else{
			temp2 = direct2;
		}
		op[0] = temp1;
		op[1] = temp2;
		op[2] = place;
		if(childtype == 5){
			ic[index ++] = create_ir(ADD,op);
			
		}
		else if(childtype == 6){
			
			ic[index ++] = create_ir(SUB,op);
			
		}
		else if(childtype == 7){
			
			ic[index ++] = create_ir(MUL,op);
		}
		else{
			ic[index ++] = create_ir(DIV,op);
		}
		connectic(ic,index);
		return ic[0];
	
	}
	else if(childtype == 9){//LP Exp RP
		Operand direct = directexp(tnode[1]);
		if(direct == NULL || place->kind != TEMP_VARIABLE){
			return translate_Exp(tnode[1],place,false);
		}
		else{
			place = direct;
		}
		
	}
	else if(childtype == 10){//{"MINUS","Exp"};
		//t1 = new_temp()
		//code1 = translate_Exp(Exp1, sym_table, t1)
		//code2 = [place := #0 - t1]
		//return code1 + code2
		InterCodes* ic[2];
		Operand temp1 = create_op(TEMP_VARIABLE,NULL);
		Operand direct = directexp(tnode[1]);
		if(direct == NULL){
			ic[0] = translate_Exp(tnode[1], temp1,false);
			Operand con1 = create_op_constant(CONSTANT,0);
			op[0] = con1;
			op[1] = temp1;
			op[2] = place;
			ic[1] = create_ir(SUB,op);
			connectic(ic,2);
			return ic[0];
		}
		else{
			Operand con1 = create_op_constant(CONSTANT,0);
			op[0] = con1;
			op[1] = direct;
			op[2] = place;
			return create_ir(SUB,op);
		}
	}
	else if(childtype == 13){//{"ID","LP","RP"};
		/*function = lookup(sym_table, ID)
		if (function.name == “read”) return [READ place]
		return [place := CALL function.name]
		*/
		InterCodes* ic[1];
		func_node* fn = (func_node *)getfunc(tnode[0]->data.c);
		
		if(strcmp(fn->name,"read") == 0){
			op[0] = place;
			ic[0] = create_ir_func(READ,op[0],NULL);
			
			
		}
		else{
			op[0] = place;
			ic[0] = create_ir_func(CALL,op[0],fn->name);
		}
		connectic(ic,1);
		
		return ic[0];
		
	}
	else if(childtype == 12){//ID LP Args RP 
		/*function = lookup(sym_table, ID)
		arg_list = NULL
		code1 = translate_Args(Args, sym_table, arg_list)
		if (function.name == “write”) return code1 + [WRITE arg_list[1]]
		   for i = 1 to length(arg_list) code2 = code2 + [ARG arg_list[i]]
		  return code1 + code2 + [place := CALL function.name]
		*/
		InterCodes* ic[MAXARGS + 2];
		func_node* fn = (func_node *)getfunc(tnode[0]->data.c);
		Args* arg_list = NULL;
		int index = 0;
		InterCodes * ica = translate_Args(tnode[2], &arg_list);
		if(ica!= NULL){
			ic[index ++] = ica;
		}
		
		if(strcmp(fn->name,"write") == 0){
			if(arg_list!= NULL){
				op[0] = arg_list->op;
			}
			
			
			ic[index ++] = create_ir_func(WRITE,op[0],NULL);
			connectic(ic,index);
			return ic[0];
		}
		else{
			Args *p = arg_list;
			for(p = arg_list; p != NULL; p = p->next){
				//Operand oparg = p->op;
				
				ic[index ++] = create_ir_func(ARGS,p->op,NULL);
			}
			ic[index] = create_ir_func(CALL,place,fn->name);
			connectic(ic,index + 1);
			
			return ic[0];
		}
		
	}
	else if(childtype == 14){//Exp LB Exp RB
		Node *tn1[4];
		Node *tn2[4];
		int index = 0;
		if(expchild(tnode[0],tn1) == 16 ){//只考虑一维数组
			InterCodes* ic[3];
			Operand temp1 = create_op(TEMP_VARIABLE,NULL);
			Operand v1 = NULL;
			if(expchild(tnode[2],tn2) == 16){
				v1 = create_op(VARIABLE,tnode[2]->firstChild);
			}
			else if(expchild(tnode[2],tn2) == 17){
				v1 = create_op_constant(CONSTANT,tn2[0]->data.i);
			}
			else if(expchild(tnode[2],tn2) == 14){
				printf("不是多维数组组\n");
			}
			else{
				v1 = create_op(TEMP_VARIABLE,NULL);
				
				ic[index ++] = translate_Exp(tnode[2],v1,true);
			}
			int size = sizeoftype(tnode[0]->val);
			Operand c1 = create_op_constant(CONSTANT,size);
			op[0] = v1;
			op[1] = c1;
			op[2] = temp1;
			ic[index ++] = create_ir(MUL,op);
			Operand temp2 = (Operand)malloc(sizeof(struct Operand_));
			var_copy(place,temp2);
			Operand v2 = create_op(VARIABLE,tnode[0]->firstChild);
			Operand v3 = (Operand)malloc(sizeof(struct Operand_));
			v3->kind = VARIABLE_VALUE;
			v3->u.var_no = v2->u.var_no;
			op[0] = v3;
			op[1] = temp1;
			op[2] = temp2;
			ic[index ++] = create_ir(ADD,op);
			connectic(ic,index);
			return ic[0];
		}
		else if(expchild(tnode[0],tn1) == 15 && (expchild(tnode[2],tn2) == 16 || expchild(tnode[2],tn2) == 17 )){//结构体中的一维数组
			Operand temp1 = create_op(TEMP_VARIABLE,NULL);
			Operand temp2 = create_op(TEMP_VARIABLE,NULL);
			InterCodes* ic[3];	
			int index = 0;
			foraddress = true;
			ic[index ++] = translate_Exp(tnode[0],temp1,true);
			temp1->kind = TEMP_VARIABLE;
			Operand v1 = NULL;
			
			if(expchild(tnode[2],tn2) == 16){
				v1 = create_op(VARIABLE,tnode[2]->firstChild);
			}
			else if(expchild(tnode[2],tn2) == 17){
				v1 = create_op_constant(CONSTANT,tn2[0]->data.i);
			}
			else if(expchild(tnode[2],tn2) == 14){
				printf("不是多维数组组\n");
			}
			else{
				
				v1 = create_op(TEMP_VARIABLE,NULL);
				ic[index ++] = translate_Exp(tnode[2],v1,true);
				
			}
			int size = sizeoftype(tnode[0]->inh);
			Operand c1 = create_op_constant(CONSTANT,size);
			op[0] = v1;
			op[1] = c1;
			op[2] = temp2;
			ic[index ++] = create_ir(MUL,op);
			Operand temp3 = (Operand)malloc(sizeof(struct Operand_));
			var_copy(place,temp3);
			
			op[0]= temp1;
			op[1]= temp2;
			op[2]= temp3;
			ic[index ++] = create_ir(ADD,op);
			connectic(ic,index);
			return ic[0];
		}
		
	}
	else if(childtype == 15){//Exp DOT ID
		Node *tn[4];
		InterCodes* ic[2];
		if(expchild(tnode[0],tn)== 16){
			FieldList var = (FieldList)getvar(tn[0]->data.c);
			if(lookup(tnode[2]->data.c) == 0){
				if(var->in == inargs){
					
					//printf("lllllllllllllllllllllllllllllllllllllll****:%s\n",tnode[2]->data.c);
					Operand v1 = create_op(ADDRESS_VARIABLE,tn[0]);
					op[0] = place;
					op[1] = v1;
					return create_ir(ASSIGN,op);
				}
				else{
					//printf("**&*&8&8&&&&&&&&&**************&&&&&&&&&&&&8********:%s\n",tnode[2]->data.c);
					Operand temp1 = NULL;
					if(place != NULL){
						
						temp1 =  (Operand)malloc(sizeof(struct Operand_)); 
						//memcpy(temp1,place,sizeof(temp1));
						temp1->u.var_no = place->u.var_no;
						place->kind = ADDRESS_TEMP_VARIABLE;
					}
					else{
						temp1 = create_op(TEMP_VARIABLE,NULL);
					}
					temp1->kind = TEMP_VARIABLE;
					Operand v1 = create_op(VARIABLE_VALUE,tn[0]);
					op[0] = temp1;
					op[1] = v1;
					return create_ir(ASSIGN,op);
				}
			}
			else{
				FieldList var = getvar(tnode[0]->firstChild->data.c);
				if(var->in == inargs){
					
					Operand v1 = create_op(VARIABLE,tn[0]);
					Operand temp2 = create_op_constant(CONSTANT,getvar(tnode[2]->data.c)->index);
					Operand result1 = create_op(TEMP_VARIABLE,NULL);
					op[0] = v1;
					op[1] = temp2;
					op[2] = result1;
					ic[0] = create_ir(ADD,op);
					Operand result2 = (Operand)malloc(sizeof(struct Operand_)); 
					result2->u.var_no = result1->u.var_no;
					if(foraddress == true){
						result2->kind = TEMP_VARIABLE;
					}
					else{
						result2->kind = ADDRESS_TEMP_VARIABLE;
					}
					foraddress = false;
					op[0] = place;
					op[1] = result2;
					ic[1] = create_ir(ASSIGN,op);
					connectic(ic,2);
					return ic[0];
				}
				else{
					place->kind = ADDRESS_TEMP_VARIABLE;
					Operand v1 = create_op(VARIABLE_VALUE,tn[0]);
					Operand temp2 = create_op_constant(CONSTANT,getvar(tnode[2]->data.c)->index);
					Operand result1 = (Operand)malloc(sizeof(struct Operand_)); 
					result1->kind = TEMP_VARIABLE;
					result1->u.var_no = place->u.var_no;
					place->kind = ADDRESS_TEMP_VARIABLE;
					op[0] = v1;
					op[1] = temp2;
					op[2] = result1;
					ic[0] = create_ir(ADD,op);
					/*Operand result2 = (Operand)malloc(sizeof(struct Operand_)); 
					//memcpy(result2,result1,sizeof(result1));	
					result2->u.var_no = result1->u.var_no;
					result2->kind = ADDRESS_TEMP_VARIABLE;
					place->kind = ADDRESS_TEMP_VARIABLE;
					Operand temp3 = (Operand)malloc(sizeof(struct Operand_)); 
					temp3->kind = TEMP_VARIABLE;
					
					op[0] = place;
					op[1] = result2;
					ic[1] = create_ir(ASSIGN,op);
					connectic(ic,2);*/
					return ic[0];
				}
			}
		}
		else if(expchild(tnode[0],tn)== 15 || expchild(tnode[0],tn)== 14){
			InterCodes* ic[2];
			Operand temp1 = create_op(TEMP_VARIABLE,NULL);
			foraddress = true;
			ic[0] = translate_Exp(tnode[0],temp1,true);
			/*FieldList var = (FieldList)getvar(tn[0]->data.c);
			
			if(var == NULL){
				printf("怎么可能:%s?\n",tn[0]->data.c);
			}*/
			if(lookup(tnode[2]->data.c) == 0){
				/*if(var->in == inargs){
					
					printf("还没考虑在参数中出现结构里的结构\n");
				}
				else{*/
					//printf("**&*&8&8&&&&&&&&&**************&&&&&&&&&&&&8********:%s\n",tnode[2]->data.c);
					/*Operand temp2 = (Operand)malloc(sizeof(struct Operand_));
					var_copy(place,temp2);
					temp2->kind =  ADDRESS_TEMP_VARIABLE;*/
					Operand temp3 = (Operand)malloc(sizeof(struct Operand_));
					var_copy(temp1,temp3);
					//printf("temp1->u.var_no:%d\n",temp1->u.var_no);
					//temp3->kind = TEMP_VARIABLE_VALUE;
					temp1->kind = TEMP_VARIABLE;
					Operand temp4 = (Operand)malloc(sizeof(struct Operand_));
					var_copy(place,temp4);
					op[0] = temp4;
					op[1] = temp3;
					if(foraddress == true){
						temp3->kind =  TEMP_VARIABLE;
					}
					else{
						temp3->kind =  ADDRESS_TEMP_VARIABLE;					
					}
					foraddress = false;
					ic[1] = create_ir(ASSIGN,op);
					connectic(ic,2);
					return ic[0];
				//}
			}
			else{
				/*if(var->in == inargs){
					
					printf("还没考虑在参数中出现结构里的结构\n");
				}
				else{*/
					//printf("**&*&8&8&&&&&&&&&**************&&&&&&&&&&&&8********:%s\n",tnode[2]->data.c);
					Operand temp2 = (Operand)malloc(sizeof(struct Operand_));
					var_copy(place,temp2);
					place->kind = ADDRESS_TEMP_VARIABLE;
					Operand temp3 = create_op_constant(CONSTANT,getvar(tnode[2]->data.c)->index);
					Operand temp4 = (Operand)malloc(sizeof(struct Operand_));
					var_copy(temp1,temp4);
					temp1->kind = TEMP_VARIABLE;
					temp4->kind = TEMP_VARIABLE_VALUE;
					if(foraddress == true){
						temp4->kind =  TEMP_VARIABLE;
					}
					else{
						temp3->kind =  ADDRESS_TEMP_VARIABLE;					
					}
					foraddress = false;
					op[0] = temp4;
					op[1] = temp3;
					op[2] = temp2;
					ic[1] = create_ir(ADD,op);
					connectic(ic,2);
					return ic[0];
				//}
			}
			
			
		}
	}
	return NULL;
	
}

InterCodes * translate_Args(Node *args, Args** arg_list){
	
	Node* tnode[3];
	
	int achild = argschild(args,tnode);
	if(achild == 1){//Exp
		/*t1 = new_temp()
		code1 = translate_Exp(Exp, sym_table, t1)
		arg_list = t1 + arg_list
		return code1
		*/
		InterCodes* ic;
		Operand temp1 = create_op(TEMP_VARIABLE,NULL);
		in_ARGS = true;
		//printf("mark @@@@@@@@@@@@@@@@:kind:%d\n",tnode[0]->firstChild->val->kind);
		Operand direct = directexp(tnode[0]);
		if(direct == NULL){
			ic = translate_Exp(tnode[0], temp1,false);
		}
		else{
			temp1 = direct;
			ic = NULL;
		}
		in_ARGS = false;
		Args* arg = (Args*)malloc(sizeof(Args));
		arg->op = temp1;
		insert_arg(arg_list,  arg);


		
		
		//printf("arg_list->op->kind:%d\n",(*arg_list)->op->kind);
		return ic;
		
	}
	else if(achild == 2){//Exp COMMA Args1 
		/*
		t1 = new_temp()
		code1 = translate_Exp(Exp, sym_table, t1)
		arg_list = t1 + arg_list
		code2 = translate_Args(Args1, sym_table, arg_list)
		return code1 + code2
		*/
		InterCodes* ic[2];
		Operand temp1 = create_op(TEMP_VARIABLE,NULL);
		in_ARGS = true;
		ic[0] = translate_Exp(tnode[0], temp1,false);
		in_ARGS = false;
		Args* arg = (Args*)malloc(sizeof(Args));
		arg->op = temp1;
		insert_arg(arg_list,arg);

		

		
		ic[1] = translate_Args(tnode[2], arg_list);
		
		connectic(ic,2);
		
		return ic[0];
	}
	
	return NULL;
}


InterCodes *translate_Cond(Node *exp,int label_true,int label_false) {
	Node* tnode[4];
	Operand op[4];
	int childtype = expchild(exp,tnode);
	if(childtype == 4){//Exp1 RELOP Exp2
		/*t1 = new_temp()
		t2 = new_temp()
		code1 = translate_Exp(Exp1, sym_table, t1)
		code2 = translate_Exp(Exp2, sym_table, t2)
		op = get_relop(RELOP);
		code3 = [IF t1 op t2 GOTO label_true]
		return code1 + code2 + code3 + [GOTO label_false]
		*/
		InterCodes* ic[4];
		Operand temp1 = create_op(TEMP_VARIABLE,NULL);
		Operand temp2 = create_op(TEMP_VARIABLE,NULL);
		
		Operand direct1 = directexp(tnode[0]);
		Operand direct2 = directexp(tnode[2]);
		int index = 0;
		if(direct1 == NULL){
			ic[index ++] = translate_Exp(tnode[0],temp1,false);
		}
		else{
			temp1 = direct1;
		}
		if(direct2 == NULL){
			ic[index ++] = translate_Exp(tnode[2],temp2,false);
		}
		else{
			temp2 = direct2;
		}
		char relop[10];
		op[0] = temp1;
		op[1] = temp2;
		strcpy(relop,get_relop(tnode[1]));
		ic[index ++] = create_ir_conf(IF,op,label_true,relop);
		ic[index ++] = create_ir_conf(GOTO,NULL,label_false,NULL);
		connectic(ic,index);
		return ic[0];
			
	}
	else if(childtype == 11){//NOT Exp1 
		//return translate_Cond(Exp1, label_false, label_true, sym_table)
		return translate_Cond(tnode[1],label_false,label_true);
	}
	else if(childtype == 2){//Exp1 AND Exp2 
		/*label1 = new_label()
		code1 = translate_Cond(Exp1, label1, label_false, sym_table)
		code2 = translate_Cond(Exp2, label_true, label_false, sym_table)
		return code1 + [LABEL label1] + code2
		*/
		int label1 = create_label();
		
		InterCodes* ic[3];
		ic[0] = translate_Cond(tnode[0], label1, label_false);
		ic[1] = create_ir_conf(LABEL,NULL,label1,NULL);
		ic[2] = translate_Cond(tnode[2], label_true, label_false);
		connectic(ic,3);
		return ic[0];
		
	}
	else if(childtype == 3){//Exp1 OR Exp2 
		/*label1 = new_label()
		code1 = translate_Cond(Exp1, label_true, label1, sym_table)
		code2 = translate_Cond(Exp2, label_true, label_false, sym_table)
		return code1 + [LABEL label1] + code2
		*/
		
	
		int label1 = create_label();
		
		InterCodes* ic[3];
		ic[0] = translate_Cond(tnode[0], label_true, label1);
		ic[1] = create_ir_conf(LABEL,NULL,label1,NULL);
		ic[2] = translate_Cond(tnode[2], label_true, label_false);
		connectic(ic,3);
		return ic[0];

	}
	else {//other
		/*t1 = new_temp()
		code1 = translate_Exp(Exp, sym_table, t1)
		code2 = [IF t1 != #0 GOTO label_true]
		return code1 + code2 + [GOTO label_false]
		*/
		Operand temp1 = create_op(TEMP_VARIABLE,NULL);
		InterCodes* ic[3];
		Operand direct1 = directexp(exp);
		int index = 0;
		if(direct1 == NULL){
			ic[index ++] = translate_Exp(exp,temp1,false);
		}
		else{
			temp1 = direct1;
		}
		Operand con1 = create_op_constant(CONSTANT,0);
		op[0] = temp1;
		op[1] = con1;
		char relop[10];
		strcpy(relop,"NE");
		ic[index ++] = create_ir_conf(IF,op,label_true,relop);
		ic[index ++] = create_ir_conf(GOTO,NULL,label_false,NULL);
		connectic(ic,index);
		return ic[0];
	}
}
InterCodes * translate_CompSt(Node *compSt){
	Node *p = compSt->firstChild->nextSibing;
	Node * q =compSt->firstChild->nextSibing->nextSibing;
	if(strcmp(p->name,"StmtList") == 0){
		return translate_StmtList(p);
	}
	else if(q != NULL && strcmp(q->name,"StmtList") == 0 && strcmp(p->name,"DefList") == 0){
		InterCodes* ic[2];
		ic[0] = translate_DefList(p);
		if(ic[0] != NULL){
			ic[1]= translate_StmtList(q);
			connectic(ic,2);
			return ic[0];
		}
		else{
			InterCodes *ic= translate_StmtList(q);
			return ic;
		}
	
	}
	return NULL;
}

InterCodes * translate_DefList(Node *deflist){
	if(strcmp(deflist->firstChild->name,"Def") == 0 && deflist->firstChild->nextSibing == NULL){
		return translate_Def(deflist->firstChild);
	}
	else if(strcmp(deflist->firstChild->name,"Def") == 0 && strcmp(deflist->firstChild->nextSibing->name,"DefList") == 0){//Def DefList
		
		InterCodes * icd = translate_Def(deflist->firstChild);
		if(icd != NULL){
			InterCodes* ic[2];
			ic[0] = icd;
			ic[1] = translate_DefList(deflist->firstChild->nextSibing);
			if(ic[1] == NULL){
				return ic[0];
			}
			else{
				connectic(ic,2);
				return ic[0];
			}
		}
		else{
			InterCodes * ic = translate_DefList(deflist->firstChild->nextSibing);
			
			return ic;
		}
	}
	return NULL;
}

InterCodes * translate_Def(Node *def){
	Node * p = def->firstChild;
	if(strcmp(p->name,"Specifier") == 0 && strcmp(p->nextSibing->name,"DecList") == 0){//Specifier DecList SEMI

		//printf("###########################################p->firstChild->name:%s\n",p->firstChild->name);
		//if(strcmp(p->firstChild->name,"StructSpecifier") == 0){
			return translate_DecList(p->nextSibing);
		//}
	}
	return NULL;

}
InterCodes * translate_DecList(Node *declist){
	Node* tnode[4];
	int childtype = declistchild(declist,tnode);	
	if(childtype == 1){//Dec
		return translate_Dec(tnode[0]);
	}
	else if(childtype == 2){//Dec COMMA DecList
		InterCodes* ic[2];
		InterCodes *ic1 = translate_Dec(tnode[0]);
		if(ic1 != NULL){
			ic[1] = translate_DecList(tnode[2]);
			if(ic[1] == NULL){
				return ic1;
			}
			else{
				ic[0] = ic1;
				connectic(ic,2);
				return ic[0];
			}
		}
		else{
			InterCodes *ic2 = translate_DecList(tnode[2]);
			
			return ic2;
		}
	}
	return NULL;

}

InterCodes * translate_Dec(Node *declist){
	Node* tnode[4];
	int childtype = decchild(declist,tnode);
	if(childtype == 1){//VarDec
		return translate_VarDec(tnode[0],0);
	}
	else if(childtype == 2){//VarDec ASSIGNOP Exp!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!还没考虑变量初始化
		if(strcmp(tnode[0]->firstChild->name,"ID") == 0){
			Operand v1 = create_op(VARIABLE,tnode[0]->firstChild);
			Operand temp1 = create_op(TEMP_VARIABLE,NULL);
			InterCodes* ic[2];
			Operand op[2];
			op[0] = v1;
			op[1] = temp1;
			Operand direct = directexp(tnode[2]);
			Node *tn3[4];
			int child2 = expchild(tnode[2],tn3);
			if(direct == NULL){

	
				if(child2 == 5 || child2 == 6 || child2 == 7 || child2 == 8){
					return translate_Exp(tnode[2], v1,false);
				}
				else{
					ic[0] = translate_Exp(tnode[2], temp1,false);
					op[0] = v1;
					op[1] = temp1;
					ic[1] = create_ir(ASSIGN,op);	
					connectic(ic,2);
					return ic[0];
				}
				
			}
			else{
				op[1] = direct;
				ic[0] = create_ir(ASSIGN,op);
				return ic[0];
			}

		}
	}
	return NULL;

}

InterCodes * translate_FunDec(Node *fundec){	
	Node* tnode[4];
	int childtype = funcdecchild(fundec,tnode);
	//printf("fundecchildtype:%d\n",childtype);
	if(childtype == 2){
		return create_ir_func(FUNCTION,NULL,tnode[0]->data.c);
	}
	else if(childtype == 1){//ID LP VarList RP
		InterCodes* ic[2];
		ic[0] = create_ir_func(FUNCTION,NULL,tnode[0]->data.c);
		ic[1] = translate_VarList(tnode[2]);
		connectic(ic,2);
		
		return ic[0];
	}
	
	return NULL;
}


InterCodes * translate_VarList(Node *varlist){
	Node* tnode[4];
	int childtype = varlistchild(varlist,tnode);
	if(childtype == 1){//ParamDec COMMA VarList
		InterCodes* ic[2];
		ic[0] = translate_ParamDec(tnode[0]);
		ic[1] = translate_VarList(tnode[2]);
		connectic(ic,2);
		return ic[0];
	}
	else if(childtype == 2){//ParamDec
		return translate_ParamDec(tnode[0]);
	}
	return NULL;
}

InterCodes * translate_ParamDec(Node *paramDec){
	if(strcmp(paramDec->firstChild->name,"Specifier") == 0 && strcmp(paramDec->firstChild->nextSibing->name,"VarDec") == 0){
		return translate_VarDec(paramDec->firstChild->nextSibing,1);
		
	}
	return NULL;
}

InterCodes * translate_VarDec(Node *vardec,int args){
	Node* tnode[4];
	
	int childtype = vardecchild(vardec,tnode);
	if(childtype == 1){//ID
		if(args == 1){
			Operand op = create_op(VARIABLE,tnode[0]);
			InterCodes* ic = create_ir_func(PARAM,op,NULL);
			return ic;
		}
		else if(getvar(tnode[0]->data.c)->type->kind == structure){
			Operand op = create_op(VARIABLE,tnode[0]);
			InterCodes* ic = create_ir_str(DEC,op,tnode[0]->val->u.structure->index);
			return ic;
		}
	}
	else if(childtype == 2){//{"VarDec","LB","INT","RB"};
		//只考虑一维数组
		if(tnode[0]->firstChild != NULL && strcmp(tnode[0]->firstChild->name,"ID") == 0){//一维数组
			Operand op = create_op(VARIABLE,tnode[0]->firstChild);
			//FieldList arrayid = (FieldList)malloc(sizeof(struct FieldList_));
			int size = sizeoftype(tnode[0]->inh) * tnode[2]->data.i;
			InterCodes* ic = create_ir_str(DEC,op,size);
			return ic;
		}
		else{
			printf("Can not translate the code: Contain multidimensional array and function parameters of array type!\n");
			exit(0);
		}
	}
	return NULL;
}


void insert_arg(Args** arg_list, Args* arg){
	//Args* p = *arg_list;
	/*if(p!= NULL){
		//for(p = *arg_list; p ->next != NULL; p = p->next);//找到尾
		p->next = arg;
			
	}
	else{
		
		*arg_list = arg;
		
		
	}
	arg->next = NULL;*/
	arg->next = *arg_list;
	*arg_list = arg;
}

InterCodes * translate_Stmt(Node *stmt) {
	Node* tnode[7];
	Operand op[4];
	
	int stmttype = stmtchild(stmt,tnode);
	if(stmttype == 1){//{"Exp","SEMI"};
		//return translate_Exp(Exp, sym_table, NULL)
		Operand temp1 = create_op(TEMP_VARIABLE,NULL);
		Node *tn[4];
		int child = expchild(tnode[0],tn);
		if(child != 16 && child != 17){
			InterCodes * eic = translate_Exp(tnode[0], temp1,false);

			DagNode* dhead = NULL;
			if(createdag(eic,&dhead) == true){
				InterCodes * dic  = dagtoic(&dhead);

				return dic;
			}
			else {
				return eic;
			}
		}
		else
			return translate_Exp(tnode[0], temp1,false);
	}
	else if(stmttype == 2){//{"CompSt"};
		//return translate_CompSt(CompSt, sym_table)
		return translate_CompSt(tnode[0]);

	}
	else if(stmttype == 3){//{"RETURN","Exp","SEMI"};
		/*t1 = new_temp()
		code1 = translate_Exp(Exp, sym_table, t1)
		code2 = [RETURN t1]
		return code1 + code2
		*/
		InterCodes* ic[2];
		Operand temp1 = create_op(TEMP_VARIABLE,NULL);
		op[0] = temp1;
		Operand direct = directexp(tnode[1]);
		if(direct == NULL){
			ic[0] = translate_Exp(tnode[1],temp1,false);
			ic[1] = create_ir(RETURN,op);
			connectic(ic,2);
		
			return ic[0];
		}
		else{
			op[0] = direct;
			return create_ir(RETURN,op);
		}

	}
	else if(stmttype == 4){//{"IF","LP","Exp","RP","Stmt"};
		/*label1 = new_label()
		label2 = new_label()
		code1 = translate_Cond(Exp, label1, label2, sym_table)
		code2 = translate_Stmt(Stmt1, sym_table)
		return code1 + [LABEL label1] + code2 + [LABEL label2]
		*/
		InterCodes* ic[4];
		int label1 = create_label();
		int label2 = create_label();
		ic[0] = translate_Cond(tnode[2],label1,label2);
		ic[1] = create_ir_conf(LABEL,NULL,label1,NULL);
		ic[2] = translate_Stmt(tnode[4]);
		ic[3] = create_ir_conf(LABEL,NULL,label2,NULL);
		connectic(ic,4);
		return ic[0];
	}
	else if(stmttype == 5){//{"IF","LP","Exp","RP","Stmt","ELSE","Stmt"};
		/*label1 = new_label()
		label2 = new_label()
		label3 = new_label()
		code1 = translate_Cond(Exp, label1, label2, sym_table)
		code2 = translate_Stmt(Stmt1, sym_table)
		code3 = translate_Stmt(Stmt2, sym_table)
		return code1 + [LABEL label1] + code2 + [GOTO label3] + [LABEL
		label2] + code3 + [LABEL label3]
		*/
		InterCodes* ic[7];
		int label1 = create_label();
		int label2 = create_label();
		int label3 = create_label();
		ic[0] = translate_Cond(tnode[2],label1, label2);
		ic[1] = create_ir_conf(LABEL,NULL,label1,NULL);
		ic[2] = translate_Stmt(tnode[4]);
		ic[3] = create_ir_conf(GOTO,NULL,label3,NULL);
		ic[4] = create_ir_conf(LABEL,NULL,label2,NULL);
		ic[5] = translate_Stmt(tnode[6]);
		ic[6] = create_ir_conf(LABEL,NULL,label3,NULL);
		connectic(ic,7);
		return ic[0];
	}
	else if(stmttype == 6){//{"WHILE","LP","Exp","RP","Stmt"};
		/*label1 = new_label()
		label2 = new_label()
		label3 = new_label()
		code1 = translate_Cond(Exp, label2, label3, sym_table)
		code2 = translate_Stmt(Stmt1, sym_table)
		return [LABEL label1] + code1 + [LABEL label2] + code2 + [GOTO
		label1] + [LABEL label3]
		*/
		InterCodes* ic[6];
		int label1 = create_label();
		int label2 = create_label();
		int label3 = create_label();
		ic[0] = create_ir_conf(LABEL,NULL,label1,NULL);
		ic[1] = translate_Cond(tnode[2], label2, label3);
		ic[2] = create_ir_conf(LABEL,NULL,label2,NULL);
		ic[3] = translate_Stmt(tnode[4]);
		ic[4] = create_ir_conf(GOTO,NULL,label1,NULL);
		ic[5] = create_ir_conf(LABEL,NULL,label3,NULL);
		connectic(ic,6);
		return ic[0];
	}
	return NULL;
}


InterCodes * translate_StmtList(Node *stmtlist){
	
	if(stmtlist->firstChild != NULL){
		if(stmtlist->firstChild->nextSibing != NULL){
			if(strcmp(stmtlist->firstChild->name,"Stmt") == 0 && strcmp(stmtlist->firstChild->nextSibing->name,"StmtList") == 0)   				{			
				
				InterCodes* ic[2];
				InterCodes * ts = translate_Stmt(stmtlist->firstChild);
				if(ts == NULL){
					ic[0] = translate_StmtList(stmtlist->firstChild->nextSibing);
					return ic[0];
				}
				else{
					ic[0] = ts;
					ic[1] = translate_StmtList(stmtlist->firstChild->nextSibing);
					connectic(ic,2);
					return ic[0];	
				}
			}
		}
		else if(strcmp(stmtlist->firstChild->name,"Stmt") == 0 ){
				InterCodes* ic[1];
				ic[0] = translate_Stmt(stmtlist->firstChild);
				
				
				return ic[0];	
		}
	}
	return NULL;
	
}


InterCodes * translate_ExtDef(Node *extdef){
	//Specifier FunDec CompSt
	Node *tnode[4];
	InterCodes* ic[2];
	
	int childtype = extdefchild(extdef,tnode);
	if(childtype == 3){
		ic[0] = translate_FunDec(tnode[1]);
		
		ic[1] = translate_CompSt(tnode[2]);
		connectic(ic,2);
		return ic[0];
	}
	return NULL;
}


InterCodes * translate_ExtDefList(Node *extdeflist){
	if(extdeflist->firstChild != NULL){
		//printf("strcmp(extdeflist->firstChild->name:%s\n",extdeflist->firstChild->name);
		if(extdeflist->firstChild->nextSibing != NULL){
			if(strcmp(extdeflist->firstChild->name,"ExtDef") == 0 && strcmp(extdeflist->firstChild->nextSibing->name,"ExtDefList") == 0)   			{			
				
				InterCodes* ic[2];
				ic[0] = translate_ExtDef(extdeflist->firstChild);
				if(ic[0] != NULL){
					ic[1] = translate_ExtDefList(extdeflist->firstChild->nextSibing);
					connectic(ic,2);
					return ic[0];	
				}
				else{
					ic[0] = translate_ExtDefList(extdeflist->firstChild->nextSibing);
					return ic[0];
				}
			}
		}
		else if(strcmp(extdeflist->firstChild->name,"ExtDef") == 0 ){
				InterCodes* ic[1];
				ic[0] = translate_ExtDef(extdeflist->firstChild);
				
				
				return ic[0];	
		}
	}
	return NULL;
}


int create_label(){
	label_no ++;
	return label_no;
}

int lookup(char *id){	
	FieldList variable = (FieldList)getvar(id);
	if(variable->index >= 0){
		return variable->index;
	}
	else{
		var_no ++;
		variable->index = var_no;
		return variable->index;
	}
}




char *get_relop(Node *node){
	return node->data.c;
}

InterCodes* create_ir(int kind,Operand op[]){
	InterCodes* ic = (InterCodes*)malloc(sizeof(InterCodes));
	ic->code.kind = kind;
	switch(kind){
		case ASSIGN:
			ic->code.u.assign.left = op[0];
			ic->code.u.assign.right = op[1];
			break;
		case ADD:case SUB:case MUL:case DIV:
			
			ic->code.u.binop.op1 = op[0];
			ic->code.u.binop.op2 = op[1];
			ic->code.u.binop.result = op[2];
			break;
		case RETURN:
			ic->code.u.oneop.op = op[0];
			break;
			
		
			
	}
	ic->prev = NULL;
	ic->next = NULL;
	return ic;
}

InterCodes* create_ir_conf(int kind,Operand op[],int label,char *relop){
	InterCodes* ic = (InterCodes*)malloc(sizeof(InterCodes));
	ic->code.kind = kind;
	switch(kind){
		case IF:
			ic->code.u.ific.op1 = op[0];
			ic->code.u.ific.op2 = op[1];
			ic->code.u.ific.label = label;
			strcpy(ic->code.u.ific.relop,relop);
			break;
		case GOTO:case LABEL:
			ic->code.u.mlabel.label = label;
			break;
			
	}
	ic->prev = NULL;
	ic->next = NULL;
	return ic;
}


InterCodes* create_ir_func(int kind,Operand op,char *name){
	InterCodes* ic = (InterCodes*)malloc(sizeof(InterCodes));
	ic->code.kind = kind;
	switch(kind){
		case READ:
			ic->code.u.funcop.op = op;
			strcpy(ic->code.u.funcop.funcname,"read");
			break;
		case CALL:
			ic->code.u.funcop.op = op;
			strcpy(ic->code.u.funcop.funcname,name);
			break;
		case WRITE:
			ic->code.u.funcop.op = op;
			strcpy(ic->code.u.funcop.funcname,"write");
			break;
		case ARGS: case PARAM:
			ic->code.u.funcop.op = op;
			memset(ic->code.u.funcop.funcname,0,strlen(ic->code.u.funcop.funcname));
			break;
		case FUNCTION:
			ic->code.u.funcop.op = NULL;
			strcpy(ic->code.u.funcop.funcname,name);
			break;
		
	}
	ic->prev = NULL;
	ic->next = NULL;
	return ic;
}


InterCodes* create_ir_str(int kind,Operand op,int size){
	InterCodes* ic = (InterCodes*)malloc(sizeof(InterCodes));
	ic->code.kind = kind;
	ic->code.u.structure.op = op;
	ic->code.u.structure.size = size;
	ic->prev = NULL;
	ic->next = NULL;
	return ic;
}

Operand create_op_constant(int kind,int value){
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = kind;
	op->u.value = value;
	return op;
}

Operand create_op(int kind,Node *node){
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = kind;
	switch(kind){
		case VARIABLE:case ADDRESS_VARIABLE:case VARIABLE_VALUE:
			op->u.var_no = lookup(node->data.c);
			break;
		case CONSTANT:
			if(node != NULL){
				if(strcmp(node->name,"INT") == 0){
					op->u.value = get_value_int(node);
				}
				else{	
					op->u.value = get_value_float(node);
				}
			}
			else{
				op->u.value = 0;
			}
			break;
		case TEMP_VARIABLE:case ADDRESS_TEMP_VARIABLE:case TEMP_VARIABLE_VALUE:
			temp_no ++;
			op->u.temp_no = temp_no;
			break;
		
			
	}
	return op;
}




int get_value_int(Node *intnode){
	return intnode->data.i;
}

float get_value_float(Node *floatnode){
	return floatnode->data.f;
}

void IRinit(){//初始化中间代码表
	tail = NULL;
	head = NULL;
	//insert read()
	func_node * fn1 = (func_node *)malloc(sizeof(func_node));
	strcpy(fn1->name,"read");
	fn1->formalargs = NULL;
	Type t1 = (Type)malloc(sizeof(struct Type_));
	t1->kind = basic;
	t1->u.basic = kint;
	fn1->returnargs = t1;
	fn1->ifdefined = 1;
	insertfunc(fn1);
	
	//insert write()
	func_node * fn2 = (func_node *)malloc(sizeof(func_node));
	strcpy(fn2->name,"write");
	FieldList arg = (FieldList)malloc(sizeof(struct FieldList_));
	arg->type = t1;
	fn2->formalargs = arg;
	fn2->returnargs = t1;
	fn2->ifdefined = 1;
	insertfunc(fn2);
	
}

void insertIR(InterCodes* ic){//将中间代码插入中间代码表
	if(tail == NULL){//链表为空
		head = tail = ic;
		ic->prev = NULL;
		ic->next = NULL;
	}
	else{
		ic->next = NULL;
		ic->prev = tail;
		tail->next = ic;
	}

}

void connectic(InterCodes* ic[],int num){
	int i = 0;
	int j = 0;
	//printf("before num:%d\n",num);
	if(num > 1){
		for(i = 0; i < num; i ++){//将空的ic从数组中删除
			if(ic[i] == NULL){
			
				if(i == num - 1){
					
					num --;
				}
				else{
					for(j = i; j < num - 1; j ++){
						ic[j] = ic[j + 1];
					}
					ic[j - 1]->next = NULL;
					ic[j] = NULL;
					num --;
				}
			}
		}
		//printf("later num:%d\n",num);
		InterCodes* p = NULL;
		InterCodes* q = NULL;
		if(num == 1){
			ic[0]->prev = NULL;
			ic[0]->next = NULL;
		}
		else if(num > 1){
		
		
			for(i = 0; i < num; i ++){
				if(i > 0){
					for(p = ic[i-1]; p->next!= NULL; p = p->next);//找到ic[i-1]的尾部
				}
				if(i < num){
					for(q = ic[i]; q->next!= NULL; q = q->next);//找到ic[i]的尾部
				}
				if(i == 0){
					q->next = ic[i + 1];
				}
				else if(i == num -1){
					ic[i]->prev = p;
				}
				else{	
					ic[i]->prev = p;
					q->next = ic[i + 1];
				}
			}
		}
	}
}

void var_copy(Operand place,Operand temp){
	if(place->kind == TEMP_VARIABLE){
		temp->kind = TEMP_VARIABLE;
		temp->u.var_no = place->u.var_no;
		place->kind = ADDRESS_TEMP_VARIABLE;
	}
	else if(place->kind == VARIABLE){
		temp->kind = VARIABLE;
		temp->u.var_no = place->u.var_no;
		place->kind = ADDRESS_VARIABLE;
	}
	else{
		temp->kind = place->kind;
		temp->u.var_no = place->u.var_no;
	}
}

//优化ID和INT

Operand directexp(Node *exp){
	Node *tnode[4];
	int childtype = expchild(exp,tnode);
	if(childtype == 16){

		if(tnode[0]->val->kind == structure){
			return  create_op(VARIABLE_VALUE,tnode[0]);
			
		}
		else{
			return  create_op(VARIABLE,tnode[0]);
		}
	}
	else if(childtype == 17){
		return  create_op(CONSTANT,tnode[0]);
	}
	return NULL;
}

//优化LABEL

void optimizelabel(InterCodes* head){
	int label1 = -1;
	int label2 = -1;
	int label3 = -1;
	InterCodes* ic1 = NULL;
	InterCodes* ic2 = NULL;
	InterCodes* ic3 = NULL;
	InterCodes* p = head;
	
	for(p = head; p!= NULL; p =p->next){
		ic1 = p;
		if(ic1!= NULL && ic1->code.kind == IF){
			label1 = ic1->code.u.ific.label;
			ic2 = ic1->next;
			if(ic2 != NULL && ic2->code.kind == GOTO){
				label2 = ic2->code.u.mlabel.label;
				ic3 = ic2->next;
				if(ic3 != NULL && ic3->code.kind == LABEL){
					
					label3 = ic3->code.u.mlabel.label;
					if(label1 == label3){
						strcpy(ic1->code.u.ific.relop,dealrelop(ic1->code.u.ific.relop));
						ic1->code.u.ific.label = label2;
						ic1->next = ic3;
						ic3->prev = ic1;
						p = p->next->next;
					}
				}
			}
		}
	}
}

//DAG图优化法

DagNode *findchild(DagNode** dhead,Operand fop){	
	DagNode* p =  *dhead;
	DagNode* tail = NULL;
	if(p!= NULL){
		for(p = *dhead; p ->next!= NULL; p = p->next);
		tail = p;
	}
	if(tail == NULL){
		return NULL;
	}
	else{
		for(p = tail; p != NULL; p = p->prev){//对每一条语句进行查找
			dOperand* dop = p->dop;
			dOperand* addop = (dOperand*)malloc(sizeof(dOperand));
			memset(addop,0,sizeof(dOperand));
			addop->op = fop;
			addop->next =NULL;
			for(;dop!= NULL; dop = dop->next){//对每条语句中的每一个变量进行查找
				if(ifassign(dop->op,fop) == true){
					return p;
				}
				if(p->left != NULL && p->left->left == NULL){//叶子节点
					dOperand* lop = p->left->dop;
					for(;lop!= NULL; lop = lop->next){
						if(ifassign(lop->op,fop) == true){
							return p->left;
						}
					}
				}
				if(p->right != NULL && p->right->left == NULL){//叶子节点
					dOperand* rop = p->right->dop;
					for(;rop!= NULL; rop = rop->next){
						if(ifassign(rop->op,fop) == true){
							return p->right;
						}
					}
				}
			}
		}
	}
	return NULL;
}


DagNode *findfather(DagNode** dhead,Operand fop,DagNode* left,DagNode* right,int ickind){
	DagNode* p =  *dhead;
	DagNode* tail = NULL;
	if(p!= NULL){
		for(p = *dhead; p ->next!= NULL; p = p->next);
		tail = p;
	}
	if(tail == NULL){
		return NULL;
	}
	else{
		for(p = tail; p != NULL; p = p->prev){//对每一条语句进行查找
			if(p->ickind == ickind && p->dop->op->kind == fop->kind){
				int count = 0;
				if(p->left != NULL){//对孩子节点进行查找
					dOperand* lop = p->left->dop;
					for(;lop!= NULL; lop = lop->next){
						if(ifassign(lop->op,left->dop->op) == true){
							count ++;
						}
					}
				}
				if(p->right != NULL){//对孩子节点进行查找
					dOperand* rop = p->right->dop;
					for(;rop!= NULL; rop = rop->next){
						if(ifassign(rop->op,right->dop->op) == true){
							count ++;
						}
					}
				}
				if(count == 2){
					dOperand* addop = (dOperand*)malloc(sizeof(dOperand));
					memset(addop,0,sizeof(dOperand));
					addop->op = fop;
					addop->next =NULL;
					p->dop->next = addop;
					return p;
				}
			}
		}
	}
	return NULL;
}


DagNode* createchild(Operand op,DagNode** dhead,int* id){
	DagNode* finddn = findchild(dhead,op);
	if(finddn == NULL){
		DagNode* dn = (DagNode*)malloc(sizeof(DagNode));
		dOperand* d = (dOperand*)malloc(sizeof(dOperand));
		memset(d,0,sizeof(dOperand));
		dn->id = -1;
		dn->dop = d;
		dn->dop->op = op;
		dn->dop->next = NULL;
		dn->left = NULL;
		dn->right = NULL;
		dn->prev = NULL;
		dn->next = NULL;

		return dn;
	}
	else{
		return finddn;
	}
}



DagNode* createfather(int* id,int ickind,Operand fop,DagNode* left,DagNode* right,DagNode** prev,DagNode* next,DagNode** dhead){
	
	DagNode* p =  *dhead;
	DagNode* tail = NULL;
	if(p!= NULL){
		for(p = *dhead; p ->next!= NULL; p = p->next);
		tail = p;
	}
	DagNode* finddn = findfather(dhead, fop,left,right,ickind);
	if(finddn == NULL){
		DagNode* dn = (DagNode*)malloc(sizeof(DagNode));
		dn->ickind = ickind;
		(*id) ++;
		dn->id = *id;
		dOperand* d = (dOperand*)malloc(sizeof(dOperand));
		memset(d,0,sizeof(dOperand));	
		dn->dop = d;
		dn->dop->op = fop;
		dn->dop->next = NULL;
		dn->left = left;
		dn->right = right;
		dn->prev = *prev;
		dn->next = NULL;;
		if(*id == 1){
			*dhead = dn;
		}
		if(tail!= NULL){
			tail->next = dn;
			dn->prev = tail;
		}
		else{
			next = dn;
		}
		return dn;
	}
	else{
		return finddn;
	}
}

boolean inserticdagnode(InterCodes* ic,DagNode** dhead,int* id){
	int kind = ic->code.kind;
	//printf("~~~~~~~~~~~~~~\n");
	DagNode* node1 = NULL;
	DagNode* node2 = NULL;
	DagNode* result = NULL;
	switch(kind){
		case ASSIGN:
			node1 = createchild(ic->code.u.assign.right,dhead,id);
			result = createfather(id,kind,ic->code.u.assign.left,node1,NULL,dhead,NULL,dhead);
			return true;
		case ADD: case SUB: case MUL: case DIV:
			node1 =  createchild(ic->code.u.binop.op1,dhead,id);
			node2 =  createchild(ic->code.u.binop.op2,dhead,id);
			result = createfather(id,kind,ic->code.u.binop.result,node1,node2,dhead,NULL,dhead);
			return true;
		default:
			return false;
			
	}
	
	//printf("~~~~~~~~~~~~~~\n");
}

boolean createdag(InterCodes* head,DagNode** dhead){
	InterCodes* p = head;
	
	int id = 0;
	int *pid = &id;
	for(;p!= NULL; p = p->next){
		if(inserticdagnode(p,dhead,pid) == false)
			return false;
	}
	return true;
}

InterCodes* dagtoic(DagNode** dhead){
	DagNode* p = *dhead;
	InterCodes* ic = NULL;
	InterCodes* head;
	int kind ;
	for(;p!= NULL;p = p->next){
		kind = p->ickind;
		InterCodes* ic1  =NULL;
		if(p->left!= NULL){
			if(kind == ASSIGN){
				Operand op[0];
				op[0] = p->dop->op;
				op[1] = p->left->dop->op;
				ic1 = create_ir(kind,op);
				if(ic == NULL){
					ic = ic1;
					head = ic1;
				}
				else{
					ic->next = ic1;
					ic1->prev = ic;
					ic = ic1;
				}
			}
			else{
				Operand op[3];
				op[0] = p->left->dop->op;
				op[1] = p->right->dop->op;
				op[2] = p->dop->op;
				ic1 = create_ir(kind,op);
				if(ic == NULL){
					ic = ic1;
					head = ic1;
				}
				else{
					ic->next = ic1;
					ic1->prev = ic;
					ic = ic1;
				}
				
			}
		}
		dOperand* dop = p->dop;
		for(;dop!= NULL; dop = dop->next){//对每条语句中的每一个变量进行查找
			if(p->dop->op != dop->op){
			Operand op[2];
			op[1] = p->dop->op;
			op[0] = dop->op;
			InterCodes* ic1 = create_ir(ASSIGN,op);
			if(ic == NULL){
					ic = ic1;
					head = ic1;
				}
				else{
					ic->next = ic1;
					ic1->prev = ic;
					ic = ic1;
				}
			}
		}
	}
	return head;
}













//优化操作数是数字的
void optimizedigital(InterCodes* head){
	InterCodes* p = head;
	for(p = head; p!= NULL; p =p->next){
		int ickind = p->code.kind;
		if(ickind == ADD){
			if(p->code.u.binop.op1->kind == CONSTANT){	
				if(p->code.u.binop.op1->u.value == 0){
					
					Operand op1 = p->code.u.binop.result;
					Operand op2 = p->code.u.binop.op2;
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}	
				else if(p->code.u.binop.op2->u.value == 0){
					Operand op1 = p->code.u.binop.result;
					Operand op2 = p->code.u.binop.op1;
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}	
				else if(p->code.u.binop.op2->kind == CONSTANT){
					int result = p->code.u.binop.op1->u.value + p->code.u.binop.op2->u.value;
					Operand op1 = p->code.u.binop.result;
					Operand op2 = create_op_constant(CONSTANT,result);
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}
			}
		}
		else if(ickind == SUB){
			if(p->code.u.binop.op1->kind == CONSTANT){	
				if(p->code.u.binop.op2->u.value == 0){
					Operand op1 = p->code.u.binop.result;
					Operand op2 = p->code.u.binop.op1;
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}
				else if(p->code.u.binop.op2->kind == CONSTANT){
					int result = p->code.u.binop.op1->u.value - p->code.u.binop.op2->u.value;
					Operand op1 = p->code.u.binop.result;
					Operand op2 = create_op_constant(CONSTANT,result);
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}	
			}
			else if(ifassign(p->code.u.binop.op1, p->code.u.binop.op2)==true){
					Operand op1 = p->code.u.binop.result;
					Operand op2 = create_op_constant(CONSTANT,0);
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
			}
			
		}
		else if(ickind == MUL){
			if(p->code.u.binop.op1->kind == CONSTANT){	
				if(p->code.u.binop.op1->u.value == 1){
					
					Operand op1 = p->code.u.binop.result;
					Operand op2 = p->code.u.binop.op2;
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}	
				else if(p->code.u.binop.op2->u.value == 1){
					Operand op1 = p->code.u.binop.result;
					Operand op2 = p->code.u.binop.op1;
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}
				else if(p->code.u.binop.op2->kind == CONSTANT){
					int result = p->code.u.binop.op1->u.value * p->code.u.binop.op2->u.value;
					Operand op1 = p->code.u.binop.result;
					Operand op2 = create_op_constant(CONSTANT,result);
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}		
			}
		}
		else if(ickind == DIV){
			if(p->code.u.binop.op1->kind == CONSTANT){	
				if(p->code.u.binop.op2->u.value == 1){
					Operand op1 = p->code.u.binop.result;
					Operand op2 = p->code.u.binop.op1;
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}
				else if(p->code.u.binop.op2->kind == CONSTANT){
					int result = p->code.u.binop.op1->u.value / p->code.u.binop.op2->u.value;
					Operand op1 = p->code.u.binop.result;
					Operand op2 = create_op_constant(CONSTANT,result);
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
				}			
			}
			else if(ifassign(p->code.u.binop.op1, p->code.u.binop.op2)==true){
					Operand op1 = p->code.u.binop.result;
					Operand op2 = create_op_constant(CONSTANT,1);
					p->code.kind = ASSIGN;
					p->code.u.assign.left = op1;
					p->code.u.assign.right = op2;
			}
		}
	}
}



//去除t1 = #常数这种冗余的情况
void  delete_tac(InterCodes* head){
	InterCodes* p = head;
	InterCodes* q = NULL;
	for(p = head; p!= NULL; q = p,p =p->next){
		//display_intercode(p);
		if(p->code.kind == ASSIGN){
			
			if(p->code.u.assign.left->kind == TEMP_VARIABLE && p->code.u.assign.right->kind == CONSTANT){
				Operand t1 = p->code.u.assign.left;
				Operand t2 = p->code.u.assign.right;
				if(p->prev != NULL){
					q->next = p->next;
				}
				else{
					head = p->next;
				}
				if(p->next != NULL){		
					p->next->prev = q;
				}
				//display_intercode(p);
				//display_intercode(p->next);
				//exit(0);
				if(p->next != NULL){
					InterCodes* q = p->next;
					for(q = p->next; q!= NULL; q =q->next){
						deal_intercode(q,t2,t1);
					}
				}
				//p = p->next;
			}
		}
	}
}

//去除t1 = t2这种冗余的情况
void  delete_tat(InterCodes* head){
	InterCodes* p = head;
	InterCodes* q = NULL;
	for(p = head; p!= NULL; q = p,p =p->next){
		//display_intercode(p);
		if(p->code.kind == ASSIGN){
			
			if(p->code.u.assign.left->kind == TEMP_VARIABLE && p->code.u.assign.right->kind == TEMP_VARIABLE){
				//删除p
				//printf("delete:p->code.u.assign.left:%d#########################\n",p->code.u.assign.left->u.value);
				Operand t1 = p->code.u.assign.left;
				Operand t2 = p->code.u.assign.right;
				if(p->prev != NULL){
					p->prev->next = p->next;
				}
				else{
					head = p->next;
				}	
				p->next->prev = p->prev;
				if(p != NULL){
					
					for(q = p->next; q!= NULL; q =q->next){
						deal_intercode(q,t2,t1);
					}
				}
				
			}
			/*else if(p->code.u.assign.left->kind == TEMP_VARIABLE && p->code.u.assign.right->kind == CONSTANT){
				printf("constant: p->code.u.assign.left:%d#########################\n",p->code.u.assign.left->u.value);
				Operand t1 = p->code.u.assign.left;
				Operand t2 = p->code.u.assign.right;
				if(p->prev != NULL){
					q->next = p->next;
				}
				else{
					head = p->next;
				}
				if(p->next != NULL){		
					p->next->prev = q;
				}
				display_intercode(q);
				//display_intercode(p);
				//display_intercode(p->next);
				//exit(0);
				if(p->next != NULL){
					InterCodes* q = p->next;
					printf("******************************************************************************\n");
					for(q = p->next; q!= NULL; q =q->next){
						deal_intercode(q,t2,t1);
					}
				}
				//p = p->next;
			}*/
		}
	}
}




void replacetemp(Operand to,Operand from,Operand op){
	
	if(from->kind == TEMP_VARIABLE && to->kind == TEMP_VARIABLE && (op -> kind == TEMP_VARIABLE || op -> kind == ADDRESS_TEMP_VARIABLE || op -> kind == TEMP_VARIABLE_VALUE)){
		if(op->u.temp_no == from->u.temp_no){
			op->u.temp_no = to->u.temp_no;
		}
	}
	else if(from->kind == TEMP_VARIABLE && to->kind == CONSTANT && ifassigntemp(from, op)){
		op->kind = CONSTANT;
		op->u.value = to->u.value;
	}
}

/*
void replacetemp2(Operand to,Operand from,Operand op){
	
	if(from->kind == TEMP_VARIABLE && to->kind == CONSTANT && ifassigntemp(from, op)){
		op->kind = CONSTANT;
		op->u.value = to->u.value;
	}
}*/

boolean ifassigntemp(Operand temp1, Operand temp2){
	if(temp1->kind == temp2->kind && temp1->kind == VARIABLE){
		if(temp1->u.var_no == temp2->u.var_no){
			return true;
		}
	}
	else if(temp1->kind == temp2->kind && temp1->kind == TEMP_VARIABLE){
		if(temp1->u.temp_no == temp2->u.temp_no){
			return true;
		}
	}
	return false;
}

boolean ifassign(Operand temp1, Operand temp2){
	if((temp1->kind == temp2->kind && temp1->kind == VARIABLE) || (temp1->kind == temp2->kind && temp1->kind ==  ADDRESS_VARIABLE) || (temp1->kind == temp2->kind && temp1->kind == VARIABLE_VALUE)){
		if(temp1->u.var_no == temp2->u.var_no){
			return true;
		}
	}
	else if((temp1->kind == temp2->kind && temp1->kind == TEMP_VARIABLE) || (temp1->kind == temp2->kind && temp1->kind == ADDRESS_TEMP_VARIABLE) || (temp1->kind == temp2->kind && temp1->kind == TEMP_VARIABLE_VALUE)){
		if(temp1->u.temp_no == temp2->u.temp_no){
			return true;
		}
	}
	else if(temp1->kind == temp2->kind && temp1->kind == CONSTANT){
		if(temp1->u.value == temp2->u.value){
			return true;
		}
	}
	return false;
}



char * dealrelop(char *relop){//对比较符号取反
	if(strcmp(relop,"GT") == 0){
		return "LE";
	}
	else if(strcmp(relop,"LT") == 0){
		return "GE";
	}
	if(strcmp(relop,"GE") == 0){
		return "LT";
	}
	else if(strcmp(relop,"LE") == 0){
		return "GT";
	}
	if(strcmp(relop,"EQ") == 0){
		return "NE";
	}
	else if(strcmp(relop,"NE") == 0){
		return "EQ";
	}
	return NULL;
}





void display_ir(InterCodes* head,char *filename){
	InterCodes* p = head;
	FILE *fp = fopen(filename,"w");
	for(p = head ; p != NULL; p = p->next){
		display_intercode(p,fp);
	}
	fclose(fp);
}


void deal_intercode(InterCodes* ic,Operand to, Operand from){
	int kind = ic->code.kind;
	//printf("~~~~~~~~~~~~~~\n");
	switch(kind){
		case ASSIGN:
			
			replacetemp(to,from,ic->code.u.assign.left);
			replacetemp(to,from,ic->code.u.assign.right);
			break;
		case ADD: case SUB: case MUL: case DIV:
			replacetemp(to,from,ic->code.u.binop.result);
			replacetemp(to,from,ic->code.u.binop.op1);
			replacetemp(to,from,ic->code.u.binop.op2);
			break;
		case IF:
			replacetemp(to,from,ic->code.u.ific.op1);
			replacetemp(to,from,ic->code.u.ific.op2);
			break;
		case RETURN:
			replacetemp(to,from,ic->code.u.oneop.op);
			break;
		case CALL:
			replacetemp(to,from,ic->code.u.funcop.op);
			break;
		case READ:
			replacetemp(to,from,ic->code.u.funcop.op);
			break;
		case WRITE:
			replacetemp(to,from,ic->code.u.funcop.op);
			break;
		case ARGS:
			replacetemp(to,from,ic->code.u.funcop.op);
			break;
		case PARAM:
			replacetemp(to,from,ic->code.u.funcop.op);
			break;
		case DEC:
			replacetemp(to,from,ic->code.u.structure.op);
			break;
			
			
	}
	//printf("~~~~~~~~~~~~~~\n");
}






void display_intercode(InterCodes* ic,FILE *fp){
	int kind = ic->code.kind;
	//printf("~~~~~~~~~~~~~~\n");
	int opkind;
	Operand op;
	switch(kind){
		case ASSIGN:
			display_op(fp,ic->code.u.assign.left);	
			fputs(" := ",fp);
			display_op(fp,ic->code.u.assign.right);
			fputs("\n",fp);
			break;
		case ADD: case SUB: case MUL: case DIV:
			display_op(fp,ic->code.u.binop.result);	
			fputs(" := ",fp);
			display_op(fp,ic->code.u.binop.op1);
			if(kind == ADD){
				fputs(" + ",fp);
			}
			else if(kind == SUB){
				fputs(" - ",fp);
			}
			else if(kind == MUL){
				fputs(" * ",fp);
			}
			else if(kind == DIV){
				fputs(" / ",fp);
			}
			display_op(fp,ic->code.u.binop.op2);
			fputs("\n",fp);
			break;
		case IF:
			//IF t1 op t2 GOTO label_true
			fputs("IF ",fp);
			display_op(fp,ic->code.u.ific.op1);	
			if(strcmp(ic->code.u.ific.relop,"GT") == 0){
				fputs(" > ",fp);
			}
			else if(strcmp(ic->code.u.ific.relop,"LT") == 0){
				fputs(" < ",fp);
			}
			else if(strcmp(ic->code.u.ific.relop,"GE") == 0){
				fputs(" >= ",fp);
			}
			else if(strcmp(ic->code.u.ific.relop,"LE") == 0){
				fputs(" <= ",fp);
			}
			else if(strcmp(ic->code.u.ific.relop,"EQ") == 0){
				fputs(" == ",fp);
			}
			else if(strcmp(ic->code.u.ific.relop,"NE") == 0){
				fputs(" != ",fp);
			}
			display_op(fp,ic->code.u.ific.op2);	
			fputs(" GOTO ",fp);
			fprintf(fp,"label%d\n",ic->code.u.ific.label);
			break;

		case GOTO:
			fprintf(fp,"GOTO label%d\n",ic->code.u.mlabel.label);
			break;
		case LABEL:
			fprintf(fp,"LABEL label%d :\n",ic->code.u.mlabel.label);
			break;
		case RETURN:
			fputs("RETURN ",fp);
			display_op(fp,ic->code.u.oneop.op);
			fputs("\n",fp);	
			break;
		case CALL:
			display_op(fp,ic->code.u.funcop.op);
			fputs(" :=",fp);
			fputs(" CALL ",fp);
			fprintf(fp,"%s\n",ic->code.u.funcop.funcname);
			break;
		case READ:
			fputs("READ ",fp);
			display_op(fp,ic->code.u.funcop.op);	
			fprintf(fp,"\n");
			break;
		case WRITE:
			fputs("WRITE ",fp);
			display_op(fp,ic->code.u.funcop.op);
				
			fputs("\n",fp);
			break;
		case ARGS:
			fputs("ARG ",fp);
			op = ic->code.u.funcop.op;
			//display_op(fp,ic->code.u.funcop.op);
			
			opkind = op->kind;
			if(opkind ==  VARIABLE){
				fprintf(fp,"v%d",op->u.var_no);
			}
			else if(opkind ==  CONSTANT){
				fprintf(fp,"#%d",op->u.value);
			}
			else if(opkind == TEMP_VARIABLE){
				fprintf(fp,"t%d",op->u.temp_no);
			}
			else if(opkind ==  ADDRESS_VARIABLE){
				fprintf(fp,"*v%d",op->u.temp_no);
			}
			else if(opkind ==  ADDRESS_TEMP_VARIABLE){
				fprintf(fp,"*t%d",op->u.temp_no);
			}
			else if(opkind ==  TEMP_VARIABLE_VALUE){
				fprintf(fp,"&t%d",op->u.temp_no);
			}
			else if(opkind ==  VARIABLE_VALUE){
				fprintf(fp,"&v%d",op->u.temp_no);
			}


			fputs("\n",fp);	
			break;
		case FUNCTION:
			fprintf(fp,"FUNCTION %s :\n",ic->code.u.funcop.funcname);
			break;
		case PARAM:
			fputs("PARAM ",fp);
			display_op(fp,ic->code.u.funcop.op);
			fputs("\n",fp);	
			break;
		case DEC:
			fputs("DEC ",fp);
			display_op(fp,ic->code.u.structure.op);
			fprintf(fp," %d\n",ic->code.u.structure.size);	
			break;
			
			
	}
	//printf("~~~~~~~~~~~~~~\n");
}




void display_op(FILE *fp,Operand op){
	int kind = op->kind;
	//printf("kind:%d\n",kind);
	switch(kind){
		case VARIABLE:
			fprintf(fp,"v%d",op->u.var_no);
			break;
		case CONSTANT:
			fprintf(fp,"#%d",op->u.value);
			break;
		case TEMP_VARIABLE:
			fprintf(fp,"t%d",op->u.temp_no);
			break;
		case ADDRESS_VARIABLE:
			fprintf(fp,"*v%d",op->u.temp_no);
			break;
		case ADDRESS_TEMP_VARIABLE:
			fprintf(fp,"*t%d",op->u.temp_no);
			break;
		case TEMP_VARIABLE_VALUE:
			fprintf(fp,"&t%d",op->u.temp_no);
			break;
		case VARIABLE_VALUE:
			fprintf(fp,"&v%d",op->u.temp_no);
			break;
	}
}

int varlistchild(Node* varlist,Node *tnode[]){
	char* name1[3] = {"ParamDec", "COMMA" ,"VarList"};
	char* name2[1] = {"ParamDec"};
	if(comparechild(name1,3,tnode,varlist)== true){
		return 1;
	}
	else if(comparechild(name2,1,tnode,varlist)== true){
		return 2;
	}
	else{
		return 0;
	}
}


int declistchild(Node* declist,Node *tnode[]){
	char* name1[1] = {"Dec"};
	char* name2[3] = {"Dec","COMMA","DecList"};
	if(comparechild(name2,3,tnode,declist)== true){
		return 2;
	}
	if(comparechild(name1,1,tnode,declist)== true){
		return 1;
	}
	else{
		return 0;
	}
}

int vardecchild(Node* vardec,Node *tnode[]){
	char* name1[1] = {"ID"};
	char* name2[4] = {"VarDec","LB","INT","RB"};
	if(comparechild(name1,1,tnode,vardec)== true){
		return 1;
	}
	else if(comparechild(name2,4,tnode,vardec)== true){
		return 2;
	}
	else{
		return 0;
	}
}

int decchild(Node* dec,Node *tnode[]){
	char* name1[1] = {"VarDec"};
	char* name2[3] = {"VarDec","ASSIGNOP" ,"Exp"};
	
	if(comparechild(name2,3,tnode,dec)== true){
		return 2;
	}
	if(comparechild(name1,1,tnode,dec)== true){
		return 1;
	}
	else{
		return 0;
	}
}
int argschild(Node* args,Node *tnode[]){
	char* name1[1] = {"Exp"};
	char* name2[3] = {"Exp","COMMA","Args"};
	
	if(comparechild(name2,3,tnode,args)== true){
		return 2;
	}
	if(comparechild(name1,1,tnode,args)== true){
		return 1;
	}
	else{
		return 0;
	}
}
int funcdecchild(Node* funcdec,Node *tnode[]){
	char* name1[4] = {"ID","LP","VarList","RP"};
	char* name2[3] = {"ID","LP","RP"};
	if(comparechild(name1,4,tnode,funcdec)== true){
		return 1;
	}
	else if(comparechild(name2,3,tnode,funcdec)== true){
		return 2;
	}
	else{
		return 0;
	}
}
int extdefchild(Node* extdef,Node *tnode[]){
	char* name1[3] = {"Specifier","ExtDecList","SEMI"};
	char* name2[2] = {"Specifier","SEMI"};
	char* name3[3] = {"Specifier","FunDec","CompSt"};
 	if(comparechild(name1,3,tnode,extdef)== true){
		return 1;
	}
	
	else if(comparechild(name3,3,tnode,extdef)== true){
		return 3;
	}
	else if(comparechild(name2,2,tnode,extdef)== true){
		return 2;
	}
	else{
		return 0;
	}
}

int stmtchild(Node *stmt,Node *tnode[]){
	//Node* tnode[4];
	char* name1[2] = {"Exp","SEMI"};
	char* name2[1] = {"CompSt"};
	char* name3[3] = {"RETURN","Exp","SEMI"};
	char* name4[5] = {"IF","LP","Exp","RP","Stmt"};
	char* name5[7] = {"IF","LP","Exp","RP","Stmt","ELSE","Stmt"};
	char* name6[5] = {"WHILE","LP","Exp","RP","Stmt"};
	
	if(comparechild(name5,7,tnode,stmt)== true){
		return 5;
	}
	else if(comparechild(name4,5,tnode,stmt)== true){
		return 4;
	}
	else if(comparechild(name6,5,tnode,stmt)== true){
		return 6;
	}
	else if(comparechild(name3,3,tnode,stmt)== true){
		return 3;
	}
	else if(comparechild(name2,1,tnode,stmt)== true){
		return 2;
	}
	else if(comparechild(name1,2,tnode,stmt)== true){
		return 1;
	}
	
	else{
		return 0;
	}
}





int expchild(Node *exp,Node *tnode[]){
	//Node* tnode[4];
	char* name1[3] = {"Exp","ASSIGNOP","Exp"};
	char* name2[3] = {"Exp","AND","Exp"};
	char* name3[3] = {"Exp","OR","Exp"};
	char* name4[3] = {"Exp","RELOP","Exp"};
	char* name5[3] = {"Exp","PLUS","Exp"};
	char* name6[3] = {"Exp","MINUS","Exp"};
	char* name7[3] = {"Exp","STAR","Exp"};
	char* name8[3] = {"Exp","DIV","Exp"};
	char* name9[3] = {"LP","Exp","RP"};
	char* name10[2] = {"MINUS","Exp"};
	char* name11[2] = {"NOT","Exp"};
	char* name12[4] = {"ID","LP","Args", "RP"};
	char* name13[3] = {"ID","LP","RP"};
	char* name14[4] = {"Exp","LB","Exp","RB"};
	char* name15[3] = {"Exp","DOT","ID"};
	char* name16[1] = {"ID"};
	char* name17[1] = {"INT"};
	char* name18[1] = {"FLOAT"};
	
	if(comparechild(name1,3,tnode,exp)== true){
		return 1;
	}
	if(comparechild(name2,3,tnode,exp)== true){
		return 2;
	}
	if(comparechild(name3,3,tnode,exp)== true){
		return 3;
	}
	if(comparechild(name4,3,tnode,exp)== true){
		return 4;
	}
	else if(comparechild(name5,3,tnode,exp)== true){
		return 5;
	}
	else if(comparechild(name6,3,tnode,exp)== true){
		return 6;
	}
	else if(comparechild(name7,3,tnode,exp)== true){
		return 7;
	}
	else if(comparechild(name8,3,tnode,exp)== true){
		return 8;
	}
	else if(comparechild(name9,3,tnode,exp)== true){
		return 9;
	}
	else if(comparechild(name10,2,tnode,exp)== true){
		return 10;
	}
	else if(comparechild(name11,2,tnode,exp)== true){
		return 11;
	}
	else if(comparechild(name12,4,tnode,exp) == true){
		return 12;
	}
	else if(comparechild(name13,3,tnode,exp) == true){
		return 13;
	}
	else if(comparechild(name14,4,tnode,exp) == true){
		return 14;
	}
	else if(comparechild(name15,3,tnode,exp) == true){
		return 15;
	}
	else if(comparechild(name16,1,tnode,exp) == true){
		return 16;
	}
	else if(comparechild(name17,1,tnode,exp) == true){
		return 17;
	}
	else if(comparechild(name18,1,tnode,exp) == true){
		return 18;
	}
	else{
		return 0;
	}
}
