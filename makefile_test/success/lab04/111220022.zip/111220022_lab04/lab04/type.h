
#define MAX_SYMBOL_NAME 32
#define SYMBOL_TABLE_NUM 0x4000
#define MAXNAME 32

#define MAXARGS 10
#define MAXARGBYTE 1024
enum boolean{false,true};
enum basickind{ kint,kfloat };
typedef enum boolean boolean;
enum tkind{common,Def,StructSpecifier};
typedef enum tkind tkind;
typedef struct Type_* Type;
typedef struct FieldList_* FieldList;

struct Type_
{
	enum { basic, array, structure } kind;
	union
	{
		// 基本类型
		enum basickind basic;
		// 数组类型信息包括元素类型与数组大小构成
		struct { Type elem; int size; } array;
		// 结构体类型信息是一个链表
		FieldList structure;
	} u;
};

struct FieldList_
{
	char name[MAXNAME];// 域的名字
	Type type;// 域的类型
	FieldList next;// 下一个域(for one func or one struct)
	FieldList innerlink;// point to the item which hash the same key in hash table
	enum { commom, instruct, inargs } in;
	int index;//标记变量在中间代码中对应变量编号 //若为机构体，则表示结构体的size，//若为结构体中的变量，则为其偏移量
};

//变量表
extern FieldList var_table[SYMBOL_TABLE_NUM];

//结构表
extern FieldList structure_table[SYMBOL_TABLE_NUM];
extern Type t;



typedef struct func_{
	char name[MAXNAME]; //函数名
	Type returnargs;//返回的参数类型
	FieldList formalargs;//形參
	int ifdefined;
	struct func_* next;
}func_node;

//函数表
extern func_node* func_table[SYMBOL_TABLE_NUM];

unsigned int hash_pjw(char* name);


typedef struct declarenode{
	char name[MAXNAME];
	int location;
	struct declarenode* next;
}declare_node;
extern declare_node* dhead;
extern declare_node* dtail;

union type{
		int i;
		float f;
		char c[MAXNAME];
	};
	typedef struct Node{
		 char name[MAXNAME];
		 union type data;
		 struct Node* firstChild;
		 struct Node* nextSibing;
		 Type inh;
		 Type val;
		 int location;
		// int index;//标记变量在中间代码中对应变量编号
		 
	}Node;

boolean insertdeclare(declare_node* dn);
boolean deleatedeclarenode(char* name);
unsigned int hash_pjw(char* name);
void inittable();
FieldList getvar(char *name);
FieldList  getstructure(char *name);
func_node* getfunc(char *name);
boolean insertvar(FieldList node);
boolean insertstructure(FieldList node);
boolean insertfunc(func_node * node);


boolean comparechild(char* Name[],int num,Node* child[],Node *f);
int argnumber(char *funcname);

int structureindex(FieldList structure);
int sizeoftype(Type type);
