
#include "liner_IR.h"
#include<stdio.h>
#include<string.h>
#include <unistd.h>
#include <stdlib.h>


//变量表
FieldList var_table[SYMBOL_TABLE_NUM];

//结构表
FieldList structure_table[SYMBOL_TABLE_NUM];

//函数表
func_node* func_table[SYMBOL_TABLE_NUM];


	/*union type{
		int i;
		float f;
		char c[MAXNAME];
	};
	typedef struct Node{
		 char name[MAXNAME];
		 union type data;
		 struct Node* firstChild;
		 struct Node* nextSibing;
		 Type inh;
		 Type val;
		 int location;
		 int index;//标记变量在中间代码中对应变量编号
		 
	}Node;	*/
Type t = NULL;
FieldList var = NULL;
FieldList a = NULL;
boolean checktype(Type a,Type b);
void printfargs(Type t[],int num,char *pri);
boolean argmark = false;//小trick，用于控制当Exp在函数参数中时不进行一般的类型检查，而是等到arg层所有属性一起检查
boolean inStructSpecifier = false;//标记当前变量在结构定义中，使得报出的错会区分时类型3还是类型15
void printf_error(int kind,int location,char * name,char *args);
void dealexp(Node *f);
boolean checkleft(Node *exp);
boolean comparechild(char* Name[],int num,Node* child[],Node *f);
int expchild(Node *exp,Node *tnode[]);
boolean compareargs(char *name,FieldList inh, FieldList arg,char *pri,char *ari);//函数参数检查
boolean inASSIGNOP = false;
boolean funcvar = false;
boolean indeclare = false;
boolean declareerror = false;
boolean in_paramdec = false;
void PreOrder_syn(Node *p,int h){
	if(p != NULL){
		
		h ++;
	
		
		Node * f = p;
		Node * q = NULL;
		int i = 0;
		
		for(p = p->firstChild; p != NULL;q = p, p = p->nextSibing){
			//printf("firstchild:%s\n",p->firstChild->name);
			if(i == 0){
				p->inh = f->inh; //第一个节点从父节点获得继承属性
			}
			else{
				p->inh = q->val;//后面的节点从兄弟节点获得继承属性
				//for test
				
			}
			//特殊的继承属性赋值
			
			if(strcmp(f->name,"Args") == 0){
				argmark = true;
			}
			else if(strcmp(f->name,"StructSpecifier") == 0){
				inStructSpecifier = true;
			}
			else if(strcmp(f->name,"Exp") == 0){
				//Exp ASSIGNOP Exp
				char* name[3] = {"Exp","ASSIGNOP","Exp"};
				Node *tnode[3];
				if(comparechild(name,3,tnode,f) == true){
					inASSIGNOP = true;
				}
			}
			else if(strcmp(f->name,"FunDec") == 0){
				//Specifier FunDec SEMI
				if(f->nextSibing != NULL && strcmp(f->nextSibing->name,"SEMI") == 0){
					indeclare = true;
				}
				//下面不一定要保留
				if((FieldList)getfunc(f->firstChild->data.c) != NULL){
					funcvar = true;
				}
				
			}
			else if(strcmp(f->name,"CompSt") == 0 && strcmp(p->name,"StmtList") == 0){//为return检查做准备
				p->inh = f->inh;
			}
			else if(strcmp(f->name,"StmtList") == 0 && strcmp(p->name,"Stmt") == 0){//为return检查做准备
				p->inh = f->inh;
				
			}
			else if(strcmp(f->name,"Stmt") == 0 && strcmp(p->name,"Stmt") == 0){//为return检查做准备
				p->inh = f->inh;
			}
			else if(strcmp(f->name,"DecList") == 0){
				char *name[3] = {"Dec","COMMA","DecList"};
				Node *tnode[3];
				if(comparechild(name,3,tnode,f) == true){
					tnode[2]->inh = f->inh;
				}
			
			}
			else if(strcmp(f->name,"ParamDec") == 0){
				in_paramdec = true;
			}
			//for test
			
			PreOrder_syn(p,h);
			
			i ++;	
			//for test
					
		}
		
		if(f->firstChild!= NULL){
			
			f->val = f->firstChild->val;//综合属性
		}
		else if(f->val == NULL){
			f->val = f->inh;//本身没有属性的终结符except(TYPE 、 INT、FLOAT)
			
		}
		
		if(strcmp(f->name,"DecList") == 0){
			//printf("in declist\n");
			FieldList v = NULL;
			
			if(strcmp(f->firstChild->firstChild->firstChild->name,"ID")== 0){//普通变量
				//printf("f->firstChild->firstChild->firstChild->data.c:%s\n",f->firstChild->firstChild->firstChild->data.c);
				
				v =  (FieldList)getvar(f->firstChild->firstChild->firstChild->data.c);//DecList->Dec->VarDec->ID
			}
			else{//数组变量
				//printf("数组变量\n");
				Node *arrayt = f->firstChild->firstChild->firstChild;
				for(;(Node *)array != NULL && strcmp(arrayt->name,"ID") != 0; arrayt = arrayt->firstChild);
				if((Node *)array!= NULL){
					//printf("arrayt->data.c:%s\n",arrayt->data.c);
					v =  (FieldList)getvar(arrayt->data.c);
				}
			}
			Type tnode = (Type)malloc(sizeof(struct Type_));
			memset(tnode,0,sizeof(struct Type_));
			f->val = tnode;
			f->val->kind = structure;
			f->val->u.structure = v;//DecList的综合属性为指向ID代表节点的指针
			f->val->u.structure->innerlink = NULL;
			//Dec COMMA DecList
			char *name[3] = {"Dec","COMMA","DecList"};
			Node *nodes[3];
			if(comparechild(name,3,nodes,f) == true){
				f->val->u.structure->innerlink = nodes[2]->val->u.structure;//将结构体内的域连接起来
			}
			//printf("out declist\n");
			
		}
		else if(strcmp(f->name,"Dec") == 0){//VarDec ASSIGNOP Exp
			//printf("in dec\n");
			char *name[3] = {"VarDec","ASSIGNOP","Exp"};
			Node *tnode[3];
			if(comparechild(name,3,tnode,f) == true){
				if(tnode[0]->val != NULL && tnode[2]->val != NULL){
					if(checkleft(f->firstChild) == false){
						printf_error(6,f->location,NULL,NULL);
					}
					else{
						if(checktype(tnode[0]->val,tnode[2]->val) == false){
							printf_error(5,f->location,NULL,NULL);
						}
					}
				}
			}
		}
		else if(strcmp(f->name,"Program") == 0){//检查一下是否有声明了但未定义的函数
			declare_node *dn = dhead;
			for(dn = dhead; dn!= NULL; dn = dn->next){
				printf_error(18,dn->location,dn->name,NULL);
			}
		}
		else if(strcmp(f->name,"Def") == 0){
			f->val = f->firstChild->nextSibing->val;//Def->Specifier->DecList
		}
		else if(strcmp(f->name,"DefList") == 0){
			Node *fchild = f->firstChild;
			if(fchild ->nextSibing != NULL){
				
				//要找到Def的尾部再连接
				if(fchild->val->u.structure != NULL){
					FieldList  link = fchild->val->u.structure->innerlink;
					if(link != NULL){//不能对只有一个节点的情况进行下列循环，因为会访问link->innerlink
						for(link = fchild->val->u.structure->innerlink; link->innerlink != NULL; link = link->innerlink);
						link->innerlink = fchild->nextSibing->val->u.structure;//将结构体内的域连接起来
					}
					else{
						fchild->val->u.structure->innerlink = fchild->nextSibing->val->u.structure;//将结构体内的域连接起来
					}
				}
				else{
					fchild->val->u.structure->innerlink = fchild->nextSibing->val->u.structure;//将结构体内的域连接起来
				}
				
			}
		}
		if(strcmp(f->name,"StructSpecifier") == 0){//附上结构体的type
			inStructSpecifier = false;
			char* Name[5] = {"STRUCT","OptTag","LC","DefList","RC"};
			Node* dstruct[5];
			int i = 0;
			Node *t;
			for(t = f->firstChild; t !=NULL; t = t->nextSibing){
				dstruct[i] = t;
				if(strcmp(t->name,Name[i]) != 0){
					break;
				}
				i ++;
			}
			char* Name2[4] = {"STRUCT","LC","DefList","RC"};
			
			if(i == 5){//结构定义
				if(dstruct[1] != NULL){//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!还没想好结构体没有名字怎么处理
					//为了实现结构体的名等价，将带有结构体的名字的节点插入到结构体的域链表的第一个
					FieldList p = (FieldList)malloc(sizeof(struct FieldList_));
					memset(p,0,sizeof(struct FieldList_));
					strcpy(p->name,dstruct[1]->firstChild->data.c);
					p->type = dstruct[3]->val;
					p->innerlink = 	dstruct[3]->val->u.structure;	
					p->index = structureindex(dstruct[3]->val->u.structure);			
					FieldList s = (FieldList)malloc(sizeof(struct FieldList_));
					memset(s,0,sizeof(struct FieldList_));
					strcpy(s->name,dstruct[1]->firstChild->data.c);
					Type tnode = (Type)malloc(sizeof(struct Type_));
					memset(tnode,0,sizeof(struct Type_));
					s->type = tnode;
					s->type->kind = structure;
					s->type->u.structure = p;
					s->index = p->index;
					if(insertstructure(s) == true){
						//printf("structure insert successfully\n");
						f -> val = s -> type;
					}
					else{
						//printf("结构体重定义\n");
						printf_error(16,f->location,s->type->u.structure->name,NULL);
					}
				}
				
			}
			else if(comparechild(Name2,4,dstruct,f)){//实现匿名结构类
				
				FieldList p = (FieldList)malloc(sizeof(struct FieldList_));
				memset(p,0,sizeof(struct FieldList_));
				p->type = dstruct[3]->val;
				p->innerlink = 	dstruct[3]->val->u.structure;	
				//for test
				//printf("dstruct[3]->val->u.structure->name:%s\n",dstruct[3]->val->u.structure->name);			
				FieldList s = (FieldList)malloc(sizeof(struct FieldList_));
				memset(s,0,sizeof(struct FieldList_));
				//s->name = NULL;
				Type tnode = (Type)malloc(sizeof(struct Type_));
				memset(tnode,0,sizeof(struct Type_));
				s->type = tnode;
				s->type->kind = structure;
				s->type->u.structure = p;
				f -> val = s -> type;
			}
			else if(strcmp(f->firstChild->name,"STRUCT") == 0 && strcmp(f->firstChild->nextSibing->name,"Tag") == 0 ){
				Node *t = f->firstChild->nextSibing;
				FieldList g = (FieldList)getstructure(t->firstChild->data.c);
				if(g == NULL){
					//printf("未定义的结构体\n");
					printf_error(17,f->location,t->firstChild->data.c,NULL);
				}
			}
			//printf("out structspecifier\n");
		}
		else if(strcmp(f->name,"Tag") == 0){
			f->val = f->inh;
			
			FieldList g = (FieldList)getstructure(f->firstChild->data.c);
			if(g != NULL){
				f->val->u.structure = g;
			}
			
		}
		else if(strcmp(f->name,"Stmt") == 0){
			char* name3[3] = {"RETURN","Exp","SEMI"};//RETURN Exp SEMI
			char* name4[5] = {"IF","LP","Exp","RP","Stmt"};
			char* name5[7] = {"IF","LP","Exp","RP","Stmt","ELSE","Stmt"};
			char* name6[5] = {"WHILE","LP","Exp","RP","Stmt"};
			Node *tnode[7];
			if(comparechild(name3,3,tnode,f) == true){//RETURN Exp SEMI
				if(tnode[1]->val!= NULL){
					if(checktype(f->inh,tnode[1]->val) == false){
						printf_error(8,f->location,NULL,NULL);
					}
				}
			}
			else if(comparechild(name4,5,tnode,f) == true || comparechild(name5,7,tnode,f) == true){//{"IF","LP","Exp","RP"...
				if(tnode[2]->val != NULL){
					if(tnode[2]->val->kind != basic || tnode[2]->val->u.basic != kint){
						//printf_error(7,f->location,NULL,NULL);
						printf("Error type 7 at line %d: the confidition of if is not correct\n",f->location);
					}
				}
			}
			else if(comparechild(name6,5,tnode,f) == true){//{"WHILE","LP","Exp","RP","Stmt"}
				if(tnode[2]->val != NULL){
					if(tnode[2]->val->kind != basic || tnode[2]->val->u.basic != kint){
						//printf_error(7,f->location,NULL,NULL);
						printf("Error type 7 at line %d: the confidition of while is not correct\n",f->location);
					}
				}
			}
			
			
			
		}
		else if(strcmp(f->name,"VarDec")==0){
			//printf("in VarDec\n");
			if((f->nextSibing == NULL || strcmp(f->nextSibing->name,"ASSIGNOP") == 0)){
				var = (FieldList)malloc(sizeof(struct FieldList_));
				memset(var,0,sizeof(struct FieldList_));
				
				if(f->firstChild->nextSibing == NULL && strcmp(f->firstChild->name,"ID") == 0){//!!!!!!!!!!!!!!!!!!!!!!!!没考虑赋值
					strcpy(var->name,f->firstChild->data.c);
					f->firstChild->val = f->firstChild->inh;
					var->type = f->inh;
					if(in_paramdec == true){
						var->in = inargs;
					}
					var->innerlink = NULL;
					//待考量
					f->val = var -> type;
					f->firstChild ->val =  var -> type;
					var->index = -1;
					//待考量
					if((FieldList)getstructure(f->firstChild->data.c) != NULL){
						printf("Error type 3 at line %d: variable \"%s\" has the same name with a sturecure\n",f->location,f->firstChild->data.c);
					}
					//printf("++++++++++++++++++var->type->basic:%d+++++++++++\n",var->type->u.basic);
					if(insertvar(var) == false){//插入变量
						if(funcvar == false){//第一个条件保证若统一个函数的多次声明和定义只将参数中的变量插入一次
								//将该条件放在这而不是放在VarDec最前面是因为有可能出现变量声明不一致的 情况
							if(inStructSpecifier == false){
								printf_error(3,f->location,f->firstChild->data.c,NULL);
							}
							else{
								printf_error(15,f->location,f->firstChild->data.c,NULL);
							}
						}
						else if(checktype(var->type,((FieldList)getvar(var->name))->type) == false){//
							printf("Error type 19 at line %d: Inconsistent args of function\n",f->location,var->name);
						}
						if(indeclare == true){		
							declareerror = true;	
						}
					}
					else{
						
						if(f->nextSibing!= NULL){
							if(inStructSpecifier == true && strcmp(f->nextSibing->name,"ASSIGNOP") == 0){
								printf("Error type 15 at line %d: error field \"%s\"\n",f->location,f->firstChild->data.c);
							}
						}
						//printf("insert sucessfully\n");
					}
			
				}
				
			}
			else{
				char* Name[4] = {"VarDec","LB","INT","RB"};
				Node* darray[4];
				int i = 0;
				Node *t;
				for(t = f->firstChild; t !=NULL; t = t->nextSibing){
					darray[i] = t;
					if(strcmp(t->name,Name[i]) != 0){
						break;
					}
					i ++;
				}
				if(i == 4){//数组定义
					Type t = (Type)malloc(sizeof(struct Type_));
					memset(t,0,sizeof(struct Type_));
					f->val = t;
					f->val->kind = array;
					f->val->u.array.elem = f->firstChild->val;
					f->val->u.array.size = f->nextSibing->nextSibing->data.i;//VarDec ->LB ->INT
					a->type = f->val;
					// for test
					//printf("f->val->u.array.size:%d\n",f->val->u.array.size);
					//printf("f->val->u.array.elem->u.array.size:%d\n",f->val->u.array.elem->u.array.size);
					//printf("a->type->u.array.size:%d\n",a->type->u.array.size);
					//printf("a->type->u.array.elem->u.array.size:%d\n",a->type->u.array.elem->u.array.size);
					
					
				}
				else if(strcmp(f->firstChild->name,"ID") == 0 && f->firstChild-> nextSibing == NULL){
				//在VacDec这一层进行类型赋值处理	
					a = (FieldList)malloc(sizeof(struct FieldList_));
					memset(a,0,sizeof(struct FieldList_));
					//printf("f->firstChild->data.c:%s\n",f->firstChild->data.c);
					strcpy(a->name,f->firstChild->data.c);
					
					
					Type t = (Type)malloc(sizeof(struct Type_));
					memset(t,0,sizeof(struct Type_));
					f->val = t;
					f->val->kind = array;
					f->val->u.array.elem = f->inh;
					
					f->val->u.array.size = f->nextSibing->nextSibing->data.i;//VarDec ->LB ->INT
					f->firstChild->val = f->val;
					a->type = f->val;
					a->innerlink = NULL;
					if(in_paramdec == true){
						a->in = inargs;
					}
					a->index = -1;
					if(insertvar(a) == true){
						//printf("array insert successfully\n");
					}
					else{
						//printf("数组重定义\n");
						printf_error(3,f->location,f->firstChild->data.c,NULL);
					}
					//for test
					
				}
			}
			
			//}
			//printf("out vardec\n");
			
		}
		else if(strcmp(f->name,"ParamDec") == 0){//!!!!!!!!!!!!!!!!!!!!!！！！！！！！！！！！！！！！！！！！!!!!先只处理有参数的
			//printf("in paramdec\n");
			if(f->firstChild->nextSibing != NULL){
				Type tnode = (Type)malloc(sizeof(struct Type_));
				memset(tnode,0,sizeof(struct Type_));
				f->val = tnode;
				f->val->kind = structure;
				if(strcmp(f->firstChild->nextSibing->firstChild->name,"ID") == 0){//普通变量
					f->val->u.structure = (FieldList)getvar(f->firstChild->nextSibing->firstChild->data.c);//ParamDec->Specifier->VarDec->ID
					((FieldList)getvar(f->firstChild->nextSibing->firstChild->data.c))->in = inargs;
				}
				else{//数组
					Node* alist = f->firstChild->nextSibing->firstChild;
					for(;alist!= NULL && strcmp(alist->name,"ID") != 0; alist = alist->firstChild);
					if(alist!= NULL){
						f->val->u.structure = (FieldList)getvar(alist->data.c);
						((FieldList)getvar(alist->data.c))->in = inargs;
					}
				}
				//printf("f->val->u.structure->name:%s\n",f->val->u.structure->name);
			}
			in_paramdec = false;
			//printf("out paramdec\n");
		}
		else if(strcmp(f->name,"VarList") == 0){
			//printf("in varlist\n");
			char* Name[3] = {"ParamDec","COMMA","VarList"};//ParamDec COMMA VarList

			Node* dfunc[3];
			int i = 0;
			Node *t;
			for(t = f->firstChild; t !=NULL; t = t->nextSibing){
				dfunc[i] = t;
				if(strcmp(t->name,Name[i]) != 0){
					break;
				}
				i ++;
			}
			if(i == 3){
				
				FieldList arg = (FieldList)getvar(dfunc[0]->val->u.structure->name);
				
				if(arg != NULL){
					arg->innerlink = dfunc[2]->val->u.structure;
				}
				//Type ft = (Type)malloc(sizeof(struct Type_));
				//memset(ft,0,sizeof(struct Type_));
				//ft->kind = structure;
				//ft->u.structure = 
				
			}
			else{	
				FieldList arg = (FieldList)getvar(f->firstChild->val->u.structure->name);
				//printf("f->firstChild->val->u.structure->name:%s\n",f->firstChild->val->u.structure->name);
				if(arg != NULL){
					arg->innerlink = NULL;
				}
			}
			f->val = dfunc[0]->val;
			//printf("out varlist\n");
		}
		else if(strcmp(f->name,"FunDec") == 0){//插入函数节点
			//printf("in fundec\n");
			char* Name[4] = {"ID","LP","VarList","RP"};//ID LP VarList RP
			Node* dfunc[4];
			int i = 0;
			Node *t;
			for(t = f->firstChild; t !=NULL; t = t->nextSibing){
				dfunc[i] = t;
				if(strcmp(t->name,Name[i]) != 0){
					break;
				}
				i ++;
			}
			func_node* fn = (func_node*)malloc(sizeof(func_node));
			memset(fn,0,sizeof(func_node));
			if(i == 4){//有参数的函数
				if(f->firstChild != NULL){
					//printf("f->firstChild->data.c:%s\n",f->firstChild->data.c);
					strcpy(fn->name,f->firstChild->data.c);
				}
				else{
					printf("无函数名\n");
				}
				if(f->inh != NULL){
					fn->returnargs = f->inh;
				}
				else{
					
					printf("函数无返回值\n");
				}
				fn->formalargs = dfunc[2]->val->u.structure;
				
			}
			else{//无参数的函数
				char* Name[3] = {"ID","LP","RP"};//ID LP VarList RP
				Node* dfunc[3];
				int i = 0;
				Node *t;
				for(t = f->firstChild; t !=NULL; t = t->nextSibing){
					dfunc[i] = t;
					if(strcmp(t->name,Name[i]) != 0){
						break;
					}
					i ++;
				}
				if(i == 3){
					if(f->firstChild != NULL){
						//printf("f->firstChild->data.c:%s\n",f->firstChild->data.c);
						strcpy(fn->name,f->firstChild->data.c);
					}
					else{
						printf("无函数名\n");
					}
					if(f->inh != NULL){
						fn->returnargs = f->inh;
					}
					else{
						printf("函数无返回值\n");
					}
					fn->formalargs = NULL;
					/*if(insertfunc(fn) == true){
						printf("func insert successfully\n");
					//for test
				
					}
					else{
						//printf("Error type 4 at line %d: Redefined function \"%s\"\n",f->location,f->firstChild->data.c);
						printf_error(4,f->location,f->firstChild->data.c,NULL);
					}*/
				}
			}
			if(f->nextSibing != NULL && strcmp(f->nextSibing->name,"SEMI") == 0){//函数声明
					//printf("~~in func declare~~~~~\n");
					
					fn->ifdefined = 0;
					func_node* funcn = (func_node*)getfunc(f->firstChild->data.c);
					if(funcn == NULL){//还没有定义过该函数，直接将该节点插入
						declare_node* dn = (declare_node*)malloc(sizeof(declare_node));
						
						memset(dn,0,sizeof(declare_node));
						dn->location = f->location;
						strcpy(dn->name,f->firstChild->data.c);
						dn->next = NULL;
						if(declareerror == false){//若函数在声明过程中有错，则不将函数插入表中，以防后面进行参数匹配时出错
							if(insertdeclare(dn) == true){
								//printf("declarenode insert successfully\n");
							}
					
							insertfunc(fn);
						}
					/*	else{
							printf("declareerror == true\n");
						}*/
					}
					else if(fn->ifdefined == 0){//已定义过但未声明
						char pri[MAXARGBYTE];
						char ari[MAXARGBYTE];
						if(compareargs(f->firstChild->data.c,funcn->formalargs,fn->formalargs,pri,ari) == false){
							printf_error(19,f->location,f->firstChild->data.c,NULL);
							
						}
						else if(checktype(fn->returnargs,funcn->returnargs) == false){//检查函数返回值
							printf_error(19,f->location,f->firstChild->data.c,NULL);
						}
						
					}
					declareerror = false;
				}
				else if(f->nextSibing != NULL && strcmp(f->nextSibing->name,"CompSt") == 0){//函数定义
					//printf("in func define\n");
					fn->ifdefined = 1;
					func_node* funcn = (func_node*)getfunc(f->firstChild->data.c);
					if(funcn == NULL){
						if(insertfunc(fn) == true){
						//printf("func insert successfully\n");
						//for test
						//printf("dfunc[3]->firstChild->val->u.structure->name:%s\n",dfunc[2]->firstChild->val->u.structure->name);
						//printf("dfunc[3]->firstChild->val->u.structure->name:%s\n",dfunc[2]->firstChild->val->u.structure->innerlink->name);
						}
						
					}
					else if(funcn -> ifdefined  == 0){//声明但未定义
						char pri[MAXARGBYTE];
						char ari[MAXARGBYTE];
						if(compareargs(f->firstChild->data.c,funcn->formalargs,fn->formalargs,pri,ari) == true){
							funcn->ifdefined = 1;
							if(checktype(fn->returnargs,funcn->returnargs) == false){
								printf("Error type 19 at line %d: Inconsistent declaration and definition of function \"%s\"\n",f->location,f->firstChild->data.c);
							}
						}
						else{
							//printf("ari:%s\n",ari);
							//printf("pri:%s\n",pri);
							//printf("函数声明和定义不统一！！！！\n");
							printf("Error type 19 at line %d: Inconsistent declaration and definition of function \"%s\"\n",f->location,f->firstChild->data.c);
						}
						//printf("声明但未定义\n");
						if(deleatedeclarenode(f->firstChild->data.c) == true){
							//printf("declarenode delete successfully\n");
						}
					}
					else{//已定义
						printf_error(4,f->location,f->firstChild->data.c,NULL);
						
					}
				}
			//printf("out fundec\n");
		}
		else if(strcmp(f->name,"Args") == 0){//对于args而言，虽然用fieldlist串起来，但只有其中的type和innerlink有用，名字没用
			
			char* Name[3] = {"Exp","COMMA","Args"};//Exp COMMA Args

			Node* dargs[3];
			int i = 0;
			Node *t;
			for(t = f->firstChild; t !=NULL; t = t->nextSibing){
				dargs[i] = t;
				if(strcmp(t->name,Name[i]) != 0){
					break;
				}
				i ++;
			}
			if(i == 3){//
				
				FieldList e = (FieldList)malloc(sizeof(struct FieldList_));
				memset(e,0,sizeof(struct FieldList_));
				e->type = dargs[0]->val;
				e->innerlink = dargs[2]->val->u.structure;
				Type typenode = (Type)malloc(sizeof(struct Type_));
				f->val = typenode;
				f->val->kind = structure;
				f->val->u.structure = e;
			}
			else if(f->firstChild!= NULL && strcmp(f->firstChild->name,"Exp") == 0 && f->firstChild->nextSibing == NULL){//Args->Exp
				FieldList e = (FieldList)malloc(sizeof(struct FieldList_));
				memset(e,0,sizeof(struct FieldList_));
				e->type = f->firstChild->val;
				e->innerlink = NULL;
				Type typenode = (Type)malloc(sizeof(struct Type_));
				f->val = typenode;
				f->val->kind = structure;
				f->val->u.structure = e;
			}
			argmark = false;
		}
		else if(strcmp(f->name,"Exp") == 0){
			//printf("in exp\n");
			dealexp(f);
		}
	}
	else{
		h = 0;
		printf("root = NULL\n");
	}
	
}

void dealexp(Node *f){
	Node* tnode[4];
	Node *p = f->firstChild;
	func_node * fn = (func_node *)getfunc(f->firstChild->data.c);
	Node* innernode[4];//用于case内部使用
	switch(expchild(f,tnode)){
		case 1://{"Exp","ASSIGNOP","Exp"}
			if(tnode[0]->val != NULL && tnode[2]->val != NULL){
				if(checkleft(f->firstChild) == false){
					printf_error(6,f->location,NULL,NULL);
				}
				else{
					if(checktype(tnode[0]->val,tnode[2]->val) == false){
						printf_error(5,f->location,NULL,NULL);
					}
				}
			}
			
			break;
		case 2: case 3://Exp AND Exp //Exp OR Exp
			if(tnode[0]->val != NULL && tnode[2]->val != NULL){
				if(tnode[0]->val->kind != basic || tnode[0]->val->u.basic != kint || tnode[2]->val->kind != basic || tnode[2]->val->u.basic != kint){
					printf_error(7,f->location,NULL,NULL);
					f->val = NULL;
				}
			}
			else{
				f->val = NULL;	
			}
			break;
		case 4://Exp RELOP Exp
			if(tnode[0]->val != NULL && tnode[2]->val != NULL){
				if(tnode[0]->val->kind != basic || tnode[2]->val->kind != basic || tnode[0]->val->u.basic != tnode[2]->val->u.basic){
					printf_error(7,f->location,NULL,NULL);
					f->val = NULL;
				}
			}
			else{
				f->val = NULL;//防止出现在IF或WHILE条件中出现多个错误
			}
			break;
		case 5: case 6:case 7: case 8://Exp PLUS Exp //Exp MINUS Exp //Exp STAR Exp //Exp DIV Exp
			if(tnode[0]->val != NULL && tnode[2]->val != NULL){
				if(checktype(tnode[0]->val,tnode[2]->val) == false){
					printf_error(7,f->location,NULL,NULL);	
					f->val = NULL;			
				}
			}
			else{
				f->val = NULL;	
			}	
			break;
		case 9://LP Exp RP
			f->val = tnode[1] -> val;
			break;
		case 10://MINUS Exp
			if(tnode[1]->val->kind != basic){
				printf_error(7,f->location,NULL,NULL);
			}
			f->val = tnode[1] -> val;
			break;
		case 11://NOT Exp//仅有 int 型变量才能进行逻辑运算
			if(tnode[1]->val->kind != basic || tnode[1]->val->u.basic != kint ){
				printf_error(7,f->location,NULL,NULL);
			}
			f->val = tnode[1] -> val;
			break;
		case 12://ID LP Args RP
			

			if(fn == NULL){
				//printf("未定义的函数\n");
				FieldList fvar = (FieldList)getvar(f->firstChild->data.c);
				if(fvar == NULL){
					printf_error(2,f->location,f->firstChild->data.c,NULL);
				}
				else{
					printf_error(11,f->location,f->firstChild->data.c,NULL);
				}
			}
			else{
				FieldList inh = fn->formalargs;
				FieldList arg = tnode[2]->val->u.structure;
				char pri[MAXARGBYTE];
				char ari[MAXARGBYTE];
				if(compareargs(f->firstChild->data.c,inh,arg,pri,ari) == false){
					printf_error(9,f->location,pri,ari);
				} 
				f->val = fn->returnargs;
			}
			break;
		case 13://ID LP RP
			if(fn == NULL){
				//printf("未定义的函数\n");
				FieldList fvar = (FieldList)getvar(f->firstChild->data.c);
				if(fvar == NULL){
					printf_error(2,f->location,f->firstChild->data.c,NULL);
				}
				else{
					printf_error(11,f->location,f->firstChild->data.c,NULL);
				}
				
			}
			else{
				if(fn->formalargs != NULL){

					char pri[MAXARGBYTE];
					char ari[MAXARGBYTE];
					FieldList b = NULL;
					strcat(ari,"()");
					compareargs(f->firstChild->data.c,fn->formalargs,b,pri,ari);
					printf_error(9,f->location,pri,ari);
				}
				f->val = fn->returnargs;
			}
			break;
		case 14://Exp LB Exp RB
			//printf("______________________________in case14 __________\n");
			/*if(expchild(tnode[0],innernode) == 16){//ID
				FieldList arrayvar = (FieldList)getvar(tnode[0]->firstChild->data.c);
				if(arrayvar == NULL){
					printf_error(1,f->location,tnode[0]->firstChild->data.c,NULL);
					f->val = NULL;
				}
				else if(arrayvar->type->kind != array){
					printf_error(10,f->location,tnode[0]->firstChild->data.c,NULL);
					f->val = NULL;
				}
			}
			else if(expchild(tnode[0],innernode) == 14){//数组[]
				if(tnode[0]->val != NULL && tnode[0]->val -> kind != array){
					
					printf("Error type 10 at line %d: the application of dimension of array over the defined\n",f->location);
					f->val = NULL;
				}
			}*/	
			if(expchild(tnode[0],innernode) == 14){//数组[]
				if(tnode[0]->val != NULL && tnode[0]->val -> kind != array){
					
					printf("Error type 10 at line %d: the application of dimension of array over the defined\n",f->location);
					f->val = NULL;
				}
			}
			else if(tnode[0]->val != NULL && tnode[0]->val -> kind != array){
				if(expchild(tnode[0],innernode) == 16){
					printf_error(10,f->location,tnode[0]->firstChild->data.c,NULL);
				}
				else if(expchild(tnode[0],innernode) == 15){
					printf_error(10,f->location,tnode[0]->firstChild->nextSibing->nextSibing->data.c,NULL);
				}
				else{
					printf("Error type 10 at line %d: the var is not an array but used []\n",f->location);
				}
			}
			int expc = expchild(tnode[2],innernode);
			if(expc!= 14 && expc != 17){//处理下标不为整数的情况
				if(tnode[2]->val != NULL){
					if(tnode[2]->val->kind != basic || tnode[2]->val->u.basic != kint){
						printf_error(12,f->location,tnode[0]->firstChild->data.c,NULL);
					}
				}
			}
			if(f->val != NULL){
				//printf("~~~~~~~~~~f->val = f->val->u.array.elem->kind:%d\n",f->val->u.array.elem->kind);
				
				if(f->val->kind == array){
					tnode[0]->val = f->val->u.array.elem;
					f->val = f->val->u.array.elem;
				}
				
			}
			//printf("______________________________out case14 __________\n");
			break;
		case 15://Exp DOT ID
			//printf("______________________________in case15 __________\n");
			if(tnode[0]->val != NULL){
				//printf("________________111______________in case15 __________\n");
				
				//printf("tnode[0]->val->kind:%d\n",tnode[0]->val->kind);
				//FieldList test = (FieldList)getvar(tnode[0]->firstChild->data.c);
				//printf("tnode[0]->firstChild->data.c:%s~~~:%d~~%d\n",tnode[0]->firstChild->data.c,test->type->kind,tnode[0]->firstChild->val->kind);
				if(tnode[0]->val->kind != structure){
					printf_error(13,f->location,NULL,NULL);
				}
				else{//若前面不是结构，则无需进行后面的域检查
					//printf("________in case15 __________\n");
					FieldList field = NULL;
					if(strlen(tnode[0]->val->u.structure->name) != 0){
						
						FieldList structvar = (FieldList)getstructure(tnode[0]->val->u.structure->name);
						field = structvar->type->u.structure->innerlink;
						for(field = structvar->type->u.structure->innerlink; field != NULL; field = field->innerlink){
							if(strcmp(field->name,tnode[2]->data.c) == 0){
								f->val = field->type;
								break;
							}
						}
						if(field == NULL){
							printf_error(14,f->location,tnode[2]->data.c,NULL);
							f->val = NULL;
						}

						
					}
					else{//匿名结构类
						field = tnode[0]->val->u.structure->type->u.structure;
						//printf("tnode[0]->val->u.structure->type->u.structure->name",tnode[0]->val->u.structure->type->u.structure->name);
						for(field = tnode[0]->val->u.structure->type->u.structure; field != NULL; field = field->innerlink){
							
							if(strcmp(field->name,tnode[2]->data.c) == 0){
								f->val = field->type;
								break;
							}
						}
						if(field == NULL){
							printf_error(14,f->location,tnode[2]->data.c,NULL);
						}
						
					}
					
				}
			}
			
			break;
		case 16://ID
			//Node *p = f->firstChild;
			//printf("________in case16 __________\n");
			if(strcmp(p->name,"ID") == 0 && (p->nextSibing != NULL && strcmp(p->nextSibing->name,"LP") == 0)&&(p->nextSibing->nextSibing != NULL && strcmp(p->nextSibing->nextSibing->name,"Args") == 0)){//函数节点
				/*func_node fn = getfunc(f->firstChild->data.c);
				if(fn != NULL){//将ID的属性附成指向函数参数的指针!!!!!!!!!!!!!!!!还没有考虑对Exp的赋值，还没有相到返回值
					Type typenode = (Type)malloc(sizeof(struct Type_));
					f->firstChild->val = typenode;
					f->firstChild->val.kind = structure;
					f->firstChild->val.u.structure = formalargs;
				}*/
			}				
			else{//若不是函数名，则从变量表中进行查找
				
				FieldList g = (FieldList)getvar(f->firstChild->data.c);
				//printf("!!!!!!!!!!!!f->firstChild->data.c:%s\n",f->firstChild->data.c);
				//printf("!!!!!!!!!!!!g->kind:%d\n",g->type->kind);
				if(g != NULL){
					f->val = g->type;//将exp的属性附成对应的变量在符号表中的属性
					tnode[0]->val = g->type;//将ID的属性附成对应的变量在符号表中的属性
				}
				else{
					
					f->val = NULL;
					printf_error(1,f->location,f->firstChild->data.c,NULL);
				}
			}
				
			break;
		case 0:
			break;
		default:
			break;
	}
}


boolean checkleft(Node *exp){//左值检查
	//printf("+++++++++++in check left++++++++\n");
	
		Node* tnode[4];
		int t = expchild(exp,tnode);
		
		if(t != 16 && t != 14 && t!= 15){
			return false;
		}
		else if(exp->val != NULL && exp->val->kind == array){
			return false;
		}
		
	return true;
}
boolean comparechild(char* Name[],int num,Node* child[],Node *f){
	int i = 0;
	Node *t = f->firstChild;
	for(t = f->firstChild; t !=NULL; t = t->nextSibing){
		child[i] = t;
		if(strcmp(t->name,Name[i]) != 0){
			break;
		}
		i ++;
	}
	if(i == num){
		return true;
	}
	else{
		return false;
	}
}
void printfargs(Type t[],int num,char *pri){
	//printf("in printfargs\n");
	strcat(pri,"(");
	int i = 0;
	for(i = 0; i < num; i ++){
		if(i > 0){
			strcat(pri,",");
		}
		if(t[i]->kind == basic){
			if(t[i]->u.basic == kint){
				strcat(pri,"int");
			}
			else if(t[i]->u.basic == kfloat){
				strcat(pri,"float");
			}
		}
		else if(t[i]->kind == array){
			Type tq = (Type)malloc(sizeof(struct Type_));
			memset(tq,0,sizeof(struct Type_));
			int tsize = arraysize(t[i],tq);
			strcat(pri,"array");
			int j = 0;
			for(j = 0; j <= tsize; j ++){
				strcat(pri,"[]");
			}
			
		}
		else if(t[i]->kind == structure){
			strcat(pri,"struct");
			strcat(pri,t[i]->u.structure->name);
		}
	}
	strcat(pri,")");
	//printf("out printfargs\n");
}


//!!!!!!!!!!!!!!!!!!!!!注意:使用该函数时一定要保证t!= NULL
int arraysize(Type b,Type t){
	Type q = b->u.array.elem;
	int fsize = 0;
	Type p = NULL;
	for(q = b->u.array.elem; q -> kind == array; p = q,q = q->u.array.elem){
		fsize ++;
	}
	t->kind = q->kind;
	if(t->kind == basic){
		t -> u.basic = q->u.basic;
	}
	else if(t->kind == array){
		t->u.array.elem = q->u.array.elem;
		t->u.array.size = q->u.array.size;
	}
	else if(t->kind == structure){
		t->u.structure = q->u.structure;
	}
	return fsize;
}

boolean checktype(Type a,Type b){
	//printf("in checktype\n");				
	if(a->kind == b->kind ){
		
		if(a->kind == basic && a->u.basic != b->u.basic){//基本类型
			//printf("in basic\n");
			//printf("Error type 5 at line %d: Type mismatched",location);
			if(a->u.basic != b->u.basic){
				return false;
			}
		}
		else if(a->kind == array){//数组类型
			//printf("in array\n");
			/*Type t = a->u.array.elem;
			int esize = a->u.array.size;
			for(t = a->u.array.elem; t -> kind == array; t = t->u.array.elem){
				esize *= t->u.array.size;
			}*/
			Type tq = (Type)malloc(sizeof(struct Type_));
			memset(tq,0,sizeof(struct Type_));
			int esize = arraysize(a,tq);
			//printf("esize:%d\n",esize);
			/*Type q = b->u.array.elem;
			int fsize = b->u.array.size;
			for(q = b->u.array.elem; q -> kind == array; q = q->u.array.elem){
				fsize *= q->u.array.size;
			}*/
			Type tp = (Type)malloc(sizeof(struct Type_));
			memset(tp,0,sizeof(struct Type_));
			int fsize = arraysize(b,tp);
			//printf("fsize:%d\n",fsize);
			if(esize != fsize){
				//printf("Error type 5 at line %d: Type mismatched",location);
				return false;
			}
			else{
				
				if(checktype(tq,tp) == false){
					return false;
				}
			}
		}
		else if(a->kind == structure){//结构类型
			//printf("in structure\n");
			if(a->u.structure != NULL && b->u.structure != NULL){
				
				if(strlen(a->u.structure->name) != 0 && strlen(b->u.structure->name) != 0){//有名字的结构体实现名等价
					/*printf("a->u.structure->kind:%d\n",a->u.structure->type->kind);
					printf("b->u.structure->kind:%d\n",b->u.structure->type->kind);
					printf("a->u.structure->name:%s:%d\n",a->u.structure->name,strlen(a->u.structure->name));
					printf("b->u.structure->name:%s:%d\n",b->u.structure->name,strlen(b->u.structure->name));*/
					if(strcmp(a->u.structure->name,b->u.structure->name) != 0){
						//printf("Error type 5 at line %d: Type mismatched",location);
						return false;
					
					}
					
				}
				else{
					FieldList y = a->u.structure->type->u.structure;
					//printf("y->name:%s\n",y->name);
					FieldList x = b->u.structure->type->u.structure;
					//printf("x->name:%s\n",x->name);
					char pri[MAXARGBYTE];
					char ari[MAXARGBYTE];
					boolean k = compareargs("noname",x,y,pri,ari);
					return k;
				}
			}
			else{
				/*if(a->u.structure == NULL){
					printf("a->u.structure == NULL\n");
				}
				if(b->u.structure == NULL){
					printf("b->u.structure == NULL\n");
				}*/
			}
		}
		else{
			/*printf("~~a->kind:%d\n",a->kind);
			printf("~~b->kind:%d\n",b->kind);*/
		}
		
						
	}
	else{
		/*printf("*else type check**\n");
		printf("a->kind :%d\n",a->kind );
		printf("b->kind :%d\n",b->kind);*/
		//printf("Error type 5 at line %d: Type mismatched",location);*/
		return false;
		
	}
	return true;
}


int structureindex(FieldList structure){//返回值为结构体大小
	int index = 0;
	int count = 0;
	FieldList p = structure;
	for(;p!= NULL; p = p->innerlink){
		p->index = index;
		count = count +  sizeoftype(p->type);
		index = count;
	}
	return count;
}


int sizeoftype(Type type){
	if(type->kind == basic){
		return 4;
	}
	else if(type->kind == array){
		return type->u.array.size * sizeoftype(type->u.array.elem);
	}
	else if(type->kind == structure){
		return type->u.structure->index;
	}
	else{
		return 0;
	}
}


int argnumber(char *funcname){	
	int j = 0;
	//printf("before\n");
	func_node *fn = getfunc(funcname);
	FieldList inh = fn->formalargs;
	for(;inh!= NULL; inh = inh->innerlink){
		j ++;
	}
	return j;
}



boolean compareargs(char *name,FieldList inh, FieldList arg,char *pri,char *ari){//inh指符号表中的参数，arg指实际调用时的参数,pri表示inh的参数,ari表示arg参数
	//printf("in compareargs\n");
	Type tarray_inh[MAXARGS];
	Type tarray_arg[MAXARGS];
	int i = 0;
	for(i = 0; i < MAXARGS; i ++){
		tarray_inh[i] = NULL;
		tarray_arg[i] = NULL;
	}
	i = 0;
	
	for(;arg!= NULL; arg = arg->innerlink){
		tarray_arg[i] = arg->type;
		i ++;
	}
	
								
	int j = 0;
	//printf("before\n");
	for(;inh!= NULL; inh = inh->innerlink){
		tarray_inh[j] = inh ->type;
		j ++;
	}
	//printf("after\n");							
	if(i != j){
		//printf("函数参数不匹配\n");
		memset(pri,0,MAXARGBYTE);
		strcat(pri,name);
		printfargs(tarray_inh,j,pri);
		// arg
		memset(ari,0,MAXARGBYTE);
		printfargs(tarray_arg,i,ari);
		//printf_error(9,f->location,pri,ari);
		return false;
	}
	else{
		int k = 0;
		for(k = 0; k < i; k ++){
			if(checktype(tarray_inh[k],tarray_arg[k]) == false){
				break;
			}
									
		}
		if(k != i){
										
			//inh
			
			
			memset(pri,0,MAXARGBYTE);	
			strcat(pri,name);
			printfargs(tarray_inh,i,pri);
			// arg
			
			memset(ari,0,MAXARGBYTE);
			strcat(ari,name);
			printfargs(tarray_arg,i,ari);
			//printf_error(9,f->location,pri,ari);
			return false;
									
		}
		
	}
	return true;
	//printf("out compareargs\n");
}




void printf_error(int kind,int location,char * name,char *args){
	switch(kind){
		case 1:
			printf("Error type 1 at line %d: Undefined variable \"%s\"\n",location,name);
			break;
		case 2:
			printf("Error type 2 at line %d: Undefined function \"%s\"\n",location,name);
			break;
		case 3:
			printf("Error type 3 at line %d: Redefined variable \"%s\"\n",location,name);
			break;
		case 4:
			printf("Error type 4 at line %d: Redefined function \"%s\"\n",location,name);
			break;
		case 5:
			printf("Error type 5 at line %d: Type mismatched\n",location);
			break;
		case 6:
			printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n",location);
			break;
		case 7:
			printf("Error type 7 at line %d: Operands type mismatched\n",location);
			break;
		case 8:
			printf("Error type 8 at line %d: The return type mismatched\n",location);
			break;
		case 9:
			printf("Error type 9 at line %d: The method \"%s\" is not applicable for the arguments \"%s\"\n",location,name,args);
			break;
		case 10:
			printf("Error type 10 at line %d: \"%s\" must be an array\n",location,name);
			break;
		case 11:
			printf("Error type 11 at line %d: \"%s\" must be a function\n",location,name);
			break;
		case 12:
			printf("Error type 12 at line %d: Operands type mistaken\n",location);
			break;
		case 13:
			printf("Error type 13 at line %d: Illegal use of \".\"\n",location);
			break;
		case 14:
			printf("Error type 14 at line %d: Un-existed field \"%s\"\n",location,name);
			break;
		case 15:
			printf("Error type 15 at line %d: Redefined field \"%s\"\n",location,name);
			break;
		case 16:
			printf("Error type 16 at line %d: Duplicated name \"%s\"\n",location,name);
			break;
		case 17:
			printf("Error type 17 at line %d: Undefined struct \"%s\"\n",location,name);
			break;
		case 18:
			printf("Error type 18 at line %d: Undefined function \"%s\"\n",location,name);
			break;
		case 19:
			printf("Error type 19 at line %d: Inconsistent declaration of function \"%s\"\n",location,name);
			break;
		default:
			break;
	}
	
}
