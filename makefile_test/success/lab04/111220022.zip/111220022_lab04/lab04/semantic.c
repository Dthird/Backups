#include "type.h"
#include<stdio.h>
#include<string.h>
#include <unistd.h>
#include <stdlib.h>
#include <ctype.h>
//变量表
FieldList var_table[SYMBOL_TABLE_NUM];

//结构表
FieldList structure_table[SYMBOL_TABLE_NUM];

//函数表
func_node* func_table[SYMBOL_TABLE_NUM];

declare_node* dhead = NULL;
declare_node* dtail = NULL;

boolean insertdeclare(declare_node* dn){//
	if(dhead == NULL){
		dhead = dtail = dn;
	}
	else{
		dtail -> next = dn;
		dtail = dn;
		dtail ->next = NULL;
	}
}

boolean deleatedeclarenode(char* name){
	declare_node * p = dhead;
	declare_node * q = NULL;
	for(p = dhead; p != NULL; q = p,p = p->next){
		if(strcmp(name,p->name) == 0){
			if(q != NULL){
				q->next = p->next;
			}
			else{
				dhead = p->next;
			}
			break;
		}
	}
	if(p == NULL){
		return false;
	}
	return true;
}

unsigned int hash_pjw(char* name)
{
	unsigned int val = 0, i;
	for (; *name; ++name)
	{
		val = (val << 2) + *name;
		if (i = val & ~0x3fff) val = (val ^ (i >> 12)) & 0x3fff;
	}
	return val;
}

//初始表符号表
void inittable(){
	int i = 0;
	for(i = 0; i < SYMBOL_TABLE_NUM; i ++){
		var_table[i] = NULL;
	}
	for(i = 0; i < SYMBOL_TABLE_NUM; i ++){
		structure_table[i] = NULL;
	}
	for(i = 0; i < SYMBOL_TABLE_NUM; i ++){
		func_table[i] = NULL;
	}
}


//在变量表中查找节点 
FieldList getvar(char *name){
	//printf("in getvar:%s\n",name);
	int index = hash_pjw(name);
	FieldList p  = var_table[index];
	for(p = var_table[index]; p !=NULL; p = p->next){
		//printf("~~~~~~~~~name:%s",p->name);
		if(strcmp(p->name,name) == 0){
			return p;
		}
	}
	return NULL;
}

//在结构表中查找节点
FieldList  getstructure(char *name){
	
	int index = hash_pjw(name);
	
	FieldList p  = structure_table[index];
	
	for(p = structure_table[index]; p !=NULL; p = p->next){
		if(strcmp(p->name,name) == 0){
			
			return p;
		}
	}
	return NULL;
}

//在函数表中查找节点
func_node* getfunc(char *name){
	int index = hash_pjw(name);
	func_node* p  = func_table[index];
	for(p = func_table[index]; p !=NULL; p = p->next){
		if(strcmp(p->name,name) == 0){
			return p;
		}
	}
	return NULL;
}

//向变量表中加入节点
boolean insertvar(FieldList node){
	
	// judge symboltable if has the same name struct
	if(getvar(node->name) == NULL){
		int index = hash_pjw(node->name);
		FieldList  p  = NULL;
		if(var_table[index] == NULL){
			var_table[index] = node;
			// for test
			//printf("var_table[index]->name:%s\n",var_table[index]->name);
			//printf("var_table[index]->kind:%d\n",var_table[index]->type->kind);
		}
		else{//insert into the tail of link
			for(p = var_table[index]; p ->next!=NULL; p = p->next);
			p->next = node;
			node ->next = NULL;
		}
		return true;
	}
	else{
		return false;
	}
}
//向结构表中加入节点
boolean insertstructure(FieldList node){
	
	// judge symboltable if has the same name struct
	if(getstructure(node->name) == NULL){
		int index = hash_pjw(node->name);
		FieldList  p  = NULL;
		if(structure_table[index] == NULL){
			structure_table[index] = node;
		}
		else{//insert into the tail of link
			for(p = structure_table[index]; p ->next != NULL; p = p->next);
			p->next = node;
			node ->next = NULL;
		}
		return true;
	}
	else{
		return false;
	}
}

//向函数表中加入节点
boolean insertfunc(func_node * node){
	// judge symboltable if has the same name struct
	if(getfunc(node->name) == NULL){
		int index = hash_pjw(node->name);
		func_node *p  = NULL;
		if(func_table[index] == NULL){
			func_table[index] = node;
		}
		else{//insert into the tail of link
			for(p = func_table[index]; p ->next !=NULL; p = p->next);
			p->next = node;
			node ->next = NULL;
		}
		return true;
	}
	else{
		return false;
	}
}

