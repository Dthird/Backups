int main()
 {
 int a[3];
 int b;
 a[0] = 5;

a[1] = 8;
a[2] = 6;
 b = a[0] + a[1] + a[2];
 write(b);
 return 0;

}

