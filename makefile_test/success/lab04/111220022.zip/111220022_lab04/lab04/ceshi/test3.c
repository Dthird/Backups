int main()
 {
 int i = 20;
 while(i>5) {
 write(i);
 i = i-1;
 }
 return 0;
}

