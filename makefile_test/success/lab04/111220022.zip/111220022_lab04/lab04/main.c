#include <stdio.h>
#include "huibian.h"
#include <stdlib.h>

extern mark;
extern yydebug;
#define MAXNAME 32
/*union type{
	int i;
	float f;
	char c[MAXNAME];
};
typedef struct Node{
	char name[MAXNAME];
	union type data;
	struct Node* firstChild;
	struct Node* nextSibing;
	Type inh;
        Type val;
	int location;
		 
}Node;*/
	
extern Node *root;
extern MipsCodes* mhead;

void PreOrder(Node *p,int h);
#define MAXNAME 32
	
int main(int argc, char** argv)
{
	if (argc <= 2) return 1;
	FILE* f = fopen(argv[1], "r");
	if (!f)
	{
		perror(argv[1]);
		return 1;
	}
	
	yyrestart(f);
	
	 // yylloc.first_line = yylloc.last_line = 1;
	 // yylloc.first_column = yylloc.last_column = 0;
	 //yydebug = 1;

	if(yyparse()==0){
		printf("There is not any syntax error!\n");
	}

	inittable();//初始化符号表
	IRinit();
	Node *p = root;
	if(mark == 0){
		
		PreOrder_syn(p,0);
	}
	//printf("there is not any syntax error\n");
	p = root;
	
	PreOrder_ir(p,0);
	InterCodes* head1 = head;
	//optimizelabel(head1);
	//optimizedigital(head1);
	
	InterCodes* head2 = head;
	//delete_tat(head2);
	//delete_tac(head2);
	
	//display_ir(head,argv[2]);	
	
	//生成汇编代码
	initreg();
	
	
	FILE *fp = fopen(argv[2],"w");
	createmips(head);
	if(mhead == NULL){
		printf("mhead = NULL\n");
	}
	fprintf(fp,".data\n_prompt: .asciiz \"Enter an integer:\"\n_ret: .asciiz \"\\n\"\n.globl main\n.text\nread:\n	li $v0, 4\n	la $a0, _prompt\n	syscall\n	li $v0, 5\n	syscall\n	jr $ra\nwrite:\n	li $v0, 1\n	syscall\n	li $v0, 4\n	la $a0, _ret\n	syscall\n	move $v0, $0\n	jr $ra\n");
	displaymips(mhead,fp);
	
	return 0;
}


void PreOrder(Node *p,int h){
	
	if(p != NULL){
		h ++;
		int i = 1;
		for(i = 1; i < h; i ++){
			printf("  ");
		}
		
		if(strcmp(p->name,"RELOP") == 0){
			printf("%s\n",p->data.c);
		}
		else if(strcmp(p->name,"TYPE") == 0){
			printf("TYPE : %s\n",p->data.c);
		}
		else if(strcmp(p->name,"INT") == 0){
			printf("INT : %d\n",p->data.i);
		}
		else if(strcmp(p->name,"FLOAT") == 0){
			printf("FLOAT : %lf\n",p->data.f);
		}
		else if(strcmp(p->name,"ID") == 0){
			if(p->inh != NULL){
				printf("ID : %s ----- %d\n",p->data.c,p->val->kind);
			}
			else{
				printf("ID : %s\n",p->data.c);
			}
		}
		else{
			if(p->firstChild!= NULL){
				printf("%s (%d)\n",p->name,p->location);
			}
			else{
				
				printf("%s\n",p->name);

				
			}
		}
		
		Node *f = p;	
		for(p = p->firstChild; p != NULL; p = p->nextSibing){
			//printf("firstchild:%s\n",p->firstChild->name);
			
			PreOrder(p,h);
		}
		
	}
	else{
		h = 0;
		printf("root = NULL\n");
	}
}
