#ifndef __COMPILE_H__
#define __COMPILE_H__

#include "rbtree.h"
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

/** 语法分析*/
typedef struct TreeNode
{
	int i_value;
	float f_value;
	int line;
	char *id;        // to record the value of the id, such as "main", "i"
	char *type;	 // to record the type of the token, such as "SEMI", "ID"
	int mark;	//用于语义分析，判断是否遍历过
	struct TreeNode *firstChild;
	struct TreeNode *nextSibling;
} Node;

Node* create(int lineno, char *value, char *token);
Node *insertSibling(Node *first, Node *next);
Node *insertChild(Node *parent, Node *child);
int isToken(char type[]);
void printSyntaxTree(Node *root, int depth);

/** 语义分析*/
//类型定义
typedef struct Type_* Type;
typedef struct FieldList_* FieldList;
typedef struct TypeList_* TypeList;
typedef struct Symbol_* Symbol;

struct Type_
{
	enum { basic, array, structure } kind;
	union
	{
		// 基本类型，认为1是int类型，2是float类型
		int basic;
		// 数组类型信息包括元素类型与数组大小构成
		struct { Type elem; int size; } array;
		// 结构体类型信息是一个链表
		FieldList structure;
	} u;
	char *name;		//用于记录struct类型的名字
};

struct FieldList_
{
	char* name;	// 域的名字
	Type type;	// 域的类型
	FieldList tail;	// 下一个域
};

struct TypeList_	//struct型的类型定义表节点
{
	char* name;	//类型的名字
	int size;	//type类型的大小
	FieldList tail;		//类型里的内容
	TypeList next;
};

struct Symbol_		//符号表的类型
{
	enum { var, func } kind;	//符号类型
	char *name;	//变量的名字
	int num;	//变量的下表（用于中间代码的生成）
	union
	{
		Type type;	//域的类型
		struct 
		{ 
			Type return_type;	//返回值类型
			int num;	//参数个数
			FieldList first;	//参数类型
		} func;
	} u;
	int flag;		//用于区分struct结构体是作为参数传递（1）还是参数使用（0）
};

struct mynode 
{
	struct rb_node node;
	Symbol sign;
};

//表定义
TypeList struct_list;
extern struct rb_root mytree;	//符号表根节点

//函数声明
int my_search(struct rb_root *root, char *string, Symbol sign);
int my_insert(struct rb_root *root, struct mynode *data);
void my_free(struct mynode *node);
void printVar(Type type);
void printStruct(TypeList structure);
int equalType(Type t1, Type t2);
int equalStruct(FieldList structure1, FieldList structure2);
int searchStruct(char *name, FieldList field);
void judgeType(Type type, Node * node);
void insertVarDec(Type type, Node * VarDec, int mark);		//mark用来区分是参数还是普通变量
void insertExtDecList(Type type, Node * node);
void insertDecList(Type type, Node * DecList);
void insertFunDec(Type type, Node * FunDec);
void dealArgs(FieldList func, Node * Args);
int judgeValue(Node * Exp);
int searchStructName(FieldList structure, char *name, Type type);
void dealExp(Type type, Node * Exp);
void traverse(Node * root);

/** 中间代码的生成*/
//类型定义
typedef struct Operand_* Operand;

struct Operand_ 
{
	enum { VARIABLE, CONSTANT, ADDRESS_T, ADDRESS_V, TEMP, LABEL, OP, MEM_T, MEM_V } kind;
	union 
	{
		int var_no;
		int value;
		int temp_no;
		int label_no;
		int op_kind;	// 0: ==, 1: !=, 2: <, 3: >, 4: <=, 5: >=
	} u;
	int flag;		//该标志位与符号表中的标志位同步
};

struct InterCode
{
	enum { DEF_LABEL, FUNCTION, ASSIGN, ADD, SUB, MUL, DIVI, GOTO_LABEL, GOTO_CON, RETURN_OP, DEC, ARG, CALL, PARAM, READ, WRITE, LABEL_CODE, NOTH } kind;	//NOTH为空类型，看见它时不处理
	union 
	{
		struct { Operand label; } labelop;			//定义标签
		struct { char *name; } func;				//定义函数
		struct { Operand left, right; } assign;			//赋值操作
		struct { Operand result, op1, op2; } binop;		//二元操作
		struct { Operand goto_label; } gotoop;			//无条件跳转
		struct { Operand op1, op, op2, label; } goto_con;	//条件跳转
		struct { Operand op; } returnop;			//函数返回
		struct { Operand op; int size; } dec;			//内存块声明
		struct { Operand arg; } arg;				//参数传递
		struct { Operand place; char *name; } callop;		//函数调用
		struct { Operand param; } param;			//设置参数
		struct { Operand op; } read;
		struct { Operand op; } write;
		struct { Operand label; } label_code;
	} u;
};

//表定义（双向链表）
struct InterCodes 
{ 
	struct InterCode code; 
	struct InterCodes *prev, *next; 
};

//参数列表定义（用链表实现）
struct ArgList
{
	struct Operand_ arg;
	struct ArgList *next;
};

//全局变量的定义
FILE *file;		//用于创建.ir文件
struct InterCodes *head;	//双向链表的头部，用于中间代码的打印

//函数声明
void preDeal();			//对符号表的预处理，添加两个成员
void addcode(struct InterCodes *code1, struct InterCodes *code2);
void deletecode(struct InterCodes *code);		//删除链表中的节点
Operand new_temp();
Operand new_label();
Operand lookup(Node *ID);
Type lookupType(Node *ID);		//返回该ID的类型
int lookupSize(Type type, int size);		//返回struct所占空间的大小
int lookupOffset(Type type, Node *ID, int offset);		//返回结构体内的偏移量
char *lookupfunc(Node *ID);
int get_size(char *name);		//得到struct类型的大小
Operand get_value(int value);
Operand get_relop(Node *RELOP);
struct InterCodes *gen_assign(Operand left, Operand right);
struct InterCodes *gen_bin(Operand result, Operand op1, Operand op2, int kind);		//kind用来标记进行哪种操作
struct InterCodes *gen_label(Operand label);
struct InterCodes *gen_return(Operand op);
struct InterCodes *gen_goto(Operand label);
struct InterCodes *gen_con(Operand op1, Operand op, Operand op2, Operand label);
struct InterCodes *gen_read(Operand op);
struct InterCodes *gen_call(Operand place, char *name);
struct InterCodes *gen_write(Operand op);
struct InterCodes *gen_arg(Operand arg);
struct InterCodes *gen_func(char *name);
struct InterCodes *gen_param(Operand param);
struct InterCodes *gen_dec(Operand var, int size);
struct InterCodes *gen_null();
struct InterCodes *translate_Args(Node *Args, struct ArgList **arg_list);
struct InterCodes *translate_Cond(Node *Exp, Operand label_true, Operand label_false);
struct InterCodes *translate_Exp(Node *Exp, Operand place);
struct InterCodes *translate_VarDec(Node *VarDec);
struct InterCodes *translate_Dec(Node *Dec);
struct InterCodes *translate_DecList(Node *DecList);
struct InterCodes *translate_DefList(Node *DefList);
struct InterCodes *translate_CompSt(Node *CompSt);
struct InterCodes *translate_Stmt(Node *Stmt);
struct InterCodes *translate_VarList(Node *VarList);
struct InterCodes *translate_FunDec(Node *FunDec);
struct InterCodes *translate_ExtDef(Node *ExtDef);
struct InterCodes *translate_ExtDefList(Node *ExtDefList);
void traverseForIR(Node *root);
void optimizeTemp();		//对产生的双向链表进行优化，优化减少临时变量
void printLabel(struct InterCodes *iptimcode);
void printFunc(struct InterCodes *icode);
void printAssign(struct InterCodes *icode);
void printBin(struct InterCodes *icode);
void printGotoLabel(struct InterCodes *icode);
void printGotoCon(struct InterCodes *icode);
void printReturn(struct InterCodes *icode);
void printDec(struct InterCodes *icode);
void printArg(struct InterCodes *icode);
void printCall(struct InterCodes *icode);
void printParam(struct InterCodes *icode);
void printRead(struct InterCodes *icode);
void printWrite(struct InterCodes *icode);
void printIR();

/** 机器代码生成，会复用中间代码部分定义的数据结构*/
struct Offset		//用来记录相对于$fp的偏移
{
	struct Operand_ op;
	int num;
	struct Offset *prev;
	struct Offset *next;
};

struct Offset *begin;		//偏移开始
struct Offset *current;		//当前偏移
struct Offset *next;		//下一个偏移位置

int return_func_count();	//返回函数个数
void init_offset();
int find_offset(Operand op);		//找到当前偏移
void allocate(Operand op);		//给变量初始化偏移位置
void load(Operand op, char *reg_name);		//将内存中的内容取出放在寄存器中
void store(Operand op, char *reg_name);		//将寄存器中的内容放在内存中
void init();			//用于一开始的申请空间与全局函数main的声明并产生read函数的机器代码和产生write函数的机器代码
void print_func(struct InterCodes *code);
void print_assign(struct InterCodes *code);
void print_bin(struct InterCodes *code);
void print_goto_label(struct InterCodes *code);
void print_goto_con(struct InterCodes *code);
void print_return(struct InterCodes *code);
void print_arg(struct InterCodes *code);
void print_param(struct InterCodes *code);
void print_call(struct InterCodes *code);
void print_label(struct InterCodes *code);
void print_read(struct InterCodes *code);
void print_write(struct InterCodes *code);
void printMC();			//产生机器代码，输出到文件中去

#endif
