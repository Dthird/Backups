#include <stdio.h>
#include "compile.h"

extern FILE* yyin;
extern int yylineno;
extern int mark;
extern FILE* file;

int main(int argc, char** argv)
{
//	if (argc <= 1) return 1;
	if (argc <= 2)
	{
		printf("Too few arguments!\n");
//		printf("Usage: ./parser file.c file.ir");
		printf("Usage: ./parser file.c file.s");
		return 1;
	}
	FILE* f = fopen(argv[1], "r");
	file = fopen(argv[2], "w+");
	if (!f)
	{
		perror(argv[1]);
		return 1;
	}
	else if (!file)
	{
		perror(argv[2]);
		return 1;
	}
	yyrestart(f);
//	yydebug = 1;
	yyparse();
	return 0;
}

yyerror(char *msg)
{
	mark = 1;
	fprintf(stderr, "Error type B at line %d: %s\n", yylineno, msg);
}
