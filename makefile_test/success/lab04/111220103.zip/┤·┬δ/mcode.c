#include "compile.h"

char arg_param[10][4] = {"$a0", "$a1", "$a2", "$a3", "$t4", "$t5", "$t6", "$t7", "$t8", "$t9"};

void init_offset()
{
	begin = (struct Offset*)malloc(sizeof(struct Offset));
	begin->num = -1;
	begin->prev = begin;
	begin->next = begin;
	current = begin;
}

int find_offset(Operand op)
{
	struct Offset *start = begin;
	do		//找到需要操作的变量在内存中的位置
	{
		if(start->op.u.temp_no == op->u.temp_no)
		{
			if(start->op.kind == TEMP)
			{
				if(op->kind == ADDRESS_T || op->kind == TEMP)
					return start->num;
			}
			else if(start->op.kind == ADDRESS_T)
			{
				if(op->kind == ADDRESS_T || op->kind == TEMP)
					return start->num;
			}
			else if(start->op.kind == VARIABLE)
			{
				if(op->kind == VARIABLE || op->kind == MEM_V)
					return start->num;
			}
			else if(start->op.kind == MEM_V)
			{
				if(op->kind == VARIABLE || op->kind == MEM_V)
					return start->num;
			}
		}
		start = start->next;
	}while(start != current);
	return -1;
}

void allocate(Operand op)
{
	if(op->kind == CONSTANT)
		return;
	else if(find_offset(op) == -1)	//表示该变量还未分配空间
	{
		if(begin->num == -1)		//表示此时没有给任何变量赋值
		{
			begin->num = 1;
			memcpy(&begin->op, op, sizeof(struct Operand_));
			current = (struct Offset*)malloc(sizeof(struct Offset));
			current->num = begin->num + 1;
			begin->next = current;
			current->prev = begin;
		}
		else
		{
			memcpy(&current->op, op, sizeof(struct Operand_));
			next = (struct Offset*)malloc(sizeof(struct Offset));
			next->num = current->num + 1;
			current->next = next;
			next->prev = current;
			current = next;
		}
	}
	else
		return;
}

void load(Operand op, char *reg_name)		//将内存中的内容取出放在寄存器中
{
	if(op->kind == CONSTANT)
		fprintf(file, "\tli %s, %d\n", reg_name, op->u.value);
	else
	{
		int offset = find_offset(op);
		if(offset != -1)
		{
			if(op->kind == TEMP || op->kind == VARIABLE)
				fprintf(file, "\tlw %s, -%d($fp)\n", reg_name, offset * 4);
			else if(op->kind == ADDRESS_T)
			{
				fprintf(file, "\tlw $t3, -%d($fp)\n", offset * 4);//先将地址值取出放在寄存器中（三地址表达式，保留寄存器$t3）
				fprintf(file, "\tlw %s, 0($t3)\n", reg_name);
			}	
			else if(op->kind == MEM_V)
			{
				fprintf(file, "\tli $t3, %d\n", offset * 4);
				fprintf(file, "\tsub %s, $fp, $t3\n", reg_name);
			}
		}
	}
}

void store(Operand op, char *reg_name)		//将寄存器中的内容放在内存中
{
	int offset = find_offset(op);
	if(offset != -1)
	{
		if(op->kind == TEMP || op->kind == VARIABLE)
			fprintf(file, "\tsw %s, -%d($fp)\n", reg_name, offset * 4);
		else if(op->kind == ADDRESS_T)
		{
			fprintf(file, "\tlw $t3, -%d($fp)\n", offset * 4);	//先将地址值取出放在寄存器中
			fprintf(file, "\tsw %s, 0($t3)\n", reg_name);
		}
	}
}

void init()
{
	fputs(".data\n", file);
	fputs("_prompt: .asciiz \"Enter an integer:\"\n", file);
	fputs("_ret: .asciiz \"\\n\"\n", file);
	fputs(".globl main\n", file);
	fputs(".text\n", file);
	fputs("read:\n", file);
	fputs("\tli $v0, 4\n", file);
	fputs("\tla $a0, _prompt\n", file);
	fputs("\tsyscall\n", file);
	fputs("\tli $v0, 5\n", file);
	fputs("\tsyscall\n", file);
	fputs("\tjr $ra\n", file);
	fputs("\nwrite:\n", file);
	fputs("\tli $v0, 1\n", file);
	fputs("\tsyscall\n", file);
	fputs("\tli $v0, 4\n", file);
	fputs("\tla $a0, _ret\n", file);
	fputs("\tsyscall\n", file);
	fputs("\tmove $v0, $0\n", file);
	fputs("\tjr $ra\n", file);
}

void print_func(struct InterCodes *code)
{
	//释放空间
	struct Offset *start = begin;
	while(start != current)
	{
		next = start->next;
		free(start);
		start = next;
	}
	free(start);
	init_offset();

	fprintf(file, "\n%s:\n", code->code.u.func.name);
	if(strcmp(code->code.u.func.name, "main") == 0)
		fputs("\tmove $fp, $sp\n", file);
	//将$sp下移（移动足够大的空间，保证可以给活动记录提供足够大的空间）
	fputs("\taddi $sp, $sp, -1024\n", file);
}

void print_assign(struct InterCodes *code)
{
	Operand left = code->code.u.assign.left;
	Operand right = code->code.u.assign.right;

	allocate(left);
	allocate(right);	

	load(right, "$t0");		//将值从内存取出放在寄存器里
	store(left, "$t0");		//将寄存器里的值放回内存中
}

void print_bin(struct InterCodes *code)
{
	Operand result = code->code.u.binop.result;
	Operand op1 = code->code.u.binop.op1;
	Operand op2 = code->code.u.binop.op2;
	
	allocate(op1);
	allocate(op2);
	allocate(result);

	load(op1, "$t0");
	if(code->code.kind == ADD)
	{
		if(op2->kind == CONSTANT)
			fprintf(file, "\taddi $t2, $t0, %d\n", op2->u.value);
		else
		{
			load(op2, "$t1");
			fputs("\tadd $t2, $t1, $t0\n", file);
		}
	}
	else if(code->code.kind == SUB)
	{
		if(op2->kind == CONSTANT)
			fprintf(file, "\taddi $t2, $t0, -%d\n", op2->u.value);
		else
		{
			load(op2, "$t1");
			fputs("\tsub $t2, $t0, $t1\n", file);
		}
	}
	else if(code->code.kind == MUL)
	{
		load(op2, "$t1");
		fputs("\tmul $t2, $t1, $t0\n", file);
	}
	else if(code->code.kind == DIVI)
	{
		load(op2, "$t1");
		fputs("\tdiv $t0, $t1\n", file);
		fputs("\tmflo $t2\n", file);
	}
	store(result, "$t2");
}

void print_goto_label(struct InterCodes *code)
{
	Operand label = code->code.u.gotoop.goto_label;
	fprintf(file, "\tj label%d\n", label->u.label_no);
}

void print_goto_con(struct InterCodes *code)
{
	Operand op1 = code->code.u.goto_con.op1;
	Operand op = code->code.u.goto_con.op;
	Operand op2 = code->code.u.goto_con.op2;
	Operand label = code->code.u.goto_con.label;

	allocate(op1);
	allocate(op2);

	load(op1, "$t0");
	load(op2, "$t1");
	switch(op->u.op_kind)
	{
		case 0 : fprintf(file, "\tbeq $t0, $t1, label%d\n", label->u.label_no); break;
		case 1 : fprintf(file, "\tbne $t0, $t1, label%d\n", label->u.label_no); break;
		case 2 : fprintf(file, "\tblt $t0, $t1, label%d\n", label->u.label_no); break;
		case 3 : fprintf(file, "\tbgt $t0, $t1, label%d\n", label->u.label_no); break;
		case 4 : fprintf(file, "\tble $t0, $t1, label%d\n", label->u.label_no); break;
		case 5 : fprintf(file, "\tbge $t0, $t1, label%d\n", label->u.label_no); break;
		default : break;
	}
}

void print_return(struct InterCodes *code)
{
	Operand op = code->code.u.returnop.op;
	fputs("\taddi $sp, $sp, 1024\n", file);
	load(op, "$v0");
	fputs("\tjr $ra\n", file);
}

void print_arg(struct InterCodes *code)
{
	//将内存中的值取出来放在寄存器中传递给函数
	struct InterCodes *head = code;
	int i = 0;
	while(head->code.kind == ARG)
	{
		Operand arg = head->code.u.arg.arg;
		load(arg, arg_param[i]);
		if(i == 10)		//最多允许11个参数，有更多的参数就报错并且代码强制退出
		{
			printf("Too many arguments\n"); 
			exit(0);
		}
		head = head->next;
		i++;
	}
}

void print_param(struct InterCodes *code)
{
	//将传递进来的参数存放在应该的内存位置中
	struct InterCodes *head = code;
	int i = 0;
	while(head->code.kind == PARAM)
	{
		head = head->next;
		i++;
	}
	i--;
	head = code;
	while(head->code.kind == PARAM)
	{
		Operand param = head->code.u.param.param;
		allocate(param);
		store(param, arg_param[i]);
		head = head->next;
		i--;
	}
}

void print_call(struct InterCodes *code)
{
	Operand call = code->code.u.callop.place;
	allocate(call);
	store(call, "$t0");
	int active = find_offset(call);
	fprintf(file, "\tsw $fp -%d($fp)\n", (active + 1) * 4);	//记录上一层活动记录
	fprintf(file, "\tsw $ra -%d($fp)\n", (active + 2) * 4);	//记录返回值地址
	fprintf(file, "\taddi $fp $fp -%d\n", (active + 2) * 4);	//开始记录新的活动记录
	fprintf(file, "\tjal %s\n", code->code.u.callop.name);		//跳转
	fputs("\tlw $ra 0($fp)\n", file);		//取出返回值
	fputs("\tlw $fp 4($fp)\n", file);		//取出原来的活动记录地址
	fputs("\tmove $t0, $v0\n", file);		//取出返回值
	store(call, "$t0");			//记录返回值
}

void print_read(struct InterCodes *code)
{
	Operand op = code->code.u.read.op;
	fputs("\taddi $sp, $sp, -4\n", file);
	fputs("\tsw $ra, 0($sp)\n", file);
	fputs("\tjal read\n", file);
	fputs("\tlw $ra, 0($sp)\n", file);
	fputs("\taddi $sp, $sp, 4\n", file);
	fputs("\tmove $t0, $v0\n", file);
	allocate(op);
	store(op, "$t0");		//运算结束后，将返回值放回内存中
}

void print_write(struct InterCodes *code)
{
	Operand op = code->code.u.write.op;
	load(op, "$t0");		//将参数从内存中取出
	fputs("\tmove $a0, $t0\n", file);
	fputs("\taddi $sp, $sp, -4\n", file);
	fputs("\tsw $ra, 0($sp)\n", file);
	fputs("\tjal write\n", file);
	fputs("\tlw $ra, 0($sp)\n", file);
	fputs("\taddi $sp, $sp, 4\n", file);
}

void print_label(struct InterCodes *code)
{
	Operand op = code->code.u.label_code.label;
	fprintf(file, "label%d:\n", op->u.label_no);
}

void printMC()
{
	optimizeTemp();
	init_offset();
	init();
	struct InterCodes *temp = head;		//指向双向链表的头部，进行逐条对应
	do
	{
		if(temp->code.kind == DEC)
		{
			if(begin->num == -1)		//表示此时没有给任何变量赋值
			{
			//	begin->num = 1;
				begin->num = temp->code.u.dec.size/4;
				memcpy(&begin->op, temp->code.u.dec.op, sizeof(struct Operand_));
				current = (struct Offset*)malloc(sizeof(struct Offset));
			//	current->num = begin->num + temp->code.u.dec.size/4;
				current->num = begin->num + 1;
				begin->next = current;
				current->prev = begin;
			}
			else
			{
				current->num = current->num - 1 + temp->code.u.dec.size/4;
				memcpy(&current->op, temp->code.u.dec.op, sizeof(struct Operand_));
				next = (struct Offset*)malloc(sizeof(struct Offset));
			//	next->num = current->num + temp->code.u.dec.size/4;
				next->num = current->num + 1;
				current->next = next;
				next->prev = current;
				current = next;
			}
		}
		if(temp->code.kind == DEF_LABEL)
			print_label(temp);
		if(temp->code.kind == FUNCTION)
			print_func(temp);
		if(temp->code.kind == ASSIGN)
			print_assign(temp);
		if(temp->code.kind == ADD || temp->code.kind == SUB || temp->code.kind == MUL || temp->code.kind == DIVI)
			print_bin(temp);
		if(temp->code.kind == GOTO_LABEL)
			print_goto_label(temp);
		if(temp->code.kind == GOTO_CON)
			print_goto_con(temp);
		if(temp->code.kind == RETURN_OP)
			print_return(temp);
		if(temp->code.kind == ARG)
		{
			print_arg(temp);
			while(temp->code.kind == ARG)
				temp = temp->next;		//在函数print_arg中已经将temp之后的intercode给处理过了
			continue;
		}
		if(temp->code.kind == PARAM)
		{
			print_param(temp);
			while(temp->code.kind == PARAM)
				temp = temp->next;		//在函数print_param中已经将temp之后的intercode给处理过了
			continue;
		}
		if(temp->code.kind == CALL)
			print_call(temp);
		if(temp->code.kind == READ)
			print_read(temp);
		if(temp->code.kind == WRITE)
			print_write(temp);
		if(temp->code.kind == LABEL_CODE)
			print_label(temp);
		if(temp->code.kind == NOTH)
		{
			temp = temp->next;
			continue;
		}
		temp = temp->next;
	}while(temp != head);
	fputs("\tli $v0, 10\n", file);
	fputs("\tsyscall\n", file);
	if(fclose(file) != 0)		//打印结束后关闭文件
		printf("Error in closing file\n");
}
