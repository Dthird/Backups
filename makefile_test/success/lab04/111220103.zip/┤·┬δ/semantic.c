#include "compile.h"

struct rb_root mytree = RB_ROOT;	//符号表根节点
int null = 0;
int var_count = 0;
int func_count = 0;

void printVar(Type type)
{
	if(type->kind == 0)
	{
		if(type->u.basic == 1)
			printf("type kind : int\n");
		else
			printf("type kind : float\n");
	}
	else if(type->kind == 1)
	{
		printf("type kind : array\n");
		printf("size	  : %d\n", type->u.array.size);
		if(type->u.array.elem != NULL)
			printVar(type->u.array.elem);
	}
	else
	{
		printf("type kind : structure\n");
		FieldList structure = type->u.structure;
		while(structure != NULL)
		{
			printf("name :      %s\n", structure->name);
			if(structure->type != NULL)
				printVar(structure->type);
			structure = structure->tail;
		}
	}
}

void printStruct(TypeList structure)
{
	printf("--------------------------------------------\n");
	printf("structure name : %s\n", structure->name);
	FieldList tail = structure->tail;
	while(tail != NULL)
	{
		printf("field name     : %s\n", tail->name);
		printVar(tail->type);
		tail = tail->tail;
	}
}


int equalType(Type t1, Type t2)		//比较类型是否相等，包括结构体，相等返回1，不等返回0
{
	if(t1 == NULL || t2 == NULL)
		return 0;
	if(t1->kind != t2->kind)	//类型不同
		return 0;
	if(t1->kind == basic)
	{
		if(t1->u.basic != t2->u.basic)
			return 0;
		else
			return 1;
	}
	if(t1->kind == array)
	{
/*		if(t1->u.array.size != t2->u.array.size)
			return 0;
		else*/
			return equalType(t1->u.array.elem, t2->u.array.elem);
	}
	if(t1->kind == structure)
	{
		if(strcmp(t1->name, t2->name) == 0)
			return 1;
		else
			return equalStruct(t1->u.structure, t2->u.structure);
	}
}

int equalStruct(FieldList structure1, FieldList structure2)	//比较两个结构体是否相等，不等返回0，相等返回1
{
	int temp_result;
	while(structure1 != NULL || structure2 != NULL)
	{
		if(structure1 == NULL)
			return 0;
		if(structure2 == NULL)
			return 0;
		if(equalType(structure1->type, structure2->type) == 0)
			return 0;
		structure1 = structure1->tail;
		structure2 = structure2->tail;
	}
	return 1;
}

int searchStruct(char *name, FieldList field)		//判断某一类型是否存在，如果存在返回1，否则返回0
{
	TypeList temp;
	FieldList t1, t2;
	temp = struct_list;
	while(temp != NULL)
	{
		if(strcmp(name, temp->name) == 0)
		{
			//把结构体内容给拷贝过去，没有拷贝结构体名字（分组原因，结构体相等，而非名相等）
			memcpy(field, temp->tail, sizeof(struct FieldList_));		
			return 1;
		}
		temp = temp->next;
	}
	return 0;
}

void judgeType(Type type, Node * node)
{
	if(strcmp(node->firstChild->type, "TYPE") == 0)		//基本类型或者数组，做为继承属性传递，后面可能还会有所修改
	{
		if(strcmp(node->firstChild->id, "int") == 0)
		{
			type->kind = basic;
			type->u.basic = 1;
		}
		if(strcmp(node->firstChild->id, "float") == 0)
		{
			type->kind = basic;
			type->u.basic = 2;
		}
	}
	if(strcmp(node->firstChild->type, "StructSpecifier") == 0)		//结构体
	{
		type->kind = structure;
		type->u.structure = (FieldList)malloc(sizeof(struct FieldList_));
		if(strcmp(node->firstChild->firstChild->nextSibling->type, "Tag") == 0)
		{
			FieldList t = (FieldList)malloc(sizeof(struct FieldList_));
			if(searchStruct(node->firstChild->firstChild->nextSibling->firstChild->id, t) == 0)	//需要判断该结构体是否已经存在
			{
				if(node->firstChild->firstChild->nextSibling->firstChild->mark != 1)
				{
					node->firstChild->firstChild->nextSibling->firstChild->mark = 1;
					printf("Error type 17 at line %d: Undefined struct ‘%s’\n", node->firstChild->firstChild->nextSibling->line, node->firstChild->firstChild->nextSibling->firstChild->id);
				}
				return;
			}
			else
			{
				type->name = (char *)malloc(sizeof(char) *(strlen(node->firstChild->firstChild->nextSibling->firstChild->id) + 1));
		                memcpy(type->name, node->firstChild->firstChild->nextSibling->firstChild->id, strlen(node->firstChild->firstChild->nextSibling->firstChild->id) + 1);
				memcpy(type->u.structure, t, sizeof(struct FieldList_));
			}
		}
		else	//StructSpecifier : STRUCT OptTag LC DefList RC
		{
			if(node->firstChild->firstChild->nextSibling->mark == 1)	//该结构体已经遍历过，不重复遍历，直接查找结构表并进行赋值
			{
				FieldList t = (FieldList)malloc(sizeof(struct FieldList_));
				searchStruct(node->firstChild->firstChild->nextSibling->firstChild->id, t);
				type->name = (char *)malloc(sizeof(char) *(strlen(node->firstChild->firstChild->nextSibling->firstChild->id) + 1));
		                memcpy(type->name, node->firstChild->firstChild->nextSibling->firstChild->id, strlen(node->firstChild->firstChild->nextSibling->firstChild->id) + 1);
				memcpy(type->u.structure, t, sizeof(struct FieldList_));
				return;
			}
			else
				node->firstChild->firstChild->nextSibling->mark = 1;
			//对struct类型开始递归赋值
			if(strcmp(node->firstChild->firstChild->nextSibling->type, "LC") == 0)	//类型名为空如何处理？？？
								//node->firstChild->firstChild->nextSibling是LC，因为OptTag为空，就没有链上
			{
				type->name = malloc(32);		//分配四个字节的空间
				sprintf(type->name, "%d", null);
				null ++;
			}
			else
			{
				type->name = (char *)malloc(sizeof(char) *(strlen(node->firstChild->firstChild->nextSibling->firstChild->id) + 1));
		                memcpy(type->name, node->firstChild->firstChild->nextSibling->firstChild->id, strlen(node->firstChild->firstChild->nextSibling->firstChild->id) + 1); 
			}
			type->u.structure = NULL;

			//先只考虑一个DefList再循环
			Node *DefList;
			if(strcmp(node->firstChild->firstChild->nextSibling->type, "LC") == 0)
				DefList = node->firstChild->firstChild->nextSibling->nextSibling;
			else
				DefList = node->firstChild->firstChild->nextSibling->nextSibling->nextSibling;
			while(DefList != NULL)
			{
				Type temp = (Type)malloc(sizeof(struct Type_));
				judgeType(temp, DefList->firstChild->firstChild);	//递归调用，这里为Def : Specifier DecList SEMI
			
				Node *DecList = DefList->firstChild->firstChild->nextSibling;
				while(DecList != NULL)
				{
					Node *VarDec = DecList->firstChild->firstChild;	
					if(VarDec->nextSibling != NULL)		//产生式Dec : VarDec ASSIGINOP Exp，对结构体定义时初始化
					{
						if(VarDec->nextSibling->mark != 1)
						{
							VarDec->nextSibling->mark = 1;
							if(strcmp(VarDec->nextSibling->type, "ASSIGNOP") == 0)
							{
								Node * v = VarDec->firstChild;
								while(strcmp(v->type, "ID") != 0)
									v = v->firstChild;
								printf("Error type 15 at line %d: Initialization when defining ‘%s’\n", VarDec->line, v->id);
							}
						}				
					}
					FieldList field = (FieldList)malloc(sizeof(struct FieldList_));		//由VarDec可以初步确定数据域中的内容
					field->type = (Type)malloc(sizeof(struct Type_));

					if(strcmp(VarDec->firstChild->type, "ID") == 0)		//如果是ID，则类型即为上一层的Specifier类型，可能为基本类型或者struct类型
					{
						//检测struct域内是否存在域名重复定义
						FieldList through = type->u.structure;
						while(through != NULL)
					 	{
							if(strcmp(through->name, VarDec->firstChild->id) == 0)
								printf("Error type 15 at line %d: Redefined field ‘%s’\n", VarDec->line, VarDec->firstChild->id);
							through = through->tail;
						}
						field->name = (char *)malloc(sizeof(char) *(strlen(VarDec->firstChild->id) + 1));
		                		memcpy(field->name, VarDec->firstChild->id, strlen(VarDec->firstChild->id) + 1);
						memcpy(field->type, temp, sizeof(struct Type_));	//类型赋值
					}
					else		//产生式产生的为数组，可以直接定义类型为array，产生式为VarDec : VarDec LB INT RB
					{
						Type last = (Type)malloc(sizeof(struct Type_));
						memcpy(last, temp, sizeof(struct Type_));	//最后的类型，遍历顺序是从后向前，所以最初的类型应该记录在最后
		
						Type arrayType;
						Node *first = VarDec->firstChild;
						while(strcmp(first->type, "ID") != 0)		//将逐一匹配下去，直到最后
						{
							arrayType = (Type)malloc(sizeof(struct Type_));
							arrayType->kind = array;
							arrayType->u.array.elem = last;
							arrayType->u.array.size = first->nextSibling->nextSibling->i_value;
								
							last = arrayType;		//向前传递
							first = first->firstChild;		//进入树的下一层
						}
						FieldList through = type->u.structure;
						while(through != NULL)
					 	{
							if(strcmp(through->name, first->id) == 0)
								printf("Error type 15 at line %d: Redefined field ‘%s’\n", first->line, first->id);
							through = through->tail;
						}
						field->name = (char *)malloc(sizeof(char) *(strlen(first->id) + 1));
		                		memcpy(field->name, first->id, strlen(first->id) + 1);
						field->type = arrayType;
						field->tail = NULL;
					}
		
					//把得到的类型加入到type的数据域中去
					FieldList through = type->u.structure;
					if(type->u.structure == NULL)
					{
						type->u.structure = field;
						type->u.structure->tail = NULL;
					}
					else
					{
						while(through->tail != NULL)
						 	through = through->tail;		//遍历到type的数据域中的最后一项，并把新得到的类型加入末尾
						through->tail = field;
					}
	
					//判断循环的条件
					if(DecList->firstChild->nextSibling == NULL)		//产生式为DecList : Dec
						DecList = NULL;		//可以认为DecList已经遍历完毕
					else		//产生式为DecList： Dec COMMA DecList
						DecList = DecList->firstChild->nextSibling->nextSibling;
				}
				DefList = DefList->firstChild->nextSibling;
			}
			
			//递归结束，开始插入到结构表中
			if(struct_list == NULL)		//结构表一开始为空，进行初始化
			{
				struct_list = (TypeList)malloc(sizeof(struct TypeList_));
				struct_list->name = (char *)malloc(sizeof(char) *(strlen(type->name) + 1));
		                memcpy(struct_list->name, type->name, strlen(type->name) + 1);
				struct_list->tail = type->u.structure;
				struct_list->next = NULL;
			}
			else
			{
				FieldList t = (FieldList)malloc(sizeof(struct FieldList_));
				Symbol t2 = (Symbol)malloc(sizeof(struct Symbol_));
				//判断结构体是否重名或者与之前定义过的变量重名
				if(searchStruct(type->name, t) == 1 || my_search(&mytree, type->name, t2) == 1)
					printf("Error type 16 at line %d: Duplicated name ‘%s’\n", node->firstChild->firstChild->nextSibling->line, type->name);
				else			//没有重名的话就将该结构加入到结构表中
				{
					TypeList tl = struct_list;
					while(tl->next != NULL)
						tl = tl->next;
					TypeList ttl = (TypeList)malloc(sizeof(struct TypeList_));
					ttl->name = (char *)malloc(sizeof(char) *(strlen(type->name) + 1));
		                	memcpy(ttl->name, type->name, strlen(type->name) + 1);	
					ttl->tail = type->u.structure;
					ttl->next = NULL;
					tl->next = ttl;
				}		
			}
/*			//因为要做结构体内部等价，所以名字只用来插入表中，不用来判断
			//在名字为空的情况下，变量的类别不应该包括已定义的名字，所以要进行重新赋值
			if(strcmp(node->firstChild->firstChild->nextSibling->type, "LC") == 0)
			{
				FieldList empty = (FieldList)malloc(sizeof(struct FieldList_));
				memcpy(empty, type->u.structure->tail, sizeof(struct Type_));
				memcpy(type->u.structure, empty, sizeof(struct FieldList_));
			}*/
		}
	}
}

void insertVarDec(Type type, Node * VarDec, int mark)
{
	struct mynode *mn = (struct mynode *)malloc(sizeof(struct mynode));
	Symbol sign = (Symbol)malloc(sizeof(struct Symbol_));
	sign->kind = var;
	
	if(strcmp(VarDec->firstChild->type, "ID") == 0)
	{
		Symbol temp = (Symbol)malloc(sizeof(struct Symbol_));
		FieldList t = (FieldList)malloc(sizeof(struct FieldList_));
		//查表判断是否重名
		if(my_search(&mytree, VarDec->firstChild->id, temp) == 1 || searchStruct(VarDec->firstChild->id, t) == 1 )
		{
			printf("Error type 3 at line %d: Redefined variable '%s'\n", VarDec->line, VarDec->firstChild->id);
			return;
		}
	
		//sprintf(sign->name, "%s",VarDec->firstChild->id);
		sign->name = (char *)malloc(sizeof(char) *(strlen(VarDec->firstChild->id) + 1));
		memcpy(sign->name, VarDec->firstChild->id, strlen(VarDec->firstChild->id) + 1);
		sign->u.type = (Type)malloc(sizeof(struct Type_));
		memcpy(sign->u.type, type, sizeof(struct Type_));
	}
	else		//如果类型不是ID，那么产生式为VarDec : VarDec LB INT RB，处理过程与sturcture里面的VarDec过程类似
	{
		Type last = (Type)malloc(sizeof(struct Type_));
		last->kind = type->kind;	//最后的类型，遍历顺序是从后向前，所以最初的类型应该记录在最后

		memcpy(last, type, sizeof(struct Type_));
		
		Type arrayType;
		Node *first = VarDec->firstChild;
		while(strcmp(first->type, "ID") != 0)		//将逐一匹配下去，直到最后
		{
			arrayType = (Type)malloc(sizeof(struct Type_));
			arrayType->kind = array;
			arrayType->u.array.elem = last;
			arrayType->u.array.size = first->nextSibling->nextSibling->i_value;
								
			last = arrayType;		//向前传递
			first = first->firstChild;		//进入树的下一层
		}

		Symbol temp1 = (Symbol)malloc(sizeof(struct Symbol_));
		FieldList temp2 = (FieldList)malloc(sizeof(struct FieldList_));
		//查表判断是否重名
		if(my_search(&mytree, first->id, temp1) == 1 || searchStruct(first->id, temp2))
		{
			printf("Error type 3 at line %d: Redefined variable '%s'\n", first->line, first->id);
			return;
		}
	
		//sprintf(sign->name, "%s", first->id);
		sign->name = (char *)malloc(sizeof(char) *(strlen(first->id) + 1));
		memcpy(sign->name, first->id, strlen(first->id) + 1);
		sign->u.type = arrayType;
		memcpy(type, arrayType, sizeof(struct Type_));
	}

	sign->flag = mark;
	sign->num = var_count;
	var_count++;

	mn->sign = sign;
	my_insert(&mytree, mn);
/*	printf("-----------------插入变量----------------\n");
	printf("name :      %s\n", mn->sign->name);
	printVar(mn->sign->u.type);*/
}

//因为产生式ExtDecList : VarDec COMMA ExtDecList 产生式涉及到了相同的部分，所以这里使用函数递归来实现
//对ExtDecList的遍历可能会导致对type进行修改，所以这里要将type做为参数传递进去
void insertExtDecList(Type type, Node * node)
{
	Node *VarDec = node->firstChild;
	if(VarDec->nextSibling != NULL)	//产生式为ExtDecList : VarDec COMMA ExtDecList，递归调用函数
	{
//		Type temp = (Type)malloc(sizeof(struct Type_));
//		memcpy(temp, type, sizeof(struct Type_));
		insertExtDecList(type, VarDec->nextSibling->nextSibling);
	}
	//当进行到产生式为ExtDecList : VarDec时对VarDec进行处理
	insertVarDec(type, VarDec, 0);
}

void insertDecList(Type type, Node * DecList)
{
	Node *Dec = DecList->firstChild;
	if(Dec->nextSibling != NULL)
	{
//		Type temp = (Type)malloc(sizeof(struct Type_));
//		memcpy(temp, type, sizeof(struct Type_));
		insertDecList(type, Dec->nextSibling->nextSibling);
	}
	insertVarDec(type, Dec->firstChild, 0);
	if(Dec->firstChild->nextSibling != NULL)	//产生式为Dec : VarDec ASSIGNOP Exp
							//可能在定义时初始化
	{
		Type temp = (Type)malloc(sizeof(struct Type_));
		dealExp(temp, Dec->firstChild->nextSibling->nextSibling);
		if(equalType(type, temp) == 0)
		{
			printf("Error type 5 at line %d: Type mismatched\n", Dec->line);
		}
	}
	else
		return;
}

void insertFunDec(Type type, Node * FunDec)
{
	Symbol temp = (Symbol)malloc(sizeof(struct Symbol_));
	//查表判断是否重名
	if(my_search(&mytree, FunDec->firstChild->id, temp) == 1)
	{
		printf("Error type 4 at line %d: Redefined function '%s'\n", FunDec->line, FunDec->firstChild->id);
		return;
	}

	struct mynode *mn = (struct mynode *)malloc(sizeof(struct mynode));
	Symbol sign = (Symbol)malloc(sizeof(struct Symbol_));

	sign->kind = func;
	sign->name = (char *)malloc(sizeof(char) *(strlen(FunDec->firstChild->id) + 1));
	memcpy(sign->name, FunDec->firstChild->id, strlen(FunDec->firstChild->id) + 1);

	sign->u.func.return_type = (Type)malloc(sizeof(struct Type_));
	memcpy(sign->u.func.return_type, type, sizeof(struct Type_));
	sign->u.func.num = 0;

	if(strcmp(FunDec->firstChild->nextSibling->nextSibling->type, "VarList") == 0)		//产生式为FunDec : ID LP VarList RP
	{
		Node *VarList = FunDec->firstChild->nextSibling->nextSibling;
		while(VarList != NULL)
		{
			Node *ParamDec = VarList->firstChild;
			Type temp = (Type)malloc(sizeof(struct Type_));
			judgeType(temp, ParamDec->firstChild);
			insertVarDec(temp, ParamDec->firstChild->nextSibling, 1);
			sign->u.func.num++;

			Node * id = ParamDec->firstChild->nextSibling;
			while(strcmp(id->type, "ID") != 0)
				id = id->firstChild;
			char *name = (char *)malloc(sizeof(char) *(strlen(id->id) + 1));
			memcpy(name, id->id, strlen(id->id) + 1);

			if(sign->u.func.first == NULL)		//函数参数列表为空
			{
				sign->u.func.first = (FieldList)malloc(sizeof(struct FieldList_));
				sign->u.func.first->name = (char *)malloc(sizeof(char) *(strlen(name) + 1));
				memcpy(sign->u.func.first->name, name, strlen(name) + 1);
				sign->u.func.first->type = (Type)malloc(sizeof(struct Type_));
				memcpy(sign->u.func.first->type, temp, sizeof(struct Type_));
				sign->u.func.first->tail = NULL;
			}
			else
			{
				FieldList next = (FieldList)malloc(sizeof(struct FieldList_));
				next->name = (char *)malloc(sizeof(char) *(strlen(name) + 1));
				next->type = (Type)malloc(sizeof(struct Type_));
				memcpy(next->name, name, strlen(name) + 1);
				memcpy(next->type, temp, sizeof(struct Type_));
				next->tail = NULL;
				FieldList first = sign->u.func.first;
				while(first->tail != NULL)
					first = first->tail;
				first->tail = next;
			}

			if(ParamDec->nextSibling == NULL)
				VarList = NULL;
			else
				VarList = ParamDec->nextSibling->nextSibling;
		}
	}

	sign->num = func_count;
	func_count++;

	//插入到符号表中
	mn->sign = sign;
	my_insert(&mytree, mn);
}

void dealArgs(FieldList func, Node * Args)
{
	int mark = 0;		//mark用来标记第一次调用t2作为参数列表的头部
	FieldList t1 = (FieldList)malloc(sizeof(struct FieldList_));
	t1->type = (Type)malloc(sizeof(struct Type_));
	FieldList t2 = (FieldList)malloc(sizeof(struct FieldList_));
	t2->type = (Type)malloc(sizeof(struct Type_));
	FieldList t3;
	while(Args != NULL)
	{
		Type type = (Type)malloc(sizeof(struct Type_));
		dealExp(type, Args->firstChild);
		memcpy(t1->type, type, sizeof(struct Type_));
		if(mark == 0)
		{
			mark = 1;
			memcpy(t2->type, t1->type, sizeof(struct Type_));
			t2->tail = NULL;
		}
		else
		{
			t3 = t2;
			while(t3->tail != NULL)
				t3 = t3->tail;
			t3->tail = (FieldList)malloc(sizeof(struct FieldList_));
			t3->tail->type = (Type)malloc(sizeof(struct Type_));
			memcpy(t3->tail->type, t1->type, sizeof(struct Type_));
			t3->tail->tail = NULL;
		}
		if(Args->firstChild->nextSibling != NULL)
			Args = Args->firstChild->nextSibling->nextSibling;
		else
			Args = NULL;
	}
	memcpy(func, t2, sizeof(struct FieldList_));
	return;
}

int judgeValue(Node * Exp)		//左值判断
{
	if(strcmp(Exp->firstChild->type, "ID") == 0)
	{
		Symbol temp = (Symbol)malloc(sizeof(struct Symbol_));
		if(my_search(&mytree, Exp->firstChild->id, temp) == 1)
		{
			if(temp->kind == func)
				return 0;
			else
				return 1;
		}
		return 1;		//如果符号不存在的话错误类型应该为1（未定义的变量），不在此处报错
	}
	if(strcmp(Exp->firstChild->type, "Exp") == 0 && (strcmp(Exp->firstChild->nextSibling->type, "LB") == 0 || strcmp(Exp->firstChild->nextSibling->type, "DOT") == 0))
		return 1;
	if(strcmp(Exp->firstChild->type, "LP") == 0)
		return judgeValue(Exp->firstChild->nextSibling);
	return 0;
}

int searchStructName(FieldList structure, char *name, Type type)		//搜寻结构体内的成员并判断类型
{
	FieldList tail = structure;
	while(tail != NULL)
	{
		if(strcmp(tail->name, name) == 0)
		{
			memcpy(type, tail->type, sizeof(struct Type_));
			return 1;
		}
		tail = tail->tail;
	}
	return 0;
}

void dealExp(Type type, Node * Exp)		//需要用type来记录住当前Exp的类型
{
	//首先处理非Exp
	if(strcmp(Exp->firstChild->type, "INT") == 0)
	{
		type->kind = basic;
		type->u.basic = 1;
	}
	if(strcmp(Exp->firstChild->type, "FLOAT") == 0)
	{
		type->kind = basic;
		type->u.basic = 2;
	}
	if(strcmp(Exp->firstChild->type, "ID") == 0 && Exp->firstChild->nextSibling == NULL)	//Exp : ID
	{
		Symbol temp = (Symbol)malloc(sizeof(struct Symbol_));
		if(my_search(&mytree, Exp->firstChild->id, temp) == 1)		//查符号表
		{
			if(temp->kind == var)		//不可能为func，这里的产生式不允许
				memcpy(type, temp->u.type, sizeof(struct Type_));		//记住当前Exp的类型，用于后续的类型判断
			else
			{
				if(Exp->firstChild->mark != 1)		//对遍历过的ID进行标记，防止重复报错
				{
					Exp->firstChild->mark = 1;
					printf("Error type 1 at line %d: Undefined variable '%s'\n", Exp->line, Exp->firstChild->id);
					return;
				}
			}
		}
		else
		{
			if(Exp->firstChild->mark != 1)		//对遍历过的ID进行标记，防止重复报错
			{
				Exp->firstChild->mark = 1;
				printf("Error type 1 at line %d: Undefined variable '%s'\n", Exp->line, Exp->firstChild->id);
				return;
			}
		}
	}
	if(strcmp(Exp->firstChild->type, "ID") == 0 && Exp->firstChild->nextSibling != NULL)		//函数调用
	{
		if(Exp->firstChild->mark != 1)
		{
			Exp->firstChild->mark = 1;
			//查表
			Symbol temp = (Symbol)malloc(sizeof(struct Symbol_));
			if(my_search(&mytree, Exp->firstChild->id, temp) == 1)		//查符号表
			{
				if(temp->kind == func)		//不可能为var
					memcpy(type, temp->u.func.return_type, sizeof(struct Type_));		//记住当前Exp的类型，用于后续的类型判断
				else		//如果类型为var，则说明对变量的使用不正确
				{
					printf("Error type 11 at line %d: '%s' must be a function\n", Exp->line, Exp->firstChild->id);
					return;
				}
			
				//进行参数判断
				int num = 0;
				if(strcmp(Exp->firstChild->nextSibling->nextSibling->type, "RP") == 0)	//函数参数个数为0
				{
					if(temp->u.func.num != 0)
					{
						printf("Error type 9 at line %d: The argument(s) for the method %s()' is not applicable\n", Exp->line, Exp->firstChild->id);
						return; 
					}
				}
				else		//匹配函数参数
				{
					FieldList func = (FieldList)malloc(sizeof(struct FieldList_));
					func->type = (Type)malloc(sizeof(struct Type_));
					dealArgs(func, Exp->firstChild->nextSibling->nextSibling);		//获得传递进去的实参列表
				//	func->tail = NULL;
					FieldList t1, t2;
					t1 = func; t2 = temp->u.func.first;
					while(t1 != NULL || t2 != NULL)		//与形参个数和类型进行匹配
					{
						if(t1 == NULL || t2 == NULL || t1->type == NULL || t2->type == NULL
						|| equalType(t1->type, t2->type) == 0)
						{
							printf("Error type 9 at line %d: The argument(s) for the method %s()' is not applicable\n", Exp->line, Exp->firstChild->id);
							return;
						}
						t1 = t1->tail; t2 = t2->tail;
					}
				}
			}
			else
			{
				printf("Error type 2 at line %d: Undefined function '%s'\n", Exp->line, Exp->firstChild->id);
				return;
			}
		}
	}
	if(strcmp(Exp->firstChild->type, "Exp") == 0)
	{
		if(strcmp(Exp->firstChild->nextSibling->type, "ASSIGNOP") == 0)		//进行左右值判断和类型匹配
		{
			//左值判断
			if(judgeValue(Exp->firstChild) == 0)
			{
				printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n", Exp->line);
				return;
			}

			//类型匹配
			Type t1 = (Type)malloc(sizeof(struct Type_));
			Type t2 = (Type)malloc(sizeof(struct Type_));
			dealExp(t1, Exp->firstChild);
			dealExp(t2, Exp->firstChild->nextSibling->nextSibling);
			if(equalType(t1, t2) == 0)
			{
				printf("Error type 5 at line %d: Type mismatched\n", Exp->line);
				return;
			}
			memcpy(type, t1, sizeof(struct Type_));
		}
		if(strcmp(Exp->firstChild->nextSibling->type, "AND") == 0 || strcmp(Exp->firstChild->nextSibling->type, "OR") == 0)
		{
			Type t1 = (Type)malloc(sizeof(struct Type_));
			Type t2 = (Type)malloc(sizeof(struct Type_));
			dealExp(t1, Exp->firstChild);
			dealExp(t2, Exp->firstChild->nextSibling->nextSibling);
//			printf("1111111111111111111111\n");
			if(t1->kind != basic || t2->kind != basic)		//要求类型必须是int
			{
				printf("Error type 7 at line %d: Operands type mismatched\n", Exp->line);
				return;
			}
			if(t1->u.basic != 1 || t2->u.basic != 1)
			{
				printf("Error type 7 at line %d: Operands type mismatched\n", Exp->line);
				return;
			}
			memcpy(type, t1, sizeof(struct Type_));
		}
		if(strcmp(Exp->firstChild->nextSibling->type, "RELOP") == 0 || strcmp(Exp->firstChild->nextSibling->type, "PLUS") == 0
		|| strcmp(Exp->firstChild->nextSibling->type, "MINUS") == 0 || strcmp(Exp->firstChild->nextSibling->type, "STAR") == 0
		|| strcmp(Exp->firstChild->nextSibling->type, "DIV") == 0)
		{
			Type t1 = (Type)malloc(sizeof(struct Type_));
			Type t2 = (Type)malloc(sizeof(struct Type_));
			dealExp(t1, Exp->firstChild);
			dealExp(t2, Exp->firstChild->nextSibling->nextSibling);
			if(Exp->firstChild->nextSibling->mark != 1)
			{
				Exp->firstChild->nextSibling->mark = 1;
//				printf("222222222222222222222222222\n");
				if(t1->kind != basic || t2->kind != basic)		//要求类型必须是基本类型
				{
					printf("Error type 7 at line %d: Operands type mismatched\n", Exp->line);
					return;
				}
				if(t1->u.basic != t2->u.basic)
				{
					printf("Error type 7 at line %d: Operands type mismatched\n", Exp->line);
					return;
				}
				if(strcmp(Exp->firstChild->nextSibling->type, "RELOP") == 0)
				{
					type->kind = basic;
					type->u.basic = 1;
				}
				else
					memcpy(type, t1, sizeof(struct Type_));
			}
			else
			{
				type->kind = basic;
				type->u.basic = 1;
			}
		}
		if(strcmp(Exp->firstChild->nextSibling->type, "LB") == 0 && Exp->firstChild->nextSibling->mark != 1)	//数组访问
		{
			Exp->firstChild->nextSibling->mark = 1;		//防止对数组元素的重复遍历和访问
			Type t1 = (Type)malloc(sizeof(struct Type_));
			Type t2 = (Type)malloc(sizeof(struct Type_));
			dealExp(t1, Exp->firstChild);
			dealExp(t2, Exp->firstChild->nextSibling->nextSibling);
			if(t2->kind != basic || (t2->kind == basic && t2->u.basic != 1))
				printf("Error type 12 at line %d: Operands type mistaken\n", Exp->line);
			if(t1->kind != array)
			{
				Node * t = Exp;
				while(strcmp(t->firstChild->type, "ID") != 0)
					t = t->firstChild;
				if(strcmp(t->nextSibling->type, "DOT") == 0)
					t = t->nextSibling->nextSibling;
				else
					t = t->firstChild;
				printf("Error type 10 at line %d: '%s' must be an array\n", Exp->line, t->id);
				return;
			}
			memcpy(type, t1->u.array.elem, sizeof(struct Type_));
		}
		if(strcmp(Exp->firstChild->nextSibling->type, "DOT") == 0)	//结构体访问
		{
			if(Exp->firstChild->nextSibling->mark != 1)
			{
				Exp->firstChild->nextSibling->mark = 1;
				Type t = (Type)malloc(sizeof(struct Type_));
				dealExp(t, Exp->firstChild);
				if(t->kind != structure)
				{
					printf("Error type 13 at line %d: Illegal use of “.”\n", Exp->line);
					return;
				}
				if(Exp->firstChild->nextSibling->nextSibling->mark != 1)
				{
					Exp->firstChild->nextSibling->nextSibling->mark = 1;
					if(searchStructName(t->u.structure, Exp->firstChild->nextSibling->nextSibling->id, type) == 0)
					{
						printf("Error type 14 at line %d: Un-existed field '%s'\n", Exp->line, Exp->firstChild->nextSibling->nextSibling->id);
						return;
					}
				}
			}	
			else
				memcpy(type, lookupType(Exp->firstChild->nextSibling->nextSibling), sizeof(struct Type_));
		}
	}
	if(strcmp(Exp->firstChild->type, "LP") == 0)
	{
		dealExp(type, Exp->firstChild->nextSibling);
		return;
	}
	if(strcmp(Exp->firstChild->type, "MINUS") == 0)		//不能为struct类型，必须为基本类型
	{
		Type t = (Type)malloc(sizeof(struct Type_));
		dealExp(t, Exp->firstChild->nextSibling);
//		printf("333333333333333333333333333333333\n");
		if(t->kind != basic)
		{
			printf("Error type 7 at line %d: Operands type mismatched\n", Exp->line);
			return;
		}
		memcpy(type, t, sizeof(struct Type_));
	}
	if(strcmp(Exp->firstChild->type, "NOT") == 0)		//类型必须为int型
	{
		Type t = (Type)malloc(sizeof(struct Type_));
		dealExp(t, Exp->firstChild->nextSibling);
//		printf("44444444444444444444444444444\n");
		if(t->kind != basic || (t->kind == basic && t->u.basic != 1))
		{
			printf("Error type 7 at line %d: Operands type mismatched\n", Exp->line);
			return;
		}
		memcpy(type, t, sizeof(struct Type_));
	}
}

void traverse(Node * root)
{
	if(root != NULL)
	{
        	if(strcmp(root->type,"ExtDef") == 0) 	//插入到符号表中
		{
			//首先判断是什么类型
			Type type = (Type)malloc(sizeof(struct Type_));
			judgeType(type, root->firstChild);

			if(strcmp(root->firstChild->nextSibling->type, "ExtDecList") == 0)
				insertExtDecList(type, root->firstChild->nextSibling);
			if(strcmp(root->firstChild->nextSibling->type, "FunDec") == 0)
				insertFunDec(type, root->firstChild->nextSibling);		//type用来记录返回值
            	}
		if(strcmp(root->type, "RETURN") == 0)		//检查函数返回类型
		{
			Type t1 = (Type)malloc(sizeof(struct Type_));
			Type t2 = (Type)malloc(sizeof(struct Type_));
    			dealExp(t1, root->nextSibling);
			
			//寻找符号表里的最后一个为函数类型的节点，该函数即为return所在的函数
    			struct rb_node *node;
  			for (node = rb_first(&mytree); node; node = rb_next(node))
				if(rb_entry(node, struct mynode, node)->sign->kind == func && 
				(rb_entry(node, struct mynode, node)->sign->num == func_count-1))
				{
					memcpy(t2, rb_entry(node, struct mynode, node)->sign->u.func.return_type, sizeof(struct Type_));
					break;
				}

    			if(equalType(t1, t2) == 0)
        			printf("Error type 8 at line %d: The return type mismatched\n", root->line);
		}
		if(strcmp(root->type, "IF") == 0 || strcmp(root->type, "WHILE") == 0)		//检查判断语句
		{
			Type type = (Type)malloc(sizeof(struct Type_));
			dealExp(type, root->nextSibling->nextSibling);
			if(type->kind != basic || (type->kind == basic && type->u.basic != 1))
				printf("Error type 7 at line %d: Operands type mismatched\n", root->line);
		}
        	if(strcmp(root->type, "Def") == 0)
		{
            		Type type = (Type)malloc(sizeof(struct Type_));
            		judgeType(type, root->firstChild);
            		Node * DecList = root->firstChild->nextSibling;
            		insertDecList(type, DecList);
        	}
        	if(strcmp(root->type, "Exp") == 0)
		{
			Type type = (Type)malloc(sizeof(struct Type_));
			dealExp(type, root);
            	}
		if(root->firstChild != NULL) 
             		traverse(root->firstChild);
		if(root->nextSibling != NULL)
            		traverse(root->nextSibling); 
	}
    	else if(root->nextSibling != NULL)
            traverse(root->nextSibling);
}
