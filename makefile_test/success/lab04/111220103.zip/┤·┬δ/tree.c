#include "compile.h"

char tokens[27][10] =   {
                                "INT", "FLOAT", "ID", "SEMI", "COMMA", "ASSIGNOP", "RELOP", "PLUS", "MINUS",
                                "STAR", "DIV", "AND", "OR", "DOT", "NOT", "TYPE", "LP", "RP",
                                "LB", "RB", "LC", "RC", "STRUCT", "RETURN", "IF", "ELSE", "WHILE"
                        };

Node* create(int lineno, char *value, char *token)
{
	Node *temp = (Node *)malloc(sizeof(Node));
	//Node temp;
	temp->line = lineno;
	if(token != "INT" || token != "FLOAT") 
	{
        	temp->id = (char *)malloc(sizeof(char) *(strlen(value) + 1));
        	memcpy(temp->id, value, strlen(value) + 1); // \0 is a must, because I use memcpy instead of strcpy
    	}
	temp->type = token;
	temp->firstChild = NULL;
	temp->nextSibling = NULL;
	return temp;
}

Node *insertSibling(Node *first, Node *next) 
{
	//printf("value:%s token:%s line:%d\n", first->id, first->type, first->line);
	first->nextSibling = next;
	return first;
}

Node *insertChild(Node *parent, Node *child)
{
	//printf("value:%s token:%s line:%d\n", parent->id, parent->type, parent->line);
	parent->firstChild = child;
	return parent;
}

int isToken(char type[])
{
	int i = 0;
	for( ; i < 27; i++)
		if(strcmp(type, tokens[i]) == 0)
			return 1;
	return 0;
}

void printSyntaxTree(Node *root, int depth)
{
	int i;
	
	if(root != NULL)
	{
/*		printf("%s\n", root->type);
		printf("%s\n", root->firstChild->type);
		printf("%s\n", root->firstChild->firstChild->type);*/
		for(i = 0; i < depth; i++)
			printf("  ");
		if(isToken(root->type))
		{
			if(strcmp(root->type, "INT") == 0)
				printf("%s: %d\n", root->type, root->i_value);
			else if(strcmp(root->type, "FLOAT") == 0)
				printf("%s: %.6f\n", root->type, root->f_value);
			else if(strcmp(root->type, "ID") == 0)
				printf("%s: %s\n", root->type, root->id);
			else if(strcmp(root->type, "TYPE") == 0)
				printf("%s: %s\n", root->type, root->id);
			else
				printf("%s\n", root->type);
		}
		else
			printf("%s (%d)\n", root->type, root->line);
		
	/*	for(root = root->firstChild; root != NULL; root = root->nextSibling)
		{
			printSyntaxTree(root, depth + 1);
		}
	}*/
		if(root->firstChild != NULL) 
            		printSyntaxTree(root->firstChild, depth + 1);
	        if(root->nextSibling != NULL)
            		printSyntaxTree(root->nextSibling, depth); 
		
	}
    	else if(root->nextSibling != NULL)
            printSyntaxTree(root->nextSibling, depth);
	else
		return;
	//}
}
