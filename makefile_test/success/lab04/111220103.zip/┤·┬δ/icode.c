#include "compile.h"

int label_count = 1;
int temp_count = 1;
int mark_s = 0;
extern struct rb_root mytree;
extern FILE *file;

void printFunc(struct InterCodes *icode)
{
	fprintf(file, "FUNCTION %s :\n", icode->code.u.func.name);
}

void printAssign(struct InterCodes *icode)
{
	Operand right, left;
	right = icode->code.u.assign.right;
	left = icode->code.u.assign.left;

	if(left->kind == VARIABLE)
		fprintf(file, "v%d := ", left->u.var_no);
	else if(left->kind == TEMP)
		fprintf(file, "t%d := ", left->u.temp_no);
	else if(left->kind == ADDRESS_V)
		fprintf(file, "*v%d := ", left->u.var_no);
	else if(left->kind == ADDRESS_T)
		fprintf(file, "*t%d := ", left->u.temp_no);
	else if(left->kind == MEM_V)
		fprintf(file, "&v%d := ", left->u.var_no);
	else if(left->kind == MEM_T)
		fprintf(file, "*t%d := ", left->u.temp_no);

	if(right->kind == VARIABLE)
		fprintf(file, "v%d\n", right->u.var_no);
	else if(right->kind == TEMP)
		fprintf(file, "t%d\n", right->u.temp_no);
	else if(right->kind == CONSTANT)
		fprintf(file, "#%d\n", right->u.value);
	else if(right->kind == ADDRESS_V)
		fprintf(file, "*v%d\n", right->u.var_no);
	else if(right->kind == ADDRESS_T)
		fprintf(file, "*t%d\n", right->u.temp_no);
	else if(right->kind == MEM_V)
		fprintf(file, "&v%d\n", right->u.var_no);
	else if(right->kind == MEM_T)
		fprintf(file, "*t%d\n", right->u.temp_no);
}

void printBin(struct InterCodes *icode)
{
	Operand result, op1, op2;
	result = icode->code.u.binop.result;
	op1 = icode->code.u.binop.op1;
	op2 = icode->code.u.binop.op2;

	if(result->kind == VARIABLE)
		fprintf(file, "v%d := ", result->u.var_no);
	else if(result->kind == TEMP)
		fprintf(file, "t%d := ", result->u.temp_no);
	else if(result->kind == ADDRESS_V)
		fprintf(file, "*v%d := ", result->u.var_no);
	else if(result->kind == ADDRESS_T)
		fprintf(file, "*t%d := ", result->u.temp_no);
	else if(result->kind == MEM_V)
		fprintf(file, "&v%d := ", result->u.var_no);
	else if(result->kind == MEM_T)
		fprintf(file, "&t%d := ", result->u.temp_no);
	
	if(op1->kind == VARIABLE)
		fprintf(file, "v%d", op1->u.var_no);
	else if(op1->kind == TEMP)
		fprintf(file, "t%d", op1->u.temp_no);
	else if(op1->kind == CONSTANT)
		fprintf(file, "#%d", op1->u.value);
	else if(op1->kind == ADDRESS_V)
		fprintf(file, "*v%d", op1->u.var_no);
	else if(op1->kind == ADDRESS_T)
		fprintf(file, "*t%d", op1->u.temp_no);
	else if(op1->kind == MEM_V)
		fprintf(file, "&v%d", op1->u.var_no);
	else if(op1->kind == MEM_T)
		fprintf(file, "&t%d", op1->u.temp_no);

	switch(icode->code.kind)
	{
		case ADD : fputs(" + ", file); break;
		case SUB : fputs(" - ", file); break;
		case MUL : fputs(" * ", file); break;
		case DIVI : fputs(" / ", file); break;
		default: break;
	}

	if(op2->kind == VARIABLE)
		fprintf(file, "v%d\n", op2->u.var_no);
	else if(op2->kind == TEMP)
		fprintf(file, "t%d\n", op2->u.temp_no);
	else if(op2->kind == CONSTANT)
		fprintf(file, "#%d\n", op2->u.value);
	else if(op2->kind == ADDRESS_V)
		fprintf(file, "*v%d\n", op2->u.var_no);
	else if(op2->kind == ADDRESS_T)
		fprintf(file, "*t%d\n", op2->u.temp_no);
	else if(op2->kind == MEM_V)
		fprintf(file, "&v%d\n", op2->u.var_no);
	else if(op2->kind == MEM_T)
		fprintf(file, "&t%d\n", op2->u.temp_no);
}

void printGotoLabel(struct InterCodes *icode)
{
	fprintf(file, "GOTO label%d\n", icode->code.u.gotoop.goto_label->u.label_no);
}

void printGotoCon(struct InterCodes *icode)
{
	Operand op1, op, op2, label;
	op1 = icode->code.u.goto_con.op1;
	op = icode->code.u.goto_con.op;
	op2 = icode->code.u.goto_con.op2;
	label = icode->code.u.goto_con.label;

	fputs("IF ", file);
	if(op1->kind == VARIABLE)
		fprintf(file, "v%d", op1->u.var_no);
	else if(op1->kind == TEMP)
		fprintf(file, "t%d", op1->u.temp_no);
	else if(op1->kind == ADDRESS_T)
		fprintf(file, "*t%d", op1->u.temp_no);
	else if(op1->kind == MEM_T)
		fprintf(file, "&t%d", op1->u.temp_no);
	else if(op1->kind == CONSTANT)
		fprintf(file, "#%d", op1->u.value);

	switch(op->u.op_kind)
	{
		case 0 : fputs(" == ", file); break;
		case 1 : fputs(" != ", file); break;
		case 2 : fputs(" < ", file); break;
		case 3 : fputs(" > ", file); break;
		case 4 : fputs(" <= ", file); break;
		case 5 : fputs(" >= ", file); break;
		default : break;
	}

	if(op2->kind == VARIABLE)
		fprintf(file, "v%d ", op2->u.var_no);
	else if(op2->kind == TEMP)
		fprintf(file, "t%d ", op2->u.temp_no);
	else if(op2->kind == CONSTANT)
		fprintf(file, "#%d ", op2->u.value);
	else if(op2->kind == ADDRESS_T)
		fprintf(file, "*t%d ", op2->u.temp_no);
	else if(op2->kind == MEM_T)
		fprintf(file, "&t%d ", op2->u.temp_no);

	fprintf(file, "GOTO label%d\n", label->u.label_no);
}

void printReturn(struct InterCodes *icode)
{
	Operand op = icode->code.u.returnop.op;
	if(op->kind == TEMP)
		fprintf(file, "RETURN t%d\n", op->u.temp_no);
	else if(op->kind == CONSTANT)
		fprintf(file, "RETURN #%d\n", op->u.value);
	else if(op->kind == VARIABLE)
		fprintf(file, "RETURN v%d\n", op->u.var_no);
}

void printDec(struct InterCodes *icode)
{
	fprintf(file, "DEC v%d %d\n", icode->code.u.dec.op->u.var_no, icode->code.u.dec.size);
}

void printArg(struct InterCodes *icode)
{
	Operand arg = icode->code.u.arg.arg;
	
	if(arg->kind == VARIABLE)
		fprintf(file, "ARG v%d\n", arg->u.var_no);
	else if(arg->kind == TEMP)
		fprintf(file, "ARG t%d\n", arg->u.temp_no);
	else if(arg->kind == CONSTANT)
		fprintf(file, "ARG #%d\n", arg->u.value);
	else if(arg->kind == MEM_V)
		fprintf(file, "ARG &v%d\n", arg->u.var_no);
	else if(arg->kind == MEM_T)
		fprintf(file, "ARG &t%d\n", arg->u.var_no);
	else if(arg->kind == ADDRESS_V)
		fprintf(file, "ARG *v%d\n", arg->u.var_no);
	else if(arg->kind == ADDRESS_T)
		fprintf(file, "ARG *t%d\n", arg->u.var_no);
}

void printCall(struct InterCodes *icode)
{
	Operand call = icode->code.u.callop.place;
	
	if(call->kind == TEMP)
		fprintf(file, "t%d := CALL ", call->u.temp_no);
	else if(call->kind == VARIABLE)
		fprintf(file, "v%d := CALL ", call->u.temp_no);
	fprintf(file, "%s\n", icode->code.u.callop.name);
}

void printParam(struct InterCodes *icode)
{
	Operand param = icode->code.u.param.param;

	if(param->kind == VARIABLE)
		fprintf(file, "PARAM v%d\n", param->u.var_no);
	if(param->kind == TEMP)
		fprintf(file, "PARAM t%d\n", param->u.temp_no);
	if(param->kind == CONSTANT)
		fprintf(file, "PARAM #%d\n", param->u.value);
}

void printRead(struct InterCodes *icode)
{
	Operand op = icode->code.u.read.op;
	
	if(op->kind == VARIABLE)
		fprintf(file, "READ v%d\n", op->u.var_no);
	else if(op->kind == TEMP)
		fprintf(file, "READ t%d\n", op->u.temp_no);
}

void printWrite(struct InterCodes *icode)
{
	Operand op = icode->code.u.write.op;
	
	if(op->kind == VARIABLE)
		fprintf(file, "WRITE v%d\n", op->u.var_no);
	else if(op->kind == TEMP)
		fprintf(file, "WRITE t%d\n", op->u.temp_no);
	else if(op->kind == ADDRESS_T)
		fprintf(file, "WRITE *t%d\n", op->u.temp_no);
	else if(op->kind == CONSTANT)
		fprintf(file, "WRITE #%d\n", op->u.value);
}

void printLabel(struct InterCodes *icode)
{
	Operand op = icode->code.u.label_code.label;
	fprintf(file, "LABEL label%d :\n", op->u.label_no);
}

void preDeal()
{
	//插入read函数
	struct mynode *mn1 = (struct mynode *)malloc(sizeof(struct mynode));
	Symbol sign1 = (Symbol)malloc(sizeof(struct Symbol_));
	sign1->kind = func;
	sign1->name = "read";
	sign1->u.func.return_type = (Type)malloc(sizeof(struct Type_));
	sign1->u.func.return_type->kind = basic;
	sign1->u.func.return_type->u.basic = 1;
	sign1->u.func.num = 0;
	sign1->u.func.first = NULL;
	mn1->sign = sign1;
	my_insert(&mytree, mn1);

	//插入write函数
	struct mynode *mn2 = (struct mynode *)malloc(sizeof(struct mynode));
	Symbol sign2 = (Symbol)malloc(sizeof(struct Symbol_));
	sign2->kind = func;
	sign2->name = "write";
	sign2->u.func.return_type = (Type)malloc(sizeof(struct Type_));
	sign2->u.func.return_type->kind = basic;
	sign2->u.func.return_type->u.basic = 1;
	sign2->u.func.num = 1;
	sign2->u.func.first = (FieldList)malloc(sizeof(struct FieldList_));
	sign2->u.func.first->name = NULL;
	sign2->u.func.first->type = (Type)malloc (sizeof(struct Type_));
	sign2->u.func.first->type->kind = basic;
	sign2->u.func.first->type->u.basic = 1;
	sign2->u.func.first->tail = NULL;
	mn2->sign = sign2;
	my_insert(&mytree, mn2);
}

void addcode(struct InterCodes *code1, struct InterCodes *code2)	//code1、code2分别为一系列节点的头部
{
	struct InterCodes *temp;
	temp = code1->prev;
	code1->prev = code2->prev;
	code2->prev->next = code1;
	temp->next = code2;
	code2->prev = temp;
}

void deletecode(struct InterCodes *code)
{
	code->prev->next = code->next;
	code->next->prev = code->prev;
	code->prev = NULL;
	code->next = NULL;
	free(code);
}

Operand new_temp()
{
	Operand temp = (Operand)malloc(sizeof(struct Operand_));
	temp->kind = TEMP;
	temp->u.temp_no = temp_count;
	temp_count++;
	return temp;
}

Operand new_label()
{
	Operand label = (Operand)malloc(sizeof(struct Operand_));
	label->kind = LABEL;
	label->u.label_no = label_count;
	label_count++;
	return label;
}

Operand lookup(Node *ID)
{
	Symbol temp = (Symbol)malloc(sizeof(struct Symbol_));
	my_search(&mytree, ID->id, temp);		//确定一定存在该变量，所以在这里不进行判断
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = VARIABLE;
	op->flag = temp->flag;
	op->u.var_no = temp->num + 1;			//下标从1开始
	return op;
}

Type lookupType(Node *ID)
{
	Symbol temp = (Symbol)malloc(sizeof(struct Symbol_));
	my_search(&mytree, ID->id, temp);
	Type type = (Type)malloc(sizeof(struct Type_));
	memcpy(type, temp->u.type, sizeof(struct Type_));		//确定该ID一定是变量，不可能是函数，所以这里不仅下判断
	return type;
}

int lookupSize(Type type, int size)
{
	FieldList first = type->u.structure;
//	static int size = 0;
	while(first != NULL)
	{
		if(first->type->kind == basic)
			size = size + 4;		//默认只含有int类型
		if(first->type->kind == structure)
			size = size + lookupSize(first->type, size);
		if(first->type->kind == array)
		{
			if(first->type->u.array.elem->kind == array)		//高维数组
			{
				printf("Can not translate the code: Contain multidimensional array!\n");
				exit(0);
			}
			else if(first->type->u.array.elem->kind == structure)
				size = size + first->type->u.array.size * lookupSize(first->type->u.array.elem, size);
			else
				size = size + first->type->u.array.size * 4;
		}
		first = first->tail;
	}
	return size;
}

int lookupOffset(Type type, Node *ID, int offset)
{
	mark_s = 0;
	if(type->kind == array)
	{
		if(type->u.array.elem->kind == basic)
			return 0;
		else if(type->u.array.elem->kind == structure)
			return lookupOffset(type->u.array.elem, ID, offset);
	}
	else if(type->kind == structure)		//结构体类型
	{
		FieldList first = type->u.structure;
		while(first != NULL && strcmp(first->name, ID->id) != 0)
		{
			if(first->type->kind == basic)
				offset = offset + 4;
			else if(first->type->kind == array)
			{
				if(first->type->u.array.elem->kind == basic)
					offset = offset + 4 * first->type->u.array.size;
				else if(first->type->u.array.elem->kind == structure)
				{
					Type temp_type = (Type)malloc(sizeof(struct Type_));
					if(searchStructName(first->type->u.array.elem->u.structure->tail, ID->id, temp_type) == 1)
						offset = offset + lookupOffset(first->type->u.array.elem, ID, offset);
					else
						offset = offset + lookupSize(first->type->u.array.elem, 0) * first->type->u.array.size;
				}
			}
			else if(first->type->kind == structure)
				offset = offset + lookupOffset(first->type, ID, offset);
//			else
//				offset = offset + lookupSize(first->type, 0);
			if(mark_s == 1)
				break;
			first = first->tail;
		}
		if(first != NULL && strcmp(first->name, ID->id) == 0)
			mark_s = 1;
	}
	return offset;
}

char *lookupfunc(Node *ID)
{
	Symbol temp = (Symbol)malloc(sizeof(struct Symbol_));
	my_search(&mytree, ID->id, temp);
	return temp->name;
}

Operand get_value(int value)
{
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = CONSTANT;
	op->u.value = value;
	return op;
}

Operand get_relop(Node *RELOP)
{
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = OP;
	if(strcmp(RELOP->id, "==") == 0)
		op->u.op_kind = 0;
	else if(strcmp(RELOP->id, "!=") == 0)
		op->u.op_kind = 1;
	else if(strcmp(RELOP->id, "<") == 0)
		op->u.op_kind = 2;
	else if(strcmp(RELOP->id, ">") == 0)
		op->u.op_kind = 3;
	else if(strcmp(RELOP->id, "<=") == 0)
		op->u.op_kind = 4;
	else if(strcmp(RELOP->id, ">=") == 0)
		op->u.op_kind = 5;
	return op;
}

struct InterCodes *gen_assign(Operand left, Operand right)		//赋值操作
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;		//双向循环链表，所以头和尾部仍然指向自己
	icodes->next = icodes;
	icodes->code.kind = ASSIGN;
	icodes->code.u.assign.left = (Operand)malloc(sizeof(struct Operand_));
	icodes->code.u.assign.right = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.assign.left, left, sizeof(struct Operand_));
	memcpy(icodes->code.u.assign.right, right, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_bin(Operand result, Operand op1, Operand op2, int kind)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;		//双向循环链表，所以头和尾部仍然指向自己
	icodes->next = icodes;
	switch(kind)
	{
		case 0 : icodes->code.kind = ADD; break;
		case 1 : icodes->code.kind = SUB; break;
		case 2 : icodes->code.kind = MUL; break;
		case 3 : icodes->code.kind = DIVI; break;
		default :break;
	}
	icodes->code.u.binop.result = (Operand)malloc(sizeof(struct Operand_));
	icodes->code.u.binop.op1 = (Operand)malloc(sizeof(struct Operand_));
	icodes->code.u.binop.op2 = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.binop.result, result, sizeof(struct Operand_));
	memcpy(icodes->code.u.binop.op1, op1, sizeof(struct Operand_));
	memcpy(icodes->code.u.binop.op2, op2, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_label(Operand label)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = LABEL_CODE;
	icodes->code.u.gotoop.goto_label = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.gotoop.goto_label, label, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_return(Operand op)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = RETURN_OP;
	icodes->code.u.returnop.op = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.returnop.op, op, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_goto(Operand label)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = GOTO_LABEL;
	icodes->code.u.gotoop.goto_label = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.gotoop.goto_label, label, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_con(Operand op1, Operand op, Operand op2, Operand label)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = GOTO_CON;
	icodes->code.u.goto_con.op1 = (Operand)malloc(sizeof(struct Operand_));
	icodes->code.u.goto_con.op = (Operand)malloc(sizeof(struct Operand_));
	icodes->code.u.goto_con.op2 = (Operand)malloc(sizeof(struct Operand_));
	icodes->code.u.goto_con.label = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.goto_con.op1, op1, sizeof(struct Operand_));
	memcpy(icodes->code.u.goto_con.op, op, sizeof(struct Operand_));
	memcpy(icodes->code.u.goto_con.op2, op2, sizeof(struct Operand_));
	memcpy(icodes->code.u.goto_con.label, label, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_read(Operand op)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = READ;
	icodes->code.u.read.op = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.read.op, op, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_call(Operand place, char *name)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = CALL;
	icodes->code.u.callop.place = (Operand)malloc(sizeof(struct Operand_));
	icodes->code.u.callop.name = (char *)malloc(sizeof(char) *(strlen(name) + 1));
	memcpy(icodes->code.u.callop.place, place, sizeof(struct Operand_));
	memcpy(icodes->code.u.callop.name, name, sizeof(char) *(strlen(name) + 1));
	return icodes;
}

struct InterCodes *gen_write(Operand op)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = WRITE;
	icodes->code.u.write.op = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.write.op, op, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_arg(Operand arg)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = ARG;
	icodes->code.u.arg.arg = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.arg.arg, arg, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_func(char *name)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = FUNCTION;
	icodes->code.u.func.name = (char *)malloc(sizeof(char) *(strlen(name) + 1));
	memcpy(icodes->code.u.func.name, name, sizeof(char) *(strlen(name) + 1));
	return icodes;
}

struct InterCodes *gen_param(Operand param)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = PARAM;
	icodes->code.u.param.param = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.param.param, param, sizeof(struct Operand_));
	return icodes;
}

struct InterCodes *gen_dec(Operand var, int size)
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = DEC;
	icodes->code.u.dec.op = (Operand)malloc(sizeof(struct Operand_));
	memcpy(icodes->code.u.dec.op, var, sizeof(struct Operand_));
	icodes->code.u.dec.size = size;
	return icodes;
}

struct InterCodes *gen_null()
{
	struct InterCodes *icodes = (struct InterCodes *)malloc(sizeof(struct InterCodes));
	icodes->prev = icodes;
	icodes->next = icodes;
	icodes->code.kind = NOTH;
	return icodes;
}

struct InterCodes *translate_Args(Node *Args, struct ArgList **arg_list)
{
	Operand t1 = new_temp();

	struct InterCodes *code1 = translate_Exp(Args->firstChild, t1);
	int mark = 0;	
//	printf("#################: %d\n", Args->line);
	Node *temp_node = Args->firstChild;
	Node *temp_prev = NULL;
	do
	{
		if(strcmp(temp_node->type, "Exp") != 0 && strcmp(temp_node->type, "ID") != 0)
		{
			mark = 1;
			break;
		}
		else if(temp_prev != NULL && temp_prev->nextSibling != NULL && strcmp(temp_prev->nextSibling->type, "DOT") == 0)
		{
			temp_node = temp_prev->nextSibling->nextSibling;
			break;
		}
		else if(strcmp(temp_node->type, "ID") == 0)
			break;
		else
		{
			temp_prev = temp_node;
			temp_node = temp_node->firstChild;
		}
	}while(1);
	
	if(mark == 0)
	{
		Type type = lookupType(temp_node);

		//用来处理数组和结构体参数传递，这时候传递的是地址
		if(type->kind == array)
		{
			if(type->u.array.elem->kind == structure)
				t1->kind = TEMP;
		}
		else if(type->kind == structure)
		{
			//用来处理结构体引用，应该引用变量的地址。而不是临时变量的
			if(code1->code.u.assign.right->kind == VARIABLE)
				code1->code.u.assign.right->kind = MEM_V;
			else if(code1->code.u.assign.right->kind == TEMP)
				code1->code.u.assign.right->kind = MEM_T;
			t1->kind = TEMP;
		}
	}

	if(*arg_list == NULL)
	{
		*arg_list = (struct ArgList *)malloc(sizeof(struct ArgList));
		memcpy(&((*arg_list)->arg), t1, sizeof(struct Operand_));
		(*arg_list)->next = NULL;
	}
	else
	{
		struct ArgList* temp = (struct ArgList *)malloc(sizeof(struct ArgList));
		memcpy(&(temp->arg), t1, sizeof(struct Operand_));
		temp->next = *arg_list;
		*arg_list = temp;
	}
	if(Args->firstChild->nextSibling == NULL)		// Args : Exp
		return code1;
	else		// Args : Exp COMMA Args
	{
		struct InterCodes *code2 = translate_Args(Args->firstChild->nextSibling->nextSibling, arg_list);
		addcode(code1, code2);
		return code1;
	}
}

struct InterCodes *translate_Cond(Node *Exp, Operand label_true, Operand label_false)
{
	if(strcmp(Exp->firstChild->type, "Exp") == 0 && strcmp(Exp->firstChild->nextSibling->type, "RELOP") == 0)
	{
		Operand t1 = new_temp();
		Operand t2 = new_temp();
		struct InterCodes *code1 = translate_Exp(Exp->firstChild, t1);
		struct InterCodes *code2 = translate_Exp(Exp->firstChild->nextSibling->nextSibling, t2);
		Operand op = get_relop(Exp->firstChild->nextSibling);
		struct InterCodes *code3 = gen_con(t1, op, t2, label_true);
		struct InterCodes *code4 = gen_goto(label_false);
		addcode(code1, code2);
		addcode(code1, code3);
		addcode(code1, code4);
		return code1;
	}
	else if(strcmp(Exp->firstChild->type, "Exp") == 0 && strcmp(Exp->firstChild->nextSibling->type, "AND") == 0)
	{
		Operand label1 = new_label();
		struct InterCodes *code1 = translate_Cond(Exp->firstChild, label1, label_false);
		struct InterCodes *code2 = translate_Cond(Exp->firstChild->nextSibling->nextSibling, label_true, label_false);
		struct InterCodes *temp_code = gen_label(label1);
		addcode(code1, temp_code);
		addcode(code1, code2);
		return code1;
	}
	else if(strcmp(Exp->firstChild->type, "Exp") == 0 && strcmp(Exp->firstChild->nextSibling->type, "OR") == 0)
	{
		Operand label1 = new_label();
		struct InterCodes *code1 = translate_Cond(Exp->firstChild, label_true, label1);
		struct InterCodes *code2 = translate_Cond(Exp->firstChild->nextSibling->nextSibling, label_true, label_false);
		struct InterCodes *temp_code = gen_label(label1);
		addcode(code1, temp_code);
		addcode(code1, code2);
		return code1;
	}
	else if(strcmp(Exp->firstChild->type, "NOT") == 0 && strcmp(Exp->firstChild->nextSibling->type, "Exp") == 0)
	{
		return translate_Cond(Exp->firstChild->nextSibling, label_false, label_true);
	}
	else
	{
		Operand t1 = new_temp();
		struct InterCodes *code1 = translate_Exp(Exp, t1);
		Operand t2 = (Operand)malloc(sizeof(struct Operand_));
		t2->kind = OP;
		t2->u.op_kind = 1;
		Operand t3 = get_value(0);
		struct InterCodes *code2 = gen_con(t1, t2, t3, label_true);
		struct InterCodes *code3 = gen_goto(label_false);
		addcode(code1, code2);
		addcode(code1, code3);
		return code1;
	}
}

struct InterCodes *translate_Exp(Node *Exp, Operand place)
{
	if(place == NULL)		//首先判断place是否为空
		place = new_temp();
	if(strcmp(Exp->firstChild->type, "INT") == 0)
	{
		Operand value = get_value(Exp->firstChild->i_value);
		memcpy(place, value, sizeof(struct Operand_));			//对立即数进行优化操作
		struct InterCodes *icodes = gen_null();
//		struct InterCodes *icodes = gen_assign(place, value);
		return icodes;
	}
	if(strcmp(Exp->firstChild->type, "ID") == 0)
	{
		if(Exp->firstChild->nextSibling == NULL)		//Exp : ID
		{
			Operand var = lookup(Exp->firstChild);
			struct InterCodes *icodes = gen_assign(place, var);

			Type type = lookupType(Exp->firstChild);		//处理参数是struct类型（其他不会出现）
			if(type->kind == structure)
				place->kind = MEM_T;

			return icodes;
		}
		else if(strcmp(Exp->firstChild->nextSibling->type, "LP") == 0)		//函数调用
		{
			char *func_name = lookupfunc(Exp->firstChild);
			struct InterCodes *icodes;
			if(strcmp(Exp->firstChild->nextSibling->nextSibling->type, "RP") == 0)	//无参函数调用
			{
				if(strcmp(func_name, "read") == 0)
					icodes = gen_read(place);
				else
					icodes = gen_call(place, func_name);
				return icodes;
			}
			else			//含参函数调用
			{
				struct ArgList *arg_list = NULL;
				struct InterCodes *code1 = translate_Args(Exp->firstChild->nextSibling->nextSibling, &arg_list);
				if(strcmp(func_name, "write") == 0)
				{
					struct InterCodes *code2;
					if(arg_list->arg.kind == ADDRESS_T)
					{
						Operand t1 = new_temp();
						struct InterCodes *temp_code = gen_assign(t1, &(arg_list->arg));
						addcode(code1, temp_code);
						code2 = gen_write(t1);
					}
					else
						code2 = gen_write(&(arg_list->arg));
					addcode(code1, code2);
					return code1;
				}
				else
				{
					struct InterCodes *code2 = NULL;
					struct InterCodes *temp_code;
					struct ArgList *temp_arg = arg_list;
					while(temp_arg != NULL)
					{
/*						if(temp_arg->arg.kind == ADDRESS_T)
						{
							temp_arg->arg.kind = TEMP;
						}*/
						if(code2 == NULL)
							code2 = gen_arg(&(temp_arg->arg));
						else
						{
							temp_code = gen_arg(&(temp_arg->arg));
							addcode(code2, temp_code);
						}
						temp_arg = temp_arg->next;
					}
					addcode(code1, code2);
					struct InterCodes *code3 = gen_call(place, func_name);
					addcode(code1, code3);
					return code1;
				}
			}
		}
	}
	if(strcmp(Exp->firstChild->type, "Exp") == 0)
	{
		if(strcmp(Exp->firstChild->nextSibling->type, "ASSIGNOP") == 0)
		{
			if(strcmp(Exp->firstChild->firstChild->type, "ID") == 0)	//如果Exp1产生ID
			{
				Operand t1 = new_temp();
				Operand var = lookup(Exp->firstChild->firstChild);
	
				struct InterCodes *code1 = translate_Exp(Exp->firstChild->nextSibling->nextSibling, t1);

				struct InterCodes *code2_1 = gen_assign(var, t1);
				struct InterCodes *code2_2 = gen_assign(place, var);
				addcode(code2_1, code2_2);
				addcode(code1, code2_1);
				return code1;
			}
			else
			{	
				Operand t1 = new_temp();
				struct InterCodes *code1 = translate_Exp(Exp->firstChild, place);
//				place->kind = ADDRESS_T;
//				printf("place num: %d\n", place->u.temp_no);
				struct InterCodes *code2_1 = translate_Exp(Exp->firstChild->nextSibling->nextSibling, t1);
				struct InterCodes *code2_2 = gen_assign(place, t1);
				addcode(code2_1, code2_2);
				addcode(code1, code2_1);
				return code1;
			}
		}
		if(strcmp(Exp->firstChild->nextSibling->type, "LB") == 0)	// Exp : Exp LB Exp RB
		{
			Operand t1 = new_temp();	//t1用来获取数组下标
			Operand t2 = new_temp();	//t2用来获取数组偏移量
			struct InterCodes *code1 = translate_Exp(Exp->firstChild->nextSibling->nextSibling, t1);

			//只可能出现ID或者结构体的情况，其余不可能

			if(strcmp(Exp->firstChild->firstChild->type, "ID") == 0)
			{
				Operand var = lookup(Exp->firstChild->firstChild);
				//得到数组的类型（即单元大小）
				Type type = lookupType(Exp->firstChild->firstChild);
				Operand size = (Operand)malloc(sizeof(struct Operand_));
				size->kind = CONSTANT;
				if(type->u.array.elem->kind == basic)
					size->u.value = 4;		//只允许int型
				else if(type->u.array.elem->kind == structure)			//对struct类型进行处理
					size->u.value = lookupSize(type->u.array.elem, 0);		//从struct表中取出该类型的大小
				else			//多维数组，报错！
				{
					printf("Can not translate the code: Contain multidimensional array!\n");
					exit(0);
				}
				
				struct InterCodes *code2 = NULL;
				if(size->u.value == 0)
					code2 = gen_assign(t2, size);
				else if(t1->kind == CONSTANT && t1->u.value == 0)
					code2 = gen_assign(t2, t1);
				else if(t1->kind == CONSTANT && t1->u.value == 1)
					code2 = gen_assign(t2, size);
				else if(size->kind == CONSTANT && size->u.value == 1)
					code2 = gen_assign(t2, t1);
				else
					code2 = gen_bin(t2, t1, size, 2);
				//得到地址
				var->kind = MEM_V;
				struct InterCodes *code3 = NULL;
				if(t2->kind == CONSTANT && t2->u.value == 0)
					code3 = gen_assign(place, var);
				else
					code3 = gen_bin(place, var, t2, 0);
				addcode(code1, code2);
				addcode(code1, code3);
				place->kind = ADDRESS_T;
//				printf("place num: %d\n", place->u.temp_no);
				return code1;
			}
			else if(strcmp(Exp->firstChild->firstChild->type, "Exp") == 0 && strcmp(Exp->firstChild->firstChild->nextSibling->type, "DOT") == 0)		//对结构体进行处理
			{	
				Operand temp = new_temp();
				//得到的temp是数组的首地址，是ADDRESS_T类型
				struct InterCodes *code1_2 = translate_Exp(Exp->firstChild, temp);	
				temp->kind = TEMP;
				
				Type type = lookupType(Exp->firstChild->firstChild->nextSibling->nextSibling);
				Operand size = (Operand)malloc(sizeof(struct Operand_));
				size->kind = CONSTANT;
				if(type->u.array.elem->kind == basic)
					size->u.value = 4;		//只允许int型
				else if(type->u.array.elem->kind == structure)			//对struct类型进行处理
					size->u.value = lookupSize(type->u.array.elem, 0);		//从struct表中取出该类型的大小
				else			//多维数组，报错！
				{
					printf("Can not translate the code: Contain multidimensional array!\n");
					exit(0);
				}

				struct InterCodes *code2 = NULL;
				if(size->u.value == 0)
					code2 = gen_assign(t2, size);
				else if(t1->kind == CONSTANT && t1->u.value == 0)
					code2 = gen_assign(t2, t1);
				else if(t1->kind == CONSTANT && t1->u.value == 1)
					code2 = gen_assign(t2, size);
				else if(size->kind == CONSTANT && size->u.value == 1)
					code2 = gen_assign(t2, t1);
				else
					code2 = gen_bin(t2, t1, size, 2);
				//得到地址
				struct InterCodes *code3 = NULL;
				if(t2->kind == CONSTANT && t2->u.value == 0)
					code3 = gen_assign(place, temp);
				else
					code3 = gen_bin(place, temp, t2, 0);
				addcode(code1, code1_2);
				addcode(code1, code2);
				addcode(code1, code3);
				place->kind = ADDRESS_T;
//				printf("place num: %d\n", place->u.temp_no);
				return code1;

			}
			else
			{
				printf("Can not translate the code: Contain multidimensional array!\n");
				exit(0);
			}
		}
		if(strcmp(Exp->firstChild->nextSibling->type, "DOT") == 0)
		{
			//得到偏移
			Operand offset = (Operand)malloc(sizeof(struct Operand_));
			offset->kind = CONSTANT;

			if(strcmp(Exp->firstChild->firstChild->type, "ID") == 0)
			{
				Type type = lookupType(Exp->firstChild->firstChild);
				offset->u.value = lookupOffset(type, Exp->firstChild->nextSibling->nextSibling, 0);
				Operand var = lookup(Exp->firstChild->firstChild);
				if(var->flag == 0)		//普通变量
				{
//					Operand t1 = new_temp();		//t1用来获得偏移量
					var->kind = MEM_V;
				}
				struct InterCodes *code1 = NULL;
				if(offset->u.value == 0)
					code1 = gen_assign(place, var);
				else
					code1 = gen_bin(place, var, offset, 0);		//得到偏移
				place->kind = ADDRESS_T;
				return code1;
			}
			else if(strcmp(Exp->firstChild->firstChild->type, "Exp") == 0)
			{
				Node *temp = Exp->firstChild->firstChild;
				while(strcmp(temp->type, "ID") != 0)
					temp = temp->firstChild;
				Type type = lookupType(temp);
				offset->u.value = lookupOffset(type, Exp->firstChild->nextSibling->nextSibling, 0);

				Operand t1 = new_temp();
				//只考虑可能是Exp DOT ID或者Exp LB Exp RB，t1返回的是首地址
				struct InterCodes *code1 = translate_Exp(Exp->firstChild, t1);
				t1->kind = TEMP;
				struct InterCodes *code2 = NULL;
				if(offset->u.value == 0)
					code2 = gen_assign(place, t1);
				else
					code2 = gen_bin(place, t1, offset, 0);
				place->kind = ADDRESS_T;
				addcode(code1, code2);
				return code1;
			}
			//有没有可能是括号？？？？？？？？？？？？？？？？？？
		}
		if(strcmp(Exp->firstChild->nextSibling->type, "PLUS") == 0 || strcmp(Exp->firstChild->nextSibling->type, "MINUS") == 0
		|| strcmp(Exp->firstChild->nextSibling->type, "STAR") == 0 || strcmp(Exp->firstChild->nextSibling->type, "DIV") == 0)
		{
			Operand t1 = new_temp();
			Operand t2 = new_temp();
			struct InterCodes *code1 = translate_Exp(Exp->firstChild, t1);
			struct InterCodes *code2 = translate_Exp(Exp->firstChild->nextSibling->nextSibling, t2);
			struct InterCodes *code3 = NULL;
			if(strcmp(Exp->firstChild->nextSibling->type, "PLUS") == 0)
			{
				if(t1->kind == CONSTANT && t2->kind == CONSTANT)
				{
					int result = t1->u.value + t2->u.value;
					Operand bin = get_value(result);
					code3 = gen_assign(place, bin);
				}
				else
				{
					if(t2->kind == CONSTANT && t2->u.value == 0)
						code3 = gen_assign(place, t1);
					else
						code3 = gen_bin(place, t1, t2, 0);
				}
			}
			if(strcmp(Exp->firstChild->nextSibling->type, "MINUS") == 0)
			{
				if(t1->kind == CONSTANT && t2->kind == CONSTANT)
				{
					int result = t1->u.value - t2->u.value;
					Operand bin = get_value(result);
					code3 = gen_assign(place, bin);
				}
				else
				{
					if(t2->kind == CONSTANT && t2->u.value == 0)
						code3 = gen_assign(place, t1);
					else
						code3 = gen_bin(place, t1, t2, 1);
				}
			}
			if(strcmp(Exp->firstChild->nextSibling->type, "STAR") == 0)
			{
				if(t1->kind == CONSTANT && t2->kind == CONSTANT)
				{
					int result = t1->u.value * t2->u.value;
					Operand bin = get_value(result);
					code3 = gen_assign(place, bin);
				}
				else if(t1->kind == CONSTANT && t1->u.value == 1)
					code3 = gen_assign(place, t2);
				else if(t2->kind == CONSTANT && t2->u.value == 1)
					code3 = gen_assign(place, t1);
				else
				{
					if(t2->kind == CONSTANT && t2->u.value == 0)
						code3 = gen_assign(place, t2);
					else if(t1->kind == CONSTANT && t1->u.value == 0)
						code3 = gen_assign(place, t1);
					else
						code3 = gen_bin(place, t1, t2, 2);
				}
			}
			if(strcmp(Exp->firstChild->nextSibling->type, "DIV") == 0)
			{
				if(t1->kind == CONSTANT && t2->kind == CONSTANT)
				{
					int result = t1->u.value / t2->u.value;
					Operand bin = get_value(result);
					code3 = gen_assign(place, bin);
				}
				else if(t2->kind == CONSTANT && t2->u.value == 1)
					code3 = gen_assign(place, t1);
				else
					code3 = gen_bin(place, t1, t2, 3);
			}
			addcode(code1, code2);
			addcode(code1, code3);
			return code1;
		}
		if(strcmp(Exp->firstChild->nextSibling->type, "AND") == 0 || strcmp(Exp->firstChild->nextSibling->type, "OR") == 0
		|| strcmp(Exp->firstChild->nextSibling->type, "RELOP") == 0)
		{
			Operand label1 = new_label();
			Operand label2 = new_label();
			Operand va1 = get_value(0);
			struct InterCodes *code0 = gen_assign(place, va1);
			struct InterCodes *code1 = translate_Cond(Exp, label1, label2);
			struct InterCodes *code2_1 = gen_label(label1);
			Operand va2 = get_value(1);
			struct InterCodes *code2_2 = gen_assign(place, va2);
			addcode(code2_1, code2_2);
			struct InterCodes *code3 = gen_label(label2);
			addcode(code0, code1);
			addcode(code0, code2_1);
			addcode(code0, code3);
			return code0;
		}
	}
	if(strcmp(Exp->firstChild->type, "LP") == 0)
	{
		return translate_Exp(Exp->firstChild->nextSibling, place);
	}
	if(strcmp(Exp->firstChild->type, "MINUS") == 0)
	{
		Operand t1 = new_temp();
		struct InterCodes *code1 = translate_Exp(Exp->firstChild->nextSibling, t1);
		Operand va = get_value(0);
		struct InterCodes *code2 = NULL;
		if(t1->kind == CONSTANT)
		{
			int result = 0 - t1->u.value;
			Operand bin = get_value(result);
			code2 = gen_assign(place, bin);
		}
		else
			code2 = gen_bin(place, va, t1, 1);
		addcode(code1, code2);
		return code1;
	}
	if(strcmp(Exp->firstChild->type, "NOT") == 0)
	{
		Operand label1 = new_label();
		Operand label2 = new_label();
		Operand va1 = get_value(0);
		struct InterCodes *code0 = gen_assign(place, va1);
		struct InterCodes *code1 = translate_Cond(Exp, label1, label2);
		struct InterCodes *code2_1 = gen_label(label1);
		Operand va2 = get_value(1);
		struct InterCodes *code2_2 = gen_assign(place, va2);
		addcode(code2_1, code2_2);
		struct InterCodes *code3 = gen_label(label2);
		addcode(code0, code1);
		addcode(code0, code2_1);
		addcode(code0, code3);
		return code0;
	}
}

struct InterCodes *translate_VarDec(Node *VarDec)
{
	if(strcmp(VarDec->firstChild->type, "ID") == 0)		// VarDec : ID
	{
		Type type = lookupType(VarDec->firstChild);
		if(type->kind == structure)			//对结构体赋空间
		{
			int size = lookupSize(type, 0);
			Operand var = lookup(VarDec->firstChild);
			struct InterCodes* code = gen_dec(var, size);
			return code;
		}
		else
			return NULL;
	}
	else
	{
		if(strcmp(VarDec->firstChild->firstChild->type, "ID") != 0)		//不允许高维数组
		{
			printf("Can not translate the code: Contain multidimensional array!\n");
			exit(0);
		}
		else
		{
			Type type = lookupType(VarDec->firstChild->firstChild);
			int size;
			if(type->u.array.elem->kind == basic)
				size = 4 * VarDec->firstChild->nextSibling->nextSibling->i_value;
			else		//只可能为struct类型
				size = lookupSize(type->u.array.elem, 0) * VarDec->firstChild->nextSibling->nextSibling->i_value;
			Operand var = lookup(VarDec->firstChild->firstChild);
			struct InterCodes* code = gen_dec(var, size);
			return code;
		}
	}
}

struct InterCodes *translate_Dec(Node *Dec)
{
	if(Dec->firstChild->nextSibling == NULL)
	{
		Node *VarDec = Dec->firstChild;
		return translate_VarDec(VarDec);
	}
	else
	{
/*		if(place == NULL)
			place = new_temp();*/
		Node *Exp = Dec->firstChild->nextSibling->nextSibling;
		Node *VarDec = Dec->firstChild;
		Operand t1 = new_temp();
		struct InterCodes *code1 = translate_Exp(Exp, t1);
		if(strcmp(VarDec->firstChild->type, "ID") == 0)		// VarDec : ID
		{
			Operand var = lookup(VarDec->firstChild);
			struct InterCodes *code2_1 = gen_assign(var, t1);
//			struct InterCodes *code2_2 = gen_assign(place, var);
//			addcode(code2_1, code2_2);
			addcode(code1, code2_1);
			return code1;
		}
		else		// VarDec : VarDec LB INT RB
		{
			//数组定义时不能初始化
			printf("Can not translate the code: Contain multidimensional array!\n");
			exit(0);
		}
	}
}

struct InterCodes *translate_DecList(Node *DecList)
{
	Node *Dec = DecList->firstChild;
//	struct InterCodes *code1 = translate_Dec(Dec, NULL);
	struct InterCodes *code1 = translate_Dec(Dec);
	if(Dec->nextSibling != NULL)
	{
		struct InterCodes *code2 = translate_DecList(Dec->nextSibling->nextSibling);
		if(code1 == NULL)
			return code2;
		else if(code2 == NULL)
			return code1;
		else
		{
			addcode(code1, code2);
			return code1;
		}
	}
	else
		return code1;
}

struct InterCodes *translate_DefList(Node *DefList)
{
	if(DefList == NULL)
		return NULL;
	Node *DecList = DefList->firstChild->firstChild->nextSibling;
	struct InterCodes *code1 = translate_DecList(DecList);
	struct InterCodes *code2 = translate_DefList(DefList->firstChild->nextSibling);
	if(code2 == NULL)
		return code1;
	else if(code1 == NULL)
		return code2;
	else
	{
		addcode(code1, code2);
		return code1;
	}
}

struct InterCodes *translate_CompSt(Node *CompSt)
{
	Node *DefList = NULL;
	Node *StmtList = NULL;
	if(strcmp(CompSt->firstChild->nextSibling->type, "StmtList") == 0)	//DefList为空
		StmtList = CompSt->firstChild->nextSibling;
	else
	{
		DefList = CompSt->firstChild->nextSibling;
		StmtList = CompSt->firstChild->nextSibling->nextSibling;
	}
	
	struct InterCodes *code1;
	if(DefList == NULL)
		code1 = NULL;
	else
		code1 = translate_DefList(DefList);
	
	if(StmtList == NULL)
		return code1;		//code1也可能为NULL，这时候就返回为NULL

	struct InterCodes *code2 = NULL;
	while(StmtList != NULL)
	{
		Node *Stmt = StmtList->firstChild;
		if(code2 == NULL)
			code2 = translate_Stmt(Stmt);
		else
		{
			struct InterCodes *temp = translate_Stmt(Stmt);
			addcode(code2, temp);
		}
		StmtList = Stmt->nextSibling;
	}
	
	if(code1 == NULL)
		return code2;
	else
	{
		addcode(code1, code2);
		return code1;
	}
}

struct InterCodes *translate_Stmt(Node *Stmt)
{
	if(strcmp(Stmt->firstChild->type, "Exp") == 0)		// Stmt : Exp SEMI
	{
		return translate_Exp(Stmt->firstChild, NULL);
	}
	if(strcmp(Stmt->firstChild->type, "CompSt") == 0)		// Stmt : Compst
	{
		return translate_CompSt(Stmt->firstChild);
	}
	if(strcmp(Stmt->firstChild->type, "RETURN") == 0)		// Stmt : RETURN Exp SEMI
	{
		Operand t1 = new_temp();
		struct InterCodes *code1 = translate_Exp(Stmt->firstChild->nextSibling, t1);
		struct InterCodes *code2 = gen_return(t1);
		addcode(code1, code2);
		return code1;
	}
	if(strcmp(Stmt->firstChild->type, "IF") == 0)
	{
		Operand label1 = new_label();
		Operand label2 = new_label();
		struct InterCodes *code1 = translate_Cond(Stmt->firstChild->nextSibling->nextSibling, label1, label2);
		struct InterCodes *code2 = translate_Stmt(Stmt->firstChild->nextSibling->nextSibling->nextSibling->nextSibling);
		if(Stmt->firstChild->nextSibling->nextSibling->nextSibling->nextSibling->nextSibling != NULL)	//IF语句含有ELSE
		{
			Operand label3 = new_label();
			struct InterCodes *code3 = translate_Stmt(Stmt->firstChild->nextSibling->nextSibling->nextSibling->nextSibling->nextSibling->nextSibling);
			struct InterCodes *temp1 = gen_label(label1);
			struct InterCodes *temp2 = gen_goto(label3);
			struct InterCodes *temp3 = gen_label(label2);
			struct InterCodes *temp4 = gen_label(label3);
			addcode(code1, temp1);
			addcode(code1, code2);
			addcode(code1, temp2);
			addcode(code1, temp3);
			addcode(code1, code3);
			addcode(code1, temp4);	
			return code1;
		}
		else		//IF语句不含有ELSE
		{
			struct InterCodes *temp1 = gen_label(label1);
			struct InterCodes *temp2 = gen_label(label2);
			addcode(code1, temp1);
			addcode(code1, code2);
			addcode(code1, temp2);
			return code1;
		}
	}
	if(strcmp(Stmt->firstChild->type, "WHILE") == 0)
	{
		Operand label1 = new_label();
		Operand label2 = new_label();
		Operand label3 = new_label();
		struct InterCodes *code1 = translate_Cond(Stmt->firstChild->nextSibling->nextSibling, label2, label3);
		struct InterCodes *code2 = translate_Stmt(Stmt->firstChild->nextSibling->nextSibling->nextSibling->nextSibling);
		struct InterCodes *temp1 = gen_label(label1);
		struct InterCodes *temp2 = gen_label(label2);
		struct InterCodes *temp3 = gen_goto(label1);
		struct InterCodes *temp4 = gen_label(label3);
		addcode(temp1, code1);
		addcode(temp1, temp2);
		addcode(temp1, code2);
		addcode(temp1, temp3);
		addcode(temp1, temp4);
		return temp1;
	}
}

struct InterCodes *translate_VarList(Node *VarList)
{
	struct InterCodes *code1 = NULL;
	struct InterCodes *code2 = NULL;
	while(VarList != NULL)
	{
		Node *ParamDec = VarList->firstChild;
		Node *VarDec = ParamDec->firstChild->nextSibling;
		if(strcmp(VarDec->firstChild->type, "ID") == 0 )	// VarDec : ID
		{
			Operand var = lookup(VarDec->firstChild);
			if(code1 == NULL)
				code1 = gen_param(var);
			else
			{
				code2 = gen_param(var);
				addcode(code1, code2);
			}
		}
		else		// VarDec : VarDec LB INT RB
		{
			//函数参数不能传递数组类型
			printf("Can not translate the code: Contain function parameters of array type!\n");
			exit(0);
		}
		if(VarList->firstChild->nextSibling == NULL)
			VarList = NULL;
		else
			VarList = VarList->firstChild->nextSibling->nextSibling;
	}
	return code1;
}

struct InterCodes *translate_FunDec(Node *FunDec)
{
	char *name = lookupfunc(FunDec->firstChild);
	struct InterCodes *code1 = gen_func(name);
	if(FunDec->firstChild->nextSibling->nextSibling->nextSibling == NULL)		// FunDec : ID LP RP
		return code1;
	else		// FunDec : ID LP VarList RP
	{
		struct InterCodes *code2 = translate_VarList(FunDec->firstChild->nextSibling->nextSibling);
		addcode(code1, code2);
		return code1;
	}
}

struct InterCodes *translate_ExtDef(Node *ExtDef)
{
	if(ExtDef->firstChild->nextSibling->nextSibling == NULL)	//ExtDef : Specifier SEMI
	{
		return NULL;
	}
	else if(strcmp(ExtDef->firstChild->nextSibling->nextSibling->type, "SEMI") == 0)	//ExtDef : Specifier ExtDecList SEMI
	{
		Node *ExtDecList = ExtDef->firstChild->nextSibling;
		struct InterCodes *code1 = NULL;
		struct InterCodes *code2 = NULL;
		while(ExtDecList != NULL)
		{
			Node *VarDec = ExtDecList->firstChild;
			if(code1 == NULL)
				code1 = translate_VarDec(VarDec);
			else
			{
				code2 = translate_VarDec(VarDec);
				addcode(code1, code2);
			}
			if(VarDec->nextSibling != NULL)
				ExtDecList = VarDec->nextSibling->nextSibling;
			else
				ExtDecList = NULL;
		}
		return code1;
	}
	else		//ExtDef : Specifier FunDec CompSt
	{
		struct InterCodes *code1 = translate_FunDec(ExtDef->firstChild->nextSibling);
		struct InterCodes *code2 = translate_CompSt(ExtDef->firstChild->nextSibling->nextSibling);
		addcode(code1, code2);
		return code1;
	}
}

struct InterCodes *translate_ExtDefList(Node *ExtDefList)
{
	Node *ExtDef = ExtDefList->firstChild;
	struct InterCodes *code1 = translate_ExtDef(ExtDef);
	struct InterCodes *code2 = NULL;
	if(ExtDef->nextSibling != NULL)
	{
		code2 = translate_ExtDefList(ExtDef->nextSibling);
		if(code1 != NULL)
			addcode(code1, code2);	
		else
			return code2;
	}
	return code1;
}

void traverseForIR(Node * root)
{
	if(root != NULL)
	{
		if(strcmp(root->type, "ExtDefList") == 0)
		{
			if(head == NULL)
				head = translate_ExtDefList(root);
			else
			{
				struct InterCodes *code = translate_ExtDefList(root);
				addcode(head, code);
			}
			if(root->nextSibling != NULL)
            			traverseForIR(root->nextSibling); 
		}
		else
		{
			if(root->firstChild != NULL) 
        	     		traverseForIR(root->firstChild);
			if(root->nextSibling != NULL)
        	    		traverseForIR(root->nextSibling); 
		}
	}
/*    	else if(root->nextSibling != NULL)
            traverseForIR(root->nextSibling);*/
}

void optimizeTemp()
{
	struct InterCodes *current = head;
	int count = 10, mark = 0, num;		//向前后者向后看5个
	struct InterCodes *temp1 = NULL;
	struct InterCodes *temp2 = NULL;
	do
	{
		temp1 = temp2 = current;
		if(temp1->code.kind == ASSIGN)
		{
			//如果赋值号左边是临时变量，则向后看，将后面用到临时变量的直接用它右边的值给替代掉
			if(temp1->code.u.assign.left->kind == TEMP)
			{
				num = temp1->code.u.assign.left->u.temp_no;
				while(temp2 != head)
				{
					mark = 0;
					temp2 = temp2->next;
					switch(temp2->code.kind)
					{
						case ASSIGN:
							if(temp2->code.u.assign.left->kind == ADDRESS_T && temp2->code.u.assign.left->u.temp_no == num)	//这时候的临时变量是为了取地址而产生的，不能消除
								mark = 1;
							else if(temp2->code.u.assign.right->kind == ADDRESS_T && temp2->code.u.assign.right->u.temp_no == num)	//这时候的临时变量是为了取地址而产生的，不能消除
								mark = 1;
							else if(temp2->code.u.assign.left->kind == MEM_T && temp2->code.u.assign.left->u.temp_no == num)	//这时候的临时变量是为了取地址而产生的，不能消除
								mark = 1;
							else if(temp2->code.u.assign.right->kind == MEM_T && temp2->code.u.assign.right->u.temp_no == num)	//这时候的临时变量是为了取地址而产生的，不能消除
								mark = 1;
							else if(temp2->code.u.assign.right->kind == TEMP && temp2->code.u.assign.right->u.temp_no == num)
								memcpy(temp2->code.u.assign.right, temp1->code.u.assign.right, sizeof(struct Operand_));
							break;
						case ADD : case SUB : case MUL : case DIVI :
							if(temp2->code.u.binop.result->kind == ADDRESS_T && temp2->code.u.binop.result->u.temp_no == num)	//这时候的临时变量是为了取地址而产生的，不能消除
								mark = 1;
							else if(temp2->code.u.binop.op1->kind == TEMP && temp2->code.u.binop.op1->u.temp_no == num)
								memcpy(temp2->code.u.binop.op1, temp1->code.u.assign.right, sizeof(struct Operand_));
							else if(temp2->code.u.binop.op2->kind == TEMP && temp2->code.u.binop.op2->u.temp_no == num)
								memcpy(temp2->code.u.binop.op2, temp1->code.u.assign.right, sizeof(struct Operand_));
							else if(temp2->code.u.binop.op1->kind == ADDRESS_T && temp2->code.u.binop.op1->u.temp_no == num)
							{
								memcpy(temp2->code.u.binop.op1, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.binop.op1->kind = ADDRESS_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.binop.op1->kind = ADDRESS_V;
							}
							else if(temp2->code.u.binop.op1->kind == MEM_T && temp2->code.u.binop.op1->u.temp_no == num)
							{
								memcpy(temp2->code.u.binop.op1, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.binop.op1->kind = MEM_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.binop.op1->kind = MEM_V;
							}
							else if(temp2->code.u.binop.op2->kind == ADDRESS_T && temp2->code.u.binop.op2->u.temp_no == num)
							{
								memcpy(temp2->code.u.binop.op2, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.binop.op2->kind = ADDRESS_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.binop.op2->kind = ADDRESS_V;
							}
							else if(temp2->code.u.binop.op2->kind == MEM_T && temp2->code.u.binop.op2->u.temp_no == num)
							{
								memcpy(temp2->code.u.binop.op2, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.binop.op2->kind = ADDRESS_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.binop.op2->kind = ADDRESS_V;
							}
							break;
						case WRITE :
							if(temp2->code.u.write.op->kind == TEMP && temp2->code.u.write.op->u.temp_no == num)
								memcpy(temp2->code.u.write.op, temp1->code.u.assign.right, sizeof(struct Operand_));
							else if(temp2->code.u.write.op->kind == ADDRESS_T && temp2->code.u.write.op->u.temp_no == num)
							{
								memcpy(temp2->code.u.write.op, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.write.op->kind = ADDRESS_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.write.op->kind = ADDRESS_V;
							}
							else if(temp2->code.u.write.op->kind == MEM_T && temp2->code.u.write.op->u.temp_no == num)
							{
								memcpy(temp2->code.u.write.op, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.write.op->kind = MEM_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.write.op->kind = MEM_V;
							}
							break;
						case ARG :
							if(temp2->code.u.arg.arg->kind == TEMP && temp2->code.u.arg.arg->u.temp_no == num)
								memcpy(temp2->code.u.arg.arg, temp1->code.u.assign.right, sizeof(struct Operand_));
							else if(temp2->code.u.arg.arg->kind == ADDRESS_T && temp2->code.u.arg.arg->u.temp_no == num)
							{
								memcpy(temp2->code.u.arg.arg, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.arg.arg->kind = ADDRESS_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.arg.arg->kind = ADDRESS_V;
							}
							else if(temp2->code.u.arg.arg->kind == MEM_T && temp2->code.u.arg.arg->u.temp_no == num)
							{
								memcpy(temp2->code.u.arg.arg, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.arg.arg->kind = MEM_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.arg.arg->kind = MEM_V;
							}
							break;
						case RETURN_OP :
							if(temp2->code.u.returnop.op->kind == TEMP && temp2->code.u.returnop.op->u.temp_no == num)
								memcpy(temp2->code.u.returnop.op, temp1->code.u.assign.right, sizeof(struct Operand_));
							
							else if(temp2->code.u.returnop.op->kind == ADDRESS_T && temp2->code.u.returnop.op->u.temp_no == num)
							{
								memcpy(temp2->code.u.returnop.op, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.returnop.op->kind = ADDRESS_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.returnop.op->kind = ADDRESS_V;
							}
							else if(temp2->code.u.returnop.op->kind == MEM_T && temp2->code.u.returnop.op->u.temp_no == num)
							{
								memcpy(temp2->code.u.returnop.op, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.returnop.op->kind = MEM_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.returnop.op->kind = MEM_V;
							}
							break;
						case GOTO_CON : 
							if(temp2->code.u.goto_con.op1->kind == TEMP && temp2->code.u.goto_con.op1->u.temp_no == num)
								memcpy(temp2->code.u.goto_con.op1, temp1->code.u.assign.right, sizeof(struct Operand_));
							else if(temp2->code.u.goto_con.op2->kind == TEMP && temp2->code.u.goto_con.op2->u.temp_no == num)
								memcpy(temp2->code.u.goto_con.op2, temp1->code.u.assign.right, sizeof(struct Operand_));
							
							else if(temp2->code.u.goto_con.op1->kind == ADDRESS_T && temp2->code.u.goto_con.op1->u.temp_no == num)
							{
								memcpy(temp2->code.u.goto_con.op1, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.goto_con.op1->kind = ADDRESS_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.goto_con.op1->kind = ADDRESS_V;
							}
							else if(temp2->code.u.goto_con.op1->kind == MEM_T && temp2->code.u.goto_con.op1->u.temp_no == num)
							{
								memcpy(temp2->code.u.goto_con.op1, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.goto_con.op1->kind = MEM_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.goto_con.op1->kind = MEM_V;
							}
							else if(temp2->code.u.goto_con.op2->kind == ADDRESS_T && temp2->code.u.goto_con.op2->u.temp_no == num)
							{
								memcpy(temp2->code.u.goto_con.op2, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.goto_con.op2->kind = ADDRESS_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.goto_con.op2->kind = ADDRESS_V;
							}
							else if(temp2->code.u.goto_con.op2->kind == MEM_T && temp2->code.u.goto_con.op2->u.temp_no == num)
							{
								memcpy(temp2->code.u.goto_con.op2, temp1->code.u.assign.right, sizeof(struct Operand_));
								if(temp1->code.u.assign.right->kind == TEMP)
									temp2->code.u.goto_con.op2->kind = MEM_T;
								else if(temp1->code.u.assign.right->kind == VARIABLE)
									temp2->code.u.goto_con.op2->kind = MEM_V;
							}
							break;
						default : break;
					}
					if(mark == 1)
						break;
				}
				current = current->next;
				if(mark == 0 || temp2 == head)
					deletecode(temp1);	//如果是进行修改过后的就删除，如果是没有使用过的那就是死代码，也是直接删除
				mark = 0;
			}
			//如果赋值号右边是临时变量，则向前看，用其赋值过程替代掉它本身
			else if(temp1->code.u.assign.left->kind == VARIABLE)
			{
				if(temp1->code.u.assign.right->kind == TEMP)
					num = temp1->code.u.assign.right->u.temp_no;
				else
				{
					current = current->next;
					continue;
				}
				while(temp2 != head)
				{
					mark = 0;
					temp2 = temp2->prev;
					if(temp2->code.kind == ADD || temp2->code.kind == SUB || temp2->code.kind == MUL || temp2->code.kind == DIVI)
					{
						if(temp2->code.u.binop.result->kind == TEMP && temp2->code.u.binop.result->u.temp_no == num)
						{
							memcpy(temp2->code.u.binop.result, temp1->code.u.assign.left, sizeof(struct Operand_));
							current = current->next;
							mark = 1;
							deletecode(temp1);
							break;
						}
					}
					else if(temp2->code.kind == CALL)
					{
						if(temp2->code.u.callop.place->kind == TEMP && temp2->code.u.callop.place->u.temp_no == num)
						{
							memcpy(temp2->code.u.callop.place, temp1->code.u.assign.left, sizeof(struct Operand_));
							current = current->next;
							mark = 1;
							deletecode(temp1);
							break;
						}
					}
				}
				if(mark == 1)
					continue;
				else
					current = current->next;
			}
			else
				current = current->next;
		}
		else
			current = current->next;
	}while(current != head);
}

void printIR()
{
	optimizeTemp();
	struct InterCodes *temp = head;		//指向双向链表的头部
	do
	{
		if(temp->code.kind == DEF_LABEL)
			printLabel(temp);
		if(temp->code.kind == FUNCTION)
			printFunc(temp);
		if(temp->code.kind == ASSIGN)
			printAssign(temp);
		if(temp->code.kind == ADD || temp->code.kind == SUB || temp->code.kind == MUL || temp->code.kind == DIVI)
			printBin(temp);
		if(temp->code.kind == GOTO_LABEL)
			printGotoLabel(temp);
		if(temp->code.kind == GOTO_CON)
			printGotoCon(temp);
		if(temp->code.kind == RETURN_OP)
			printReturn(temp);
		if(temp->code.kind == DEC)
			printDec(temp);
		if(temp->code.kind == ARG)
			printArg(temp);
		if(temp->code.kind == CALL)
			printCall(temp);
		if(temp->code.kind == PARAM)
			printParam(temp);
		if(temp->code.kind == READ)
			printRead(temp);
		if(temp->code.kind == WRITE)
			printWrite(temp);
		if(temp->code.kind == LABEL_CODE)
			printLabel(temp);	
		if(temp->code.kind == NOTH)
		{
			temp = temp->next;
			continue;
		}
		temp = temp->next;
	}while(temp != head);
	if(fclose(file) != 0)		//打印结束后关闭文件
		printf("Error in closing file\n");
}
