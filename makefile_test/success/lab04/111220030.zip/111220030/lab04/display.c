#include "src.h"
void InterCodesDisplay(InterCodes root)
{
	//InterCodes codes = root;
	//printf("-----------------\n");
	while(root != NULL) {
		InterCodeDisplay(root->code);
		root = root->next;
	}
}

void InterCodeDisplay(InterCode code)
{
	if(code->kind == ASSIGN) {
        	OperandDisplay(code->u.assign.left);
        	printf("%s"," := ");
		fprintf(fp,"%s"," := ");
        	OperandDisplay(code->u.assign.right);
	}
	else if(code->kind == ADD) {
        	OperandDisplay(code->u.binop.result);
        	printf("%s"," := ");
		fprintf(fp,"%s"," := ");
        	OperandDisplay(code->u.binop.op1);
        	printf("%s"," + ");
		fprintf(fp,"%s"," + ");
        	OperandDisplay(code->u.binop.op2);
	}
	else if(code->kind == SUB) {
		OperandDisplay(code->u.binop.result);
        	printf("%s"," := ");
		fprintf(fp,"%s"," := ");
        	OperandDisplay(code->u.binop.op1);
        	printf("%s"," - ");
		fprintf(fp,"%s"," - ");
        	OperandDisplay(code->u.binop.op2);
	}
	else if(code->kind == MUL) {
		OperandDisplay(code->u.binop.result);
        	printf("%s"," := ");
		fprintf(fp,"%s"," := ");
        	OperandDisplay(code->u.binop.op1);
        	printf("%s"," * ");
		fprintf(fp,"%s"," * ");
        	OperandDisplay(code->u.binop.op2);
	}
	else if(code->kind == DIVI) {
		OperandDisplay(code->u.binop.result);
        	printf("%s"," := ");
		fprintf(fp,"%s"," := ");
        	OperandDisplay(code->u.binop.op1);
        	printf("%s"," / ");
		fprintf(fp,"%s"," / ");
        	OperandDisplay(code->u.binop.op2);
	}	
	else if(code->kind == LABEL) {
		printf("%s","LABEL ");
		fprintf(fp,"%s","LABEL ");
		OperandDisplay(code->u.label.label);
		printf("%s"," :");
		fprintf(fp,"%s"," :");
	}
	else if(code->kind == BLTZ) {
		printf("%s","IF ");
		fprintf(fp,"%s","IF ");
		OperandDisplay(code->u.bltz.op1);
		printf("%s"," ");
		fprintf(fp,"%s"," ");
		OperandDisplay(code->u.bltz.relop);
		printf("%s"," ");
		fprintf(fp,"%s"," ");		
		OperandDisplay(code->u.bltz.op2);
		printf("%s"," GOTO ");
		fprintf(fp,"%s"," GOTO ");
		OperandDisplay(code->u.bltz.label);
	}
	else if(code->kind == GOTO) {
		printf("%s","GOTO ");
		fprintf(fp,"%s","GOTO ");
		OperandDisplay(code->u.goto_.label);
	}
	else if(code->kind == RETURN_IC) {
		printf("%s","RETURN ");
		fprintf(fp,"%s","RETURN ");
		OperandDisplay(code->u.return_.return_place);
	}
	else if(code->kind == DEC) {
		printf("%s","DEC ");
		fprintf(fp,"%s","DEC ");
		OperandDisplay(code->u.dec.place);
		printf("%s"," ");
		fprintf(fp,"%s"," ");
		OperandDisplay(code->u.dec.size);
	}
	else if(code->kind == FUNCTION) {
		printf("%s","FUNCTION ");
		fprintf(fp,"%s","FUNCTION ");
		OperandDisplay(code->u.function.fun_name);
		printf("%s"," :");
		fprintf(fp,"%s"," :");
	}
	else if(code->kind == PARAM) {
		printf("%s","PARAM ");
		fprintf(fp,"%s","PARAM ");
		OperandDisplay(code->u.param.param_name);
	}
	else if(code->kind == ARG) {
		printf("%s","ARG ");
		fprintf(fp,"%s","ARG ");
		OperandDisplay(code->u.arg.arg_name);
	}
	else if(code->kind == CALL) {
		OperandDisplay(code->u.call.place);
		printf("%s"," := CALL ");
		fprintf(fp,"%s"," := CALL ");
		OperandDisplay(code->u.call.func);
	}
	else if(code->kind == READ) {
		printf("%s","READ ");
		fprintf(fp,"%s","READ ");
		OperandDisplay(code->u.read.place);
	}
	else if(code->kind == WRITE) {
		printf("%s","WRITE ");
		fprintf(fp,"%s","WRITE ");
		OperandDisplay(code->u.write.place);
	}
	fprintf(fp,"%s","\n");
	printf("\n");
}

void OperandDisplay(Operand op)
{
	if(op->kind == VARIABLE) {
		printf("v%d",op->u.var_no);
		fprintf(fp,"v%d",op->u.var_no);
	}
	else if(op->kind == CONSTANT) {
		fprintf(fp,"#%d",op->u.value);
		printf("#%d",op->u.value);
	}
	else if(op->kind == ADDRESS) {
		fprintf(fp,"&%s",op->u.mem_addr);
		printf("&%s",op->u.mem_addr);
		//printf("&");
		//printf(" op->u.flag:%d  ",op->u.flag);
		//if(op->u.flag == 1)
			//printf("t%d",op->u.var_no);
		//else if(op->u.flag == 2)
			//printf("v%d",op->u.var_no);
	}
	else if(op->kind == MEM) {
		fprintf(fp,"*%s",op->u.mem_addr);
		printf("*%s",op->u.mem_addr);
		/*printf("*");
		printf(" op->u.flag:%d  ",op->u.flag);
		if(op->u.flag == 1)
			printf("t%d",op->u.var_no);
		else if(op->u.flag == 2)
			printf("v%d",op->u.var_no);*/
	}
	else if(op->kind == TEMP) {
		fprintf(fp,"t%d",op->u.temp_no);
		printf("t%d",op->u.temp_no);
	}
	else if(op->kind == LABEL_OP) {
		fprintf(fp,"label%d",op->u.label_no);
		printf("label%d",op->u.label_no);
	}
	else if(op->kind == RELOP_OP) {
		fprintf(fp,"%s",op->u.relop);
		printf("%s",op->u.relop);
	}
	else if(op->kind == FUNC) {
		fprintf(fp,"%s",op->u.func_name);
		printf("%s",op->u.func_name);
	}
	else if(op->kind == SIZE) {
		fprintf(fp,"%d",op->u.value);
		printf("%d",op->u.value);
	}
}
