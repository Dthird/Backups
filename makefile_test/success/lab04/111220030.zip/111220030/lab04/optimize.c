#include "src.h"
#define Max 20
int same_test(InterCodes codes,InterCodes block[],int count)
{
	int i;
	for(i = 0;i < count;i++) {
		if(block[i]->code->kind == codes->code->kind) {
			if(block[i]->code->kind == LABEL) {
				if(block[i]->code->u.label.label->u.label_no == codes->code->u.label.label->u.label_no) {
					return 1;
				}
			}
			if(block[i]->code->kind == GOTO) {
				if(block[i]->code->u.goto_.label->u.label_no == codes->code->u.goto_.label->u.label_no) {
					return 1;
				}
			}
		}
	}
	return 0;
}
int basic_block(InterCodes codes,InterCodes block[])
{
	InterCodes codes1 = (InterCodes)malloc(sizeof(struct InterCodes_));
	int count = 0;
	block[count] = codes;
	count++;
	codes = codes->next;
	while(codes != NULL) {
		if(codes->code->kind == BLTZ || codes->code->kind == GOTO) {
			Operand label = (Operand)malloc(sizeof(struct Operand_));
			if(codes->code->kind == BLTZ) {
				label = codes->code->u.bltz.label;
			}
			else if(codes->code->kind == GOTO) {
				label = codes->code->u.goto_.label;
			}
			int n = same_test(codes->next,block,count);
			if(n == 0) {
				block[count] = codes->next;
				count++;
			}
			codes1 = codes->next->next;
			while(codes1 != NULL) {
				if(codes1->code->kind == LABEL) {
					if(codes1->code->u.label.label->u.label_no == label->u.label_no) {
						int n = same_test(codes1,block,count);
						if(n == 0) {
							block[count] = codes1;
							count++;
						}
						break;
					}
				}
				codes1 = codes1->next;
			}
		}
		codes = codes->next;	
	}
	int i;
	for(i = 1;i < count;i++) {
		//block[i]->prev->next = NULL;
	}
	return count;
}
void optimize(InterCodes codes)
{
	InterCodes block[Max];
	int i;
	for(i = 0;i < Max;i++) {
		block[i] = (InterCodes)malloc(sizeof(struct InterCodes_));
		block[i] = NULL;
	}
	InterCodes codes1 = codes;
	int count = basic_block(codes1,block);
	for(i = 0;i < count;i++) {
		/*printf("*****************\n");	
		InterCodeDisplay(block[i]->code);
		printf("*****************\n");*/
	}
}

void opt(InterCodes codes)
{
	if(codes == NULL)
		return ;
	InterCode code = codes->code;
	if(code->kind == ASSIGN && code->u.assign.left->kind != ADDRESS && code->u.assign.left->kind != MEM) {
		if(code->u.assign.right->kind == CONSTANT) {
			Operand left = code->u.assign.left;
			Operand right = code->u.assign.right;
			InterCodes codes0 = codes->next;
			int flag = 0;
			while(codes0 != NULL) {
				InterCode code0 = codes0->code;
				if(code0->kind == ASSIGN) {
					Operand op = code0->u.assign.left;
					if(op->kind == left->kind && left->kind == TEMP && op->u.temp_no == left->u.temp_no) {
						flag = 1;
						break;
					}
					if(op->kind == left->kind && left->kind == VARIABLE && op->u.var_no == left->u.var_no) {
						flag = 1;
						break;
					}
				}
				if(code0->kind == ADD || code0->kind == SUB || code0->kind == MUL || code0->kind == DIVI) {
					Operand op = code0->u.binop.result;
					if(op->kind == left->kind && left->kind == TEMP && op->u.temp_no == left->u.temp_no) {
						flag = 1;
						break;
					}
					if(op->kind == left->kind && left->kind == VARIABLE && op->u.var_no == left->u.var_no) {
						flag = 1;
						break;
					}
				}
				codes0 = codes0->next;
			}
			if(flag == 0) {codes0 = codes->next;
				//code->u.assign.left->value = code->u.assign.right->u.value;
				int tag = 0;
				int tag2 = 0;
				while(codes0 != NULL) {
					InterCode code0 = codes0->code;
					if(code0->kind == WRITE) {
						Operand op = code0->u.write.place;
						if(op->kind == left->kind && left->kind == TEMP && op->u.temp_no == left->u.temp_no) {
							tag = 1;
							code0->u.write.place = right;
						}
						if(op->kind == left->kind && left->kind == VARIABLE && op->u.var_no == left->u.var_no) {
							tag = 1;
							code0->u.write.place = right;
						}
					}	
					if(code0->kind == ASSIGN) {
						/*Operand op0 = code0->u.assign.left;
						if(op0->kind == left->kind && left->kind == TEMP && op0->u.temp_no == left->u.temp_no) {
							flag = 1;
							break;
						}
						if(op0->kind == left->kind && left->kind == VARIABLE && op0->u.var_no == left->u.var_no) {
							flag = 1;
							break;
						}*/
						Operand op = code0->u.assign.right;
						if(op->kind == left->kind && left->kind == TEMP && op->u.temp_no == left->u.temp_no) {
							tag = 1;
							code0->u.assign.right = right;
						}
						if(op->kind == left->kind && left->kind == VARIABLE && op->u.var_no == left->u.var_no) {
							tag = 1;
							code0->u.assign.right = right;
						}
					}
					if(code0->kind == RETURN_IC) {
						Operand op = code0->u.return_.return_place;
						if(op->kind == left->kind && left->kind == TEMP && op->u.temp_no == left->u.temp_no) {
							tag = 1;
							code0->u.return_.return_place = right;
						}
						if(op->kind == left->kind && left->kind == VARIABLE && op->u.var_no == left->u.var_no) {
							tag = 1;
							code0->u.return_.return_place = right;
						}
					}
					if(code0->kind == BLTZ) {
						Operand op1 = code0->u.bltz.op1;
						Operand op2 = code0->u.bltz.op2;
						if(op1->kind == left->kind && left->kind == TEMP && op1->u.temp_no == left->u.temp_no) {
							tag2 = 1;
						}
						if(op1->kind == left->kind && left->kind == VARIABLE && op1->u.var_no == left->u.var_no) {
							tag2 = 1;
						}
						if(op2->kind == left->kind && left->kind == TEMP && op2->u.temp_no == left->u.temp_no) {
							tag2 = 1;
						}
						if(op2->kind == left->kind && left->kind == VARIABLE && op2->u.var_no == left->u.var_no) {
							tag2 = 1;
						}
					}
					if(code0->kind == ADD || code0->kind == SUB || code0->kind == MUL || code0->kind == DIVI) {
						/*Operand op0 = code0->u.binop.result;
						if(op0->kind == left->kind && left->kind == TEMP && op0->u.temp_no == left->u.temp_no) {
							flag = 1;
							break;
						}
						if(op0->kind == left->kind && left->kind == VARIABLE && op0->u.var_no == left->u.var_no) {
							flag = 1;
							break;
						}*/
						Operand op1 = code0->u.binop.op1;
						Operand op2 = code0->u.binop.op2;
						if(op1->kind == left->kind && left->kind == TEMP && op1->u.temp_no == left->u.temp_no) {
							tag = 1;
							code0->u.binop.op1 = right;
						}
						if(op1->kind == left->kind && left->kind == VARIABLE && op1->u.var_no == left->u.var_no) {
							tag = 1;
							code0->u.binop.op1 = right;
						}
						if(op2->kind == left->kind && left->kind == TEMP && op2->u.temp_no == left->u.temp_no) {
							tag = 1;
							code0->u.binop.op2 = right;
						}
						if(op2->kind == left->kind && left->kind == VARIABLE && op2->u.var_no == left->u.var_no) {
							tag = 1;
							code0->u.binop.op2 = right;
						}
					}
					codes0 = codes0->next;
				}
				if(tag2 == 0 && tag == 1) {
					InterCodes pre = codes->prev;
					pre->next = codes->next;
					codes->next->prev = pre;
				}
			}
		}
	}
	if(code->kind == ADD || code->kind == SUB || code->kind == MUL || code->kind == DIVI) {
		if(code->u.binop.op1->kind == CONSTANT && code->u.binop.op2->kind == CONSTANT) {
			Operand result = code->u.binop.result;
			Operand op1 = code->u.binop.op1;
			Operand op2 = code->u.binop.op2;
			Operand right = (Operand)malloc(sizeof(struct Operand_));
			right->kind = CONSTANT;
			if(code->kind == ADD) {
				right->u.value = op1->u.value + op2->u.value;
			}
			if(code->kind == SUB) {
				right->u.value = op1->u.value - op2->u.value;
			}
			if(code->kind == MUL) {
				right->u.value = op1->u.value * op2->u.value;
			}
			if(code->kind == DIVI) {
				right->u.value = op1->u.value / op2->u.value;
			}
			code->kind = ASSIGN;
			code->u.assign.left = result;
			code->u.assign.right = right;
			codes = codes->prev;
		}
	}
	opt(codes->next);	
}
