struct Vector
{
int x, y;
};
int main()
{
 struct Vector v;
 v.x = 2;
 v.y = 4;
 write(v.x);
 return 0;

}
