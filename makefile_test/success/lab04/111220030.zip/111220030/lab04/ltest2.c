int main()
{
int a = 0, b = 1;
int c = read();
if(c < 5)
write(a);
else
write(b);
return 0;
}
