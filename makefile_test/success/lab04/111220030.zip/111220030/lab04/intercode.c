#include "src.h"
//#include "intercode.h"
int temp_number = 1;//t1,t2...
int label_number = 1;//label1,label2...
int var_number = 1;//v1,v2...
int count = 0;
//临时变量(temp)，全局变量(variable)和行标号(label)全部从1开始命名
Operand create_temp() {
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = TEMP;
	op->u.temp_no = temp_number;
	temp_number ++;
	return op;
}
Operand create_label() {
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = LABEL_OP;
	op->u.label_no = label_number;
	label_number++;
	return op;
}
Operand create_variable() {
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = VARIABLE;
	op->u.var_no = var_number;
	var_number++;
	return op;
}
Operand create_constant(int value) {
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = CONSTANT;
	op->u.value = value;
	return op;
}
Operand create_addr(int kind,int number) {
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	//printf("****************\n");
	op->kind = ADDRESS;
	char name[10];
	if(kind == TEMP) {
		name[0] = 't';
	}
	else if(kind == VARIABLE) {
		name[0] = 'v';
	}
	char string[10];
	sprintf(string, "%d", number);
	strcpy(&name[1],string);
	strcpy(op->u.mem_addr,name);
	//printf("op->u.flag:%d\n",op->u.flag);
	//op->u.var_no = number;
	return op;
}
Operand create_mem(int kind,int number) {
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	//printf("!!!!!!!!!!!!!!\n");
	op->kind = MEM;
	char name[10];
	if(kind == TEMP) {
		name[0] = 't';
	}
	else if(kind == VARIABLE) {
		name[0] = 'v';
	}
	char string[10];
	sprintf(string, "%d", number);
	strcpy(&name[1],string);
	strcpy(op->u.mem_addr,name);
	//printf("op->u.flag:%d\n",op->u.flag);
	//op->u.var_no = number;
	return op;
}
Operand create_relop(char* name) {
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = RELOP_OP;
	strcpy(op->u.relop,name);
	return op;
}
Operand create_func(char* func_name) {
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = FUNC;
	strcpy(op->u.func_name,func_name);
	return op;
}
Operand create_size(int size) {
	Operand op = (Operand)malloc(sizeof(struct Operand_));
	op->kind = SIZE;
	op->u.value = size;
	return op;
}
void operand(Operand* op) {
	//printf("op->kind:%d",(*op)->kind);
	if((*op)->kind == TEMP)
		temp_number--;
	if((*op)->kind == LABEL_OP)
		label_number--;
	if((*op)->kind == VARIABLE)
		var_number--;
	*op = NULL;
}
/*
Operands create_operand(Operand op)
{
	Operands opnode = (Operands)malloc(sizeof(struct Operands_));
	opnode->op = op;
	opnode->next = NULL;
	return opnode;
}
Operands insert_to_operands(Operands list,Operand op)
{
	Operands opnode = create_operand(op);
	while(list->next != NULL) 
		list = list->next;
	list->next = opnode;
	return list;
}
InterCodes create_intercode(InterCode ic)
{
	InterCodes icnode = (InterCodes)malloc(sizeof(struct InterCodes_));
	icnode->code = ic;
	icnode->prev = NULL;
	icnode->next = NULL;
	return codes;
}*/
InterCodes insert_to_intercodes(InterCodes codes1,InterCode code)
{
	InterCodes codes2 = (InterCodes)malloc(sizeof(struct InterCodes_));
	codes2->code = code;
	codes2->prev = NULL;
	codes2->next = NULL;
	if(codes1 != NULL) {
		InterCodes codes = codes1;
		while(codes->next != NULL) {
			codes = codes->next;
		}
		codes->next = codes2;
		codes2->prev = codes;
		return codes1;
	}
	else if(codes1 == NULL) {
		//printf("~~~~~~~~~~~~~\n");
		return codes2;
	}
}

InterCodes merge(InterCodes codes1,InterCodes codes2)
{
	if(codes1 != NULL && codes2 != NULL) {
		InterCodes codes = codes1;
		while(codes->next != NULL) {
			codes = codes->next;
		}
		codes->next = codes2;
		codes2->prev = codes;
		return codes1;
	}
	else if(codes1 != NULL && codes2 == NULL)
		return codes1;
	else if(codes1 == NULL)
		return codes2;
}

InterCodes translate_Exp(struct NODE* Exp,Operand* op,char* func_name)
{
	*op = create_temp();
	//printf("op->kind:%d\n",(*op)->kind);
	//printf("---------Exp------\n");
	char* name = Exp->child[0]->data;
	if(strcmp(name,"Exp") == 0) {//二元运算符，数组/结构体访问
		if(strcmp(Exp->child[2]->data,"Exp") == 0 && Exp->child[3] == NULL) {//二元运算符		
			char* name1 = Exp->child[1]->data;	
			//printf("name:%s",Exp->child[0]->data);	
			//printf("name1:%s",name1);
			//printf("name2:%s\n",Exp->child[2]->data);	
			if(strcmp(name1,"ASSIGNOP") == 0) {//Exp = Exp
				/*if(strcmp(Exp->child[0]->data,"ID") == 0) {
					Operand t1 = NULL;//create_temp();
					SymbolNodeVariable var = SearchVar(Exp->child[0]->value);
					Operand v1 = create_variable();
					if(var != NULL) {
						if(var->number == -1) {//该变量第一次出现
							var->number = v1->u.var_no;
						}
						else {//该变量之前已经命名过
							v1->u.var_no = var->number;
							//var_number--;
						}
						InterCodes codes0 = translate_Exp(Exp->child[2],&t1,func_name);
						InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
						code1->kind = ASSIGN;
						code1->u.assign.left = v1;
						code1->u.assign.right = t1;
						InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
						code2->kind = ASSIGN;
						code2->u.assign.left = *op;
						code2->u.assign.right = v1;
						codes0 = insert_to_intercodes(codes0,code1);
						codes0 = insert_to_intercodes(codes0,code2);
						return codes0;
					}	
				}
				else {*/
				Operand left = NULL;//create_temp();
				Operand right = NULL;//create_temp();
				InterCodes codes0 = translate_Exp(Exp->child[0], &left,func_name);
				InterCodes codes1 = translate_Exp(Exp->child[2], &right,func_name);					
				InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
				code2->kind = ASSIGN;
				code2->u.assign.left = left;
				code2->u.assign.right = right;
				//InterCodes codes2 = create_intercode(code2);
				codes0 = merge(codes0,codes1);
				codes0 = insert_to_intercodes(codes0,code2);
				return codes0;
				//}
			}
			if(strcmp(name1,"RELOP") == 0 || strcmp(name1,"AND") == 0 
				|| strcmp(name1,"OR") == 0) {//比较和与或运算
				//printf("name:%s",Exp->child[0]->data);	
				//printf("name1:%s",name1);
				//printf("name2:%s\n",Exp->child[2]->data);	
				Operand label1 = create_label();
				Operand label2 = create_label();
				Operand zero = create_constant(0);
				InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
				code0->kind = ASSIGN;
				code0->u.assign.left = *op;
				code0->u.assign.right = zero;
				InterCodes codes0 = (InterCodes)malloc(sizeof(struct InterCodes_));
				codes0 = NULL;
				codes0 = insert_to_intercodes(codes0,code0);
				InterCodes codes1 = translate_Cond(Exp, label1, label2,func_name);
				InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
				code2->kind = LABEL;
				code2->u.label.label = label1;
				Operand one = create_constant(1);
				InterCode code3 = (InterCode)malloc(sizeof(struct InterCode_));
				code3->kind = ASSIGN;
				code3->u.assign.left = *op;
				code3->u.assign.right = one;
				InterCode code4 = (InterCode)malloc(sizeof(struct InterCode_));
				code4->kind = LABEL;
				code4->u.label.label = label2;
				codes0 = merge(codes0,codes1);
				codes0 = insert_to_intercodes(codes0,code2);
				codes0 = insert_to_intercodes(codes0,code3);
				codes0 = insert_to_intercodes(codes0,code4);
				return codes0;
			}
			if(strcmp(name1,"PLUS") == 0 || strcmp(name1,"MINUS") == 0
				 || strcmp(name1,"STAR") == 0 || strcmp(name1,"DIV") == 0) {//四则运算
				//printf("225:%d\n",temp_number);				
				Operand t1 = NULL;//create_temp();
				//printf("227:%d\n",temp_number);
				Operand t2 = NULL;//create_temp();
				//printf("come to minus\n");
				InterCodes codes1 = translate_Exp(Exp->child[0],&t1,func_name);
				InterCodes codes2 = translate_Exp(Exp->child[2],&t2,func_name);
				InterCode code3 = (InterCode)malloc(sizeof(struct InterCode_));
				if(strcmp(name1,"PLUS") == 0)
					code3->kind = ADD;
				else if(strcmp(name1,"MINUS") == 0)
					code3->kind = SUB;
				else if(strcmp(name1,"STAR") == 0)
					code3->kind = MUL;
				else if(strcmp(name1,"DIV") == 0)
					code3->kind = DIVI;
				code3->u.binop.result = *op;
				code3->u.binop.op1 = t1;
				code3->u.binop.op2 = t2;//printf("===\n");InterCodeDisplay(code3);
				//InterCodes codes3 = create_intercode(code3);
				codes1 = merge(codes1,codes2);
				codes1 = insert_to_intercodes(codes1,code3);//printf("===\n");InterCodesDisplay(codes1);
				return codes1;
			}
		}
		if(strcmp(Exp->child[1]->data,"LB") == 0) {//Exp[Exp] 数组访问表达式
			//printf("250:%d\n",temp_number);
			//printf("array\n");
			//SymbolNodeVariable var = SearchVar(Exp->child[0]->child[0]->value);//Exp->ID
			struct NODE* node = Exp->child[0];
			while(strcmp(node->data,"ID") != 0) {
				node = node->child[0];
			}
			//printf("node->value:%s\n",node->value);
			SymbolNodeFunction func = SearchFunc(func_name);
			//printf("func_name:%s\n",func_name);
			int num = func->ParameterNum;
			int i = 0;
			int flag = 0;
			for(;i < num;i++) {
				if(strcmp(func->parameters[i]->name,node->value) == 0) {
					flag = 1;
					break;
				}
			}
			if(flag == 1) {//使用函数参数（数组）
				//printf("flag = 1\n");
				//operand(op);
				//*op = create_mem(func->parameters[i]->number);
				//printf("result:var_number:%d\n",var_number);
				Operand result = create_variable();
				if(func->parameters[i]->number == -1) {//该变量第一次出现
					func->parameters[i]->number = result->u.var_no;
				}
				else {//该变量之前已经命名过
					result->u.var_no = func->parameters[i]->number;
					//var_number--;
				}
				char* name1 = Exp->child[2]->child[0]->data;
				if(strcmp(name1,"INT") == 0) {
					int size = atoi(Exp->child[2]->child[0]->value);
					if(size == 0) {
						//operand(op);
						Operand mem = create_mem(result->kind,func->parameters[i]->number);
						//printf("---temp_number:%d\n",temp_number);
						//Operand t1 = create_temp();
						InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
						code0->kind = ASSIGN;
						code0->u.assign.left = *op;
						code0->u.assign.right = mem;
						InterCodes codes0 = (InterCodes)malloc(sizeof(struct InterCodes_));
						codes0 = NULL;
						codes0 = insert_to_intercodes(codes0,code0);
						operand(&result);
						//printf("result:var_number:%d\n",var_number);
						return codes0;
					}
					else {
						//计算地址（数组元素为int，4个字节）
						//printf("--temp_no:%d\n",temp_number);
						Operand t1 = create_temp();
						int value = size * 4;
						Operand addr = create_constant(value);
						InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
						code0->kind = ADD;
						code0->u.binop.result = t1;
						code0->u.binop.op1 = result;						
						code0->u.binop.op2 = addr;
						InterCodes codes0 = (InterCodes)malloc(sizeof(struct InterCodes_));
						codes0 = NULL;
						codes0 = insert_to_intercodes(codes0,code0);
						//operand(op);
						Operand mem = create_mem(t1->kind,t1->u.temp_no);
						//Operand t2 = create_temp();
						InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
						code1->kind = ASSIGN;
						code1->u.assign.left = *op;
						code1->u.assign.right = mem;
						codes0 = insert_to_intercodes(codes0,code1);
						return codes0;
					}
				}
				else if(strcmp(name1,"ID") == 0) {
					SymbolNodeVariable var = SearchVar(Exp->child[2]->child[0]->value);//Exp->ID
					Operand t1 = create_temp();
					Operand v2 = create_variable();
					if(var->number == -1) {//该变量第一次出现
						var->number = v2->u.var_no;
					}
					else {//该变量之前已经命名过
						v2->u.var_no = var->number;
						//var_number--;
					}
					Operand four = create_constant(4);
					InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
					code0->kind = MUL;
					code0->u.binop.result = t1;
					code0->u.binop.op1 = v2;						
					code0->u.binop.op2 = four;
					Operand t2 = create_temp();
					InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
					code1->kind = ADD;
					code1->u.binop.result = t2;
					code1->u.binop.op1 = result;						
					code1->u.binop.op2 = t1;
					InterCodes codes0 = (InterCodes)malloc(sizeof(struct InterCodes_));
					codes0 = NULL;
					codes0 = insert_to_intercodes(codes0,code0);
					codes0 = insert_to_intercodes(codes0,code1);
					//operand(op);
					Operand mem = create_mem(t2->kind,t2->u.temp_no);
					//Operand t3 = create_temp();
					InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
					code2->kind = ASSIGN;
					code2->u.assign.left = *op;
					code2->u.assign.right = mem;
					codes0 = insert_to_intercodes(codes0,code2);
					return codes0;
				}
			}
			else if(flag == 0) {//使用一般数组
				//printf("flag = 0\n");
				//operand(*op);
				//*op = create_temp();
				//(*op)->kind = MEM;
				SymbolNodeVariable var = SearchVar(node->value);
				Operand basic_addr = create_addr(VARIABLE,var->number);
				//printf("basic_addr->u.flag:%d\n",basic_addr->u.flag);
				if(var->number == -1) {//该变量第一次出现
					var->number = var_number;
					basic_addr->u.var_no = var->number;
					var_number++;	
				}
				Operand addr = NULL;
				InterCodes codes = (InterCodes)malloc(sizeof(struct InterCodes_));
				codes = NULL;
				while(Exp_(node->parent,NULL)->kind == array) {
					//printf("!!!!!!!!!!!!!!\n");
					int size;
					int current_size;
					if(Exp_(node->parent->parent,NULL)->kind == basic) {
						////printf("here\n");
						size = 4;
					}
					else {
						struct NODE* n = node;
						size = 4;
						while(Exp_(n->parent->parent,NULL)->kind == array) {
							size = Exp_(node->parent->parent,NULL)->u.array.size * size;
							n = n->parent;
						}
						//printf("size:%d\n",size);
					}
					struct NODE* arraysize = node->parent->parent->child[2]->child[0];
					char* name1 = arraysize->data;
					if(strcmp(name1,"INT") == 0) {
						//printf("I am here\n");
						int current_size = atoi(arraysize->value);
						Operand con = create_constant(size * current_size);
						if(con->u.value != 0) {
							if(addr == NULL) 
								addr = con;
							else if(addr != NULL) {
								if(addr->kind == CONSTANT) {
									addr->u.value = con->u.value + addr->u.value;
								}
								else {
									Operand t1 = create_temp();
									InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
									code0->kind = ADD;
									code0->u.binop.result = t1;
									code0->u.binop.op1 = con;
									code0->u.binop.op2 = addr;
									codes = insert_to_intercodes(codes,code0);
									addr = t1;
								}
							}
						}
					}
					else if(strcmp(name1,"ID") == 0) {
						SymbolNodeVariable var = SearchVar(arraysize->value);//Exp->ID
						Operand t1 = create_temp();
						Operand v2 = create_variable();
						if(var->number == -1) {//该变量第一次出现
							var->number = v2->u.var_no;
						}
						else {//该变量之前已经命名过
							v2->u.var_no = var->number;
							//var_number--;
						}
						Operand con = create_constant(size);
						InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
						code0->kind = MUL;
						code0->u.binop.result = t1;
						code0->u.binop.op1 = v2;						
						code0->u.binop.op2 = con;
						codes = insert_to_intercodes(codes,code0);
						//InterCodesDisplay(codes);
						if(addr == NULL) {
							//printf("here here\n");
							addr = t1;
						}
						else if(addr != NULL) {
							InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
							code1->kind = ADD;
							code1->u.binop.result = addr;
							code1->u.binop.op1 = t1;
							code1->u.binop.op2 = addr;
							codes = insert_to_intercodes(codes,code1);
						}
					}
					else {
						Operand t1 = create_temp();
						Operand v2 = NULL;
						//printf("come to here\n");
						InterCodes codes0 = translate_Exp(arraysize->parent,&v2,func_name);
						Operand con = create_constant(size);
						InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
						code1->kind = MUL;
						code1->u.binop.result = t1;
						code1->u.binop.op1 = v2;						
						code1->u.binop.op2 = con;
						codes = merge(codes,codes0);
						codes = insert_to_intercodes(codes,code1);
						//InterCodesDisplay(codes);
						if(addr == NULL) {
							//printf("here here\n");
							addr = t1;
						}
						else if(addr != NULL) {
							InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
							code2->kind = ADD;
							code2->u.binop.result = addr;
							code2->u.binop.op1 = t1;
							code2->u.binop.op2 = addr;
							codes = insert_to_intercodes(codes,code2);
						}
					}
					node = node->parent;
				}
				if(addr != NULL) {
					Operand t1 = create_temp();
					InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
					code1->kind = ADD;
					code1->u.binop.result = t1;
					code1->u.binop.op1 = basic_addr;
					code1->u.binop.op2 = addr;
					codes = insert_to_intercodes(codes,code1);
					//operand(op);
					(*op) = create_mem(t1->kind,t1->u.temp_no);
					/*Operand t2 = create_temp();
					InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
					code2->kind = ASSIGN;
					code2->u.assign.left = t2;
					code2->u.assign.right = *op;
					codes = insert_to_intercodes(codes,code2);*///printf("-------------------\n");InterCodesDisplay(codes);
					return codes;
				}
				else if(addr == NULL) {
					Operand t1 = create_temp();
					InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
					code1->kind = ASSIGN;
					code1->u.assign.left = t1;
					code1->u.assign.right = basic_addr;
					codes = insert_to_intercodes(codes,code1);
					//operand(op);
					(*op) = create_mem(t1->kind,t1->u.temp_no);
					/*Operand t2 = create_temp();
					InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
					code2->kind = ASSIGN;
					code2->u.assign.left = t2;
					code2->u.assign.right = *op;
					codes = insert_to_intercodes(codes,code2);*///printf("-------------------\n");InterCodesDisplay(codes);
					return codes;
				}
			}
		}
		if(strcmp(Exp->child[1]->data,"DOT") == 0) {}//Exp.ID 结构体访问表达式
	}
	else if(strcmp(name,"ID") == 0) {//函数调用/ID
		if(Exp->child[1] == NULL) {//ID,查表，需要判断是否为第一次出现，避免同样的变量重复命名
			//printf("id:%s\n",Exp->child[0]->value);
			SymbolNodeVariable var = SearchVar(Exp->child[0]->value);
			if(var != NULL) {
				if(var->type->kind == array) {
					operand(op);
					if(var->number == -1) {//该变量第一次出现
						var->number = var_number;
					}
					*op = create_addr(VARIABLE,var->number);
					return NULL;
				}
				else if(var->type->kind == basic) {
					operand(op);
					*op = create_variable();
					//printf("op->kind:%d\n",(*op)->kind);
					if(var->number == -1) {//该变量第一次出现
						var->number = (*op)->u.var_no;
					}
					else {//该变量之前已经命名过
						(*op)->u.var_no = var->number;
						//var_number--;
					}
					return NULL;
				}
			}
		}
		else {//函数调用 ID() ID(Args)
			char* name1 = Exp->child[2]->data;
			char* func_name = Exp->child[0]->value; 
			if(strcmp(name1,"RP") == 0) {//ID()
				SymbolNodeFunction func = SearchFunc(func_name);
				if(func != NULL) {
					if(strcmp(func_name,"read") == 0) {
					        InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
						code0->kind = READ;
						code0->u.read.place = *op;
						InterCodes codes0 = (InterCodes)malloc(sizeof(struct InterCodes_));
						codes0 = NULL;
						codes0 = insert_to_intercodes(codes0,code0);
						return codes0;
					}
					else {
						Operand func = create_func(func_name);
						InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
						code0->kind = CALL;
						code0->u.call.place = *op;
						code0->u.call.func = func;
						InterCodes codes0 = (InterCodes)malloc(sizeof(struct InterCodes_));
						codes0 = NULL;
						codes0 = insert_to_intercodes(codes0,code0);
						return codes0;
					}
				}
				else
					return NULL;
			}
			else {//ID(Args)
				SymbolNodeFunction func = SearchFunc(func_name);
				int num = func->ParameterNum;
				Operand arg_list[num];
				//printf("func_name:%s num:%d",func_name,num);
				int i = 0;
				for(;i < num;i++) {
					arg_list[i] = (Operand)malloc(sizeof(struct Operand_));
					arg_list[i] = NULL;
				}
				InterCodes codes0 = translate_Args(Exp->child[2],arg_list,0,func_name);
				if(func != NULL) {
					if(strcmp(func_name,"write") == 0) {
					        InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
						code1->kind = WRITE;
						code1->u.write.place = arg_list[0];
						codes0 = insert_to_intercodes(codes0,code1);
						return codes0;
					}
					else {
						int i;
						for(i = num-1;i >= 0;i--) {
							InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
							code1->kind = ARG;
							code1->u.arg.arg_name = arg_list[i];
							codes0 = insert_to_intercodes(codes0,code1);
						}
						Operand func = create_func(func_name);
						InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
						code2->kind = CALL;
						code2->u.call.place = *op;
						code2->u.call.func = func;
						codes0 = insert_to_intercodes(codes0,code2);
						return codes0;
					}
				}
			}
		}
	}
	//if(strcmp(name,"LP") == 0 || strcmp(name,"MINUS") == 0 || strcmp(name,"NOT") == 0) {//一元运算符 ()/-/!
	else if(strcmp(name,"MINUS") == 0) {
		Operand t1 = NULL;//create_temp();
		InterCodes codes1 = translate_Exp(Exp->child[1],&t1,func_name);
		if(t1->kind == CONSTANT){
			operand(op);
		       	*op = create_constant(-(t1->u.value));
		       	return NULL;
		}
		else{
		        Operand zero = create_constant(0);
		        InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
		        code2->kind = SUB;
		        code2->u.binop.result = *op;
		        code2->u.binop.op1 = zero;
		        code2->u.binop.op2 = t1;
			codes1 = insert_to_intercodes(codes1,code2);
			return codes1;
		}
	}
	else if(strcmp(name,"NOT") == 0) {
		Operand label1 = create_label();
		Operand label2 = create_label();	
		Operand zero = create_constant(0);
		InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
		code0->kind = ASSIGN;
		code0->u.assign.left = *op;
		code0->u.assign.right = zero;
		InterCodes codes0 = (InterCodes)malloc(sizeof(struct InterCodes_));
		codes0 = NULL;
		codes0 = insert_to_intercodes(codes0,code0);
		InterCodes codes1 = translate_Cond(Exp, label1, label2,func_name);
		InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
		code2->kind = LABEL;
		code2->u.label.label = label1;
		Operand one = create_constant(1);
		InterCode code3 = (InterCode)malloc(sizeof(struct InterCode_));
		code3->kind = ASSIGN;
		code3->u.assign.left = *op;
		code3->u.assign.right = one;
		InterCode code4 = (InterCode)malloc(sizeof(struct InterCode_));
		code4->kind = LABEL;
		code4->u.label.label = label2;
		codes0 = merge(codes0,codes1);
		codes0 = insert_to_intercodes(codes0,code2);
		codes0 = insert_to_intercodes(codes0,code3);
		codes0 = insert_to_intercodes(codes0,code4);
		return codes0;
	}
	else if(strcmp(name,"LP") == 0) {
		*op = NULL;
		return translate_Exp(Exp->child[1],op,func_name);
	}
	else {//INT/FLOAT
		if(strcmp(name,"INT") == 0) {
			int value = atoi(Exp->child[0]->value);
			operand(op);
			//printf("value:%d\n",value);
			*op = create_constant(value);
			//printf("op->kind:%d\n",(*op)->kind);
		}
		return NULL;
	}
}

InterCodes translate_Args(struct NODE* Args,Operand list[],int number,char* func_name)
{
	char* name = Args->child[0]->data;
	if(strcmp(name,"Exp") == 0) {
		Operand t1 = NULL;//create_temp();
		InterCodes codes0 = translate_Exp(Args->child[0],&t1,func_name);
		list[number] = t1;
		if(Args->child[1] == NULL) {//Exp
			return codes0;
		}
		else {//Exp,Args
			char* name1 = Args->child[2]->data;
			if(strcmp(name1,"Args") == 0) {
				InterCodes codes1 = translate_Args(Args->child[2],list,number + 1,func_name);
				codes0 = merge(codes0,codes1);
				return codes0;
			}	
		}
	}
}

InterCodes translate_Stmt(struct NODE* Stmt,char* func_name)
{
	//printf("-------Stmt---------\n");
	char* name = Stmt->child[0]->data;
	if(strcmp(name,"Exp") == 0) {
		Operand t1 = NULL;//create_temp();
		//printf("Stmt END!\n");
		return translate_Exp(Stmt->child[0],&t1,func_name);
	}
	else if(strcmp(name,"CompSt") == 0) {
		//printf("Stmt END!\n");
		return translate_CompSt(Stmt->child[0],func_name);
	}
	else if(strcmp(name,"RETURN") == 0) {//函数返回语句	
		char* name1 = Stmt->child[1]->data;
		if(strcmp(name1,"Exp") == 0) {
			Operand t1 = NULL;//create_temp();
			//printf("~~~~~~~~~~~~~~%s\n",func_name);
			InterCodes codes0 = translate_Exp(Stmt->child[1],&t1,func_name);
			InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
			code1->kind = RETURN_IC;
			code1->u.return_.return_place = t1;
			codes0 = insert_to_intercodes(codes0,code1);
			//printf("Stmt END!\n");
			return codes0;
		}
	}
	else if(strcmp(name,"IF") == 0) {//if 语句
		char* name1 = Stmt->child[2]->data;
		if(strcmp(name1,"Exp") == 0) {
			Operand label1 = create_label();
			Operand label2 = create_label();
			InterCodes codes0 = translate_Cond(Stmt->child[2],label1,label2,func_name);
			//printf("exp out\n");
			char* name2 = Stmt->child[4]->data;
			if(strcmp(name2,"Stmt") == 0) {
				InterCodes codes1 = translate_Stmt(Stmt->child[4],func_name);
				InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
				code2->kind = LABEL;
				code2->u.label.label = label1;
				InterCode code3 = (InterCode)malloc(sizeof(struct InterCode_));
				code3->kind = LABEL;
				code3->u.label.label = label2;
				if(Stmt->child[5] != NULL) {//带 else
					Operand label3 = create_label();
					InterCodes codes4 = translate_Stmt(Stmt->child[6],func_name);
					InterCode code5 = (InterCode)malloc(sizeof(struct InterCode_));
					code5->kind = GOTO;
					code5->u.goto_.label = label3;
					InterCode code6 = (InterCode)malloc(sizeof(struct InterCode_));
					code6->kind = LABEL;
					code6->u.label.label = label3;
					codes0 = insert_to_intercodes(codes0,code2);
					codes0 = merge(codes0,codes1);
					codes0 = insert_to_intercodes(codes0,code5);
					codes0 = insert_to_intercodes(codes0,code3);
					codes0 = merge(codes0,codes4);
					codes0 = insert_to_intercodes(codes0,code6);
					//printf("Stmt END!\n");
					return codes0;
				}
				else {//没有else
					codes0 = insert_to_intercodes(codes0,code2);
					codes0 = merge(codes0,codes1);
					codes0 = insert_to_intercodes(codes0,code3);
					//printf("Stmt END!\n");
					return codes0;
				}
			}
		}
	}
	else if(strcmp(name,"WHILE") == 0) {//while 语句
		char* name1 = Stmt->child[2]->data;
		if(strcmp(name1,"Exp") == 0) {
			Operand label1 = create_label();
			Operand label2 = create_label();
			Operand label3 = create_label();
			InterCodes codes0 = translate_Cond(Stmt->child[2],label2,label3,func_name);
			char* name2 = Stmt->child[4]->data;
			if(strcmp(name2,"Stmt") == 0) {
				InterCodes codes1 = translate_Stmt(Stmt->child[4],func_name);
				InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
				code2->kind = LABEL;
				code2->u.goto_.label = label1;
				InterCode code3 = (InterCode)malloc(sizeof(struct InterCode_));
				code3->kind = LABEL;
				code3->u.label.label = label2;
				InterCode code4 = (InterCode)malloc(sizeof(struct InterCode_));
				code4->kind = LABEL;
				code4->u.label.label = label3;
				InterCode code5 = (InterCode)malloc(sizeof(struct InterCode_));
				code5->kind = GOTO;
				code5->u.goto_.label = label1;
				InterCodes codes = (InterCodes)malloc(sizeof(struct InterCodes_));
				codes = NULL;
				codes = insert_to_intercodes(codes,code2);
				codes = merge(codes,codes0);
				codes = insert_to_intercodes(codes,code3);
				codes = merge(codes,codes1);
				codes = insert_to_intercodes(codes,code5);
				codes = insert_to_intercodes(codes,code4);
				//printf("Stmt END!\n");
				return codes;
			}
		}
	}
	return NULL;
}

InterCodes translate_Cond(struct NODE* Exp,Operand label_true,Operand label_false,char* func_name)
{
	char* name = Exp->child[0]->data;
	if(strcmp(name,"Exp") == 0) {
		char* name1 = Exp->child[1]->data;
		if(strcmp(name1,"RELOP") == 0) {//Exp RELOP Exp
			//printf("RELOP!!!!!!!!!!!!!\n");
			Operand t1 = NULL;//create_temp();//(Operand)malloc(sizeof(struct Operand_));
			Operand t2 = NULL;//create_temp();//(Operand)malloc(sizeof(struct Operand_));
			InterCodes codes0 = translate_Exp(Exp->child[0],&t1,func_name);
			//printf("t1->kind:%d\n",t1->kind);
			InterCodes codes1 = translate_Exp(Exp->child[2],&t2,func_name);
			//printf("t2->kind:%d\n",t2->kind);
			//printf("t1->kind:%d  t2->kind:%d temp:%d",t1->kind,t2->kind,TEMP);
			Operand op = create_relop(Exp->child[1]->value);
			InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
			code2->kind = BLTZ;
			code2->u.bltz.op1 = t1;
			code2->u.bltz.relop = op;
			code2->u.bltz.op2 = t2;
			code2->u.bltz.label = label_true;
			InterCode code3 = (InterCode)malloc(sizeof(struct InterCode_));
			code3->kind = GOTO;
			code3->u.goto_.label = label_false;
			codes0 = merge(codes0,codes1);
			codes0 = insert_to_intercodes(codes0,code2);
			codes0 = insert_to_intercodes(codes0,code3);
			return codes0;
		}
		else if(strcmp(name1,"AND") == 0) {//Exp AND Exp
			Operand label1 = create_label();
			InterCodes codes0 = translate_Cond(Exp->child[0],label1,label_false,func_name);
			InterCodes codes1 = translate_Cond(Exp->child[2],label_true,label_false,func_name);
			InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
			code2->kind = LABEL;
			code2->u.label.label = label1;
			codes0 = insert_to_intercodes(codes0,code2);
			codes0 = merge(codes0,codes1);
			return codes0;
		}
		else if(strcmp(name1,"OR") == 0) {//Exp OR Exp
			Operand label1 = create_label();
			InterCodes codes0 = translate_Cond(Exp->child[0],label_true,label1,func_name);
			InterCodes codes1 = translate_Cond(Exp->child[2],label_true,label_false,func_name);
			InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
			code2->kind = LABEL;
			code2->u.label.label = label1;
			codes0 = insert_to_intercodes(codes0,code2);
			codes0 = merge(codes0,codes1);
			return codes0;
		}
	}
	else if(strcmp(name,"NOT") == 0) {//NOT Exp
		return translate_Cond(Exp->child[1],label_false,label_true,func_name);
	}
	else {
		Operand t1 = NULL;//create_temp();
		InterCodes codes0 = translate_Exp(Exp,&t1,func_name);
		Operand op = create_relop("!=");
		Operand zero = create_constant(0);
		InterCode code1 = (InterCode)malloc(sizeof(struct InterCode_));
		code1->kind = BLTZ;
		code1->u.bltz.op1 = t1;
		code1->u.bltz.relop = op;
		code1->u.bltz.op2 = zero;
		code1->u.bltz.label = label_true;
		InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
		code2->kind = GOTO;
		code2->u.goto_.label = label_false;
		codes0 = insert_to_intercodes(codes0,code1);
		codes0 = insert_to_intercodes(codes0,code2);
		return codes0;
	}
}

InterCodes translate_ExtDef(struct NODE* ExtDef)
{
	//printf("-------ExtDef--------\n");
	char* name = ExtDef->child[0]->data;
	char* func_name;
	if(strcmp(name,"Specifier") == 0) {
		//translate_Specifier(ExtDef->child[0]);
		/*if(strcmp(ExtDef->child[1]->data,"ExtDecList") == 0) {
			translate_ExtDecList(ExtDef->child[1]);
		}
		else*/ if(strcmp(ExtDef->child[1]->data,"SEMI") == 0) {}
		else if(strcmp(ExtDef->child[1]->data,"FunDec") == 0) {
			InterCodes codes0 = translate_FunDec(ExtDef->child[1],&func_name);
			//printf("=====%s\n",func_name);
			if(strcmp(ExtDef->child[2]->data,"CompSt") == 0) {
				InterCodes codes1 = translate_CompSt(ExtDef->child[2],func_name);
				codes0 = merge(codes0,codes1);
			}
			return codes0;
		}
	}
	return NULL;
	//printf("ExtDef END!\n");
}

InterCodes translate_FunDec(struct NODE* FunDec,char** func_name)//函数头
{
	//printf("-------FunDec--------\n");
	char* name = FunDec->child[0]->data;
	if(strcmp(name,"ID") == 0) {
		*func_name = FunDec->child[0]->value;
		//printf("!!!!%s\n",*func_name);
		char* name1 = FunDec->child[2]->data;
		if(strcmp(name1,"VarList") == 0) {//函数形参
			Operand func = create_func(*func_name);
			InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
			code0->kind = FUNCTION;
			code0->u.function.fun_name = func;
			InterCodes codes = (InterCodes)malloc(sizeof(struct InterCodes_));
			codes = NULL;
			codes = insert_to_intercodes(codes,code0);
			InterCodes codes1 = translate_VarList(FunDec->child[2],*func_name);
			codes = merge(codes,codes1);
			//printf("FunDec END!\n");
			return codes;
		}
		else {
			//printf("funcname:%s\n",fun_name);
			Operand func = create_func(*func_name);
			InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
			code0->kind = FUNCTION;
			code0->u.function.fun_name = func;
			InterCodes codes = (InterCodes)malloc(sizeof(struct InterCodes_));
			codes = NULL;
			codes = insert_to_intercodes(codes,code0);
			//printf("FunDec END!\n");
			//printf("codes->code->kind:%d\n",codes->code->kind);
			return codes;
		}
	}
	
	//return fun_name;
}

InterCodes translate_VarList(struct NODE* VarList,char* func_name)//形参列表
{
	//printf("-------VarList--------\n");
	char* name = VarList->child[0]->data;
	if(strcmp(name,"ParamDec") == 0) {
		//printf("para_number:%d\n",number);
		InterCodes codes0 = translate_ParamDec(VarList->child[0],func_name);
		if(VarList->child[1] != NULL) {
			char* name1 = VarList->child[2]->data;
			if(strcmp(name1,"VarList") == 0) {
				InterCodes codes1 = translate_VarList(VarList->child[2],func_name);
				codes0 = merge(codes0,codes1);
			}
		}
		return codes0;
	}
	return NULL;
	//printf("VarList END!\n");
}

InterCodes translate_ParamDec(struct NODE* ParamDec,char* func_name)//一个形参的定义
{
	//printf("-------ParamDec--------\n");
	char* name = ParamDec->child[0]->data;
	char stru_name[20];
	if(strcmp(name,"Specifier") == 0) {
		//translate_Specifier(ParamDec->child[0]);
		char* name1 = ParamDec->child[1]->data;
		if(strcmp(name1,"VarDec") == 0) {
			InterCodes codes0 = translate_VarDec(ParamDec->child[1],1,NULL,func_name);
			return codes0;
		}
	}
	return NULL;
	//printf("ParamDec END!\n");
	//return var;
}

InterCodes translate_CompSt(struct NODE* CompSt,char* func_name)//函数体 LC DefList StmtList RC
{
	//printf("-------CompSt--------\n");
	//printf("CompSt->child[1]->data:%s\n",CompSt->child[1]->data);
	InterCodes codes0 = NULL;
	InterCodes codes1 = NULL;
	if(CompSt->child[1] != NULL) {
		char* name = CompSt->child[1]->data;
		if(strcmp(name,"DefList") == 0) {
			codes0 = translate_DefList(CompSt->child[1],func_name);//DefList出现在CompSt的右边，可以初始化
		}
	}
	if(CompSt->child[2] != NULL) {
		char* name1 = CompSt->child[2]->data;
		if(strcmp(name1,"StmtList") == 0) {
			//printf("------------%s\n",func_name);
			codes1 = translate_StmtList(CompSt->child[2],func_name);
		}
	}
	codes0 = merge(codes0,codes1);
	//printf("CompSt END!\n");
	return codes0;
}

InterCodes translate_DefList(struct NODE* DefList,char* func_name)//CompSt 以及 StructSpecifier 产生式的右边,结构体和非结构体不同
{
	//printf("-------DefList--------\n");
	char* name = DefList->child[0]->data;
	if(strcmp(name,"Def") == 0) {
		InterCodes codes0 = translate_Def(DefList->child[0],func_name);//printf("~~~~~~~~~\n");InterCodesDisplay(codes0);
		if(DefList->child[1] != NULL) {
			char* name1 = DefList->child[1]->data;
			//printf("data:%s\n",DefList->child[1]->data);
			if(strcmp(name1,"DefList") == 0) {
				InterCodes codes1 = translate_DefList(DefList->child[1],func_name);
				codes0 = merge(codes0,codes1);
				//printf("---------------\n");InterCodesDisplay(codes0);
			}
		}
		return codes0;
	}
	//return NULL;
	//printf("DefList END!\n");
}
InterCodes translate_Def(struct NODE* Def,char* func_name)
{
	//printf("-------Def--------\n");
	char* name = Def->child[0]->data;
	if(strcmp(name,"Specifier") == 0) {
		//translate_Specifier(Def->child[0]);
		char* name1 = Def->child[1]->data;
		if(strcmp(name1,"DecList") == 0) {
			InterCodes codes0 = translate_DecList(Def->child[1],func_name);//printf("!!!!\n");InterCodesDisplay(codes0);
			return codes0;
		}
	}
	//return NULL;
	//printf("Def END!\n");
}
InterCodes translate_DecList(struct NODE* DecList,char* func_name)
{
	//printf("------DecList-------\n");
	char* name = DecList->child[0]->data;
	if(strcmp(name,"Dec") == 0) {
		InterCodes codes0 = translate_Dec(DecList->child[0],func_name);
		//printf("--------\n");InterCodesDisplay(codes0);
		if(DecList->child[1] != NULL) {
			//printf("DecList->child[2]->data:%s\n",DecList->child[2]->data);
			char* name1 = DecList->child[2]->data;
			if(strcmp(name1,"DecList") == 0) {
				InterCodes codes1 = translate_DecList(DecList->child[2],func_name);
				codes0 = merge(codes0,codes1);
				//printf("==========\n");InterCodesDisplay(codes0);
			}
		}
		return codes0;
	}
	//return NULL;	
	//printf("DecList END!\n");
}
InterCodes translate_Dec(struct NODE* Dec,char* func_name)
{
	//printf("------Dec-------\n");	
	Operand t1 = NULL;//create_temp();
	char* name = Dec->child[0]->data;
	if(strcmp(name,"VarDec") == 0) {
		InterCodes codes0 = translate_VarDec(Dec->child[0],2,&t1,func_name);	
		if(Dec->child[1] != NULL) {//VarDec = Exp(assign)
			char* name1 = Dec->child[2]->data;			
			//printf("data:%s\n",Dec->child[2]->data);
			if(strcmp(name1,"Exp") == 0) {
				Operand t2 = NULL;//create_temp();
				InterCodes codes1 = translate_Exp(Dec->child[2],&t2,func_name);
				InterCode code2 = (InterCode)malloc(sizeof(struct InterCode_));
				code2->kind = ASSIGN;
				code2->u.assign.left = t1;
				code2->u.assign.right = t2;
				codes0 = merge(codes0,codes1);
				codes0 = insert_to_intercodes(codes0,code2);
				//printf("--------\n");InterCodesDisplay(codes0);
			}
		}
		return codes0;
	}
	//return NULL;	
	//printf("Dec END!\n");
}
InterCodes translate_VarDec(struct NODE* VarDec,int tag,Operand* op,char* func_name)
{
	if(tag == 2)
		*op = create_temp();
	//printf("-------VarDec--------\n");
	if(tag == 1) {//作为函数参数
		char* name = VarDec->child[0]->data;
		//printf("-----------name:%s\n",name);
		//SymbolNodeFunction func = SearchFunc("add");
		//printf("func->parameters[i]->name:%s\n",func->parameters[0]->name);
		if(strcmp(name,"ID") == 0) {//ID的内容为变量名
			SymbolNodeFunction func = SearchFunc(func_name);
			//printf("VarDec--func_name:%s\n",func_name);
			int num = func->ParameterNum;
			int i = 0;
			for(;i < num;i++) {
				if(strcmp(func->parameters[i]->name,VarDec->child[0]->value) == 0) {
					break;
				}
			}
			char var_name[20];
			strcpy(var_name,func->parameters[i]->name);
			//printf("VarDec--var_name:%s\n",var_name);
			SymbolNodeVariable var;
			if(strcmp(var_name,VarDec->child[0]->value) == 0)
				var = SearchVar(var_name);
			if(func != NULL && var != NULL) {
				if(var->type->kind == basic) {
					Operand param = create_variable();
					if(func->parameters[i]->number == -1) {//该变量第一次出现
						func->parameters[i]->number = param->u.var_no;
						var->number = param->u.var_no;
						//printf("var->number:%d\n",var->number);
					}
					else {//该变量之前已经命名过
						param->u.var_no = func->parameters[i]->number;
						//var_number--;
					}
					InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
					code0->kind = PARAM;
					code0->u.param.param_name = param;
					InterCodes codes = (InterCodes)malloc(sizeof(struct InterCodes_));
					codes = NULL;
					codes = insert_to_intercodes(codes,code0);
					return codes;
				}
				else if(var->type->kind == structure){
					printf("%s\n","Can not translate the code: Contain structure and function parameters of structure type!");
					exit(0);
				}
			}
		}
		else {//数组 VarDec LB INT RB
			//translate_VarDec(VarDec->child[0]);
			//SymbolNodeFunction func = SearchFunc(func_name);
			struct NODE* node = VarDec->child[0];
			while(strcmp(node->data,"ID") != 0) {
				node = node->child[0];
			}
			//printf("func_name:%s\n",func_name);
			SymbolNodeFunction func = SearchFunc(func_name);
			int num = func->ParameterNum;
			int i = 0;
			for(;i < num;i++) {
				if(strcmp(func->parameters[i]->name,node->value) == 0) {
					break;
				}
			}
			//printf("func->parameters[i]->name:%s\n",func->parameters[i]->name);
			char var_name[20];
			strcpy(var_name,func->parameters[i]->name);
			SymbolNodeVariable var = (SymbolNodeVariable)malloc(sizeof(struct SymbolNodeVariable_));;
			if(strcmp(var_name,node->value) == 0)
				var = SearchVar(node->value);
			//printf("var_name:%s\n",node->value);
			if(var != NULL) {
				//printf("param:var_number:%d\n",var_number);
				Operand param = create_variable();				
				if(var->number == -1) {//该变量第一次出现
					var->number = param->u.var_no;
					func->parameters[i]->number = param->u.var_no;
				}
				else {//该变量之前已经命名过
					param->u.var_no = var->number;
					//var_number--;
				}
				InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
				code0->kind = PARAM;
				code0->u.param.param_name = param;
				InterCodes codes = (InterCodes)malloc(sizeof(struct InterCodes_));
				codes = NULL;
				codes = insert_to_intercodes(codes,code0);
				return codes;
			}
		}
	}
	else if(tag == 2) {//普通变量
		char* name = VarDec->child[0]->data;
		if(strcmp(name,"ID") == 0) {//ID的内容为变量名
			char* var_name = VarDec->child[0]->value;
			SymbolNodeVariable var = SearchVar(var_name);
			if(var != NULL) {
				if(var->type->kind == basic) {
					operand(op);
					*op = create_variable();
					if(var->number == -1) {//该变量第一次出现
						var->number = (*op)->u.var_no;
					}
					else {//该变量之前已经命名过
						(*op)->u.var_no = var->number;
						//var_number--;
					}
					return NULL;
				}
				else if(var->type->kind == structure){
					printf("%s\n","Can not translate the code: Contain structure and function parameters of structure type!");
					exit(0);
				}
			}
		}
		else {//数组 VarDec LB INT RB
			//translate_VarDec(VarDec->child[0],2);
			struct NODE* node = VarDec;
			int size = 1;
			while(strcmp(node->child[0]->data,"ID") != 0) {
				int s = atoi(node->child[2]->value);
				size = size * s;
				node = node->child[0];
			}
			char* var_name = node->child[0]->value;
			SymbolNodeVariable var = SearchVar(var_name);
			if(var != NULL) {
				Operand size_op = create_size(size * 4);
				//printf("----var_number:%d\n",var_number);
				Operand v1 = create_variable();
				if(var->number == -1) {//该变量第一次出现
					var->number = v1->u.var_no;
				}
				else {//该变量之前已经命名过
					v1->u.var_no = var->number;
					//var_number--;
				}
				InterCode code0 = (InterCode)malloc(sizeof(struct InterCode_));
				code0->kind = DEC;
				code0->u.dec.place = v1;
				code0->u.dec.size = size_op;
				InterCodes codes = (InterCodes)malloc(sizeof(struct InterCodes_));
				codes = NULL;
				codes = insert_to_intercodes(codes,code0);
				return codes;
			}
		}
		return NULL;
	}
}

InterCodes translate_StmtList(struct NODE* StmtList,char* func_name)
{
	//printf("-------StmtList---------\n");
	char* name = StmtList->child[0]->data;
	if(strcmp(name,"Stmt") == 0) {
		InterCodes codes0 = translate_Stmt(StmtList->child[0],func_name);
		if(StmtList->child[1] != NULL) {
			char* name1 = StmtList->child[1]->data;
			if(strcmp(name1,"StmtList") == 0) {
				InterCodes codes1 = translate_StmtList(StmtList->child[1],func_name);
				codes0 = merge(codes0,codes1);
			}
		}
		//printf("StmtList END!\n");
		return codes0;
	}
	return NULL;	
	//
}
