#include "src.h"
int param_no = 0;
int arg_no = 0;
struct func_varlist_* funchead = NULL;
struct func_varlist_* funclast = NULL;
int is_read_write_Code(InterCode code) {
	if(code != NULL) {
		if(code->kind == READ)
			return 1;
		else if(code->kind == WRITE)
			return 2;
		else
			return 0;
	}
}
int read_Codes(InterCodes root) {
	if(root != NULL) {
		InterCodes codes = root;
		int read;
		//int flag = 0;
		while(codes != NULL) {
			int flag = is_read_write_Code(codes->code);
			if(flag == 1)
				return 1;
			codes = codes->next;
		}
		return 0;
	}
}
int write_Codes(InterCodes root) {
	if(root != NULL) {
		InterCodes codes = root;
		int write;
		//int flag = 0;
		while(codes != NULL) {
			int flag = is_read_write_Code(codes->code);
			if(flag == 2)
				return 1;
			codes = codes->next;
		}
		return 0;
	}
}

void read_write_machinecode(int read,int write) {
	printf("%s",".data\n");
	fprintf(mcode_fp,"%s",".data\n");
	if(read != 0) {
		printf("%s","_prompt: .asciiz \"Enter an integer:\"\n");
		fprintf(mcode_fp,"%s","_prompt: .asciiz \"Enter an integer:\"\n");
	}
	if(write != 0) {
		printf("%s","_ret: .asciiz \"\\n\"\n");
		fprintf(mcode_fp,"%s","_ret: .asciiz \"\\n\"\n");
	}
	printf("%s",".globl main\n");
	fprintf(mcode_fp,"%s",".globl main\n");
	printf("%s",".text\n");
	fprintf(mcode_fp,"%s",".text\n");
	if(read != 0) {
		printf("%s","read:\n");
		fprintf(mcode_fp,"%s","read:\n");
		printf("\t%s","li $v0,4\n");
		fprintf(mcode_fp,"\t%s","li $v0,4\n");
		printf("\t%s","la $a0, _prompt\n");
		fprintf(mcode_fp,"\t%s","la $a0, _prompt\n");
		printf("\t%s","syscall\n");
		fprintf(mcode_fp,"\t%s","syscall\n");
		printf("\t%s","li $v0,5\n");
		fprintf(mcode_fp,"\t%s","li $v0,5\n");
		printf("\t%s","syscall\n");
		fprintf(mcode_fp,"\t%s","syscall\n");
		printf("\t%s","jr $ra\n");
		fprintf(mcode_fp,"\t%s","jr $ra\n");
		printf("\n");
		fprintf(mcode_fp,"%s","\n");
	}
	if(write != 0) {
		printf("%s","write:\n");
		fprintf(mcode_fp,"%s","write:\n");
		printf("\t%s","li $v0,1\n");
		fprintf(mcode_fp,"\t%s","li $v0,1\n");
		printf("\t%s","syscall\n");
		fprintf(mcode_fp,"\t%s","syscall\n");
		printf("\t%s","li $v0,4\n");
		fprintf(mcode_fp,"\t%s","li $v0,4\n");
		printf("\t%s","la $a0, _ret\n");
		fprintf(mcode_fp,"\t%s","la $a0, _ret\n");
		printf("\t%s","syscall\n");
		fprintf(mcode_fp,"\t%s","syscall\n");
		printf("\t%s","move $v0,$0\n");
		fprintf(mcode_fp,"\t%s","move $v0,$0\n");
		printf("\t%s","jr $ra\n");
		fprintf(mcode_fp,"\t%s","jr $ra\n");
		printf("\n");
		fprintf(mcode_fp,"%s","\n");
	}	
}
void load_Operand(Operand op,int number) {
	//printf("load\n");
	int stack_offset = 0;
	struct varoffset_* node = stackhead;
	while(node != NULL) {
		if(Operand_equal(node->var,op) == 1)//之前就加入到栈中
			break;
		node = node->next;
	}
	if(node != NULL) 
		stack_offset = node->offset;
	else if(node == NULL) {
		printf("*********************\n");
		exit(0);
	}
	//printf("node->offset:%d\n",node->offset);
	stack_offset = last->offset - node->offset;
	if(op != NULL) {
		if(op->kind == CONSTANT) {
			printf("\tli $t%d %d\n",number,op->u.value);
			fprintf(mcode_fp,"\tli $t%d %d\n",number,op->u.value);
		}
		if(op->kind == VARIABLE || op->kind == TEMP) {
			printf("\tlw $t%d %d($sp)\n",number,stack_offset);
			fprintf(mcode_fp,"\tlw $t%d %d($sp)\n",number,stack_offset);
		}
		if(op->kind == ADDRESS) {//&
			printf("\taddi $t%d $sp,%d\n",number,stack_offset);
			fprintf(mcode_fp,"\taddi $t%d $sp,%d\n",number,stack_offset);
		}
		if(op->kind == MEM) {//*
			printf("\tlw $t4 %d($sp)\n",stack_offset);
			fprintf(mcode_fp,"\tlw $t4 %d($sp)\n",stack_offset);
			printf("\tlw $t%d 0($t4)\n",number);
			fprintf(mcode_fp,"\tlw $t%d 0($t4)\n",number);
		}
	}
}
void store_Operand(Operand op,int number) {
	//printf("op:%d   %d\n",op->kind,op->u.var_no);
	int stack_offset = 0;
	struct varoffset_* node = stackhead;
	while(node != NULL) {
		if(Operand_equal(node->var,op) == 1) {//之前就加入到栈中
			//printf("zhaodaole\n");
			//printf("op:%d\n",op->u.var_no);
			break;
		}
		node = node->next;
	}
	if(node != NULL) {
		stack_offset = node->offset;
		//printf("stack_offset:%d\n",stack_offset);
	}
	else if(node == NULL)
		exit(0);
	stack_offset = last->offset - node->offset;
	//printf("stack_offset:%d\n",stack_offset);
	if(op != NULL) {
		if(op->kind == VARIABLE || op->kind == TEMP) {
			printf("\tsw $t%d %d($sp)\n",number,stack_offset);
			fprintf(mcode_fp,"\tsw $t%d %d($sp)\n",number,stack_offset);
		}
		if(op->kind == MEM) {//*
			printf("\tlw $t4 %d($sp)\n",stack_offset);
			fprintf(mcode_fp,"\tlw $t4 %d($sp)\n",stack_offset);
			printf("\tsw $t%d 0($t4)\n",number);
			fprintf(mcode_fp,"\tsw $t%d 0($t4)\n",number);
		}
	}
}
int Operand_equal(Operand op1,Operand op2) {
	if(op2->kind == ADDRESS || op2->kind == MEM) {
		//printf("mem\n");
		char string[10];
		strcpy(string,&(op2->u.mem_addr[1]));
		int num = atoi(string);
		if(op2->u.mem_addr[0] == 'v') {
			//op2->kind = VARIABLE;
			if(op1->kind == VARIABLE && op1->u.var_no == num)
				return 1;
			//printf("v%d\n",num);
		}
		else if(op2->u.mem_addr[0] == 't') {
			//op2->kind = TEMP;
			if(op1->kind == TEMP && op1->u.temp_no == num)
				return 1;
			//printf("t%d\n",num);
		}
	}
	if(op1->kind == op2->kind) {
		/*if(op1->kind == ADDRESS || op1->kind == MEM) {
			if(strcmp(op1->u.mem_addr,op2->u.mem_addr) == 0)
				return 1;
		}*/
		if(op1->kind == VARIABLE) {
			//printf("variable\n");
			if(op1->u.var_no == op2->u.var_no) {
				//printf("op1->u.var_no:%d\n",op1->u.var_no);
				return 1;
			}
		}
		if(op1->kind == CONSTANT || op1->kind == SIZE) {
			if(op1->u.value == op2->u.value)
				return 1;
		}
		if(op1->kind == TEMP) {
			if(op1->u.temp_no == op2->u.temp_no)
				return 1;
		}
		if(op1->kind == LABEL_OP) {
			if(op1->u.label_no == op2->u.label_no)
				return 1;
		}
		if(op1->kind == RELOP_OP) {
			if(strcmp(op1->u.relop,op2->u.relop) == 0)
				return 1;
		}
		if(op1->kind == FUNC) {
			if(strcmp(op1->u.func_name,op2->u.func_name) == 0)
				return 1;
		}
	}
	return 0;
}
void initstack_operand(Operand op,int size) {
	/*if(op->kind == ADDRESS || op->kind == MEM) {
		char string[10];
		strcpy(string,&(op->u.mem_addr[1]));
		int num = atoi(string);
		if(op->u.mem_addr[0] == 'v') {
			op->kind = VARIABLE;
			op->u.var_no = num;
			//printf("v%d\n",num);
		}
		else if(op->u.mem_addr[0] == 't') {
			op->kind = TEMP;
			op->u.var_no = num;
			//printf("t%d\n",num);
		}
	}*/
	struct varoffset_* offset_node = (struct varoffset_*)malloc(sizeof(struct varoffset_*));
	offset_node->var = op;
	//offset_node->offset = 4;
	offset_node->next = NULL;
	struct varoffset_* node = stackhead;
	while(node != NULL) {
		if(Operand_equal(node->var,op) == 1)//之前就加入到栈中
			break;
		node = node->next;
	}
	if(node == NULL) {//两种情况，头为空或者头不为空但是之前未曾加入栈中
		if(last == NULL) {//头为空
			//printf("^^^^^\n");			
			offset_node->offset = size;
			stackhead = offset_node;
			last = offset_node;
			if(last == NULL)
				printf("last is NULL\n");
		}
		else {//头不为空，之前未加入到栈中
			//printf("last is not NULL\n");
			offset_node->offset = last->offset + size;
			//printf("num:%d\n",offset_node->offset);
			last->next = offset_node;
			last = offset_node;
		}
	}
}
void initstack_code(InterCode code) {
	if(code != NULL) {
		if(code->kind == ASSIGN) {
			//printf("assign\n");
			//printf("left\n");
			initstack_operand(code->u.assign.left,4);
			//printf("right\n");
			initstack_operand(code->u.assign.right,4);
		}
		else if(code->kind == ADD || code->kind == SUB || code->kind == MUL || code->kind == DIVI) {
			initstack_operand(code->u.binop.op1,4);
			initstack_operand(code->u.binop.op2,4);
			initstack_operand(code->u.binop.result,4);
		}
		else if(code->kind == BLTZ) {
			initstack_operand(code->u.bltz.op1,4);
			initstack_operand(code->u.bltz.op2,4);
		}
		else if(code->kind == RETURN_IC) {
			//printf("return\n");
			initstack_operand(code->u.return_.return_place,4);
		}
		else if(code->kind == DEC) {
			//printf("dec size:%d\n",code->u.dec.size->u.value);
			initstack_operand(code->u.dec.place,code->u.dec.size->u.value);
		}
		else if(code->kind == PARAM) {
			initstack_operand(code->u.param.param_name,4);
		}
		else if(code->kind == ARG) {
			arg_no++;
			initstack_operand(code->u.arg.arg_name,4);
		}
		else if(code->kind == CALL) {
			initstack_operand(code->u.call.place,4);
		}
		else if(code->kind == READ) {
			initstack_operand(code->u.read.place,4);
		}
		else if(code->kind == WRITE) {
			initstack_operand(code->u.write.place,4);
		}
	}
}
void initstack_codes(InterCodes codes0) {
	stackhead = NULL;
	last = NULL;
	InterCodes codes = codes0;
	int tag = 0;
	while(codes != NULL){
		//printf("-------------\n");
		if(codes->code->kind == FUNCTION) {
			if(tag == 0)		
				tag = 1;
			else//遇到第二个函数
				return;
		}
		initstack_code(codes->code);
		codes = codes->next;
   	}
}
void MachineCodeDisplay(InterCode code) {
	if(code != NULL) {
		if(code->kind == ASSIGN) {
			//printf("assign\n");
			load_Operand(code->u.assign.right,1);//从内存中取到寄存器中，或者常量直接load到寄存器中
			store_Operand(code->u.assign.left,1);//将最终结果存入内存中
		}
		else if(code->kind == ADD || code->kind == SUB || code->kind == MUL || code->kind == DIVI) {
			//两个操作数均取到寄存器中
			load_Operand(code->u.binop.op1,1);
			load_Operand(code->u.binop.op2,2);
			if(code->kind == ADD) {
				printf("\t%s","add $t3,$t1,$t2\n");
				fprintf(mcode_fp,"\t%s","add $t3,$t1,$t2\n");
			}
			else if(code->kind == SUB) {
				printf("\t%s","sub $t3,$t1,$t2\n");
				fprintf(mcode_fp,"\t%s","sub $t3,$t1,$t2\n");
			}
			else if(code->kind == MUL) {
				printf("\t%s","mul $t3,$t1,$t2\n");
				fprintf(mcode_fp,"\t%s","mul $t3,$t1,$t2\n");
			}
			else if(code->kind == DIVI) {
				printf("\t%s","div $t1,$t2\n");
				fprintf(mcode_fp,"\t%s","div $t1,$t2\n");
				printf("\t%s","mflo $t3\n");
				fprintf(mcode_fp,"\t%s","mflo $t3\n");
			}
			//结果存入内存中
			store_Operand(code->u.binop.result,3);
		}
		else if(code->kind == LABEL) {
			int no = code->u.label.label->u.label_no;
			printf("lable%d :\n",no);
			fprintf(mcode_fp,"lable%d :\n",no);
		}
		else if(code->kind == BLTZ) {
			//两个操作数均取到寄存器中
			load_Operand(code->u.bltz.op1,1);
			load_Operand(code->u.bltz.op2,2);
			int no = code->u.bltz.label->u.label_no;
			if(strcmp(code->u.bltz.relop->u.relop,"==") == 0) {
				printf("\tbeq $t1,$t2,lable%d\n",no);
				fprintf(mcode_fp,"\tbeq $t1,$t2,lable%d\n",no);
			}
			if(strcmp(code->u.bltz.relop->u.relop,"!=") == 0) {
				printf("\tbne $t1,$t2,lable%d\n",no);
				fprintf(mcode_fp,"\tbne $t1,$t2,lable%d\n",no);
			}
			if(strcmp(code->u.bltz.relop->u.relop,">") == 0) {
				printf("\tbgt $t1,$t2,lable%d\n",no);
				fprintf(mcode_fp,"\tbgt $t1,$t2,lable%d\n",no);
			}
			if(strcmp(code->u.bltz.relop->u.relop,"<") == 0) {
				printf("\tblt $t1,$t2,lable%d\n",no);
				fprintf(mcode_fp,"\tblt $t1,$t2,lable%d\n",no);
			}
			if(strcmp(code->u.bltz.relop->u.relop,">=") == 0) {
				printf("\tbge $t1,$t2,lable%d\n",no);
				fprintf(mcode_fp,"\tbge $t1,$t2,lable%d\n",no);
			}
			if(strcmp(code->u.bltz.relop->u.relop,"<=") == 0) {
				printf("\tble $t1,$t2,lable%d\n",no);
				fprintf(mcode_fp,"\tble $t1,$t2,lable%d\n",no);
			}
		}
		else if(code->kind == GOTO) {
			int no = code->u.goto_.label->u.label_no;
			printf("\tj lable%d\n",no);
			fprintf(mcode_fp,"\tj lable%d\n",no);
		}
		else if(code->kind == RETURN_IC) {
			load_Operand(code->u.return_.return_place,1);
			printf("\t%s\n","move $v0,$t1");
			fprintf(mcode_fp,"\t%s\n","move $v0,$t1");
			printf("\taddi $sp,$sp,%d\n",last->offset);
			fprintf(mcode_fp,"\taddi $sp,$sp,%d\n",last->offset);
			printf("\t%s\n","jr $ra");
			fprintf(mcode_fp,"\t%s\n","jr $ra");
		}
		else if(code->kind == FUNCTION) {
			char* name = code->u.function.fun_name->u.func_name;
			printf("%s:\n",name);
			fprintf(mcode_fp,"%s:\n",name);
			
			int number = 0 - last->offset;
			printf("\taddi $sp,$sp,%d\n",number);
			fprintf(mcode_fp,"\taddi $sp,$sp,%d\n",number);
		}
		else if(code->kind == PARAM) {//函数定义时的参数，前四个参数保存在$a0-$a3中，剩下的参数压在栈中
			if(param_no >= 0 && param_no < 4) {
				printf("\tmove $t1,$a%d\n",param_no);
				fprintf(mcode_fp,"\tmove $t1,$a%d\n",param_no);
			}
			else if(param_no >= 4) {//从栈中取出参数
				//printf("\tlw $t1,%d($sp)\n",);
				//fprintf(mcode_fp,"\tlw $t1,%d($sp)\n");
				load_Operand(code->u.param.param_name,1);
				/*int number = (param_no - 3) * 4;
				int offset = last->offset - number;				
				printf("\tlw $t1 %d($sp)\n",offset);
				fprintf(mcode_fp,"\tlw $t1 %d($sp)\n",offset);*/
			}
			store_Operand(code->u.param.param_name,1);
			param_no++;
		}
		//函数调用和定义时的参数顺序相反
		else if(code->kind == ARG) {//函数调用时的参数
			//从内存中取出参数到寄存器中，然后将其保存到函数参数应保存的地方（$a0-$a3或者直接到栈中）
			//之前必须已经保存到内存中，才可以在用到的时候取出，在什么时候存到内存（栈）？？？
			
			load_Operand(code->u.arg.arg_name,1);
			if(arg_no > 0 && arg_no <= 4) {//前四个参数保存在寄存器$a0-$a3
				printf("\tmove $a%d,$t1\n",arg_no-1);
				fprintf(mcode_fp,"\tmove $a%d,$t1\n",arg_no-1);
				arg_no--;	
			}
			else if(arg_no > 4) {//将参数保存在栈中
				//printf("\tlw $t1,%d($sp)\n");
				//fprintf(mcode_fp,"\tlw $t1,%d($sp)\n");
				store_Operand(code->u.arg.arg_name,1);
				arg_no--;
			}
		}
		//为了能够使得另一个函数返回之后能将$ra中原来的内容恢复出来,调用者在进行函数调用之前需要负责把$ra暂存在栈中
		else if(code->kind == CALL) {
			printf("\t%s","addi $sp,$sp,-4\n");
			fprintf(mcode_fp,"\t%s","addi $sp,$sp,-4\n");
			printf("\t%s","sw $ra,0($sp)\n");
			fprintf(mcode_fp,"\t%s","sw $ra,0($sp)\n");
			printf("\tjal %s\n",code->u.call.func->u.func_name);
			fprintf(mcode_fp,"\tjal %s\n",code->u.call.func->u.func_name);
			printf("\t%s","lw $ra,0($sp)\n");
			fprintf(mcode_fp,"\t%s","lw $ra,0($sp)\n");
			printf("\t%s","addi $sp,$sp,4\n");
			fprintf(mcode_fp,"\t%s","addi $sp,$sp,4\n");
			printf("\t%s","move $t1,$v0\n");
			fprintf(mcode_fp,"\t%s","move $t1,$v0\n");
			//结果存入内存中
			store_Operand(code->u.call.place,1);
		}
		//read和write是特殊的函数调用
		else if(code->kind == READ) {
			printf("\t%s","addi $sp,$sp,-4\n");
			fprintf(mcode_fp,"\t%s","addi $sp,$sp,-4\n");
			printf("\t%s","sw $ra,0($sp)\n");
			fprintf(mcode_fp,"\t%s","sw $ra,0($sp)\n");
			printf("\t%s","jal read\n");
			fprintf(mcode_fp,"\t%s","jal read\n");
			printf("\t%s","lw $ra,0($sp)\n");
			fprintf(mcode_fp,"\t%s","lw $ra,0($sp)\n");
			printf("\t%s","addi $sp,$sp,4\n");
			fprintf(mcode_fp,"\t%s","addi $sp,$sp,4\n");
			printf("\t%s","move $t1,$v0\n");
			fprintf(mcode_fp,"\t%s","move $t1,$v0\n");
			//结果存入内存中
			store_Operand(code->u.read.place,1);
		}
		//write函数有参数，但是中间代码并没有用ARG显式给出，需要用$a0保存
		else if(code->kind == WRITE) {
			load_Operand(code->u.write.place,1);
			printf("%s","\tmove $a0,$t1\n");
			fprintf(mcode_fp,"%s","\tmove $a0,$t1\n");
			printf("\t%s","addi $sp,$sp,-4\n");
			fprintf(mcode_fp,"\t%s","addi $sp,$sp,-4\n");
			printf("\t%s","sw $ra,0($sp)\n");
			fprintf(mcode_fp,"\t%s","sw $ra,0($sp)\n");
			printf("\t%s","jal write\n");
			fprintf(mcode_fp,"\t%s","jal write\n");
			printf("\t%s","lw $ra,0($sp)\n");
			fprintf(mcode_fp,"\t%s","lw $ra,0($sp)\n");
			printf("\t%s","addi $sp,$sp,4\n");
			fprintf(mcode_fp,"\t%s","addi $sp,$sp,4\n");
			//printf("\t%s","move $t1,$v0\n");
			//fprintf(mcode_fp,"\t%s","move $t1,$v0\n");
		}
	}
}
void Insert_to_funcvarlist(struct func_varlist_* func_node) {
	struct func_varlist_* node = funchead;
	while(node != NULL) {
		if(strcmp(node->func_name->u.func_name,func_node->func_name->u.func_name) == 0)//之前就加入到链表中
			break;
		node = node->next;
	}
	if(node == NULL) {//两种情况，头为空或者头不为空但是之前未曾加入到链表中
		if(funclast == NULL) {//头为空
			//printf("^^^^^\n");			
			funchead = func_node;
			funclast = func_node;
			if(funclast == NULL)
				printf("last is NULL\n");
		}
		else {//头不为空，之前未加入到栈中
			//printf("last is not NULL\n");
			funclast->next = func_node;
			funclast = func_node;
		}
	}
}
int get_arglist(Operand op) {
	struct func_varlist_* node = funchead;
	while(node != NULL) {
		if(strcmp(node->func_name->u.func_name,op->u.func_name) == 0)//之前就加入到链表中
			break;
		node = node->next;
	}
	if(node != NULL) {
		return node->varlist;
		//printf("stack_offset:%d\n",stack_offset);
	}
	else if(node == NULL)
		return -1;
}
void MachineCodesDisplay(InterCodes root) {
	InterCodes codes = root;
	int read_number = read_Codes(codes);
	int write_number = write_Codes(codes);
	read_write_machinecode(read_number,write_number);
	int tag = 0;
	while(codes != NULL) {
		//printf("---------\n");
		if(codes->code->kind == FUNCTION) {//计算栈的偏移量
			param_no = 0;
			if(tag == 0) {
				//printf("------------\n");
				tag = 1;	
				initstack_codes(codes_root);
			}
			else
				initstack_codes(codes);
			//计算参数个数 
			InterCodes func = codes->next;
			struct func_varlist_* func_node = (struct func_varlist_*)malloc(sizeof(struct func_varlist_));
			func_node->func_name = codes->code->u.function.fun_name;
			func_node->next = NULL;
			int count = 0;
			while(func->code->kind == PARAM) {
				count++;
				func = func->next;
			}
			func_node->varlist = count;
			Insert_to_funcvarlist(func_node);
		}
		if(codes->code->kind == ARG) {//参数个数
			//InterCodes arg_node = codes;
			InterCodes node = codes;
			int arg = 0;
			while(node->code->kind != CALL) {
				node = node->next;
			}
			if(node->code->kind == CALL) {
				Operand function = node->code->u.call.func;
				arg = get_arglist(function);
				if(arg == -1) {
					printf("the arg number of function is not found!\n");
				}
			}
			//while(arg_node->code->kind == ARG) {
			while(codes->code->kind == ARG) {
				//printf("reach");
				//InterCode code = arg_node->code;
				InterCode code = codes->code;
				load_Operand(code->u.arg.arg_name,1);
				if(arg > 0 && arg <= 4) {//前四个参数保存在寄存器$a0-$a3
					printf("\tmove $a%d,$t1\n",arg-1);
					fprintf(mcode_fp,"\tmove $a%d,$t1\n",arg-1);
					arg--;	
				}
				else if(arg > 4) {//将参数保存在栈中
					//printf("\tlw $t1,%d($sp)\n");
					//fprintf(mcode_fp,"\tlw $t1,%d($sp)\n");
					//store_Operand(code->u.arg.arg_name,1);
					load_Operand(code->u.arg.arg_name,1);
					int offset = -4 - arg * 4;
					printf("\tsw $t1 %d($sp)\n",offset);
					fprintf(mcode_fp,"\tsw $t1 %d($sp)\n",offset);
					arg--;
				}
				codes = codes->next;
			}
			//continue;
		}
		MachineCodeDisplay(codes->code);
		codes = codes->next;
	}
}
