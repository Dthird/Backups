#ifndef SRC_H
#define SRC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ChildsNum 10//这是多叉树最多可以的分支数
struct NODE* root;
int wrong;//监测错误的产生
extern void CreateNode(char* data);
extern struct NODE* InsertNode(int line,char *data,struct NODE* cNODE[],int n);
extern void PrintTree(struct NODE* root);

struct NODE
{
	int line;//行号
	char data[20];
	char value[32];
	int cnChild;
	struct NODE *parent;
	struct NODE *child[ChildsNum];
};



#define MAXNUM 5
#define MAXSIZE 16384//pow(2,14)
typedef struct Type_* Type;
typedef struct FieldList_* FieldList;
typedef struct SymbolNodeVariable_* SymbolNodeVariable;
typedef struct SymbolNodeFunction_* SymbolNodeFunction;
typedef struct SymbolNodeStruct_* SymbolNodeStruct;

struct Type_
{
	enum { basic, array, structure } kind;
	union//几个变量公用一个内存位置
	{
		// 基本类型
		int basic;//int:1 float:2
		// 数组类型信息包括元素类型与数组大小构成
		struct { Type elem; int size; } array;
		// 结构体类型信息是一个链表
		FieldList structure;
	} u;
};
struct FieldList_
{
	char name[20];// 域的名字
	Type type;// 域的类型s
	FieldList tail;// 下一个域
};
struct SymbolNodeVariable_//变量(包括结构变量)符号表结点
//结构变量插入时需要先检查结构类型是否定义过
{
	char name[20];//变量名
	char stru_name[20];//类型名
	int number;
	Type type;
	SymbolNodeVariable next;//解决hash冲突
};
struct SymbolNodeFunction_//函数符号表结点
{
	Type returnType;//返回值类型
	char stru_name[20];//返回值为结构体类型时存储类型名
	char name[20];
	int ParameterNum;//形参个数
	SymbolNodeVariable parameters[MAXNUM];//形参类型数组
	SymbolNodeFunction next;
};
struct SymbolNodeStruct_//结构体类型符号表结点
{
	char name[20];//struct A
	Type type;
	SymbolNodeStruct next;
};
SymbolNodeVariable Vartable[MAXSIZE];//变量
SymbolNodeFunction Functable[MAXSIZE];//函数
SymbolNodeStruct Strutable[MAXSIZE];//结构体

extern unsigned int hash_pjw(char* name);
extern void VarTableInit();
extern void FuncTableInit();
extern void StructTableInit();
extern int InsertToVar(char* name,char* stru_name,Type type);
extern int InsertToFunc(Type returnType,char* stru_name,char* name,int num,SymbolNodeVariable list[]);
extern int InsertToStruct(char* name,Type type);
extern SymbolNodeVariable SearchVar(char* name);
extern SymbolNodeFunction SearchFunc(char* name);
extern SymbolNodeStruct SearchStru(char* name);
extern int isTypeEqual(Type type1,Type type2);
extern void ExtDef_(struct NODE* ExtDef);
extern Type Specifier_(struct NODE* Specifier,char* stru_name);
extern Type StructSpecifier_(struct NODE* StructSpecifier,char* stru_name);
extern FieldList DefList_(struct NODE* DefList,int flag);
extern FieldList Def_(struct NODE* Def,int flag);
extern FieldList DecList_(struct NODE* DecList,Type type,int flag,char* stru_name);
extern FieldList Dec_(struct NODE* Dec,Type type,int flag,char* stru_name);
extern FieldList VarDec_(struct NODE* VarDec,Type type,int flag,char* stru_name);
extern void ExtDecList_(struct NODE* ExtDecList,Type type,char* stru_name);
extern char* FunDec_(struct NODE* FunDec,Type type,char* stru_name);
extern void VarList_(struct NODE* VarList,SymbolNodeVariable para[],int number);
extern SymbolNodeVariable ParamDec_(struct NODE* ParamDec);
extern void CompSt_(struct NODE* CompSt,char* fun_name);
extern void StmtList_(struct NODE* StmtList,char* fun_name);
extern void Stmt_(struct NODE* Stmt,char* fun_name);
extern Type Exp_(struct NODE* Exp,char* stru_name);
extern void Args_(struct NODE* Args,SymbolNodeVariable para[],int number);


FILE *fp;
typedef struct Operand_* Operand;
typedef struct InterCode_* InterCode;
typedef struct InterCodes_* InterCodes;
struct Operand_ {
	enum { VARIABLE,CONSTANT,ADDRESS,MEM,TEMP,LABEL_OP,RELOP_OP,FUNC,SIZE} kind;
	union 
	{
		int var_no;//用于给变量命名(v1,v2...)
		int value;//常量值,大小(DEC)
		int temp_no;//用于给临时变量命名(t1,t2...)
		int label_no;//用于给行标号命名(label1,label2...)
		char mem_addr[10];
		char relop[5];//relop type
		char func_name[20];//函数名(定义和调用)或参数名
	} u;
};

struct InterCode_
{
	enum {ASSIGN,ADD,SUB,MUL,DIVI,LABEL,BLTZ,GOTO,RETURN_IC,DEC,FUNCTION,PARAM,ARG,CALL,READ,WRITE} kind;
	union 
	{
		struct { Operand right,left; } assign;//x = y
		struct { Operand result,op1,op2; } binop;//x = y + z
		struct { Operand label; } label;//LABEL label4
		struct { Operand op1,relop,op2,label; } bltz;//IF v1 > t2 GOTO label1
		struct { Operand label; } goto_;//GOTO label3
		struct { Operand return_place; } return_;//RETURN t8
		struct { Operand place,size; } dec;//DEC v2 8(数组/结构体)
		struct { Operand fun_name; } function;//FUNCTION main:
		struct { Operand param_name; } param;//PARAM t1(定义)
		struct { Operand arg_name; } arg;//ARG t1(调用)
		struct { Operand place,func; } call;//t5 = CALL func
		struct { Operand place; } read;//READ t1 
		struct { Operand place; } write;//WRITE t6		
	} u;
};
struct InterCodes_ 
{ 
	InterCode code; 
	InterCodes prev, next; 
};

extern Operand create_temp();
extern Operand create_label();
extern Operand create_variable();
extern Operand create_constant(int value);
extern Operand create_addr(int kind,int number);
extern Operand create_mem(int kind,int number);
extern Operand create_relop(char* name);
extern Operand create_func(char* func_name);
extern Operand create_size(int size);
extern InterCodes insert_to_intercodes(InterCodes codes1,InterCode code);
extern InterCodes merge(InterCodes codes1,InterCodes codes2);
extern InterCodes translate_ExtDef(struct NODE* ExtDef);
extern InterCodes translate_DefList(struct NODE* DefList,char* func_name);
extern InterCodes translate_Def(struct NODE* Def,char* func_name);
extern InterCodes translate_DecList(struct NODE* DecList,char* func_name);
extern InterCodes translate_Dec(struct NODE* Dec,char* func_name);
extern InterCodes translate_VarDec(struct NODE* VarDec,int tag,Operand* op,char* func_name);
extern InterCodes translate_FunDec(struct NODE* FunDec,char** func_name);
extern InterCodes translate_VarList(struct NODE* VarList,char* func_name);
extern InterCodes translate_ParamDec(struct NODE* ParamDec,char* func_name);
extern InterCodes translate_CompSt(struct NODE* CompSt,char* func_name);
extern InterCodes translate_StmtList(struct NODE* StmtList,char* func_name);
extern InterCodes translate_Stmt(struct NODE* Stmt,char* func_name);
extern InterCodes translate_Exp(struct NODE* Exp,Operand* op,char* func_name);
extern InterCodes translate_Args(struct NODE* Args,Operand list[],int number,char* func_name);
extern InterCodes translate_Cond(struct NODE* Exp,Operand label_true,Operand label_false,char* func_name);
extern void InterCodesDisplay(InterCodes root);
extern void InterCodeDisplay(InterCode code);
extern void OperandDisplay(Operand op);

struct InterCodes_* codes_root;
struct varoffset_* stackhead;
struct varoffset_* last;
FILE *mcode_fp;
struct varoffset_ {
	Operand var;
	int offset;
	struct varoffset_* next;
};
struct func_varlist_ {
	Operand func_name;
	int varlist;
	struct func_varlist_* next;
};
extern int is_read_write_Code(InterCode code);
extern int read_Codes(InterCodes root);
extern int write_Codes(InterCodes root);
extern void read_write_machinecode(int read,int write);
extern void load_Operand(Operand op,int number);
extern void store_Operand(Operand op,int number);
extern int Operand_equal(Operand op1,Operand op2);
extern void initstack_operand(Operand op,int size);
extern void initstack_code(InterCode code);
extern void initstack_codes(InterCodes codes);
extern void MachineCodeDisplay(InterCode code);
extern void MachineCodesDisplay(InterCodes root);
extern void Insert_to_funcvarlist(struct func_varlist_* func_node);
extern int get_arglist(Operand op);
#endif
