int inc(int x)
{
return x + 1;
}
int main()
 {
 int a = 10;
 a = inc(a);
 write(a);
 return 0;
}
