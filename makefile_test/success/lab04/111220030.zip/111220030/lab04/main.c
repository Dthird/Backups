#include "src.h"
#include "syntax.tab.h"

extern struct NODE* root;
extern struct InterCodes_* codes_root;
extern int wrong;//监测错误的产生
extern int yylineno;
extern FILE *fp;
void CreateNode(char *data)
{
	yylval.node = (struct NODE *)malloc(sizeof(struct NODE));
	strcpy(yylval.node->data,data);
	yylval.node->line = -1;
	yylval.node->cnChild = 1;
	yylval.node->parent = NULL;
	memset(yylval.node->child,0,ChildsNum); 
}
/*
void CreateNode(char *data)
{
	yylval = (struct NODE *)malloc(sizeof(struct NODE));
	strcpy(yylval->data,data);
	yylval->line = -1;
	yylval->cnChild = 1;
	yylval->parent = NULL;
	memset(yylval->child,0,ChildsNum); 
}
*/
struct NODE* InsertNode(int line,char *data,struct NODE* cNODE[],int n)//向一个多叉树节点插入一个孩子节点
{
	struct NODE* ppNode = (struct NODE*)malloc(sizeof(struct NODE));
	ppNode->line = line;
	strcpy(ppNode->data,data);
	ppNode->cnChild = n;
	ppNode->parent = NULL;
	int i;
	for(i = 0;i < n;i++) {
		if(cNODE[i] != NULL) {
			cNODE[i]->parent = ppNode;
			ppNode->child[i] = cNODE[i];
		}
		else
			ppNode->child[i] = NULL;
        }
	return ppNode;
}

void PrintTree(struct NODE* root)//递归格式化先序打印多叉树
{ 
	if (root == NULL)
	{
        	return;
    	}
    	static depth = 0;
    	int i;
	for (i=0;i<depth;i++)
   	{
		printf(" ");
   	}
   	if(root->line >= 0)
		printf("%s (%d)\n",root->data,root->line);
  	else if(root->line == -1) {//终结符
		if(strcmp(root->data,"INT") == 0)//INT
			printf("%s %d\n","INT:",atoi(root->value));
		else if(strcmp(root->data,"FLOAT") == 0)//FLOAT
			printf("%s %f\n","FLOAT:",atof(root->value));
		else if(strcmp(root->data,"TYPE") == 0)//TYPE
			printf("%s %s\n","TYPE:",root->value);
		else if(strcmp(root->data,"ID") == 0)//ID
			printf("%s %s\n","ID:",root->value);
		else
			printf("%s\n",root->data);
   	}
    	for (i=0;i < root->cnChild;i++)
    	{
        	depth++;
       		PrintTree(root->child[i]);
        	depth--;
    	}
}

void TraversalTree(struct NODE* root)
{
	if(root == NULL || root->line == -1)
    	{
        	return;
    	}
	int i;
    	for(i=0;i < root->cnChild;i++)
    	{
		if(root->child[i] != NULL && root->child[i]->line != -1) {
			if(strcmp(root->child[i]->data,"ExtDef") == 0) {
				//printf("-----%s----\n",root->child[i]->data);		
				ExtDef_(root->child[i]);
			}
			else if(root->child[i]->line != -1)
				TraversalTree(root->child[i]);
		}
    	}
}

InterCodes Traversal_for_InterCodes(struct NODE* root) {
	if(root == NULL || root->line == -1)
    	{
        	return;
    	}
	InterCodes codes = NULL;
	InterCodes codes0 = NULL;
	InterCodes codes1 = NULL;
	int i;
    	for(i=0;i < root->cnChild;i++)
    	{
		if(root->child[i] != NULL && root->child[i]->line != -1) {
		if(strcmp(root->child[i]->data,"ExtDef") == 0) {
			//printf("-----%s----\n",root->child[i]->data);		
			codes0 = translate_ExtDef(root->child[i]);
			codes = merge(codes,codes0);
		}
		else if(root->child[i]->line != -1)
        		codes1 = Traversal_for_InterCodes(root->child[i]);
			codes = merge(codes,codes1);
		}
    	}
	return codes;
}


int main(int argc, char** argv)
{
	if (argc != 3) 
	{
		printf("parameter input error!\n");
		return 1;
	}
	//int i;
	//for(i = 1;i < argc;i++) {//测试多个文件
		FILE* f = fopen(argv[1], "r");
		if (!f)
		{
			perror(argv[1]);
			return 1;
		}
		root = NULL;//初始化
		wrong = 0;
		yylineno = 1;//每次打开一个文件，将行数初始化为1
		yyrestart(f);
		yyparse();
		if(wrong == 0 && root !=NULL) {//测试代码正确，输出语法树
			//PrintTree(root);
			VarTableInit();
			FuncTableInit();
			StructTableInit();
			TraversalTree(root);
			InterCodes codes = Traversal_for_InterCodes(root);
			codes_root = codes;
			/*fp = fopen(argv[2],"w"); 
			//optimize(codes);
			InterCodesDisplay(codes);
			fclose(fp);*/
			mcode_fp = fopen(argv[2],"w");
			MachineCodesDisplay(codes);
			fclose(mcode_fp);
		}
		fclose(f);
	//}
	return 0;
}

