int fact(int a,int b,int c,int d,int e)
{
return a+b+c+d+e;
}
int main()
{
int i1 = 1;
int i2 = 2;
int i3 = 3;
int i4 = 4;
int i5 = 5;
int t;
t = fact(i1,i2,i3,i4,i5);
write(t);
return 0;
}

