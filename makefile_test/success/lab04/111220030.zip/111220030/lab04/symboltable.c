#include "src.h"

unsigned int hash_pjw(char* name)//val = 0 - (pow(2,14)-1),hashnum = pow(2,14)
{
	unsigned int val = 0, i;
	for (; *name; ++name)
	{
		val = (val << 2) + *name;//val * 4 + *name
		if (i = val & ~0x3fff)//val > pow(2,14) - 1
//val & 0xc000 > 0(val > 0x3fff) 
			val = (val ^ (i >> 12)) & 0x3fff;//val < 0x3fff
	}
	return val;
}


void VarTableInit()
{
	int i;
	for(i = 0;i < MAXSIZE;i++)
		Vartable[i] = NULL;
}
void FuncTableInit()
{
	int i;
	for(i = 0;i < MAXSIZE;i++)
		Functable[i] = NULL;
	Type type = (Type)malloc(sizeof(struct Type_));
	type->kind = basic;
	type->u.basic = 1;//int
	SymbolNodeVariable list[1];
	list[0] = (SymbolNodeVariable)malloc(sizeof(struct SymbolNodeVariable_));
	list[0]->type = type;
	InsertToFunc(type,NULL,"read",0,NULL);
	InsertToFunc(type,NULL,"write",1,list);
}
void StructTableInit()
{
	int i;
	for(i = 0;i < MAXSIZE;i++)
		Strutable[i] = NULL;
}

int InsertToVar(char* name,char* stru_name,Type type)//普通变量，函数形参，结构体变量
{
	SymbolNodeVariable v = (SymbolNodeVariable)malloc(sizeof(struct SymbolNodeVariable_));
	strcpy(v->name,name);
	if(stru_name == NULL)
		strcpy(v->stru_name,"");
	else
		strcpy(v->stru_name,stru_name);		
	v->number = -1;	
	v->type = type;
	v->next = NULL;
	unsigned int number;
	number = hash_pjw(v->name);
	if(Strutable[number] != NULL) {
		SymbolNodeStruct head = Strutable[number];		
		while(head != NULL) {
			if(strcmp(head->name,name) == 0)
				return 0;//已存在(之前定义过)
			head = head->next;
		}
	}
	if(Vartable[number] != NULL) {//产生冲突，将符号插入该数组元素下的链表中
		SymbolNodeVariable head = Vartable[number];		
		while(head != NULL) {
			if(strcmp(head->name,name) == 0)
				return 0;//已存在(之前定义过)
			head = head->next;
		}
		v->next = Vartable[number];
		Vartable[number] = v;
		return 1;//正确插入
	}
	if(Vartable[number] == NULL) {//该位置没有被占用
		Vartable[number] = v;
		return 1;
	}
}
int InsertToFunc(Type returnType,char* stru_name,char* name,int num,SymbolNodeVariable list[])
{
	SymbolNodeFunction f = (SymbolNodeFunction)malloc(sizeof(struct SymbolNodeFunction_));
	f->returnType = returnType;
	if(stru_name == NULL)
		strcpy(f->stru_name,"");
	else
		strcpy(f->stru_name,stru_name);		
	strcpy(f->name,name);
	f->ParameterNum = num;
	int i;
	for(i = 0;i < num;i++) {
		f->parameters[i] = list[i];
	}
	f->next = NULL;
	unsigned int number;
	number = hash_pjw(f->name);
	if(Functable[number] == NULL) {//该位置没有被占用
		Functable[number] = f;
		return 1;
	}
	else {//产生冲突，将符号插入该数组元素下的链表中
		SymbolNodeFunction head = Functable[number];		
		while(head != NULL) {
			if(strcmp(head->name,name) == 0)
				return 0;//已存在(之前定义过)
			head = head->next;
		}
		f->next = Functable[number];
		Functable[number] = f;
		return 1;//正确插入
	}
}

int InsertToStruct(char* name,Type type)
{
	SymbolNodeStruct s = (SymbolNodeStruct)malloc(sizeof(struct SymbolNodeStruct_));
	if(name == NULL || strcmp(name,"") == 0) {//匿名结构体
		return 1;
	}	
	strcpy(s->name,name);
	s->type = type;
	s->next = NULL;
	unsigned int number;
	number = hash_pjw(s->name);
	//printf("number:%d\n",number);
	if(Vartable[number] != NULL) {
		SymbolNodeVariable head = Vartable[number];		
		while(head != NULL) {
			if(strcmp(head->name,name) == 0)
				return 0;//已存在(之前定义过)
			head = head->next;
		}
	}
	if(Strutable[number] != NULL) {//产生冲突，将符号插入该数组元素下的链表中
		SymbolNodeStruct head = Strutable[number];		
		while(head != NULL) {
			if(strcmp(head->name,name) == 0)
				return 0;//已存在(之前定义过)
			head = head->next;
		}
		s->next = Strutable[number];
		Strutable[number] = s;
		return 1;//正确插入
	}
	if(Strutable[number] == NULL) {//该位置没有被占用
		Strutable[number] = s;
		return 1;
	}
}

SymbolNodeVariable SearchVar(char* name)
{
	unsigned int number;
	number = hash_pjw(name);
	SymbolNodeVariable head = Vartable[number];
	while(head != NULL) {
		if(strcmp(head->name,name) == 0) {//定义过
			return head;
		}
		head = head->next;
	}
	return NULL;//符号表中没有该变量,未定义
}
SymbolNodeFunction SearchFunc(char* name)
{
	unsigned int number;
	number = hash_pjw(name);
	SymbolNodeFunction head = Functable[number];		
	while(head != NULL) {
		if(strcmp(head->name,name) == 0) {//定义过
			return head;
		}
		head = head->next;
	}
	return NULL;//符号表中没有该函数,未定义
}
SymbolNodeStruct SearchStru(char* name)
{
	unsigned int number;
	number = hash_pjw(name);
	SymbolNodeStruct head = Strutable[number];		
	while(head != NULL) {
		if(strcmp(head->name,name) == 0) {//定义过
			return head;
		}
		head = head->next;
	}
	return NULL;//符号表中没有该结构,未定义
}

int isTypeEqual(Type type1,Type type2)
{
	if(type1 == NULL || type2 == NULL)
		return 0;
	if(type1->kind == basic && type2->kind == basic)//基本类型(int/float)
	{
		//printf("basic type\n");
		if(type1->u.basic == type2->u.basic)
			return 1;
		else
			return 0;
	}
	if(type1->kind == array && type2->kind == array)//数组只需考虑维度和元素类型
	{
		type1 = type1->u.array.elem;
		type2 = type2->u.array.elem;
		while(type1->kind == type2->kind) {
			if(type1->kind == basic) {
				if(type1->u.basic == type2->u.basic)
					return 1;
				else
					return 0;
			}
			else {//type1->kind == array
				type1 = type1->u.array.elem;
				type2 = type2->u.array.elem;
			}
		}
		return 0;
	}
	if(type1->kind == structure && type2->kind == structure)//结构体各元素类型相同
	{
		//printf("two struct compare\n");
		FieldList head1 = type1->u.structure;
		FieldList head2 = type2->u.structure;
		while(head1 != NULL && head2 != NULL) {
			//printf("field compare\n");
			if(isTypeEqual(head1->type,head2->type) == 1) {
				head1 = head1->tail;
				head2 = head2->tail;
			}
			else//两个结构体某元素类型不同
				return 0;
		}
		if(head1 == NULL && head2 == NULL) {
			return 1;
		}
		else {//两个结构体元素个数不同
			return 0;
		}
	}
	return 0;
}

void ExtDef_(struct NODE* ExtDef)
{
	//printf("-------ExtDef--------\n");
	Type type = (Type)malloc(sizeof(struct Type_));
	char* name = ExtDef->child[0]->data;
	char stru_name[20];
	if(strcmp(name,"Specifier") == 0) {
		type = Specifier_(ExtDef->child[0],stru_name);
		//printf("know type\n");
		//printf("ExtDef->child[1]->data:%s\nExtDef->child[2]->data:%s\n",ExtDef->child[1]->data,ExtDef->child[2]->data);
		if(strcmp(ExtDef->child[1]->data,"ExtDecList") == 0) {
			ExtDecList_(ExtDef->child[1],type,stru_name);
			//printf("ExtDecList END!\n");
			//if(strcmp(ExtDef->child[2]->data,"SEMI") == 0)
		}
		else if(strcmp(ExtDef->child[1]->data,"SEMI") == 0) {}
		else if(strcmp(ExtDef->child[1]->data,"FunDec") == 0) {
			char* fun_name = NULL;
			fun_name = FunDec_(ExtDef->child[1],type,stru_name);
			if(strcmp(ExtDef->child[2]->data,"CompSt") == 0)
				CompSt_(ExtDef->child[2],fun_name);
		}
	}
	//printf("ExtDef END!\n");
}

Type Specifier_(struct NODE* Specifier,char* stru_name)
{
	//printf("-------Speciifier--------\n");
	Type type = (Type)malloc(sizeof(struct Type_));
	char* name = Specifier->child[0]->data;
	if(strcmp(name,"TYPE") == 0) {//基本类型
		//printf("type\n");
		type->kind = basic;
		//type->u.basic = Specifier->child[0]->value;
		if(strcmp(Specifier->child[0]->value,"int") == 0)
			type->u.basic = 1;
		else if(strcmp(Specifier->child[0]->value,"float") == 0)
			type->u.basic = 2;
	}
	else if(strcmp(name,"StructSpecifier") == 0) {//结构体类型
		type = StructSpecifier_(Specifier->child[0],stru_name);
	}
	//printf("Speciifier END!\n");
	return type;
}
Type StructSpecifier_(struct NODE* StructSpecifier,char* stru_name)
{
	//printf("-------StructSpecifier--------\n");
	Type type = (Type)malloc(sizeof(struct Type_));
	type->kind = structure;
	//char* name = StructSpecifier->child[1]->data;
	//if(strcmp(StructSpecifier->child[0]->data,"STRUCT") == 0) {
	if(StructSpecifier->child[1] == NULL || strcmp(StructSpecifier->child[1]->data,"OptTag") == 0) {//定义
		if(StructSpecifier->child[1] == NULL)
			strcpy(stru_name,"");
		else if(strcmp(StructSpecifier->child[1]->child[0]->data,"ID") == 0)
			strcpy(stru_name,StructSpecifier->child[1]->child[0]->value);
		if(StructSpecifier->child[3] != NULL) {
			if(strcmp(StructSpecifier->child[3]->data,"DefList") == 0) {
				type->u.structure = DefList_(StructSpecifier->child[3],1);//1表示DefList出现在StructSpecifier 产生式的右边
			}
		}
		//printf("type->u.structure->name:%s\n",type->u.structure->name);
		//printf("type->u.structure->tail->name:%s\n",type->u.structure->tail->name);
		//printf("stru_name:%s\n",stru_name);
		if(InsertToStruct(stru_name,type) == 0) {//已存在
			printf("Error type 16 at line %d: Duplicate name \"%s\"\n", StructSpecifier->child[1]->line, stru_name);
                        return NULL;
		}
		return type;
	}
	else if(strcmp(StructSpecifier->child[1]->data,"Tag") == 0) {//直接使用，需要查符号表
		if(strcmp(StructSpecifier->child[1]->child[0]->data,"ID") == 0)
			strcpy(stru_name,StructSpecifier->child[1]->child[0]->value);		
		//printf("stru_name:%s\n",stru_name);	
		SymbolNodeStruct stru = SearchStru(stru_name);
		if (stru == NULL) {
	               	printf("Error type 17 at line %d: Undefined struct \"%s\"\n", StructSpecifier->line, stru_name);
	               	return NULL;
		}
		else{
           		type->u.structure = stru->type->u.structure;
		}
		//printf("type->u.structure->name:%s\n",type->u.structure->name);
		return type;
	}
	//printf("StructSpecifier END!\n");
	//}
}
FieldList DefList_(struct NODE* DefList,int flag)//CompSt 以及 StructSpecifier 产生式的右边,结构体和非结构体不同
{
	//printf("-------DefList--------\n");
	FieldList head = (FieldList)malloc(sizeof(struct FieldList_));
	FieldList pre_head = (FieldList)malloc(sizeof(struct FieldList_));
	//printf("~~~~~~~~jinru~~~~~~~~~\n");
	char* name = DefList->child[0]->data;
	if(strcmp(name,"Def") == 0) {
		head = Def_(DefList->child[0],flag);
		//printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		if(DefList->child[1] != NULL) {
			char* name1 = DefList->child[1]->data;
			//printf("data:%s\n",DefList->child[1]->data);
			if(strcmp(name1,"DefList") == 0) {
				pre_head = DefList_(DefList->child[1],flag);
				head->tail = pre_head;
			}
		}
	}
	//printf("DefList END!\n");
	//printf("~~~~~~~~chulai~~~~~~~~\n");
	return head;
}
FieldList Def_(struct NODE* Def,int flag)
{
	//printf("-------Def--------\n");
	FieldList head = (FieldList)malloc(sizeof(struct FieldList_));
	char* name = Def->child[0]->data;
	char stru_name[20];
	if(strcmp(name,"Specifier") == 0) {
		Type type = Specifier_(Def->child[0],stru_name);
		if(type != NULL) {
			char* name1 = Def->child[1]->data;
			if(strcmp(name1,"DecList") == 0)
				head = DecList_(Def->child[1],type,flag,stru_name);
		}
	}
	//printf("Def END!\n");
	return head;
}
FieldList DecList_(struct NODE* DecList,Type type,int flag,char* stru_name)
{
	//printf("------DecList-------\n");
	FieldList head = (FieldList)malloc(sizeof(struct FieldList_));
	FieldList pre_head = (FieldList)malloc(sizeof(struct FieldList_));
	char* name = DecList->child[0]->data;
	if(strcmp(name,"Dec") == 0) {
		head = Dec_(DecList->child[0],type,flag,stru_name);
		if(DecList->child[1] != NULL) {
			//printf("DecList->child[2]->data:%s\n",DecList->child[2]->data);
			char* name1 = DecList->child[2]->data;
			if(strcmp(name1,"DecList") == 0) {
				pre_head = DecList_(DecList->child[2],type,flag,stru_name);
				head->tail = pre_head;
				//printf("head->name:%s\n",head->name);
				//printf("pre_head->name:%s\n",pre_head->name);
			}
		}
	}
	//printf("DecList END!\n");
	return head;
}
FieldList Dec_(struct NODE* Dec,Type type,int flag,char* stru_name)
{
	//printf("------Dec-------\n");
	FieldList head = (FieldList)malloc(sizeof(struct FieldList_));
	char* name = Dec->child[0]->data;
	if(strcmp(name,"VarDec") == 0) {
		head = VarDec_(Dec->child[0],type,flag,stru_name);
		//printf("VarDec END!\n");
		//printf("data:%s\n",Dec->child[1]->data);		
		if(Dec->child[1] != NULL) {
			if(flag == 1) {//结构体中不允许初始化
				printf("Error type 15 at line %d: Assignment in STRUCT\n",Dec->line);
				//return;
			}
			if(head->type->kind == array)
			printf("Error type 6 at line %d: The left-hand side of an assignment must be basic type or struct\n",Dec->line);
			else {			
				char* name1 = Dec->child[2]->data;			
				//printf("data:%s\n",Dec->child[2]->data);
				if(strcmp(name1,"Exp") == 0) {
					//printf("go to exp\n");
					char stru_name1[20];
					Type type_ = Exp_(Dec->child[2],stru_name1);
					//printf("Exp END!\n");
					if(strcmp(stru_name,"") != 0 && strcmp(stru_name1,"") != 0 && strcmp(stru_name,stru_name1) == 0){}
					else if(isTypeEqual(type,type_) == 1){}
					else printf("Error type 5 at line %d: Type mismatched\n",Dec->line);
					//printf("======\n");
				}
			}
		}
	}
	//printf("Dec END!\n");
	return head;
}
FieldList VarDec_(struct NODE* VarDec,Type type,int flag,char* stru_name)
{
	//printf("-------VarDec--------\n");
	FieldList head = (FieldList)malloc(sizeof(struct FieldList_));
	char* name = VarDec->child[0]->data;
	if(strcmp(name,"ID") == 0) {//ID的内容为变量名
		//printf("VarDec->child[0]->value:%s\n",VarDec->child[0]->value);
		//printf("ID:%s  type:%d\n",VarDec->child[0]->value,type->u.basic);
		if(InsertToVar(VarDec->child[0]->value,stru_name,type) == 0) {//已定义过
			if(flag != 1)
				printf("Error type 3 at line %d: Redefined variable \"%s\"\n", VarDec->line, VarDec->child[0]->value);
			else if(flag == 1) {
				printf("Error type 15 at line %d: Redefined field \"%s\"\n", VarDec->line, VarDec->child[0]->value);
			}		
		}
		//printf("insert\n");
		strcpy(head->name,VarDec->child[0]->value);
		head->type = type;
		head->tail = NULL;
	}
	else {//数组 VarDec LB INT RB
		Type out_type = (Type)malloc(sizeof(struct Type_));//数组外层类型
        	out_type->kind = array;
        	out_type->u.array.size = atoi(VarDec->child[2]->value);//INT
        	out_type->u.array.elem = type;//type为数组内层类型
        	head = VarDec_(VarDec->child[0],out_type,flag,stru_name);
	}
	return head;
}
void ExtDecList_(struct NODE* ExtDecList,Type type,char* stru_name)
{
	//printf("-------ExtDecList--------\n");
	char* name = ExtDecList->child[0]->data;
	if(strcmp(name,"VarDec") == 0) {
		VarDec_(ExtDecList->child[0],type,0,stru_name);
		//printf("VarDec END!\n");
		if(ExtDecList->child[1] != NULL) {
			char* name1 = ExtDecList->child[2]->data;
			if(strcmp(name1,"ExtDecList") == 0)
				ExtDecList_(ExtDecList->child[2],type,stru_name);
		}
	}
}
char* FunDec_(struct NODE* FunDec,Type returnType,char* stru_name)//函数头
{
	//printf("-------FunDec--------\n");
	char* name = FunDec->child[0]->data;
	char* fun_name;
	if(strcmp(name,"ID") == 0) {
		fun_name = FunDec->child[0]->value;
		//printf("fun_name:%s\n",fun_name);
		char* name1 = FunDec->child[2]->data;
		int num;
		SymbolNodeVariable parameters[MAXNUM];
		if(strcmp(name1,"VarList") == 0) {//函数形参
			num = 1;
			struct NODE* node = FunDec->child[2];
			while(node->cnChild == 3) {
				num++;
				node = node->child[2];
			}
			//printf("num:%d\n",num);
			int i;
			for(i = 0;i < num;i++)
				parameters[i] = NULL;		
			VarList_(FunDec->child[2],parameters,0);
		}
		else {//无形参
			num = 0;
		}
		if(InsertToFunc(returnType,stru_name,fun_name,num,parameters) == 0) {//已定义过
			printf("Error type 4 at line %d: Redefined function \"%s\"\n", FunDec->line, fun_name);
		}		
	}
	//printf("FunDec END!\n");
	return fun_name;
}
void VarList_(struct NODE* VarList,SymbolNodeVariable para[],int number)//形参列表
{
	//printf("-------VarList--------\n");
	char* name = VarList->child[0]->data;
	//printf("VarList->child[0]->data:%s\nVarList->child[1]->data:%s\nVarList->child[2]->data:%s\n",VarList->child[0]->data,VarList->child[1]->data,VarList->child[2]->data);
	if(strcmp(name,"ParamDec") == 0) {
		//printf("para_number:%d\n",number);
		para[number] = ParamDec_(VarList->child[0]);
		if(VarList->child[1] != NULL) {
			char* name1 = VarList->child[2]->data;
			if(strcmp(name1,"VarList") == 0)
				VarList_(VarList->child[2],para,number + 1);
		}
	}
	//printf("VarList END!\n");
}
SymbolNodeVariable ParamDec_(struct NODE* ParamDec)//一个形参的定义
{
	//printf("-------ParamDec--------\n");
	SymbolNodeVariable var = (SymbolNodeVariable)malloc(sizeof(struct SymbolNodeVariable_));
	Type type = (Type)malloc(sizeof(struct Type_));
	char* name = ParamDec->child[0]->data;
	char stru_name[20];
	if(strcmp(name,"Specifier") == 0) {
		type = Specifier_(ParamDec->child[0],stru_name);
		char* name1 = ParamDec->child[1]->data;
		if(strcmp(name1,"VarDec") == 0) {
			FieldList field = VarDec_(ParamDec->child[1],type,0,stru_name);
			strcpy(var->name,field->name);
			var->type = field->type;
			var->number = -1;
		}
	}
	//printf("ParamDec END!\n");
	return var;
}
void CompSt_(struct NODE* CompSt,char* fun_name)//函数体 LC DefList StmtList RC
{
	//printf("-------CompSt--------\n");
	//printf("CompSt->child[1]->data:%s\n",CompSt->child[1]->data);
	if(CompSt->child[1] != NULL) {
		char* name = CompSt->child[1]->data;
		if(strcmp(name,"DefList") == 0) {
			DefList_(CompSt->child[1],2);//DefList出现在CompSt的右边，可以初始化
		}
	}
	if(CompSt->child[2] != NULL) {
		char* name1 = CompSt->child[2]->data;
		if(strcmp(name1,"StmtList") == 0) {
			StmtList_(CompSt->child[2],fun_name);
		}
	}
	//printf("CompSt END!\n");
}
void StmtList_(struct NODE* StmtList,char* fun_name)
{
	//printf("-------StmtList---------\n");
	char* name = StmtList->child[0]->data;
	if(strcmp(name,"Stmt") == 0) {
		Stmt_(StmtList->child[0],fun_name);
		if(StmtList->child[1] != NULL) {
			char* name1 = StmtList->child[1]->data;
			if(strcmp(name1,"StmtList") == 0)
				StmtList_(StmtList->child[1],fun_name);
		}
	}
	//printf("StmtList END!\n");
}
void Stmt_(struct NODE* Stmt,char* fun_name)
{
	//printf("-------Stmt---------\n");
	char* name = Stmt->child[0]->data;
	if(strcmp(name,"Exp") == 0) {
		//printf("Exp SEMI\n");
		Exp_(Stmt->child[0],NULL);
	}
	else if(strcmp(name,"CompSt") == 0) {
		CompSt_(Stmt->child[0],fun_name);
	}
	else if(strcmp(name,"RETURN") == 0) {//函数返回语句，需要比较与函数返回类型是否一致
		Type type = (Type)malloc(sizeof(struct Type_));		
		char* name1 = Stmt->child[1]->data;
		if(strcmp(name1,"Exp") == 0) {
			char stru_name[20];
			//printf("Stmt->child[1]->data:%s\n",Stmt->child[1]->data);
			type = Exp_(Stmt->child[1],stru_name);//返回的表达式的类型
			SymbolNodeFunction func = SearchFunc(fun_name);
			if(strcmp(func->stru_name,"") != 0 && strcmp(stru_name,"") != 0 && strcmp(func->stru_name,stru_name) == 0){}
			else if(isTypeEqual(func->returnType,type) == 1){}
			else{//类型不同
				//printf("fun_name:%s\n",fun_name);
				//printf("func->returnType->kind:%d\nType->kind:%d\n",func->returnType->kind,type->kind);
					printf("Error type 8 at line %d: The return type mismatched\n", Stmt->child[1]->line);
			}
		}
	}
	else if(strcmp(name,"IF") == 0) {//if 语句
		char* name1 = Stmt->child[2]->data;
		if(strcmp(name1,"Exp") == 0) {
			//printf("Stmt->child[2]->child[0]->data:%s\nStmt->child[2]->child[1]->data:%s\nStmt->child[2]->child[2]->data:%s\n",Stmt->child[2]->child[0]->data,Stmt->child[2]->child[1]->data,Stmt->child[2]->child[2]->data);
			Exp_(Stmt->child[2],NULL);
			//printf("exp out\n");
			char* name2 = Stmt->child[4]->data;
			if(strcmp(name2,"Stmt") == 0) {
				Stmt_(Stmt->child[4],fun_name);
				if(Stmt->child[5] != NULL) {//带 else
					Stmt_(Stmt->child[6],fun_name);
				}
			}
		}
	}
	else if(strcmp(name,"WHILE") == 0) {//while 语句
		char* name1 = Stmt->child[2]->data;
		if(strcmp(name1,"Exp") == 0) {
			Exp_(Stmt->child[2],NULL);
			char* name2 = Stmt->child[4]->data;
			if(strcmp(name2,"Stmt") == 0) {
				Stmt_(Stmt->child[4],fun_name);
			}
		}
	}
	//printf("Stmt END!\n");
}
Type Exp_(struct NODE* Exp,char* stru_name)
{
	//printf("-------Exp---------\n");
	Type type = (Type)malloc(sizeof(struct Type_));
	char* name = Exp->child[0]->data;
	//printf("name:%s\n",name);
	if(strcmp(name,"Exp") == 0) {//二元运算符，数组/结构体访问
		//printf("Exp->child[0]:%s\n",Exp->child[0]->data);
		//printf("Exp->child[1]:%s\n",Exp->child[1]->data);
		//printf("Exp->child[2]:%s\n",Exp->child[2]->data);
		Type type1 = (Type)malloc(sizeof(struct Type_));
		Type type2 = (Type)malloc(sizeof(struct Type_));
		if(strcmp(Exp->child[2]->data,"Exp") == 0 && Exp->child[3] == NULL) {//二元运算符
			char stru_name1[20];
			char stru_name2[20];						
			type1 = Exp_(Exp->child[0],stru_name1);
			type2 = Exp_(Exp->child[2],stru_name2);
			if(type1 == NULL || type2 == NULL) {			
				return NULL;
			}
			char* name1 = Exp->child[1]->data;	
			if(strcmp(name1,"ASSIGNOP") == 0) {//考虑赋值的左值问题 Exp = Exp
				//printf("Exp = Exp\n");
				//printf("Exp->child[0]->data:%s\n",Exp->child[0]->data);
				struct NODE* LeftExp = Exp->child[0];
				int istrue = 0;
				int num = LeftExp->cnChild;
				if(num == 1 && strcmp(LeftExp->child[0]->data,"ID") == 0) {
					if(type1->kind == basic || type1->kind == structure)
						istrue = 1;
				}//ID
				else if(num == 3 && strcmp(LeftExp->child[1]->data,"DOT") == 0) {
					if(type1->kind == basic || type1->kind == structure)
						istrue = 1;
				}//Exp.ID
				else if(num == 3 && strcmp(LeftExp->child[0]->data,"LP") == 0) {
					if(type1->kind == basic || type1->kind == structure)
						istrue = 1;
				}//(Exp)
				else if(num == 4 && strcmp(LeftExp->child[1]->data,"LB") == 0) {
					if(type1->kind == basic || type1->kind == structure)
						istrue = 1;
				}//Exp[Exp]
				//if(type1->kind == basic){}
				//else if(type1->kind == structure){}
				if(istrue == 0) {//赋值号左边的表达式只有右值
					printf("Error type 6 at line %d: The left-hand side of an assignment must be basic type or struct\n",Exp->line);
					return NULL;
				}
				//printf("type compare\n");
				//printf("type1->kind:%d\n",type1->kind);
				//printf("type2->kind:%d\n",type2->kind);
				//printf("type1->u.structure->name:%s\n",type1->u.structure->name);
				//printf("type1->u.structure->tail->name:%s\n",type1->u.structure->tail->name);
				//printf("type2->u.structure->name:%s\n",type2->u.structure->name);				
				//printf("type2->u.structure->tail->name:%s\n",type2->u.structure->tail->name);
				
				if(strcmp(stru_name1,"") != 0 && strcmp(stru_name2,"") != 0 && strcmp(stru_name1,stru_name2) == 0){}
				else if(isTypeEqual(type1,type2) == 1){}
				else{//赋值号两边类型不同
					printf("Error type 5 at line %d: Type mismatched\n",Exp->line);
					return NULL;
				}
			}
			if(strcmp(name1,"AND") == 0 || strcmp(name1,"OR") == 0) {//与和或运算，只有INT类型的值才能作此运算
				if(type1->kind == basic && type1->u.basic == 1 
					&& type2->kind == basic && type2->u.basic == 1) {//INT			
				}
				else {
					printf("Error type 7 at line %d: Operands type mismatched\n",Exp->child[0]->line);
					return NULL;
				}
			}
			if(strcmp(name1,"RELOP") == 0 || strcmp(name1,"PLUS") == 0 || strcmp(name1,"MINUS") == 0
				 || strcmp(name1,"STAR") == 0 || strcmp(name1,"DIV") == 0) {//比较和四则运算，INT/FLOAT类型的值可以作此运算
				//printf("plus\n");
				if(type1->kind == basic && type2->kind == basic && type1->u.basic == type2->u.basic) {//INT/FLOAT
				}
				else {
					printf("Error type 7 at line %d: Operands type mismatched\n",Exp->child[0]->line);
					return NULL;
				}
			}
			return type1;
		}
		if(strcmp(Exp->child[1]->data,"LB") == 0) {//Exp[Exp] 数组访问表达式，错误需要输出变量名
			/*type1 = Exp(Exp->child[0]);
			if(type1->kind != array) {
				printf("Error type 10 at line %d: \"%s\" must be an array\n",Exp->child[0]->line,);
			}*/
			
			struct NODE* childExp = Exp->child[0];
			Type type_stru = Exp_(childExp,stru_name);
			/*
			int dimen = 1;
			while(strcmp(childExp->child[0]->data,"ID") != 0) {
				dimen++;
				childExp = childExp->child[0];
			}*/
				
			//childExp->child[0]:ID
			/*
			SymbolNodeVariable node;
			node = SearchVar(childExp->child[0]->value);//数组变量
			if(node == NULL) {//符号表中没有，未定义
				printf("Error type 1 at line %d: Undefined Array \"%s\"\n",Exp->child[0]->line,Exp->child[0]->value);
               			return NULL;
			}*/
			//ID Exp.ID (Exp)
			if(type_stru ==NULL)
				return NULL;
			if(type_stru->kind != array) {//已定义，但不是数组
				
				printf("Error type 10 at line %d: Illegal use of \"[]\"\n",Exp->child[0]->line);
				return NULL;
			}			
			type1 = type_stru;
			/*
			type1 = node->type;//最外层数组类型(最高维)
			while(type1->u.array.elem->kind != basic) {
				dimen--;
				type1 = type1->u.array.elem;
			}//type1->u.array.elem->kind = basic
			if(dimen == 1) {}//正确
			else if(dimen > 1){
				printf("Error type 10 at line %d: \"%s\"'dimension is wrong(too many [])\n",Exp->line,node->name);
				return NULL;
			}*/
			type2 = Exp_(Exp->child[2],stru_name);
			if(type2->kind == basic && type2->u.basic == 1){}//int型
			else {//[]中出现非整数，类型不变
				printf("Error type 12 at line %d: Operands type mistaken\n",Exp->line);
			}
			return type1->u.array.elem;
		}
		if(strcmp(Exp->child[1]->data,"DOT") == 0) {//Exp.ID 结构体访问表达式
			//printf("struct Exp.ID\n");
			/*type1 = Exp(Exp->child[0]);
			if(type1->kind != structure) {//Exp不是结构类型
				printf("Error type 13 at line %d: Illegal use of \".\"\n",Exp->child[0]->line);
			}
			else {//结构类型*/
			struct NODE* childExp = Exp->child[0];
			Type type_stru = Exp_(childExp,stru_name);
			/*int dimen = 1;
			while(strcmp(childExp->child[0]->data,"ID") != 0) {
				dimen++;
				childExp = childExp->child[0];
			}*/
			
			//printf("dimen:%d\n",dimen);
			//printf("childExp->child[0]->value:%s\n",childExp->child[0]->value);
		
			/*SymbolNodeVariable node;
			node = SearchVar(childExp->child[0]->value);//结构体变量*/

			/*
			if(strcmp(Exp->child[0]->child[0]->data,"ID") == 0) {//ID.ID
				node = SearchVar(Exp->child[0]->value);
			}
			else if(strcmp(Exp->child[0]->data,"Exp") == 0) {//Exp[]/Exp.ID
				Exp(Exp->child[0])->u.structure;
			}*/

			/*if (node == NULL) {
				printf("Error type 1 at line %d: Undefined variable \"%s\"\n", Exp->line, Exp->child[0]->value);
				return NULL;
			}*/
			if(type_stru == NULL) 
				return NULL;
			if(type_stru->kind != structure) {//已定义，但不是结构体
				printf("Error type 13 at line %d: Illegal use of \".\"\n",childExp->line);
				return NULL;
			}
			type1 = type_stru;
			/*type1 = node->type;//最外层类型(最高维)
			Type type_ = type1;
			int n = dimen;
			while(type_->kind == structure) {
				n--;
				type_ = type_->u.structure->type;
			}//type_->kind != structure
			if(n == 0) {}//正确
			else if(n > 0){
				printf("Error type 13 at line %d: Illegal use of \".\"(too many .)\n",childExp->line);
				return NULL;
			}
			while(dimen > 0) {*/
				FieldList first_field = type1->u.structure;//结构体的第一个元素
				while(first_field != NULL) {
					//printf("first_field->name:%s\n",first_field->name);
					//printf("Exp->child[2]->value:%s\n",Exp->child[2]->value);
					if (strcmp(first_field->name, Exp->child[2]->value) == 0) {//ID的内容
						break;
					}
					first_field = first_field->tail;
				}
				if(first_field == NULL) {
					printf("Error type 14 at line %d: Un-existed field \"%s\"\n", childExp->line, Exp->child[2]->value);
					return NULL;
				}
				else {
					type1 = first_field->type;//结构体元素的类型
					childExp = childExp->parent;
					//dimen--;
				}
			//}
			return  type1;
			//}
		}
	}
	else if(strcmp(name,"ID") == 0) {//函数调用/ID
		if(Exp->child[1] == NULL) {//ID,查表，判断类型
			//printf("Exp->child[0]->value:%s\n",Exp->child[0]->value);
			SymbolNodeVariable var = SearchVar(Exp->child[0]->value);
			if(var == NULL) {
				printf("Error type 1 at line %d: Undefined variable \"%s\"\n",Exp->line,Exp->child[0]->value);
                    		return NULL;
			}
			//printf("var->type->u.structure->name:%s\n",var->type->u.structure->name);
			//printf("var->stru_name:%s\n",var->stru_name);
			if(var->type->kind == structure) {
				strcpy(stru_name,var->stru_name);
			}
			return var->type;
		}
		else {//函数调用 ID() ID(Args)
			//printf("Exp->child[1]->data:%s\n",Exp->child[1]->data);			
			//printf("Exp->child[2]->data:%s\n",Exp->child[2]->data);
			char* name1 = Exp->child[2]->data;
			if(strcmp(name1,"RP") == 0) {//ID()
				//printf("function\n");
				SymbolNodeFunction func = SearchFunc(Exp->child[0]->value);
				SymbolNodeVariable var = SearchVar(Exp->child[0]->value);
			    	if(var != NULL) {
					printf("Error type 11 at line %d: \"%s\" must be a function\n",Exp->line,Exp->child[0]->value);  
					return NULL;          	
			    	}
				else if(var == NULL && func == NULL) {
					printf("Error type 2 at line %d: Undefined function \"%s\"\n",Exp->line,Exp->child[0]->value);
					return NULL;
			    	}
			}
			else {//ID(Args)
				SymbolNodeFunction func = SearchFunc(Exp->child[0]->value);
				SymbolNodeVariable var = SearchVar(Exp->child[0]->value);
				if(var != NULL) {
					printf("Error type 11 at line %d: \"%s\" must be a function\n",Exp->line,Exp->child[0]->value);  
					return NULL;          	
			    	}
				else if(var == NULL && func == NULL) {
					printf("Error type 2 at line %d: Undefined function \"%s\"\n",Exp->line,Exp->child[0]->value);
					return NULL;
			    	}
				else {
					int mark = 0;
					int num = 1;
					struct NODE* node = Exp->child[2];//Args
					while(node->cnChild == 3) {//Exp,Args
						num++;
						node = node->child[2];
					}
					//printf("num:%d\n",num);
					//printf("func->ParameterNum:%d\n",func->ParameterNum);
					SymbolNodeVariable paras[num];
					int i;
					for(i = 0;i < num;i++)
						paras[i] = NULL;
					//Type type = (Type)malloc(sizeof(struct Type_));
					Args_(Exp->child[2],paras,0);
					if(num != func->ParameterNum) {
						mark = 1;
					}
					else {
						int i;
						for(i = 0;i < func->ParameterNum;i++) {
							/*if(strcmp(func->parameters[i]->stru_name,"") != 0 && strcmp(paras[i]->stru_name,"") != 0 && strcmp(func->parameters[i]->stru_name,paras[i]->stru_name) == 0){}
							else */
							//printf("func->parameters[i]->type->kind:%d\n",func->parameters[i]->type->kind);
							//printf("paras[i]->type->kind:%d\n",paras[i]->type->kind);
							if(isTypeEqual(func->parameters[i]->type,paras[i]->type) == 1){}
							else{
								mark = 1;
							}
						}
					}
					if(mark == 1)
					printf("Error type 9 at line %d: The method \"%s\" is not applicable for the arguments \n",Exp->line,Exp->child[0]->value);
				}
				return func->returnType;
			}
		}
	}
	else if(strcmp(name,"LP") == 0 || strcmp(name,"MINUS") == 0 || strcmp(name,"NOT") == 0) {//一元运算符 ()/-/!
		//printf("Exp->child[1]->data:%s\n",Exp->child[1]->data);
		//printf("Exp->child[1]->child[0]->data:%s\n",Exp->child[1]->child[0]->data);		
		type = Exp_(Exp->child[1],stru_name);
		if(type == NULL) return NULL; 
		if(strcmp(name,"LP") == 0) {}//printf("type->kind:%d\n",type->kind);
		else if(strcmp(name,"MINUS") == 0) {
			if(type->kind == basic) {}//int/float
			else {
				printf("Error type 7 at line %d: Operands type mismatched\n",Exp->child[1]->line);
			}
		}
		else if(strcmp(name,"NOT") == 0) {
			if(type->kind == basic && type->u.basic == 1) {}//int
			else {
				printf("Error type 7 at line %d: Operands type mismatched\n",Exp->child[1]->line);
			}
		}
		return type;
	}
	else {//INT/FLOAT
		type->kind = basic;
		if(strcmp(name,"INT") == 0) {
            		type->u.basic = 1;
		}
		else if(strcmp(name,"FLOAT") == 0) {
            		type->u.basic = 2;
		}
		return type;
	}
}
void Args_(struct NODE* Args,SymbolNodeVariable para[],int number)
{
	//printf("Args->child[0]:%s\n",Args->child[0]->data);
	//printf("Args->child[1]:%s\n",Args->child[1]->data);
	//printf("Args->child[2]:%s\n",Args->child[2]->data);
	SymbolNodeVariable v = (SymbolNodeVariable)malloc(sizeof(struct SymbolNodeVariable_));
	char* name = Args->child[0]->data;
	char stru_name[20];
	if(strcmp(name,"Exp") == 0) {
		strcpy(v->stru_name,stru_name);
		v->type = Exp_(Args->child[0],stru_name);
		
		//printf("number:%d\n",number);		
		para[number] = v;
		//printf("para[number]->type->kind:%d\n",para[number]->type->kind);
		if(Args->child[1] == NULL) {
			return;
		}
		else {
			char* name1 = Args->child[2]->data;
			if(strcmp(name1,"Args") == 0) {
				Args_(Args->child[2],para,number + 1);
			}	
		}	
	}
}
