#include <stdarg.h>		// varlist-arguments func
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdio.h>

#include "tree.h"

int isProgramRight = 1;		// 程序是否出现语法错误 1:正确，0错误
struct TreeNode* Root;

/*
	创建非叶子节点
	nodeType :节点类型
	numOfChilds:字节点个数
	...	:字节点指针
*/
TreeNode* createNode(char* nodeType,int numOfChilds,int lineno,...)
{
	int i;
	va_list ap;
	TreeNode *newNode = (TreeNode *)malloc(sizeof(TreeNode));
	if(newNode == NULL)
		printf("Error in malloc() in createNode.\n");
	memset(newNode,0,sizeof(*newNode));
	strcpy(newNode->nodeType,nodeType);
	
	if(strcmp(nodeType,"Program") == 0)
		newNode->type = PROGRAM_NODE;
	else if(strcmp(nodeType,"ExtDefList") == 0)
		newNode->type = EXTDEFLIST_NODE;
	else if(strcmp(nodeType,"ExtDef") == 0)
		newNode->type = EXTDEF_NODE;
	else if(strcmp(nodeType,"ExtDecList") == 0)
		newNode->type = EXTDECLIST_NODE;
	else if(strcmp(nodeType,"Specifier") == 0)
		newNode->type = SPECIFIER_NODE;
	else if(strcmp(nodeType,"StructSpecifier") == 0)
		newNode->type = STRUCTSPECIFIER_NODE;
	else if(strcmp(nodeType,"OptTag") == 0)
		newNode->type = OPTTAG_NODE;
	else if(strcmp(nodeType,"Tag") == 0)
		newNode->type = TAG_NODE;
	else if(strcmp(nodeType,"VarDec") == 0)
		newNode->type = VARDEC_NODE;
	else if(strcmp(nodeType,"FunDec") == 0)
		newNode->type = FUNDEC_NODE;
	else if(strcmp(nodeType,"VarList") == 0)
		newNode->type = VARLIST_NODE;
	else if(strcmp(nodeType,"ParamDec") == 0)
		newNode->type = PARAMDEC_NODE;
	else if(strcmp(nodeType,"CompSt") == 0)
		newNode->type = COMPST_NODE;
	else if(strcmp(nodeType,"StmtList") == 0)
		newNode->type = STMTLIST_NODE;
	else if(strcmp(nodeType,"Stmt") == 0)
		newNode->type = STMT_NODE;
	else if(strcmp(nodeType,"DefList") == 0)
		newNode->type = DEFLIST_NODE;
	else if(strcmp(nodeType,"Def") == 0)
		newNode->type = DEF_NODE;
	else if(strcmp(nodeType,"DecList") == 0)
		newNode->type = DECLIST_NODE;
	else if(strcmp(nodeType,"Dec") == 0)
		newNode->type = DEC_NODE;
	else if(strcmp(nodeType,"Exp") == 0)
		newNode->type = EXP_NODE;
	else if(strcmp(nodeType,"Args") == 0)
		newNode->type = ARGS_NODE;
	else
	{
		printf("%s\n","Something wrong in method CreateNode!");
		assert(0);
	}
	
	newNode->numOfChilds = numOfChilds;
	newNode->lineno = lineno;
	newNode->isLeaf = 0;
	va_start(ap,lineno);
	for(i = 0;i < numOfChilds;i ++)
	{
		newNode->childs[i] = va_arg(ap,TreeNode*);
	}
	va_end(ap);
	return newNode;
}

/*
	创建叶子节点
	nodeType :节点类型
	lineno:	行号
*/
TreeNode* createLeaf(char* nodeType,int lineno)
{
	TreeNode *p = (TreeNode*)malloc(sizeof(TreeNode));
	memset(p,0,sizeof(TreeNode));
	strcpy(p->nodeType,nodeType);
	
	p->numOfChilds = 0;
	p->lineno = lineno;
	p->isLeaf = 1;
	
	if(strcmp(nodeType,"INT") == 0)
		p->type = INT_NODE;
	else if(strcmp(nodeType,"FLOAT") == 0)
		p->type = FLOAT_NODE;
	else if(strcmp(nodeType,"ID") == 0)
		p->type = ID_NODE;
	else if(strcmp(nodeType,"SEMI") == 0)
		p->type = SEMI_NODE;
	else if(strcmp(nodeType,"COMMA") == 0)
		p->type = COMMA_NODE;
	else if(strcmp(nodeType,"ASSIGNOP") == 0)
		p->type = ASSIGNOP_NODE;
	else if(strcmp(nodeType,"RELOP") == 0)
		p->type = RELOP_NODE;
	else if(strcmp(nodeType,"PLUS") == 0)
		p->type = PLUS_NODE;
	else if(strcmp(nodeType,"MINUS") == 0)
		p->type = MINUS_NODE;
	else if(strcmp(nodeType,"STAR") == 0)
		p->type = STAR_NODE;
	else if(strcmp(nodeType,"DIV") == 0)
		p->type = DIV_NODE;
	else if(strcmp(nodeType,"AND") == 0)
		p->type = AND_NODE;
	else if(strcmp(nodeType,"OR") == 0)
		p->type = OR_NODE;
	else if(strcmp(nodeType,"DOT") == 0)
		p->type = DOT_NODE;
	else if(strcmp(nodeType,"NOT") == 0)
		p->type = NOT_NODE;
	else if(strcmp(nodeType,"TYPE") == 0)
		p->type = TYPE_NODE;
	else if(strcmp(nodeType,"LP") == 0)
		p->type = LP_NODE;
	else if(strcmp(nodeType,"RP") == 0)
		p->type = RP_NODE;
	else if(strcmp(nodeType,"LB") == 0)
		p->type = LB_NODE;
	else if(strcmp(nodeType,"RB") == 0)
		p->type = RB_NODE;
	else if(strcmp(nodeType,"LC") == 0)
		p->type = LC_NODE;
	else if(strcmp(nodeType,"RC") == 0)
		p->type = RC_NODE;
	else if(strcmp(nodeType,"STRUCT") == 0)
		p->type = STRUCT_NODE;
	else if(strcmp(nodeType,"RETURN") == 0)
		p->type = RETURN_NODE;
	else if(strcmp(nodeType,"IF") == 0)
		p->type = IF_NODE;
	else if(strcmp(nodeType,"ELSE") == 0)
		p->type = ELSE_NODE;
	else if(strcmp(nodeType,"WHILE") == 0)
		p->type = WHILE_NODE;
	else
	{
		// here should never be reached
		printf("%s\n","Something wrong in method CreateLeaf!");
		assert(0);	
	}
	
	return p;
}
/*
	打印多叉树
	root:   根节点指针
	blanks: 缩进的空格数
*/
void printTree(TreeNode* root,int blanks)
{
	if(root == NULL)
		return ;
	if(!root->isLeaf && root->numOfChilds == 0)		// 产生式体为空，不打印信息
		return ;
	int i;
	for(i = 0;i < blanks;i ++)				// 打印缩进空格
		printf("%c",' ');
	printf("%s",root->nodeType);
	if(!root->isLeaf && root->numOfChilds > 0)		// 中间节点
	{
		printf(" (%d)\n",root->lineno);
		for(i = 0;i < root->numOfChilds;i++)
			printTree(root->childs[i],blanks + 2);	// 递归打印多叉子树
	}
	else				// 叶子节点
	{
		if(strcmp(root->nodeType,"ID") == 0)
			printf(": %s\n",root->type_string);
		else if(strcmp(root->nodeType,"TYPE") == 0)
			printf(": %s\n",root->type_string);
		else if(strcmp(root->nodeType,"INT") == 0)
			printf(": %d\n",root->type_int);
		else if(strcmp(root->nodeType,"FLOAT") == 0)
			printf(": %f\n",root->type_float);
		else
			printf("\n");
		return ;
	}	
}
/*
*	归还申请的空间
*	root: 多叉树根节点
*/
void destroyTree(TreeNode* root)
{
	if(root == NULL)
		return ;
	if(root->numOfChilds > 0)
	{
		int i;
		for(i = 0;i < root->numOfChilds;i++ )
			destroyTree(root->childs[i]);		// 递归销毁子树
	}
	free(root);
	return ;
}


