/*
	目标代码生成函数
	
*/


#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "translate.h"
#include "target.h"


#define true 1
#define false 0
#define INTEGER_SIZE 4	// 整数类型的长度

int global_offset = 0;

struct FuncLayout* FUNC_LAY_HEAD;	// 函数stack布局双向链表头
struct VarLayout* VAR_LAY_HAED;	// 变量stack布局双向链表头
struct ArgList* CUR_ARG_LIST_HEAD;	// 当前函数调用使用的参数位置列表
// 初始化函数
void layoutInit()
{
	VAR_LAY_HAED = NULL;
	FUNC_LAY_HEAD = (struct FuncLayout *)malloc(sizeof(struct FuncLayout));  // 函数布局表头
	FUNC_LAY_HEAD->next = FUNC_LAY_HEAD->prev = FUNC_LAY_HEAD;
	FUNC_LAY_HEAD->funcName = NULL;
	FUNC_LAY_HEAD->var_size = -1;
	// 当前函数调用使用的参数位置列表的带有空表头方便参数的插入和删除
	CUR_ARG_LIST_HEAD = (struct ArgList *)malloc(sizeof(struct ArgList));
	assert(CUR_ARG_LIST_HEAD != NULL);
	CUR_ARG_LIST_HEAD->next = CUR_ARG_LIST_HEAD->prev = CUR_ARG_LIST_HEAD; // 表头初始化
	CUR_ARG_LIST_HEAD->arg_offset = -1;
}


// 取该函数内定义的变量的空间大小
int getFuncVarSize(char *funcName)
{
	struct FuncLayout *p = FUNC_LAY_HEAD->next;
	do
	{
		if(strcmp(p->funcName, funcName) == 0)
			return p->var_size;
		p = p->next;
	}while(p != FUNC_LAY_HEAD);
	
	return -1;	// 没有找到
}

// 设置函数内定义的变量的空间大小
void setFuncVarSize(char *funcName, int var_size)
{
	struct FuncLayout *p = FUNC_LAY_HEAD->next;
	do
	{
		if(strcmp(p->funcName, funcName) == 0)
		{
			p->var_size = var_size;
			return ;
		}
		p = p->next;
	}while(p != FUNC_LAY_HEAD);
	
	// here should never be reached
	assert(0);
}

// 将一个函数添加到函数的布局表中
void addFuncNameToList(char *funcName)
{
	struct FuncLayout *p = (struct FuncLayout *)malloc(sizeof(struct FuncLayout));
	p->funcName = (char *)malloc(strlen(funcName) + 1);
	strcpy(p->funcName, funcName);
	p->var_size = -1;	// 初始化为-1
	
	// 加入到布局表中
	p->prev = FUNC_LAY_HEAD->prev;
	FUNC_LAY_HEAD->prev->next = p;
	p->next = FUNC_LAY_HEAD;
	FUNC_LAY_HEAD->prev = p;
	
}
// 创建一个新的stack空间布局变量
struct VarLayout* newVarInLayout(int var_or_temp, int no, int offset, int len)
{
	struct VarLayout * p = (struct VarLayout *)malloc(sizeof(struct VarLayout));
	//assert(p != NULL);
	p->var_or_temp = var_or_temp;
	p->no = no;
	p->offset = offset;
	p->len = len;
	return p;
}

// ARG v,由于传递实在参数时，参数顺序与PARAM的顺序的是反的，所以每次插入新的参数时插在头部
void addArgAtListHead(int arg_offset)
{
	struct ArgList *p = (struct ArgList *)malloc(sizeof(struct ArgList));
	assert(p != NULL);
	p->arg_offset = arg_offset;
	
	// 插入到当前的函数调用参数列表中
	p->next = CUR_ARG_LIST_HEAD->next;
	p->prev = CUR_ARG_LIST_HEAD;
	CUR_ARG_LIST_HEAD->next = p;
	p->next->prev = p;
}
// 从当前函数调用使用的参数位置列表中取参数(从表头取),并将该参数从列表中删除，这样每次就都能在列表头部取到参数了
int getArgAtListHead()
{
	struct ArgList *p = CUR_ARG_LIST_HEAD->next;
	
	// 摘链
	p->prev->next = p->next;
	p->next->prev = p->prev;
	
	int arg_offset = p->arg_offset;
	free(p);		// 释放空间
	return arg_offset;
}


// 添加变量到stack变量布局表中
void addVarInLayout(int var_or_temp, int no, int offset, int len)
{
	struct VarLayout *p = newVarInLayout(var_or_temp, no, offset, len);
	if(VAR_LAY_HAED == NULL) // 布局表为空
	{
		p->next = p;
		p->prev = p;
		VAR_LAY_HAED = p;
	}
	else				// 新节点加入到表尾
	{
		p->prev = VAR_LAY_HAED->prev;
		VAR_LAY_HAED->prev->next = p;
		p->next = VAR_LAY_HAED;
		VAR_LAY_HAED->prev = p;
	}
}

// 将一个操作数加入到stack空间布局变量表中
void addOperandInLayout(Operand op, int *offset, int len)
{
	assert(op != NULL);
	if(op->kind == VARIABLE || op->kind == TEMP_VAR)
	{
		if(getVarOffset(op->kind, op->u.var_no) == -1)
		{
			addVarInLayout(op->kind, op->u.var_no, *offset, len);
			*offset += len;
		}
	}
}

// 获取指定变量的相对statck point的偏移
// 当变量在列表中不存在时，返回-1
// 否则返回其offset
int getVarOffset(int var_or_temp, int no)
{
	struct VarLayout *p = VAR_LAY_HAED;
	if(p == NULL)
		return -1;
	do
	{
		if(p->var_or_temp == var_or_temp && p->no == no)
			return p->offset;
		p = p->next;
	}while(p != VAR_LAY_HAED);
	
	return -1;	// not found
}


// 扫描中间代码列表建立变量(用户定义 + 临时变量)satck布局表
void getVarStackLayoutList(struct InterCodes *head)
{
	if(head == NULL)
		return ;
	
	InterCodes *p;  				// 扫描指针
	Operand result, op, op1, op2;
	p = head;
	int cur_fun_var_size = 0;	// 当前函数内的变量空间大小
	char *cur_func_name;		// 当前处理的函数的函数的名字
	bool isFirstFunc = true;
	
	do
	{
		result = op = op1 = op2 = NULL;
		
		switch(p->code.kind)
		{
			case IR_LABEL:
				break;
			case IR_FUNCTION:
				op = p->code.u.op;
				if(isFirstFunc)
				{
					isFirstFunc = false;
					cur_func_name = op->u.func_name;
					addFuncNameToList(cur_func_name);
				}
				else
				{
					setFuncVarSize(cur_func_name, cur_fun_var_size);
					cur_fun_var_size = 0;			// 遇到新的函数时清零
					cur_func_name = op->u.func_name;
					addFuncNameToList(cur_func_name);
				}
				break;
			case IR_ASSIGN: case IR_ADDR: case IR_MEM_R: case IR_MEM_L:		// 赋值号左边为用户定义的变量或者临时变量
				result = p->code.u.unaop.result;
				op = p->code.u.unaop.op;
				/* VERY IMPORTANT */
				if(result == NULL)
					return ;
				addOperandInLayout(op, &cur_fun_var_size, INTEGER_SIZE);
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				addOperandInLayout(result, &cur_fun_var_size, INTEGER_SIZE);
				break;
			case IR_ADD: case IR_SUB:  case IR_MUL: case IR_DIV:		// +, -, * , /
				result = p->code.u.binop.result;
				op1 = p->code.u.binop.op1;
				op2 = p->code.u.binop.op2;
				
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				addOperandInLayout(op1, &cur_fun_var_size, INTEGER_SIZE);
				addOperandInLayout(op2, &cur_fun_var_size, INTEGER_SIZE);
				addOperandInLayout(result, &cur_fun_var_size, INTEGER_SIZE);
				break;
		
			case IR_GOTO:
				break;
			
			case IR_RELOP:
				op1 = p->code.u.relop.op1;
				op2 = p->code.u.relop.op2;
				addOperandInLayout(op1, &cur_fun_var_size, INTEGER_SIZE);
				addOperandInLayout(op2, &cur_fun_var_size, INTEGER_SIZE);
				break;
			case IR_RETURN:			// 返回的可能是：常量/用户定义的变量/ 临时变量
				op = p->code.u.op;
				addOperandInLayout(op, &cur_fun_var_size, INTEGER_SIZE);
				break;
			case IR_DEC:
				op = p->code.u.dec.op;
				addOperandInLayout(op, &cur_fun_var_size, INTEGER_SIZE * p->code.u.dec.size);
				break;
				
			case IR_ARG_VAL:			// pass by vale,值传递
				op = p->code.u.op;
				addOperandInLayout(op, &cur_fun_var_size, INTEGER_SIZE);
				break;
			case IR_ARG_REF:			// pass by reference, 引用传递
				// here should never be reached
				printf("本实验中假设函数的参数只能为基本数据类型-int\n");
				exit(0);
			case IR_CALL:
				result = p->code.u.unaop.result;
				addOperandInLayout(result, &cur_fun_var_size, INTEGER_SIZE);
				break;
			
			case IR_PARAM:				// PARAM之后跟的一定是用户定义的变量
				op = p->code.u.op;
				addOperandInLayout(op, &cur_fun_var_size, INTEGER_SIZE);
				break;
			case IR_READ:
				op = p->code.u.op;
				addOperandInLayout(op, &cur_fun_var_size, INTEGER_SIZE);
				break;
			case IR_WRITE:
				op = p->code.u.op;
				addOperandInLayout(op, &cur_fun_var_size, INTEGER_SIZE);
				break;
			default:
				assert(0);	// here should never be reached
			
		}
		p = p->next;
	}while(p != head);
	setFuncVarSize(cur_func_name, cur_fun_var_size);	// 设置最后一个出现的函数的变量空间大小
}

//	目标代码生成函数
void printTar(InterCodes *head, FILE *p_out)
{
	if(head == NULL)
		return ;
	
	layoutInit();
	getVarStackLayoutList(head);
	
	printTarHead(p_out);		// 打印头部
	
	InterCodes *p;  				// 扫描指针
	//Operand op, op1, op2;
	p = head;
	do
	{
		//op = op1 = op2 = NULL;
		switch(p->code.kind)
		{
			case IR_LABEL:		// 标号类型
				tran_label(p, p_out);
				break;
			case IR_FUNCTION:		// 函数定义
				tran_function(p, p_out);
				break;
			case IR_ASSIGN:			// 赋值号左边为用户定义的变量或者临时变量
				tran_assign(p, p_out);
				break;
			case IR_ADD:
				tran_add(p, p_out);
				break;
			case IR_SUB:
				tran_sub(p, p_out);
				break;
			case IR_MUL:
				tran_mul(p, p_out);
				break;
			case IR_DIV:
				tran_div(p, p_out);
				break;
			case IR_ADDR:
				tran_addr(p, p_out);
				break;
			case IR_MEM_R:
				tran_mem_R(p, p_out);
				break;
			case IR_MEM_L:
				tran_mem_L(p, p_out);				
				break;
			
			case IR_GOTO:			
				tran_goto(p, p_out);
				break;
			
			case IR_RELOP:
				tran_relop(p, p_out);
				break;
			case IR_RETURN:			// 返回的可能是：常量/用户定义的变量/ 临时变量
				tran_return(p, p_out);
				break;
			case IR_DEC:
				tran_dec(p, p_out);
				break;
			case IR_ARG_VAL:			// pass by vale,值传递
				tran_arg(&p, p_out);
				break;
			case IR_ARG_REF:			// pass by reference, 引用传递
				// here shoud never be reached in this lab04
				printf("本实验中假设函数的参数只能为基本数据类型-int\n");
				exit(0);
			case IR_CALL:
				tran_call(p, p_out);
				break;
			
			case IR_PARAM:				// PARAM之后跟的一定是用户定义的变量
				tran_param(&p, p_out);
				break;
			case IR_READ:
				tran_read(p, p_out);
				break;
			case IR_WRITE:
				tran_write(p, p_out);
				break;
			default:
				assert(0);	// here should never be reached
			
		}
		p = p->next;
	}while(p != head);
	
}
// Dec x 12 1-d数组类型的翻译
void tran_dec(InterCodes *p, FILE *p_out)
{
	// just do nothing
}
// x = &y的翻译 
void tran_addr(InterCodes *p, FILE *p_out)
{
	Operand result, op;
	op = p->code.u.unaop.op;
	unsigned int offset;
	offset = getVarOffset(op->kind, op->u.var_no);
	result = p->code.u.unaop.result;
	assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
	fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op->kind, op->u.var_no));
	fprintf(p_out, "\taddi $t0, $sp, %d\n", offset);
	fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no));
}

// PARAM x的翻译
void tran_param(InterCodes **p, FILE *p_out)
{
	Operand op;
	
	int i = 0;
	while(1)  // 正向读取参数
	{
		op = (*p)->code.u.op;
		fprintf(p_out, "\tlw $t0, %d($fp)\n", i * INTEGER_SIZE);				    // 读取参数
		fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(op->kind, op->u.var_no));  // 保存参数到内存中
		if((*p)->next->code.kind != IR_PARAM)
			break;
		*p = (*p)->next;
		i ++;
	}
}
// Arg x 参数传递的翻译
void tran_arg(InterCodes **p, FILE *p_out)
{
	Operand op;
	int numOfArgs = 1;	// 参数个数
	InterCodes *tmp = (*p)->next;
	while(tmp->code.kind == IR_ARG_VAL)
	{
		tmp = tmp->next;
		numOfArgs ++;
	}
	int i = numOfArgs - 1;
	while(1)
	{
		op = (*p)->code.u.op;
		fprintf(p_out, "\tlw $t0, %d($sp)\n", getVarOffset(op->kind, op->u.var_no));
		fprintf(p_out, "\tsw $t0, %d($fp)\n", INTEGER_SIZE * i); 		// 将参数保存到约定的位置，反序存放，正向取
		
		if((*p)->next->code.kind != IR_ARG_VAL)
			break;
		*p = (*p)->next;
		i --;
	}
	assert(i == 0);
}
// LABEL x的翻译
void tran_label(InterCodes *p, FILE *p_out)
{
	fprintf(p_out, "label%d:\n", p->code.u.op->u.label_no);
}
// goto 语句的翻译
void tran_goto(InterCodes *p, FILE *p_out)
{
	fprintf(p_out, "\tj label%d\n", p->code.u.op->u.label_no);
}

// 函数的翻译
void tran_function(InterCodes *p, FILE *p_out)
{
	fprintf(p_out, "\n%s:\n", p->code.u.op->u.func_name);
	
	if(strcmp(p->code.u.op->u.func_name, "main") == 0)
	{	
		fprintf(p_out, "\t# leave space for argument, at most 20 INT type args, access by $fp\n");
		fprintf(p_out, "\taddi $sp, $sp, -80\n");
		fprintf(p_out, "\tmove $fp, $sp\n");// 将stack的栈顶指针保存在$fp中,以后所有的变量偏移均以$fp为准 
		fprintf(p_out, "\taddi $sp, $sp, -%d\n", getFuncVarSize(p->code.u.op->u.func_name));		// 为所有的变量分配stack空间
	}
	
}
// write函数调用的翻译 write t
void tran_write(InterCodes *p, FILE *p_out)
{
	Operand op;
	op = p->code.u.op;
	assert(op->kind == TEMP_VAR || op->kind == VARIABLE);
	fprintf(p_out, "\tlw $t0, %d($sp)\n", getVarOffset(op->kind, op->u.var_no));
	fprintf(p_out, "\tmove $a0, $t0\n");
	fprintf(p_out, "\taddi $sp, $sp, -4\n");
	fprintf(p_out, "\tsw $ra, 0($sp)\n");
	fprintf(p_out, "\tjal write\n");
	fprintf(p_out, "\tlw $ra, 0($sp)\n");
	fprintf(p_out, "\taddi $sp, $sp, 4\n");
}
// READ函数调用的翻译  READ x
void tran_read(InterCodes *p, FILE *p_out)
{
	Operand op;
	op = p->code.u.op;
	fprintf(p_out, "\taddi $sp, $sp, -4\n");
	fprintf(p_out, "\tsw $ra, 0($sp)\n");
	fprintf(p_out, "\tjal read\n");
	fprintf(p_out, "\tlw $ra, 0($sp)\n");
	fprintf(p_out, "\taddi $sp, $sp, 4\n");
	fprintf(p_out, "\tsw $v0, %d($sp)\n", getVarOffset(op->kind, op->u.var_no)); // 将读取的值$v0 store
}

// 条件跳转的翻译 if x relop y GOTO z
void tran_relop(InterCodes *p, FILE *p_out)
{
	Operand op1, op2;
	op1 = p->code.u.relop.op1;
	op2 = p->code.u.relop.op2;
	if(op1->kind == VARIABLE || op1->kind == TEMP_VAR)
		fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op1->kind, op1->u.var_no));	// load variable x
	else if(op1->kind == CONSTANT)	// 常量要加载到寄存器
		fprintf(p_out, "\tli $t1, %d\n", op1->u.value);
	else
		assert(0);
	if(op2->kind == VARIABLE || op2->kind == TEMP_VAR)
		fprintf(p_out, "\tlw $t2, %d($sp)\n", getVarOffset(op2->kind, op2->u.var_no));	// load variable x
	else if(op2->kind == CONSTANT)	// 常量要加载到寄存器
		fprintf(p_out, "\tli $t2, %d\n", op2->u.value);
	else
		assert(0);
	
	if(strcmp(p->code.u.relop.relop, "==") == 0)
		fprintf(p_out, "\tbeq $t1, $t2, label%d\n", p->code.u.relop.label->u.label_no);
	else if(strcmp(p->code.u.relop.relop, "!=") == 0)
		fprintf(p_out, "\tbne $t1, $t2, label%d\n", p->code.u.relop.label->u.label_no);
	else if(strcmp(p->code.u.relop.relop, ">") == 0)
		fprintf(p_out, "\tbgt $t1, $t2, label%d\n", p->code.u.relop.label->u.label_no);
	else if(strcmp(p->code.u.relop.relop, "<") == 0)
		fprintf(p_out, "\tblt $t1, $t2, label%d\n", p->code.u.relop.label->u.label_no);
	else if(strcmp(p->code.u.relop.relop, ">=") == 0)
		fprintf(p_out, "\tbge $t1, $t2, label%d\n", p->code.u.relop.label->u.label_no);
	else if(strcmp(p->code.u.relop.relop, "<=") == 0)
		fprintf(p_out, "\tble $t1, $t2, label%d\n", p->code.u.relop.label->u.label_no);
}

// return x语句的翻译
void tran_return(InterCodes *p, FILE *p_out)
{
	Operand op = p->code.u.op;
	fprintf(p_out, "\tlw $t0, %d($sp)\n", getVarOffset(op->kind, op->u.var_no));	// load x
	fprintf(p_out, "\tmove $v0, $t0\n");
	fprintf(p_out, "\tjr $ra\n");
}
// 翻译函数调用语句 x = CALL f
void tran_call(InterCodes *p, FILE *p_out)
{
	Operand result, op;
	result = p->code.u.unaop.result;
	op = p->code.u.unaop.op;
	assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
	fprintf(p_out, "\taddi $sp, $sp, -4\n");
	fprintf(p_out, "\tsw $ra, 0($sp)\n");
	fprintf(p_out, "\t#alloc stack space for callee\n");
	fprintf(p_out, "\taddi $sp, $sp, -%d\n", getFuncVarSize(op->u.func_name)); 	// 为被调用函数分配空间
	fprintf(p_out, "\tjal %s\n", op->u.func_name);
	fprintf(p_out, "\taddi $sp, $sp, %d\n", getFuncVarSize(op->u.func_name)); 	// 释放为被调用函数分配的空间
	fprintf(p_out, "\tlw $ra, 0($sp)\n");
	fprintf(p_out, "\taddi $sp, $sp, 4\n");
	fprintf(p_out, "\tmove $t0, $v0\n");
	fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no));	// store x back
}
// 翻译赋值语句
void tran_assign(InterCodes *p, FILE *p_out)
{
	Operand result, op;
	result = p->code.u.unaop.result;
	op = p->code.u.unaop.op;
	/* VERY IMPORTANT */
	if(result == NULL)
		return ;
	if(op->kind == CONSTANT) // x = #k
	{
		fprintf(p_out, "\tli $t0, %d\n", op->u.value);
		fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no));
	}
	else if(op->kind == VARIABLE || op->kind == TEMP_VAR) // x = y
	{
		fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op->kind, op->u.var_no));
		fprintf(p_out, "\tmove $t0, $t1\n");
		fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no));
	}
}

// 翻译加法
void tran_add(InterCodes* p, FILE *p_out)
{
	Operand result, op1, op2;
	result = p->code.u.binop.result;
	op1 = p->code.u.binop.op1;
	op2 = p->code.u.binop.op2;
	assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
	if(op1->kind == CONSTANT)
		fprintf(p_out, "\tli $t1, %d\n", op1->u.value);
	else if(op1->kind == VARIABLE || op1->kind == TEMP_VAR)
		fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op1->kind, op1->u.var_no));// load y
	else
		assert(0);
	if(op2->kind == CONSTANT)	// x = y + #k
		fprintf(p_out, "\tli $t2, %d\n", op2->u.value);
	else if(op2->kind == VARIABLE || op2->kind == TEMP_VAR)	// x = y + z
		fprintf(p_out, "\tlw $t2, %d($sp)\n", getVarOffset(op2->kind, op2->u.var_no));	// load z
	else
		assert(0);
	fprintf(p_out, "\tadd $t0, $t1, $t2\n");	
	fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no)); // store x
}

// 翻译减法
void tran_sub(InterCodes* p, FILE *p_out)
{
	Operand result, op1, op2;
	result = p->code.u.binop.result;
	op1 = p->code.u.binop.op1;
	op2 = p->code.u.binop.op2;
	assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
	if(op1->kind == VARIABLE || op1->kind == TEMP_VAR)
	{
		if(op2->kind == CONSTANT)	// x = y - #k
		{
			fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op1->kind, op1->u.var_no));
			fprintf(p_out, "\taddi $t0, $t1, -%d\n", op2->u.value);
			fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no));
		}
		else if(op2->kind == VARIABLE || op2->kind == TEMP_VAR)	// x = y - z
		{
			fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op1->kind, op1->u.var_no));	// load y
			fprintf(p_out, "\tlw $t2, %d($sp)\n", getVarOffset(op2->kind, op2->u.var_no));	// load z
			fprintf(p_out, "\tsub $t0, $t1, $t2\n");
			fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no));
		}
	}
	else if(op1->kind == CONSTANT) // op1为常数
	{
		fprintf(p_out, "\tli $t1, %d\n", op1->u.value);
		if(op2->kind == CONSTANT)	// x = y - #k
		{
			fprintf(p_out, "\taddi $t0, $t1, -%d\n", op2->u.value);
			fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no));
		}
		else if(op2->kind == VARIABLE || op2->kind == TEMP_VAR)	// x = y - z
		{
			fprintf(p_out, "\tlw $t2, %d($sp)\n", getVarOffset(op2->kind, op2->u.var_no));	// load z
			fprintf(p_out, "\tsub $t0, $t1, $t2\n");
			fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no));
		}
	}
	else
	{
		assert(0);
	}
}

// 乘法翻译
void tran_mul(InterCodes *p, FILE *p_out)
{
	Operand result, op1, op2;
	result = p->code.u.binop.result;
	op1 = p->code.u.binop.op1;
	op2 = p->code.u.binop.op2;
	assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
	if(op1->kind == CONSTANT)
		fprintf(p_out, "\tli $t1, %d\n", op1->u.value);						// load constant
	else if(op1->kind == VARIABLE || op1->kind == TEMP_VAR)
		fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op1->kind, op1->u.var_no));	// load y
	else
		assert(0);
	
	if(op2->kind == CONSTANT)
		fprintf(p_out, "\tli $t2, %d\n", op2->u.value);						// load constant
	else if(op2->kind == VARIABLE || op2->kind == TEMP_VAR)
		fprintf(p_out, "\tlw $t2, %d($sp)\n", getVarOffset(op2->kind, op2->u.var_no));	// load z
	else
		assert(0);
	
	fprintf(p_out, "\tmul $t0, $t1, $t2\n");		// $t0 = $t1 * $t2
	fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no)); // store back
	
}

// 除法翻译
void tran_div(InterCodes *p, FILE *p_out)
{
	Operand result, op1, op2;
	result = p->code.u.binop.result;
	op1 = p->code.u.binop.op1;
	op2 = p->code.u.binop.op2;
	assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
	if(op1->kind == CONSTANT)
		fprintf(p_out, "\tli $t1, %d\n", op1->u.value);						// load constant
	else if(op1->kind == VARIABLE || op1->kind == TEMP_VAR)
		fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op1->kind, op1->u.var_no));	// load y
	else
		assert(0);
	
	if(op2->kind == CONSTANT)
		fprintf(p_out, "\tli $t2, %d\n", op2->u.value);						// load constant
	else if(op2->kind == VARIABLE || op2->kind == TEMP_VAR)
		fprintf(p_out, "\tlw $t2, %d($sp)\n", getVarOffset(op2->kind, op2->u.var_no));	// load z
	else
		assert(0);
	
	fprintf(p_out, "\tdiv $t0, $t1, $t2\n");		// $t0 = $t1 / $t2
	fprintf(p_out, "\tmflo $t0\n");
	fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no)); // store back
}

// x = *y翻译
void tran_mem_R(InterCodes *p, FILE *p_out)
{
	Operand result, op;
	result = p->code.u.unaop.result;
	op = p->code.u.unaop.op;
	assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
	fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op->kind, op->u.var_no));	// load y
	fprintf(p_out, "\tlw $t0, 0($t1)\n");		// x = *y
	fprintf(p_out, "\tsw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no)); // store x back
}

// *x = y翻译
void tran_mem_L(InterCodes *p, FILE *p_out)
{
	Operand result, op;
	result = p->code.u.unaop.result;
	op = p->code.u.unaop.op;
	assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
	fprintf(p_out, "\tlw $t1, %d($sp)\n", getVarOffset(op->kind, op->u.var_no));	// load y
	fprintf(p_out, "\tlw $t0, %d($sp)\n", getVarOffset(result->kind, result->u.var_no));	// load y
	fprintf(p_out, "\tsw $t1, 0($t0)\n");		// *x = y
}

/**
 * 打印目标代码的头部：
 * 数据段 + read + write函数
 */
void printTarHead(FILE *p_out) 
{
	fprintf(p_out, ".data\n");
	fprintf(p_out, "_prompt: .asciiz \"Enter an integer:\"\n");
	fprintf(p_out, "_ret: .asciiz \"\\n\"\n");
	fprintf(p_out, ".globl main\n");
	fprintf(p_out, ".text\n");
	
	// read 函数
	fprintf(p_out, "read:\n");
	fprintf(p_out, "\tli $v0, 4\n");
	fprintf(p_out, "\tla $a0, _prompt\n");
	fprintf(p_out, "\tsyscall\n");
	fprintf(p_out, "\tli $v0, 5\n");
	fprintf(p_out, "\tsyscall\n");
	fprintf(p_out, "\tjr $ra\n");
	fprintf(p_out, "\n");
	
	// write函数
	fprintf(p_out, "write:\n");
	fprintf(p_out, "\tli $v0, 1\n");
	fprintf(p_out, "\tsyscall\n");
	fprintf(p_out, "\tli $v0, 4\n");
	fprintf(p_out, "\tla $a0, _ret\n");
	fprintf(p_out, "\tsyscall\n");
	fprintf(p_out, "\tmove $v0, $0\n");
	fprintf(p_out, "\tjr $ra\n");
}




