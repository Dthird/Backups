/*
 *
 * 中间代码生成源文件
 *
 *
 */
#include <stdlib.h>	// malloc()
#include <stdio.h>	// printf()
#include <assert.h>	// assert()
#include <string.h>	// strlen(),strcpy()

#include "translate.h"	// 包含了tree.h, semantic.h

InterCodes *IR_LIST_HEAD;		// 中间代码列表头指针
int TRANSLATE_RIGHT = 1;		// 读入文件能正确解析并生成中间代码标志位
unsigned int TEMP_VAR_NO = 0;	// 临时变量的编号
unsigned int LABEL_NO = 0;		// 标号编号

char* SIGN[6] = {"v", "#", "t", "label", "v", "??" };	// 注意：the last one should never be used

void 
translate_Init()	// 初始化函数
{
	// 中间代码链表头初始化
	IR_LIST_HEAD = (InterCodes *)malloc(sizeof(struct InterCodes));
	assert(IR_LIST_HEAD != NULL);
	IR_LIST_HEAD->next = IR_LIST_HEAD->prev = IR_LIST_HEAD;
	
	
}

/**
 * 中间代码生成函数
 */
InterCodes * 
translate_Program(struct TreeNode *root)
{
	if(root == NULL)
		return NULL;
	assert(root->type == PROGRAM_NODE);
	return translate_ExtDefList(root->childs[0]);
	
}

/**
  * 	ExtDefList -> ExtDef ExtDefList
  *		    | 空
  */
InterCodes *
translate_ExtDefList(struct TreeNode *pExtDefList)
{
	assert(pExtDefList->type == EXTDEFLIST_NODE);
	if(pExtDefList->numOfChilds == 0)		// ExtDefList -> 空
		return NULL;
							// ExtDefList -> ExtDef ExtDefList
	InterCodes *head1, *head2;
	head1 = translate_ExtDef(pExtDefList->childs[0]);
	head2 = translate_ExtDefList(pExtDefList->childs[1]);
	
	return join_InterCodes(head1,head2);
}
/*
 *  ExtDef -> Specifier ExtDecList SEMI
 *			| Specifier SEMI
 *  		| Specifier FunDec CompSt
 */
InterCodes *
translate_ExtDef(struct TreeNode *pExtDef)
{
	assert(pExtDef->type == EXTDEF_NODE);
	InterCodes *head1, *head2;
	
	if(pExtDef->childs[0]->childs[0]->type == STRUCTSPECIFIER_NODE)	// 包含了结构体的定义
	{
		TRANSLATE_RIGHT = 0;
		printf("Can not translate the code: Contain structure at line %d!\n", pExtDef->childs[0]->childs[0]->lineno);
		exit(0);
	}
	
	switch(pExtDef->childs[1]->type)
	{
		case EXTDECLIST_NODE:		// ExtDef -> Specifier ExtDecList SEMI, 全局变量的定义
			// 递归调用,这里可能出现[数组]的定义
			return translate_ExtDecList(pExtDef->childs[1]);	
			
		case SEMI_NODE:			// ExtDef -> Specifier SEMI, 结构体定义
			assert(0);			// here should never be reached 
			return NULL;
			
		case FUNDEC_NODE:		// ExtDef -> Specifier FunDec CompSt, 函数定义
			head1 = translate_FunDec(pExtDef->childs[1]);		// 翻译函数头
			head2 = translate_CompSt(pExtDef->childs[2]);		// 翻译函数体
			
			return join_InterCodes(head1, head2);		// 连接两个中间代码块并返回
			break;
		default:
			assert(0);		// here should never be reached
	}
}
/*
 * ExtDecList -> VarDec
 	      |	 VarDec COMMA ExtDecList
 */
InterCodes *
translate_ExtDecList(struct TreeNode* pExtDecList)	
{
	assert(pExtDecList->type == EXTDECLIST_NODE);
	InterCodes *head1 = translate_VarDec(pExtDecList->childs[0]), *head2;
	if(pExtDecList->numOfChilds == 1)
		return head1;
	else
	{
		assert(pExtDecList->numOfChilds == 3);
		head2 = translate_ExtDecList(pExtDecList->childs[2]);	// 递归调用自身
		return join_InterCodes(head1,head2);
	}
}
/*
 * VarDec -> ID 
 	   | VarDec LB INT RB
 */
InterCodes *
translate_VarDec(struct TreeNode* pVarDec)
{
	assert(pVarDec->type == VARDEC_NODE);
	if(pVarDec->numOfChilds == 4)		// VarDec -> VarDec LB INT RB
	{
		while(pVarDec->numOfChilds == 4)
			pVarDec = pVarDec->childs[0];
		
		return translate_Array_DEF(pVarDec->childs[0]);
	}
	
	return NULL;
}
/*
 * 数组类型定义的翻译
 */
InterCodes *
translate_Array_DEF(struct TreeNode* pID)
{
	Type array_type;
	Operand op;
	int array_size = 1;					// 数组元素的个数
	op = new_Operand(VARIABLE, get_var_no(pID->type_string), NULL);
	array_type = get_array_type(pID->type_string);
	assert(array_type != NULL);
	while(array_type->kind == ARRAY)
	{
		array_size *= array_type->u.array.size;
		array_type = array_type->u.array.elem;
	}
	
	return new_ir_dec(op, array_size*4);		// 每个int类型4个字节
}
/*
 * 函数头定义
 * FunDec -> ID LP VarList RP
 	      |  ID LP RP
 */
InterCodes *
translate_FunDec(struct TreeNode* pFunDec)
{
	assert(pFunDec->type == FUNDEC_NODE);
	InterCodes *code1, *code2;
	Operand op;
	assert(pFunDec->childs[0]->type_string != NULL);
	op = new_Operand(FUNCNAME, 0, pFunDec->childs[0]->type_string);
	code1 = new_ir_op(IR_FUNCTION, op);
	if(pFunDec->numOfChilds == 4)	// FunDec -> ID LP VarList RP
	{
			code2 = translate_VarList(pFunDec->childs[2]);
			code1 = join_InterCodes(code1,code2);
	}
	
	return code1;
}
/*
 * 函数形参列表
 * VarList -> ParamDec COMMA VarList
 	        | ParamDec 
 */
InterCodes *
translate_VarList(struct TreeNode* pVarList)
{
	assert(pVarList->type == VARLIST_NODE);	
	InterCodes *code1, *code2;
	code1 = translate_ParamDec(pVarList->childs[0]);
	if(pVarList->numOfChilds == 3)
	{
		code2 = translate_VarList(pVarList->childs[2]);
		code1 = join_InterCodes(code1, code2);
	}
	
	return code1;
}
/*
 * 函数头形参
 * ParamDec -> Specifier VarDec
 */
InterCodes *
translate_ParamDec(struct TreeNode* pParamDec)
{
	assert(pParamDec->type == PARAMDEC_NODE);
	if(pParamDec->childs[0]->childs[0]->type == STRUCTSPECIFIER_NODE)
	{
		TRANSLATE_RIGHT = 0;
		printf("Can not translate the code: Contain structure at line %d!\n", 
							pParamDec->childs[0]->childs[0]->lineno);
		exit(3);
	}
	Operand op;
	struct TreeNode* pID = pParamDec->childs[1]->childs[0];
	while(pID->type != ID_NODE)
		pID = pID->childs[0];
	if(get_var_type(pID->type_string)->kind == ARRAY)
		op = new_Operand(ADDRESS, get_var_no(pID->type_string), NULL);
	else
		op = new_Operand(VARIABLE, get_var_no(pID->type_string), NULL);
	
	return new_ir_op(IR_PARAM, op);
}
/*
 *	语句块
 *	CompSt -> LC DefList StmtList RC
*/
InterCodes *
translate_CompSt(struct TreeNode* pCompSt)
{
	assert(pCompSt->type == COMPST_NODE);
	InterCodes *code1, *code2;
	code1 = translate_DefList(pCompSt->childs[1]);
	code2 = translate_StmtList(pCompSt->childs[2]);
	
	return join_InterCodes(code1, code2);
}
/*
 * DefList -> Def DefList
 *          | 空
 */
InterCodes *
translate_DefList(struct TreeNode* pDefList)
{
	assert(pDefList->type == DEFLIST_NODE);
	if(pDefList->numOfChilds == 0)
		return NULL;
	InterCodes *code1, *code2;
	code1 = translate_Def(pDefList->childs[0]);
	code2 = translate_DefList(pDefList->childs[1]);
	
	return join_InterCodes(code1, code2);
}
/*
 * Def -> Specifier DecList SEMI
 *   
 */
InterCodes *
translate_Def(struct TreeNode* pDef)
{
	assert(pDef->type == DEF_NODE);
	if(pDef->childs[0]->childs[0]->type == STRUCTSPECIFIER_NODE)
	{
		TRANSLATE_RIGHT = 0;
		printf("Can not translate the code: Contain structure at line %d! \n",pDef->childs[0]->childs[0]->lineno);
		exit(2);
	}
	
	return translate_DecList(pDef->childs[1]);
}
/*
 * DecList -> Dec
 			| Dec COMMA DecList
 *   
 */
InterCodes *
translate_DecList(struct TreeNode* pDecList)
{
	assert(pDecList->type == DECLIST_NODE);
	InterCodes *code1, *code2;
	code1 = translate_Dec(pDecList->childs[0]);
	if(pDecList->numOfChilds == 3)
	{
		code2 = translate_DecList(pDecList->childs[2]);
		code1 = join_InterCodes(code1, code2);
	}
	
	return code1;
}
/*
 * Dec -> VarDec
 		| VarDec ASSIGNOP Exp
 *   
 */
InterCodes *
translate_Dec(struct TreeNode* pDec)
{
	assert(pDec->type == DEC_NODE);
	if(pDec->numOfChilds == 1)
		return translate_VarDec(pDec->childs[0]);
	// Dec -> VarDec ASSIGNOP Exp,数组类型不支持在定义时初始化
	assert(pDec->childs[0]->childs[0]->type == ID_NODE);
	
	InterCodes *code1, *code2, *code3;
	Operand result, op;
	result = new_Operand(VARIABLE, get_var_no(pDec->childs[0]->childs[0]->type_string), NULL);
	op = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
	
	code1 = translate_VarDec(pDec->childs[0]);
	code2 = translate_Exp(pDec->childs[2], op);
	code3 = new_ir_unaop(IR_ASSIGN, result, op);
	
	code1 = join_InterCodes(code1, code2);				// code1 + code2 + code3
	code1 = join_InterCodes(code1, code3);
	
	return code1;	
}
/**
  * StmtList的翻译
  * StmtList -> Stmt StmtList
  			  |  空
  */
InterCodes *
translate_StmtList(struct TreeNode *pStmtList)
{
 	assert(pStmtList->type == STMTLIST_NODE);
 	if(pStmtList->numOfChilds == 0)
	 	return NULL;
	 	
	// StmtList -> Stmt StmtList
	InterCodes *code1, *code2;
	code1 = translate_Stmt(pStmtList->childs[0]);
	code2 = translate_StmtList(pStmtList->childs[1]);
	
	return join_InterCodes(code1, code2);
}

/**
  * 语句的翻译
  * 
  */
InterCodes *
translate_Stmt(struct TreeNode *pStmt)
{
 	assert(pStmt->type == STMT_NODE);
 	Operand t1, label1, label2, label3;
 	InterCodes *code1, *code2, *code3;
 	
 	switch(pStmt->childs[0]->type)
 	{
 		case EXP_NODE:				// Stmt -> Exp SEMI
 			t1 = new_temp();		// this is never used
 			return translate_Exp(pStmt->childs[0], t1);
 			//return translate_Exp(pStmt->childs[0], NULL);
 			
 		case COMPST_NODE:			// Stmt -> CompSt
 			return translate_CompSt(pStmt->childs[0]);
 			
 		case RETURN_NODE:			// Stmt -> RETURN Exp SEMI
 			t1 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 			code1 = translate_Exp(pStmt->childs[1], t1);
 			code2 = new_ir_op(IR_RETURN, t1);
 			return join_InterCodes(code1, code2);
 			
 		case WHILE_NODE:			// Stmt -> WHILE LP Exp RP Stmt
 			label1 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 			label2 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 			label3 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 			
 			code1 = translate_Cond(pStmt->childs[2], label2, label3);
 			code2 = translate_Stmt(pStmt->childs[4]);
 			
 			// label1 + code1 + label2 + code2 + Goto label1 + label3
 			code1 = join_InterCodes(new_ir_op(IR_LABEL, label1), code1);
 			code1 = join_InterCodes(code1, new_ir_op(IR_LABEL, label2));
 			code1 = join_InterCodes(code1, code2);
 			code1 = join_InterCodes(code1, new_ir_op(IR_GOTO, label1));
 			
 			return join_InterCodes(code1, new_ir_op(IR_LABEL, label3));
 			
 		case IF_NODE:
 			if(pStmt->numOfChilds == 5)	// Stmt -> IF LP Exp RP Stmt 
 			{
 				label1 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 				label2 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 				code1 = translate_Cond(pStmt->childs[2], label1, label2);
 				code2 = translate_Stmt(pStmt->childs[4]);
 				
 				// code1 + label1 + code2 + label2
 				code1 = join_InterCodes(code1, new_ir_op(IR_LABEL, label1));
 				code1 = join_InterCodes(code1, code2);
 				
 				return join_InterCodes(code1, new_ir_op(IR_LABEL, label2));
 			}
 			else				// Stmt -> IF LP Exp RP Stmt ELSE Stmt
 			{
 				assert(pStmt->numOfChilds == 7);
 				label1 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 				label2 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 				label3 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 				code1 = translate_Cond(pStmt->childs[2], label1, label2);
 				code2 = translate_Stmt(pStmt->childs[4]);
 				code3 = translate_Stmt(pStmt->childs[6]);
 				
 				// code1 + label1 + code2 + Goto label3 + label2 + code3 + label3
 				code1 = join_InterCodes(code1, new_ir_op(IR_LABEL, label1));
 				code1 = join_InterCodes(code1, code2);
 				code1 = join_InterCodes(code1, new_ir_op(IR_GOTO, label3));
 				code1 = join_InterCodes(code1, new_ir_op(IR_LABEL, label2));
 				code1 = join_InterCodes(code1, code3);
 				
 				return join_InterCodes(code1, new_ir_op(IR_LABEL, label3));
 			}
 		default:
 			// here should never be reached
 			assert(0);
 	}
}
/*
 * 表达式的翻译
 */
InterCodes *
translate_Exp(struct TreeNode *pExp, Operand place)
{
 	assert(pExp->type == EXP_NODE);
 	Operand op, t1, t2, label1, label2;
 	InterCodes *code0, *code1, *code2, *code3, *code4;
 	FuncEntry p;
 	Type* type;
 	switch(pExp->childs[0]->type)
 	{
 		case INT_NODE:		// Exp -> INT
 			op = new_const(pExp->childs[0]->type_int);
 			return new_ir_unaop(IR_ASSIGN, place, op);		// place := #value
 			
 		case FLOAT_NODE:	// Exp -> FLOAT	
 			// here should never be reached
 			printf("Can not translate program with float type constant at line %d!\n", pExp->childs[0]->lineno);
 			exit(1);
 			
 		case LP_NODE:		// Exp -> LP Exp RP
 			return translate_Exp(pExp->childs[1], place);
 			
 		case MINUS_NODE:	// Exp -> MINUS Exp
 			t1 = new_temp();
 			code1 = translate_Exp(pExp->childs[1], t1);
 			code2 = new_ir_binop(IR_SUB, place, new_const(0), t1);
 			
 			return join_InterCodes(code1, code2);
 			
 		case ID_NODE:
 			switch(pExp->numOfChilds)
 			{
 				case 1:			// Exp -> ID
 					op = get_var(pExp->childs[0]->type_string);
 					return new_ir_unaop(IR_ASSIGN, place, op);			// place := variable.name
 					
 				case 3:			// Exp -> ID LP RP
 					if(strcmp(pExp->childs[0]->type_string, "read") == 0)
 						return new_ir_op(IR_READ, place);
 					else
 						return new_ir_unaop(IR_CALL, place, new_func(pExp->childs[0]->type_string));
 					
 				case 4:			// Exp -> ID LP Args RP
 					
 					if(strcmp(pExp->childs[0]->type_string, "write") == 0)
 					{
 						t1 = new_temp();
 						code1 = translate_Exp(pExp->childs[2]->childs[0], t1);
 						code2 = new_ir_op(IR_WRITE, t1);
 						
 						return join_InterCodes(code1, code2);
 					}
 					else
 					{
 						p = getFuncEntry(pExp->childs[0]);		// 函数的参数列表
 						code1 = translate_Args(pExp->childs[2], p);
 						code2 = new_ir_unaop(IR_CALL, place, new_Operand(FUNCNAME, 0, pExp->childs[0]->type_string));
 						return join_InterCodes(code1, code2);
 					}
 					
 				default:
 					assert(0);	// here should never be reached
 					
 			}
 			
 			break;
 		case EXP_NODE:
 			switch(pExp->childs[1]->type)
 			{
 				case ASSIGNOP_NODE:	// Exp -> Exp1 ASSIGNOP Exp2
 					
 					// 左值为ID
 					if(pExp->childs[0]->numOfChilds == 1)					// Exp1 -> ID
 					{
 						t1 = new_temp();
 						assert(pExp->childs[0]->childs[0]->type == ID_NODE);
 						op = get_var(pExp->childs[0]->childs[0]->type_string);
 						code1 = translate_Exp(pExp->childs[2], t1);
 						code2 = new_ir_unaop(IR_ASSIGN, op, t1);
 						
 						if(place != NULL)
 						{
 							code3 = new_ir_unaop(IR_ASSIGN, place, op);
 							code2 = join_InterCodes(code2, code3);
 						}
 						return join_InterCodes(code1, code2);
 					}		// 左值为数组访问
 					else
 					{
 						t1 = new_temp();
						t2 = new_temp();
						type = (Type *)malloc(sizeof(Type *));
	 					code1 = translate_Array_USE(pExp->childs[0], t1, type);	//t2存放要写的数组的地址
	 					code2 = translate_Exp(pExp->childs[2], t2);			// 翻译Exp2
	 					code3 = new_ir_unaop(IR_MEM_L, t1, t2);				// *t1 := t2
	 					if(place != NULL)
	 					{
	 						code4 = new_ir_unaop(IR_MEM_R, place, t1);		// place := *t1
	 						code3 = join_InterCodes(code3, code4);
	 					}
	 					// code1 + code2 + code3 + code4
 						code1 = join_InterCodes(code1, code2);
 						code1 = join_InterCodes(code1, code3);
 					
 						return code1;
	 				}
	 				
 				case PLUS_NODE:		// Exp -> Exp PLUS Exp
 					t1 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 					t2 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 					code1 = translate_Exp(pExp->childs[0], t1);
 					code2 = translate_Exp(pExp->childs[2], t2);
 					code3 = new_ir_binop(IR_ADD, place, t1, t2);
 					
 					code1 = join_InterCodes(code1, code2);		// code1 + code2 + code3
 					code1 = join_InterCodes(code1, code3);
 					return code1;
 					
 				case MINUS_NODE:	// Exp -> Exp MINUS Exp
 					t1 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 					t2 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 					code1 = translate_Exp(pExp->childs[0], t1);
 					code2 = translate_Exp(pExp->childs[2], t2);
 					code3 = new_ir_binop(IR_SUB, place, t1, t2);
 					
 					code1 = join_InterCodes(code1, code2);		// code1 + code2 + code3
 					code1 = join_InterCodes(code1, code3);
 					return code1;
 					
 				case STAR_NODE:		// Exp -> Exp STAR Exp
 					t1 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 					t2 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 					code1 = translate_Exp(pExp->childs[0], t1);
 					code2 = translate_Exp(pExp->childs[2], t2);
 					code3 = new_ir_binop(IR_MUL, place, t1, t2);
 					
 					code1 = join_InterCodes(code1, code2);		// code1 + code2 + code3
 					code1 = join_InterCodes(code1, code3);
 					return code1;
 					
 				case DIV_NODE:		// Exp -> Exp DIV Exp
 					t1 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 					t2 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 					code1 = translate_Exp(pExp->childs[0], t1);
 					code2 = translate_Exp(pExp->childs[2], t2);
 					code3 = new_ir_binop(IR_DIV, place, t1, t2);
 					
 					code1 = join_InterCodes(code1, code2);		// code1 + code2 + code3
 					code1 = join_InterCodes(code1, code3);
 					return code1;
 					
 				case LB_NODE:		// Exp -> Exp LB Exp RB,数组类型的翻译
 					// 注意：下面的翻印用于数组［读］
 					t1 = new_temp();
 					type = (Type *)malloc(sizeof(Type *));
 					code1 = translate_Array_USE(pExp, t1, type);
 					code2 = new_ir_unaop(IR_MEM_R, place, t1);
 					return join_InterCodes(code1, code2);
 					
 				case DOT_NODE:		// Exp -> Exp DOT ID
 					// here should never be reached
 					assert(0);
 					break;
 			
 			}
 			break;
 		default:
 			/* Exp -> NOT Exp
 				   | Exp AND Exp
 				   | Exp OR Exp
 				   | Exp RELOP Exp 
 			*/
 			label1 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 			label2 = new_Operand(LABEL, get_LABEL_NO(), NULL);
 			code0 = new_ir_unaop(IR_ASSIGN, place, new_Operand(CONSTANT, 0, NULL));
 			code1 = translate_Cond(pExp, label1, label2);
 			code2 = new_ir_op(IR_LABEL, label1);
 			code3 = new_ir_unaop(IR_ASSIGN, place, new_Operand(CONSTANT, 1, NULL));
 			// code0 + code1 + code2 + code3 + label2
 			code0 = join_InterCodes(code0, code1);
 			code0 = join_InterCodes(code0, code2);
 			code1 = join_InterCodes(code0, code3);
 			
 			return join_InterCodes(code0, new_ir_op(IR_LABEL, label2));
 	}
 	
 	return NULL;
}
/*
 * Exp -> Exp1 LB Exp2 RB
 */
InterCodes *
translate_Array_USE(struct TreeNode *pExp, Operand place, Type* type)	// type用于传递各个维度的宽度[引用类型]
{
	assert(pExp->childs[1]->type == LB_NODE);
	Operand base, t1, t2, offset;
	InterCodes *code1, *code2, *code3, *code4;
	Type array_type;
	Type *my_type;
	if(pExp->childs[0]->childs[0]->type == ID_NODE)
	{
		array_type = typeCopy(get_array_type(pExp->childs[0]->childs[0]->type_string));
		array_type = array_switch(array_type);
		set_array_width(array_type);		// 计算每一维的宽度
		
		*type = array_type->u.array.elem;	// 设置引用变量的值
		
		assert(array_type->kind == ARRAY);
		t1 = new_temp();
		t2 = get_var(pExp->childs[0]->childs[0]->type_string);
		offset = new_temp();		// 偏移
		base = new_temp();			// 数组基地址
		
		code1 = translate_Exp(pExp->childs[2], t1);
		//code2 = new_ir_binop(IR_MUL, offset, t1, new_const(4));
		code2 = new_ir_binop(IR_MUL, offset, t1, new_const(array_type->u.array.width));
		if(get_fun_param_type(pExp->childs[0]->childs[0]->type_string) == 1)
			code3 = new_ir_unaop(IR_ASSIGN, base, t2);			// 本身作为地址参数传入
		else
			code3 = new_ir_unaop(IR_ADDR, base, t2);			// 取数组元素的首地址 base = &array
		code4 = new_ir_binop(IR_ADD, place, base, offset);	// 计算base

		code1 = join_InterCodes(code1, code2);
		code1 = join_InterCodes(code1, code3);

		return join_InterCodes(code1, code4);
	}
	else
	{
		t1 = new_temp();
		t2 = new_temp();
		base = new_temp();
		my_type = (Type *)malloc(sizeof(Type *));
		code1 = translate_Array_USE(pExp->childs[0], base, my_type);		// 递归调用自身
		code2 = translate_Exp(pExp->childs[2], t1);
		code3 = new_ir_binop(IR_MUL, t2, t1, new_const((*my_type)->u.array.width));
		code4 = new_ir_binop(IR_ADD, place, base, t2);
		
		*type = (*my_type)->u.array.elem;		// 设置引用变量的值
		
		// code1 + code2 + code3
		code1 = join_InterCodes(code1, code2);
		code1 = join_InterCodes(code1, code3);
		
		return join_InterCodes(code1, code4);
		/*
		// 高维数组
		printf("Can not translate the code: \n");
		
		return NULL;
		*/
	}
		
		
}

/**
  * 条件表达式的翻译
  * 
  */
InterCodes *
translate_Cond(struct TreeNode *pExp, Operand label_true, Operand label_false)
{
 	assert(pExp->type == EXP_NODE);
 	Operand t1, t2, label1;
 	InterCodes *code1, *code2, *code3;
 	if(pExp->numOfChilds >= 2)
 	{
	 	switch(pExp->childs[1]->type)
	 	{
	 		case RELOP_NODE:		// Exp -> Exp RELOP Exp
	 			t1 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
	 			t2 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
	 			code1 = translate_Exp(pExp->childs[0], t1);
	 			code2 = translate_Exp(pExp->childs[2], t2);
	 			code3 = new_ir_relop(t1, t2, label_true, pExp->childs[1]->type_string);
	 			
	 			// code1 + code2 + code3 + GOTO label_false
	 			code1 = join_InterCodes(code1, code2);
	 			code1 = join_InterCodes(code1, code3);
	 			
	 			return join_InterCodes(code1, new_ir_op(IR_GOTO, label_false));
	 			
	 		case EXP_NODE:			// Exp -> NOT Exp
	 			return translate_Cond(pExp->childs[1], label_false, label_true);
	 			
	 		case AND_NODE:			// Exp -> Exp AND Exp
	 			label1 = new_Operand(LABEL, get_LABEL_NO(), NULL);
	 			code1 = translate_Cond(pExp->childs[0], label1, label_false);
	 			code2 = translate_Cond(pExp->childs[2], label_true, label_false);
	 			
	 			// code1 + label1 + code2
	 			code1 = join_InterCodes(code1, new_ir_op(IR_LABEL, label1));
	 			
	 			return join_InterCodes(code1, code2);
	 			
	 		case OR_NODE:			// Exp -> Exp OR Exp
	 			label1 = new_Operand(LABEL, get_LABEL_NO(), NULL);
	 			code1 = translate_Cond(pExp->childs[0], label_true, label1);
	 			code2 = translate_Cond(pExp->childs[2], label_true, label_false);
	 			
	 			// code1 + label1 + code2
	 			code1 = join_InterCodes(code1, new_ir_op(IR_LABEL, label1));
	 			
	 			return join_InterCodes(code1, code2);
	 		
	 		default:
	 			// here should never be reached
	 			assert(0);
	 	}
	 }
 	 else
 	 {
 	 	Operand t1;
 	 	InterCodes *code1, *code2, *code3;
 	 	t1 = new_temp();
 	 	code1 = translate_Exp(pExp, t1);
 	 	code2 = new_ir_relop(t1, new_const(0), label_true, "!=");
 	 	code3 = new_ir_op(IR_GOTO, label_false);
 	 	
 	 	// code1 + code2 + code3
 	 	code1 = join_InterCodes(code1, code2);
		return join_InterCodes(code1, code3) 	 	;
 	 }
}
/**
  * 实参的翻译
  *	Args -> Exp COMMA Args
  *	      | Exp
  */
InterCodes*
translate_Args(struct TreeNode *pArgs, FuncEntry p)
{
 	assert(pArgs->type == ARGS_NODE);
 	Operand t1;
 	InterCodes *code1 = NULL, *arg_list = NULL;
 	int i = 0;
 	while(1)
 	{
 		t1 = new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
 		code1 = join_InterCodes(code1, translate_Exp(pArgs->childs[0], t1));
 		
 		
 		if(p->argsTypes[i]->kind == BASIC)		// 函数参数为普通变量类型
 			arg_list = join_InterCodes(new_ir_op(IR_ARG_VAL, t1), arg_list);
 		else									// 数组类型
 		{
 			arg_list = join_InterCodes(new_ir_op(IR_ARG_REF, t1), arg_list);
 		}
		
 		
 		if(pArgs->numOfChilds == 1)
 			break;
 		pArgs = pArgs->childs[2];
 		i ++;
 	}
 	assert(++i == p->numOfArgs);
 	return join_InterCodes(code1, arg_list);
}


/*
 * 连接两个存放中间代码的双向链表
 * head1中间代码块在head2代码块之前
*/
InterCodes *
join_InterCodes(InterCodes *head1, InterCodes *head2)
{
	if(head1 == NULL)
		return head2;
	if(head2 == NULL)
		return head1;

	InterCodes *tmp;	// 指向第二个链表的尾巴
	tmp = head2->prev;
	head1->prev->next = head2;
	head2->prev->next = head1;
	head2->prev = head1->prev;
	head1->prev = tmp;
	
	return head1;
}

/*
 * 创建一个操作数
 	operand_kind: 操作数类型
 	no_val:	变量编号/整形常数值
 	func_name: 函数标号使用，其他类型为NULL
 */
Operand 
new_Operand(unsigned int operand_kind,unsigned int no_val, char* func_name)
{
	Operand op;
	op = (Operand)malloc(sizeof(struct Operand_));
	assert(op != NULL);
	op->kind = operand_kind;
	if(func_name != NULL)
	{
		assert(operand_kind == FUNCNAME);
		op->u.func_name = (char *)malloc(strlen(func_name) + 1);
		strcpy(op->u.func_name, func_name);
	}
	else
		op->u.var_no = no_val;
		
	
	return op;
}
/*
 * 新建一个临时变量
 */
Operand
new_temp()
{
	return new_Operand(TEMP_VAR, get_TEMP_VAR_NO(), NULL);
}

Operand 
get_var(char *name)
{
	return new_Operand(VARIABLE, get_var_no(name), NULL);
}

Operand
new_func(char *func_name)
{
	return new_Operand(FUNCNAME, 0, func_name);
}
Operand 
new_const(int constant)
{
	return new_Operand(CONSTANT, constant, NULL);
}

/*	创建一条只有一个操作数的中间代码
 * 
 * IR_LABEL,IR_FUNCTION,IR_GOTO,IR_RETURN,IR_ARG_VAL, IR_ARG_REF,IR_PARAM,IR_READ,IR_WRITE
 *
 */
InterCodes*
new_ir_op(unsigned int ir_type, Operand op)
{
	InterCodes* ir;
	ir = (InterCodes *)malloc(sizeof(struct InterCodes));
	assert(ir != NULL);
	ir->code.kind = ir_type;
	ir->code.u.op = op;
	ir->next = ir->prev = ir;	// 首尾连接
	
	return ir;
}
/* 
 * 创建一条中间代码
 * 单目运算:IR_ASSIGN,IR_ADDR,IR_MEM_R,IR_MEM_L,IR_CALL,
 *
 */
InterCodes*
new_ir_unaop(unsigned int ir_type, Operand result, Operand op)
{
	assert(result != NULL);
	
	InterCodes* ir;
	ir = (InterCodes *)malloc(sizeof(struct InterCodes));
	assert(ir != NULL);
	ir->code.kind = ir_type;
	ir->code.u.unaop.result = result;
	ir->code.u.unaop.op = op;
	ir->next = ir->prev = ir;	// 首尾连接
	
	return ir;
}
/*
 * 创建一条中间代码
 * 双目运算：IR_ADD,IR_SUB,IR_MUL,IR_DIV
**/
InterCodes*
new_ir_binop(unsigned int ir_type, Operand result, Operand op1, Operand op2)
{
	assert(result != NULL && op1 != NULL && op2 != NULL);
	InterCodes* ir;
	ir = (InterCodes *)malloc(sizeof(struct InterCodes));
	assert(ir != NULL);
	ir->code.kind = ir_type;
	ir->code.u.binop.result = result;
	ir->code.u.binop.op1 = op1;
	ir->code.u.binop.op2 = op2;
	ir->next = ir->prev = ir;	// 首尾连接
	
	return ir;
}
/*
 * 创建一条中间代码: IR_DEC
 * 
**/
InterCodes*
new_ir_dec(Operand op, int size)
{
	assert(op != NULL && size % 4 == 0 && size > 0);
	InterCodes* ir;
	ir = (InterCodes *)malloc(sizeof(struct InterCodes));
	assert(ir != NULL);
	ir->code.kind = IR_DEC;
	ir->code.u.dec.op = op;
	ir->code.u.dec.size = size;
	ir->next = ir->prev = ir;	// 首尾连接
	
	return ir;
}
/*
 * 创建一条中间代码 IR_RELOP
**/
InterCodes*
new_ir_relop(Operand op1, Operand op2, Operand label, char *relop)
{
	assert(label != NULL && op1 != NULL && op2 != NULL && relop != NULL);
	InterCodes* ir;
	ir = (InterCodes *)malloc(sizeof(struct InterCodes));
	assert(ir != NULL);
	ir->code.kind = IR_RELOP;
	ir->code.u.relop.label = label;
	ir->code.u.relop.op1 = op1;
	ir->code.u.relop.op2 = op2;
	ir->code.u.relop.relop = (char *)malloc(strlen(relop) + 1);
	strcpy(ir->code.u.relop.relop, relop);
	ir->next = ir->prev = ir;	// 首尾连接
	
	return ir;
}

/*
 * 中间代码打印
 */

void printIR(InterCodes *head)
{
	if(head == NULL)
		return ;
	
	InterCodes *p;  				// 扫描指针
	Operand result;
	unsigned int op_kind;			// 操作数类型
	p = head;
	do
	{
		op_kind = p->code.u.op->kind;
		switch(p->code.kind)
		{
			case IR_LABEL:
				assert(op_kind == LABEL);
				printf("LABEL %s%d :", SIGN[op_kind], p->code.u.op->u.label_no);
				break;
			case IR_FUNCTION:
				assert(op_kind == FUNCNAME);
				printf("\nFUNCTION %s :", p->code.u.op->u.func_name);
				break;
			case IR_ASSIGN:			// 赋值号左边为用户定义的变量或者临时变量
				result = p->code.u.unaop.result;
				/* VERY IMPORTANT */
				if(result == NULL)
					return ;
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				printOperand(result);			// 打印操作数result
				printf("%s", " := ");
				printOperand(p->code.u.unaop.op);
				break;
			case IR_ADD:
				result = p->code.u.binop.result;
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				printOperand(result);			// 打印操作数result
				printf("%s", " := ");
				printOperand(p->code.u.binop.op1);
				printf("%s", " + ");
				printOperand(p->code.u.binop.op2);
				break;
			case IR_SUB:
				result = p->code.u.binop.result;
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				printOperand(result);			// 打印操作数result
				printf("%s", " := ");
				printOperand(p->code.u.binop.op1);
				printf("%s", " - ");
				printOperand(p->code.u.binop.op2);
				break;
			case IR_MUL:
				result = p->code.u.binop.result;
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				printOperand(result);			// 打印操作数result
				printf("%s", " := ");
				printOperand(p->code.u.binop.op1);
				printf("%s", " * ");
				printOperand(p->code.u.binop.op2);
				break;
			case IR_DIV:
				result = p->code.u.binop.result;
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				printOperand(result);			// 打印操作数result
				printf("%s", " := ");
				printOperand(p->code.u.binop.op1);
				printf("%s", " / ");
				printOperand(p->code.u.binop.op2);
				break;
			case IR_ADDR:
				result = p->code.u.unaop.result;
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				printOperand(result);
				printf("%s"," := &");
				printOperand(p->code.u.unaop.op);
				break;
			case IR_MEM_R:
				result = p->code.u.unaop.result;
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				printOperand(result);
				printf("%s"," := *");
				printOperand(p->code.u.unaop.op);
				break;
			case IR_MEM_L:
				result = p->code.u.unaop.result;
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				printf("*");
				printOperand(result);
				printf("%s"," := ");
				printOperand(p->code.u.unaop.op);
				break;
			
			case IR_GOTO:
				assert(op_kind == LABEL);
				printf("GOTO %s%d", SIGN[op_kind], p->code.u.op->u.label_no);
				break;
			
			case IR_RELOP:
				printf("IF ");
				printOperand(p->code.u.relop.op1);
				printf(" %s ", p->code.u.relop.relop);
				printOperand(p->code.u.relop.op2);
				printf(" GOTO ");
				printOperand(p->code.u.relop.label);
				break;
			case IR_RETURN:			// 返回的可能是：常量/用户定义的变量/ 临时变量
				op_kind = p->code.u.op->kind;
				assert(op_kind == CONSTANT || op_kind == VARIABLE || op_kind == TEMP_VAR);
				printf("RETURN %s%d", SIGN[op_kind], p->code.u.op->u.var_no);
				break;
			case IR_DEC:
				printf("DEC ");
				printOperand(p->code.u.dec.op);
				printf(" %d",p->code.u.dec.size);
				break;
			case IR_ARG_VAL:			// pass by vale,值传递
				printf("ARG %s%d", SIGN[op_kind], p->code.u.op->u.var_no);
				break;
			case IR_ARG_REF:			// pass by reference, 引用传递
				printf("ARG &%s%d", SIGN[op_kind], p->code.u.op->u.var_no);
				break;
			case IR_CALL:
				result = p->code.u.unaop.result;
				assert(result->kind == VARIABLE || result->kind == TEMP_VAR);
				printOperand(result);
				printf("%s"," := CALL ");
				assert(p->code.u.unaop.op->kind == FUNCNAME);
				printOperand(p->code.u.unaop.op);
				break;
			
			case IR_PARAM:				// PARAM之后跟的一定是用户定义的变量
				assert(op_kind == VARIABLE || op_kind == ADDRESS);
				printf("PARAM %s%d", SIGN[op_kind], p->code.u.op->u.var_no);
				break;
			case IR_READ:
				printf("READ %s%d", SIGN[op_kind], p->code.u.op->u.var_no);
				break;
			case IR_WRITE:
				printf("WRITE %s%d", SIGN[op_kind], p->code.u.op->u.var_no);
				break;
			default:
				assert(0);	// here should never be reached
			
		}
		printf("\n");
		p = p->next;
	}while(p != head);
	
}




/*
 * 打印操作数
 */
void 
printOperand(Operand operand)
{
	assert(operand != NULL);
	if(operand->kind == FUNCNAME)
		printf("%s",operand->u.func_name);
	else
		printf("%s%d",SIGN[operand->kind],operand->u.var_no);
}
/*
 * 给新创建的临时变量进行编号
 */
unsigned int
get_TEMP_VAR_NO()
{
	return ++ TEMP_VAR_NO;
}
unsigned int
get_LABEL_NO()
{
	return ++ LABEL_NO;
}




