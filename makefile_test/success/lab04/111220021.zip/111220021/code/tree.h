#ifndef _TREE_H_
#define _TREE_H_

// 各个节点的类型：非叶子节点
#define PROGRAM_NODE 		0
#define EXTDEFLIST_NODE		1
#define EXTDEF_NODE		2
#define EXTDECLIST_NODE		3
#define SPECIFIER_NODE		4
#define STRUCTSPECIFIER_NODE 	5
#define OPTTAG_NODE		6
#define TAG_NODE		7
#define VARDEC_NODE		8
#define FUNDEC_NODE		9
#define VARLIST_NODE		10
#define PARAMDEC_NODE		11
#define COMPST_NODE		12
#define STMTLIST_NODE		13
#define STMT_NODE		14
#define DEFLIST_NODE		15
#define DEF_NODE		16
#define DECLIST_NODE		17
#define DEC_NODE		18
#define EXP_NODE		19
#define ARGS_NODE		20

// 各个节点的类型：叶子节点
#define INT_NODE	21
#define FLOAT_NODE	22
#define ID_NODE		23
#define	SEMI_NODE	24
#define COMMA_NODE	25
#define ASSIGNOP_NODE	26
#define RELOP_NODE	27
#define PLUS_NODE	28
#define MINUS_NODE	29
#define STAR_NODE	30
#define DIV_NODE	31
#define AND_NODE	32
#define OR_NODE		33
#define DOT_NODE	34
#define NOT_NODE	35
#define TYPE_NODE	36
#define LP_NODE		37
#define RP_NODE		38
#define LB_NODE		39
#define RB_NODE		40
#define LC_NODE		41
#define RC_NODE		42
#define STRUCT_NODE	43
#define RETURN_NODE	44
#define	IF_NODE		45
#define ELSE_NODE	46
#define WHILE_NODE	47


// 多叉树节点类型
typedef struct TreeNode TreeNode;

struct TreeNode
{
	char nodeType[32];			// 节点类型	
	int type;					// 节点类型（为了方便语义分析加上）
	int numOfChilds;			// 字节点个数
	int lineno;					// 行号
	int isLeaf;					// 是否是叶子节点(1:是，0：不是)
	char type_string[32];		// 存放数据值(ID/int/float/RELOP字符串),假设所有标识符的长度小于32
	int type_int;				// 存放int型变量的值
	float type_float;			// 存放float型变量的值
	struct TreeNode* childs[7];	// 子字节点指针(最大七个字节点)
} ;

extern int isProgramRight;		// 程序是否出现语法错误 1:正确，0错误
extern struct TreeNode* Root;

TreeNode* createNode(char* nodeType,int numOfChilds,int lineno,...);	// 创建中间结点
TreeNode* createLeaf(char* nodeType,int lineno);			// 创建叶子节点
void printTree(TreeNode* root,int blanks);				// 打印语法树
void destroyTree(TreeNode* root);					// 释放申请的内存空间

#endif
