
#ifndef _TARGET_H_
#define _TARGET_H_

struct FuncLayout
{
	char *funcName;	// 函数名
	int var_size;	// 该函数内的变量的空间的大小
	
	struct FuncLayout *prev;
	struct FuncLayout *next;
};

// var/temp var layout in memory(Stack)
struct VarLayout
{
	int var_or_temp;	// 变量/临时变量类型
	int no;		        // 变量编号
	int offset;		    // 偏移栈顶的偏移量
	int len;		    // 长度，整数类型为4，数组要乘以数组元素个数
	
	struct VarLayout *next;
	struct VarLayout *prev;
};

// 参数传递机制
// 插入时逆向插入，取参数时正向取
struct ArgList
{
	int arg_offset;		// 要传递的参数的在statck中的位置
	
	struct ArgList *prev;
	struct ArgList *next;
};

extern struct FuncLayout* FUNC_LAY_HEAD;	// 函数stack布局双向链表头
extern struct VarLayout* VAR_LAY_HAED;
extern struct ArgList* CUR_ARG_LIST_HEAD;	// 当前函数调用使用的参数位置列表
extern int global_offset;

// 打印中间代码的头部
void printTarHead(FILE *p_out) ;

// 初始化函数
void layoutInit();

// 根据函数名从链表查找函数中的变量的要分配的空间的大小
int getFuncVarSize(char *funcName);
// 将一个函数添加到函数的布局表中
void addFuncNameToList(char *funcName);
// 设置一个函数的stack上变量空间的大小
void setFuncVarSize(char *funcName, int var_size);
// 根据函数名查找其在函数布局表中的指针位置
struct funcLayout* getFuncLayEntry(char *funcName);


// 创建一个新的stack空间布局变量
struct VarLayout* newVarInLayout(int var_or_temp, int no, int offset, int len);
// 添加变量到stack变量布局表中
void addVarInLayout(int var_or_temp, int no, int offset, int len);
// 获取指定变量的相对statck point的偏移
int getVarOffset(int var_or_temp, int no);
// 扫描中间代码列表建立变量(用户定义 + 临时变量)satck布局表
void getVarStackLayoutList(struct InterCodes *head);
// ARG v,由于传递实在参数时，参数顺序与PARAM的顺序的是反的，所以每次插入新的参数时插在头部
void addArgAtListHead(int arg_offset);
// 从当前函数调用使用的参数位置列表中取参数(从表头取),并将该参数从列表中删除，这样每次就都能在列表头部取到参数了
int getArgAtListHead();
// 目标代码生成函数
void printTar(InterCodes *head, FILE *p_out);
// 函数的翻译
void tran_function(InterCodes *p, FILE *);
// 翻译赋值语句
void tran_assign(InterCodes *p, FILE *);
// 翻译加法
void tran_add(InterCodes* p, FILE *);
// 翻译减法
void tran_sub(InterCodes* p, FILE *);
// 乘法翻译
void tran_mul(InterCodes *p, FILE *);
// 除法翻译
void tran_div(InterCodes *p, FILE *);
// x = *y翻译
void tran_mem_R(InterCodes *p, FILE *);
// *x = y翻译
void tran_mem_L(InterCodes *p, FILE *);
// 翻译函数调用语句 x = CALL f
void tran_call(InterCodes *p, FILE *);
// return x语句的翻译
void tran_return(InterCodes *p, FILE *);
// 条件跳转的翻译 if x relop y GOTO z
void tran_relop(InterCodes *p, FILE *);
// READ函数调用的翻译
void tran_read(InterCodes *p, FILE *);
// write函数调用的翻译 write t
void tran_write(InterCodes *p, FILE *);
// goto 语句的翻译
void tran_goto(InterCodes *p, FILE *);
// LABEL x的翻译
void tran_label(InterCodes *p, FILE *);
// Arg x 参数传递的翻译
void tran_arg(InterCodes **p, FILE *);
// PARAM x的翻译
void tran_param(InterCodes **p, FILE *);
// x = &y的翻译 
void tran_addr(InterCodes *p, FILE *);
// Dec x 12 1-d数组类型的翻译
void tran_dec(InterCodes *p, FILE *);
#endif
