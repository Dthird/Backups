/**
 *	语义分析头文件
 *
 *
 */
#ifndef _SEMANTIC_H_
#define _SEMANTIC_H_

#include "tree.h"

typedef int bool;		// bool类型定义
typedef unsigned int Index;	// 散列表访问下标

#define TRUE 1
#define FALSE 0
#define BASIC 0
#define ARRAY 1
#define STRUCTURE 2
#define TABLE_SIZE (1 << 14)		// 散列表大小(2^14)
#define INT_TYPE 0			// 基本类型
#define FLOAT_TYPE 1
#define MAX_NEST_LEVEL 1024		// 顺序栈大小(最大嵌套层次)

#define VAR_NOT_DEFINED			0	// 变量未定义
#define VAR_DEFINED_AT_SAME_LEVEL	1	// 变量在本层次内定义
#define VAR_DEFINED_AT_UPPER_LEVEL	2	// 变量在本嵌套层之外定义

typedef struct Type_* Type;
typedef struct FieldList_* FieldList;
typedef struct FuncEntry_* FuncEntry;
typedef struct LevelList_* LevelList;


FuncEntry  FuncTb[TABLE_SIZE];		// 函数名符号表
FieldList  VarTb[TABLE_SIZE];		// 变量名符号表
FieldList Stack[MAX_NEST_LEVEL];	// 用于处理嵌套层次的栈结构

int top;				// 栈顶指针(即当前所处的嵌套层次)

struct Type_
{
	enum { BASIC_, ARRAY_, STRUCTURE_ }  kind;
	union
	{
		int basic;								// 基本类型
		struct { Type elem; int size, width; } array;	// 数组类型信息：元素类型，数组大小,该维度的宽度
		struct 
		{ 
			char *struct_name; 					// 结构体名字(名等价判断使用)
			FieldList fieldList;				// 结构体的域的链表
		} structure;	
	} u;
} ;

// 使用双向循环链表

struct FieldList_
{
	char *name;			// 域的名字
	Type type;			// 域的类型
	int level;			// 变量定义时所处的嵌套层次
	int is_addr;					// 函数参数为数组类型，传递实参时实际传递的是地址(lab03)
	unsigned int var_no;			// 用户定义的变量编号(lab03 added)
	FieldList tail;		// 下一个域指针
	FieldList head;		// 前一个域指针
	FieldList next;		// 同嵌套级别的下一个指针
	FieldList prev;		// 同嵌套级别的前一个指针
};

struct FuncEntry_
{
	char *name;			// 函数名
	Type retType;		// 返回类型
	int numOfArgs;		// 参数个数
	Type* argsTypes;	// 参数类型
	FuncEntry tail;		// 下一个域指针
};

unsigned int hash_pjw(char* name); 				// 散列函数
void Semantic_Init();							// 初始化函数:初始化层次栈Stack,变量符号表VarTb，函数名符号表FuncTb
void semanticAnalysis(struct TreeNode *root);	// 语法分析函数：root为语法树的根节点

void InsertFunc(char *name,Type retType,int numOfArgs,Type* argsTypes);	// 向函数名符号表插入函数名等信息
Type getType(struct TreeNode* specifier);
Type getType2(struct TreeNode* pSpecifier, struct TreeNode* pVarDec);
Type getExpType(struct TreeNode *pExp);
FuncEntry getFuncEntry(struct TreeNode* pID);		// 取函数参数列表

bool isTypesEqual(Type t1,Type t2);
Type typeCopy(Type srcType);			// 结构体类型深度复制
void freeType(Type type);				// 释放申请的内存空间

unsigned int get_var_no(char *name);	// 根据变量名查找该变量的编号(lab03 added)
Type get_array_type(char *name);		// 根据数组名字取其类型
Type get_var_type(char *name);			// 根据普通变量名字取其类型
int set_array_width(Type type);			// 计算数组每一维度的宽度(lab03 added)
void set_fun_param(char* param_name);
int get_fun_param_type(char* param_name);
Type array_switch(Type type);			// 多维数组的size序是反的，要条过来
#endif

