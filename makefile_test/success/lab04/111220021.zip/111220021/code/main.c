
#include <stdio.h>
#include <stdlib.h>

#include "translate.h"	
#include "target.h"

extern int yyparse();
extern void yyrestart(FILE *);

int main(int argc, char** argv)
{
	if(argc < 3)
	{
		printf("Usage: ./cc test_filename.cmm output_filename.s\n");
		return 1;
	}
	FILE *f_in = fopen(argv[1],"r");		// �����ļ�
	FILE *f_out = fopen(argv[2], "w");		// ����ļ�
	if(!f_in)
	{
		perror(argv[1]);
		return 1;
	}
	if(!f_out)
	{
		perror(argv[2]);
		return 1;
	}
	yyrestart(f_in);
	yyparse();
	
	if(isProgramRight)
	{
		//printTree(Root,0);
		Semantic_Init();
		semanticAnalysis(Root);		// 语义分析
		IR_LIST_HEAD = translate_Program(Root);		// 中间代码生成
		if(TRANSLATE_RIGHT)
		{
			//printIR(IR_LIST_HEAD);
			printTar(IR_LIST_HEAD, f_out);	// ���Ŀ����뵽�ļ�
		}
		
		
	}
	
	return 0;
}













