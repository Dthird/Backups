/**
 *	语义分析源文件	
*/


#include <stdlib.h>		// malloc()
#include <stdio.h>		// perror(),printf()
#include <string.h>		// strcmp()
#include <assert.h>

#include "semantic.h"

Type IntType;				// int常量类型
Type FloatType;				// float常量类型
Type latestRetType;			// 最新定义的函数的返回值类型
unsigned int VAR_NO = 0;	// 用户定义的变量的编号(lab03 added)

unsigned int hash_pjw(char* name)
{
	unsigned int val = 0,i;
	for( ; *name; ++name)
	{
		val = (val << 2) + *name;
		i = val;
		if(i & ~0x3fff)
			val = (val ^ (i >> 12)) & 0x3fff;
	}
	
	return val;
}

/*
	全局初始化函数
*/
void
Semantic_Init()
{
	Type Arg_Type[1];		// write函数的参数
	IntType = (Type)malloc(sizeof(struct Type_));
	FloatType = (Type)malloc(sizeof(struct Type_));
	assert(IntType != NULL && FloatType != NULL);
	IntType->kind = BASIC;
	IntType->u.basic = INT_TYPE;
	FloatType->kind = BASIC;
	FloatType->u.basic = FLOAT_TYPE;
	Arg_Type[0] = typeCopy(IntType);
	int i;
	
	for(i = 0;i < TABLE_SIZE;i ++)
	{
		FuncTb[i] = (FuncEntry)malloc(sizeof(struct FuncEntry_));
		FuncTb[i]->tail = NULL;
		VarTb[i] = (FieldList)malloc(sizeof(struct FieldList_));
		VarTb[i]->tail = VarTb[i]->head = VarTb[i]->prev = VarTb[i]->next = VarTb[i];
	}
	/*
	 * 添加read(),write()两个预定义函数（lab03 added）
	 */
	
	InsertFunc("read", IntType, 0, NULL);
	InsertFunc("write", IntType, 1, Arg_Type);
	
	top = 0;				// 栈顶初始化指针
	for(i = 0;i < MAX_NEST_LEVEL;i ++)	// 初始化栈带有链表头
	{
		Stack[i] = (FieldList)malloc(sizeof(struct FieldList_));
		Stack[i]->next = Stack[i]->prev = Stack[i];
	}
}


/* 
	在本层或者更高层查找变量(int/float, struct ,array)是否已经定义
	name: 标识符字符串
	level: 当前变量层次
	Type: NULL:本层之内有重名
	      否则返回类型
*/
Type 
LookUpVarAtHigherLevel(char *name,int level)
{
	//printf("===== In func [LookUpVarAtHigherLevel], var[%s],level[%d] =====\n",name,level);
	assert(name != NULL);
	FieldList head = VarTb[hash_pjw(name)];
	FieldList vp = head->tail;		// 桶内链表扫描指针
	while(vp != head)
	{
		if(strcmp(vp->name,name) == 0 && vp->level <= level)
		{
			assert(vp->type != NULL);
			return vp->type;
		}
		vp = vp->tail;
	}
	
	return NULL;	
}
/**
 * 在同一嵌套层中查找变量是否定义
 * name: 变量名
 * level: 该变量的嵌套层次
 */
Type 
LookUpVarAtSameLevel(char *name,int level)
{
	//printf("===== In func [LookUpVarAtSameLevel], var[%s],level[%d] =====\n",name,level);
	assert(name != NULL);
	FieldList head = VarTb[hash_pjw(name)];
	FieldList vp = head->tail;		// 桶内链表扫描指针
	while(vp != head)
	{
		if(strcmp(vp->name,name) == 0 && vp->level == level)
		{
			assert(vp->type != NULL);
			return vp->type;
		}
		vp = vp->tail;
	}
	
	return NULL;	
}
/* 
 * 根据数组名字取其类型(lab03 added)
 */
Type 
get_array_type(char *name)
{
	assert(name != NULL);
	FieldList head = VarTb[hash_pjw(name)];
	FieldList vp = head->tail;		// 桶内链表扫描指针
	while(vp != head)
	{
		if(strcmp(vp->name,name) == 0)
		{
			assert(vp->type != NULL && vp->type->kind == ARRAY);
			return vp->type;
		}
		vp = vp->tail;
	}
	
	return NULL;	
}
/*  
 *
 */
Type array_switch(Type type)
{
	
	int i = 0, j, *tmp, t;
	Type p = type;
	while(p->kind != BASIC)
	{
		i ++;
		p = p->u.array.elem;
	}
	
	tmp = (int *)malloc(sizeof(int) * i);
	
	i = 0;
	for(p = type; p->kind != BASIC; p = p->u.array.elem, i++)
		tmp[i] = p->u.array.size;
	
	// 首尾两两交换
	j = 0;
	i--;
	while(j < i)
	{
		t = tmp[j];
		tmp[j] = tmp[i];
		tmp[i] = t;
		j++;
		i--;
	}
	p = type;
	i = 0;
	while(p->kind != BASIC)
	{
		p->u.array.size = tmp[i];
		i ++;
		p = p->u.array.elem;
	}
	return type;
}
/* 
 * 根据普通变量名字取其类型(lab03 added)
 */
Type 
get_var_type(char *name)
{
	assert(name != NULL);
	FieldList head = VarTb[hash_pjw(name)];
	FieldList vp = head->tail;		// 桶内链表扫描指针
	while(vp != head)
	{
		if(strcmp(vp->name,name) == 0)
		{
			assert(vp->type != NULL);
			return vp->type;
		}
		vp = vp->tail;
	}
	
	return NULL;	
}
/*
 * 根据变量名查找该变量的编号(lab03 added)
 */
unsigned int
get_var_no(char *name)
{
	assert(name != NULL);
	//printf("----- name: %s\n", name);
	FieldList head = VarTb[hash_pjw(name)];
	FieldList vp = head->tail;		// 桶内链表扫描指针
	while(vp != head)
	{
		if(strcmp(vp->name,name) == 0)
			return vp->var_no;

		vp = vp->tail;
	}
	assert(0);		// here should never be reached
	return -1;	// not found
}

/**
 *	变量符号表VarTb插入函数
 *	name:变量名
 *	type:变量类型
 *	level:嵌套的层次
**/
void 
InsertVar(char *name,Type type,int level)
{
	assert(name != NULL);
	FieldList newEntry = NULL;
	Index index = hash_pjw(name);
	FieldList head = VarTb[index];				// 链表表头
	FieldList s_head = Stack[level];			// 栈的层次链表头
	assert(head != NULL && s_head != NULL);
	
	newEntry = (FieldList)malloc(sizeof(struct FieldList_));	// *************************************
	newEntry->name = (char *)malloc(strlen(name) + 1);		// 注意一个结束字符'\0'
	assert(newEntry != NULL && newEntry->name != NULL);
	strcpy(newEntry->name,name);				
	newEntry->type = type;						// ************************************浅复制
	newEntry->level = level;
	newEntry->is_addr = 0;
	newEntry->var_no = ++ VAR_NO;
	
	newEntry->tail = head->tail;
	head->tail = newEntry;
	newEntry->tail->head = newEntry;
	newEntry->head = head;
	
	newEntry->next = s_head->next;				// 从栈列表的头部插入
	s_head->next = newEntry;
	newEntry->next->prev = newEntry;
	newEntry->prev = s_head;	
	
	//printf("===== In func [InsertVar], insert var:[%s],type:[%d], level:[%d] =====\n",name, type->kind, level);	
}
void 
deleteVar(FieldList p)
{
	assert(p->name != NULL);
	Index index = hash_pjw(p->name);
	FieldList head = VarTb[index];
	FieldList p_del = head->tail;

	while(p_del != head)
	{
		if(strcmp(p->name,p_del->name) == 0 && p->level == p_del->level) 
		{
			p_del->tail->head = p_del->head;	// 横向摘链
			p_del->head->tail = p_del->tail;
			
			p_del->next->prev = p_del->prev;	// 纵向摘链
			p_del->prev->next = p_del->next;
			
			//printf("===== In func [deleteVar], delete var:[%s], level:[%d], Index:[%d] =====\n",p_del->name,p_del->level,index);
			
			freeType(p_del->type);		// 释放记录类型时申请的内存
			free(p_del->name);
			free(p_del);
			
			return ;
		}
		p_del = p_del->tail;
	}
	// here should never be reached
	assert(0);
}
/*
 * 若函数实参为数组，则传进来的为地址
 */
void
set_fun_param(char* param_name)
{
	assert(param_name != NULL);
	FieldList head = VarTb[hash_pjw(param_name)];
	FieldList vp = head->tail;		// 桶内链表扫描指针
	while(vp != head)
	{
		if(strcmp(vp->name,param_name) == 0)
		{
			assert(vp->type != NULL);
			vp->is_addr = 1;
			return ;
		}
		vp = vp->tail;
	}
}
int get_fun_param_type(char* param_name)
{
	assert(param_name != NULL);
	FieldList head = VarTb[hash_pjw(param_name)];
	FieldList vp = head->tail;		// 桶内链表扫描指针
	while(vp != head)
	{
		if(strcmp(vp->name,param_name) == 0)
		{
			assert(vp->type != NULL);
			return vp->is_addr;
		}
		vp = vp->tail;
	}
	assert(0);
	return 0;
}
/*
 * 函数名符号表FuncTb查找函数
 * name: 查找的函数名
 * 返回值:TRUE: 找到,否则返回FALSE
*/
bool
LookUpFunc(char *name)
{
	//printf("===== In func [LookUpFunc], func name:[%s] =====\n",name);
	assert(name != NULL);
	FuncEntry vp = FuncTb[hash_pjw(name)]->tail;		// 桶内链表扫描指针
	while(vp != NULL)
	{
		if(strcmp(vp->name,name) == 0)
			return TRUE;
		vp = vp->tail;
	}
	return FALSE;	
}
/*
	函数符号表插入
*/
void 
InsertFunc(char *name,Type retType,int numOfArgs,Type* argsTypes)
{
	assert(name != NULL && retType != NULL);
	FuncEntry newEntry = NULL;
	Index index = hash_pjw(name);
	
	newEntry = (FuncEntry)malloc(sizeof(struct FuncEntry_));	// *************************************
	newEntry->name = (char *)malloc(strlen(name) + 1);	// 注意一个结束字符'\0'
	assert(newEntry != NULL);
	assert(newEntry->name != NULL);
	strcpy(newEntry->name,name);				// 名字拷贝
	newEntry->retType = retType;
	newEntry->numOfArgs = numOfArgs;
	newEntry->argsTypes = argsTypes;			// ************************************浅复制
	
	newEntry->tail = FuncTb[index]->tail;
	FuncTb[index]->tail = newEntry;	
	latestRetType = retType;    // 修改最新的函数的返回值类型
	assert(latestRetType != NULL);
	
	//printf("===== insert func:[%s],numOfArgs:[%d] =====\n",name,numOfArgs);
}
/*
	取函数返回值类型
*/
Type 
getRetType(struct TreeNode* pID)
{
	assert(strcmp(pID->nodeType,"ID") == 0);
	//printf("--- In function getRetType ,name:[%s]180 ---\n",pID->type_string);	
	FuncEntry vp = FuncTb[hash_pjw(pID->type_string)]->tail;		// 桶内链表扫描指针
	while(vp != NULL)
	{
		if(strcmp(vp->name,pID->type_string) == 0)
			return vp->retType;
		vp = vp->tail;
	}
	
	return NULL;	
}
/*
	取函数的参数列表
*/
FuncEntry
getFuncEntry(struct TreeNode* pID)
{
	//printf("--- In Function getFuncEntry Line 218---\n");
	assert(strcmp(pID->nodeType,"ID") == 0);
	FuncEntry vp = FuncTb[hash_pjw(pID->type_string)]->tail;		// 桶内链表扫描指针
	while(vp != NULL)
	{
		if(strcmp(vp->name,pID->type_string) == 0)
			return vp;
		vp = vp->tail;
	}
	
	return NULL;
}

/*
	进入一个新的嵌套层
*/
void
EnterALevel()
{
	//printf("+++++ ENTER A LEVEL +++++\n");
	top++;
	assert(top < MAX_NEST_LEVEL);
}
/*
	退出一个嵌套层，执行同层定义变量的删除操作
*/

void OutALevel()
{
	/*
	// 因为lab03中要用到符号表VarTb, FuncTb, 
	// 所以注释掉如下lab02中退出一层删除该层定义的功能 5/22
	FieldList p = Stack[top]->next,pTemp;
	while(p != Stack[top])
	{
		pTemp = p->next;
		deleteVar(p);
		p = pTemp;
	}
	assert(Stack[top]->next == Stack[top]->prev && Stack[top]->prev == Stack[top]);
	*/
	top --;
	assert(top >= 0);
	//printf("----- OUT A LEVEL -----\n");
}

/*
	扫描语法树并创建符号表
*/

void 
semanticAnalysis(struct TreeNode *root)
{
	TreeNode *p = NULL, *pTemp = NULL,*pVarList,*pID,*pVarDec,*pDecList;
	Type type,type1,type2;
	int i;
	
	
	if(root == NULL)
		return ;
	if(root->isLeaf || root->numOfChilds == 0)	// 叶子节点,或产生式体为空
		return ;
	
	switch(root->type)
	{
	case EXTDEF_NODE:
		//printf("IN EXTDEF------------------\n");
		switch(root->childs[1]->type)	
		{
			case EXTDECLIST_NODE:	/* 全局变量的定义：ExtDef -> Specifier ExtDecList SEMI */
				//printf("------------------IN EXTDECLIST------------------\n");
				p = root->childs[1];
				assert(p->type == EXTDECLIST_NODE);
				while(1)
				{
					pID = p->childs[0]->childs[0];
					while(strcmp(pID->nodeType,"ID") != 0)
						pID = pID->childs[0];
					//printf("************找到的变量名:[%s]\n",pID->type_string);
					if(LookUpVarAtSameLevel(pID->type_string,top) != NULL)	// 变量重定义
						printf("Error Type 3 at line %d: Redifined variable \"%s\"\n",
							pID->lineno,pID->type_string);
					else		// 新出现的变量插入表中
						InsertVar(pID->type_string,getType(root->childs[0]),top);
					
					if(p->numOfChilds == 1)
						break;
					p = p->childs[2];
					assert(strcmp(p->nodeType,"ExtDecList") == 0);
				}
				
				break;
			case FUNDEC_NODE:	// ExtDef -> Specifier FunDec CompSt 函数的定义
				//printf("------------------IN FUNDEC------------------\n");
				pID = root->childs[1]->childs[0];
				assert(strcmp(root->childs[1]->nodeType,"FunDec") == 0);
				assert(strcmp(pID->nodeType,"ID") == 0);
	
				if(LookUpFunc(pID->type_string))
					printf("Error Type 4 at line %d: Redifined function \"%s\"\n",pID->lineno,pID->type_string);
				else
				{
					int numOfArgs = 0;
					Type *argsTypes = NULL;
					if(root->childs[1]->numOfChilds == 4)	// 函数参数列表非空
					{
						pTemp = pVarList = root->childs[1]->childs[2];
						assert(pVarList->type == VARLIST_NODE);
						numOfArgs = 1;
						while(pTemp->numOfChilds == 3)		// 计算函数列表中参数个数
						{
							assert(pTemp->type == VARLIST_NODE);
							numOfArgs ++;
							pTemp = pTemp->childs[2];
						}
						argsTypes = (Type *)malloc(sizeof(Type) * numOfArgs);
						assert(argsTypes != NULL);	
						i = 0;
				
						while(1)	// 计算函数列表中参数类型
						{
							assert(pVarList->type == VARLIST_NODE);			
							argsTypes[i] = getType2(pVarList->childs[0]->childs[0],pVarList->childs[0]->childs[1]);
							pVarDec = pVarList->childs[0]->childs[1];
							assert(pVarDec->type == VARDEC_NODE);
							while(pVarDec->numOfChilds == 4)
								pVarDec = pVarDec->childs[0];
							assert(strcmp(pVarDec->childs[0]->nodeType,"ID") == 0);
							// 将形式参数列表中的变量定义插入,注意level的设定[NOT FINISHED,没有进行重复性检查]
							// 注意：ArgsTypes中存储的类型与符号表中存储的类型使用不同的空间
							InsertVar(pVarDec->childs[0]->type_string, typeCopy(argsTypes[i]), top + 1); 
							
							set_fun_param(pVarDec->childs[0]->type_string);	// [lab03 added]
							
							i++;
							if(pVarList->numOfChilds == 1)
								break;
							pVarList = pVarList->childs[2];
						}
			
			
					} // 否则为没有参数的函数
		
					InsertFunc(pID->type_string,getType(root->childs[0]),numOfArgs,argsTypes);
				}
	
				assert(root->childs[2]->type == COMPST_NODE);
				semanticAnalysis(root->childs[2]);
				break;
				
			default:	// 结构体定义，忽略Specifier->TYPE
				if(root->childs[0]->childs[0]->type == STRUCTSPECIFIER_NODE)
					getType(root->childs[0]);			
		}
		
		break;
	case COMPST_NODE:		// CompSt -> LC DefList StmtList RC
		//printf("------------------IN COMPST------------------\n");
		
		EnterALevel();		// 进入一个嵌套层次
		
		semanticAnalysis(root->childs[1]);		// CompSt中的DefList;
		semanticAnalysis(root->childs[2]);		// CompSt中的StmtList

		OutALevel();		// 推出一个嵌套层次
		
		break;
	
	case DEF_NODE:	// Def -> Specifier DecList SEMI
		//printf("------------------IN DEF------------------\n");
		pDecList = root->childs[1];
		while(1)
		{
			assert(pDecList->type == DECLIST_NODE);
			type1 = getType2(root->childs[0],pDecList->childs[0]->childs[0]);
			if(pDecList->childs[0]->numOfChilds == 3)	//Dec -> VarDec ASSIGNOP Exp
			{
				type2 = getExpType(pDecList->childs[0]->childs[2]);
				
				if(!(isTypesEqual(type1, type2)))
					printf("Error type 5 at line %d: Type missmatched\n",pDecList->childs[0]->lineno);
			}
			pVarDec = pDecList->childs[0]->childs[0];
			
			assert(pVarDec->type == VARDEC_NODE);
			while(pVarDec->numOfChilds == 4)	/* VarDec-> VarDec LB INT RB */
				pVarDec = pVarDec->childs[0];
			pID = pVarDec->childs[0];		// VarDec -> ID
			
			assert(strcmp(pID->nodeType,"ID") == 0);
			if(LookUpVarAtSameLevel(pID->type_string,top) != NULL)	// 局部变量重复定
				printf("Error type 3 at line %d: Redifined variable \"%s\"\n",pID->lineno,pID->type_string);
			else
			{
				if(type1 != NULL)		// 注意：当使用结构体定义变量时，该结构体可能是未定义的
				{
					InsertVar(pID->type_string,type1,top);
				}
			}
			
			if(pDecList->numOfChilds == 1)
				break;
			else
			{
				assert(pDecList->numOfChilds == 3);
				pDecList = pDecList->childs[2];
			}
			
		}
		break;
	case EXP_NODE:
		//printf("------------------IN EXP------------------\n");
		getExpType(root);
		break;
	
	case STMT_NODE:	// 函数返回值类型检查[Type 8]
		//printf("------------------IN STMT------------------\n");
		if(root->numOfChilds == 3 && strcmp(root->childs[0]->nodeType,"RETURN") == 0) // Stmt -> RETURN Exp SEMI
		{
			type = getExpType(root->childs[1]);
			if(type == NULL)
				return ;
			if(!isTypesEqual(type,latestRetType))
				printf("Error type 8 at line %d: The return type missmatched\n",root->childs[1]->lineno);
				
			return ;
		}
		else if(root->numOfChilds == 1 && root->childs[0]->type == COMPST_NODE) // Stmt -> CompSt
			semanticAnalysis(root->childs[0]);
		else if(strcmp(root->childs[0]->nodeType,"IF") == 0) // Stmt -> IF LP Exp RP Stmt | IF LP Exp RP Stmt ELSE Stmt
		{							
			type = getExpType(root->childs[2]);
			if(type == NULL)  // 底层出错
				return ;
			if(!(type->kind == BASIC && type->u.basic == INT_TYPE))
				printf("Error type 7 at line %d: Operands type missmatched\n",root->childs[2]->lineno);
			semanticAnalysis(root->childs[4]);	// Stmt 
			if(root->numOfChilds == 7)
				semanticAnalysis(root->childs[6]);
		}
		else if(strcmp(root->childs[0]->nodeType,"WHILE") == 0)	// Stmt -> WHILE LP Exp RP Stmt
		{
			type = getExpType(root->childs[2]);
			if(type == NULL)  // 底层出错
				return ;
			if(!(type->kind == BASIC && type->u.basic == INT_TYPE))
				printf("Error type 7 at line %d: Operands type missmatched\n",root->childs[2]->lineno);
				
			semanticAnalysis(root->childs[4]);
		}
		else	// Stmt -> Exp SEMI
		{
			assert(root->childs[0]->type == EXP_NODE);
			semanticAnalysis(root->childs[0]);
		}
		
		break;
		
	default:
		//printf("------------------IN DEFAULT ------------------\n");
		//printf("NodeType:[%s]\n",root->nodeType);
		for(i = 0;i < root->numOfChilds;i++)		// 递归处理子节点
		{
			semanticAnalysis(root->childs[i]);
		}
		
	}
}
/*
 * 计算数组每一维度的宽度
 *
 */
int set_array_width(Type type)
{
	//printf("----- In func set_array_width -----\n");
	//printf("----- size :%d\n",type->u.array.size);
	if(type->kind == BASIC)
	{
		return (type->u.basic == INT_TYPE ? 4 : 8);
	}
	else
	{
		assert(type->kind == ARRAY);
		
		type->u.array.width = set_array_width(type->u.array.elem);
		//printf("----- my width: %d\n", type->u.array.width);
		return type->u.array.size * type->u.array.width;
	}
}
/*
	获取表达式类型
*/
Type getExpType(struct TreeNode *pExp)
{
	//printf("In function [getExpType]\n");
	assert(pExp->type == EXP_NODE);
	Type type1,type2,type;
	struct TreeNode *pID,*pTemp;
	char* fieldName;
		
	if(pExp->numOfChilds == 1 && strcmp(pExp->childs[0]->nodeType,"INT") == 0) // Exp -> INT:整形常量
	{
		//printf("Exp -> INT\n");
		type = (Type)malloc(sizeof(struct Type_));
		assert(type != NULL);
		type->kind = BASIC;
		type->u.basic = INT_TYPE;
		return type;
	}
	else if(pExp->numOfChilds == 1 && strcmp(pExp->childs[0]->nodeType,"FLOAT") == 0)// Exp -> FLOAT:浮点型常量
	{
		//printf("Exp -> FLOAT\n");
		type = (Type)malloc(sizeof(struct Type_));
		assert( FloatType != NULL);
		type->kind = BASIC;
		type->u.basic = FLOAT_TYPE;
		return type;
	}
	else if(pExp->numOfChilds == 1 && strcmp(pExp->childs[0]->nodeType,"ID") == 0)	// Exp -> ID: 普通变量
	{
		//printf("Exp -> ID,搜索的变量:%s\n",pExp->childs[0]->type_string);
		pID = pExp->childs[0];
		type = LookUpVarAtHigherLevel(pID->type_string,top);
		if(type == NULL)
			printf("Error type 1 at line %d: Undefined variable \"%s\"\n",pID->lineno,pID->type_string);
		return type;
	}
	else if(pExp->numOfChilds >= 3 && strcmp(pExp->childs[0]->nodeType,"ID") == 0) // Exp -> ID LP RP: 函数调用(无参)
	{										// 或者：Exp -> ID LP Args RP: 函数调用(含参)
		pID = pExp->childs[0];
		if(!LookUpFunc(pID->type_string))
		{
			if(LookUpVarAtHigherLevel(pID->type_string,top) == NULL)
				printf("Error type 2 at line %d: Undefined function \"%s\"\n",pID->lineno,pID->type_string);
			else
				printf("Error type 11 at line %d: \"%s\" must be a function\n",pID->lineno,pID->type_string);
			return NULL;
		}
		else
		{
			FuncEntry pEntry = getFuncEntry(pID);
			assert(pEntry != NULL);
			int numOfArgs = 0;
			if(pExp->numOfChilds == 4)	// 含参调用
			{
				numOfArgs = 1;
				pTemp = pExp->childs[2];
				assert(pTemp->type == ARGS_NODE);
				while(pTemp->numOfChilds == 3)
				{
					numOfArgs ++;
					pTemp = pTemp->childs[2];
				}
			}
			if(numOfArgs != pEntry->numOfArgs)	// 参数个数不匹配
				printf("Error type 9 at line %d: Num of arguments not matched\n",pExp->childs[2]->lineno);
			
			else if(numOfArgs != 0)				// 参数类型逐个检查 Exp -> ID LP Args RP
			{
				int i = 0;
				pTemp = pExp->childs[2];
				assert(pTemp->type == ARGS_NODE);
				while(1)
				{
					if(!isTypesEqual(pEntry->argsTypes[i], getExpType(pTemp->childs[0]))) // Args -> Exp COMMA Args
					{
						printf("Error type 9 at line %d: Argument type not matched\n",pTemp->lineno);
					}
					if(pTemp->numOfChilds == 1)		// Args -> Exp
						break;
										// else : Args -> Exp COMMA Args
					pTemp = pTemp->childs[2];
					i++;
				}
			}
			
		}
		return getRetType(pExp->childs[0]);		// 返回 函数的返回值类型
	}
	else if(pExp->numOfChilds == 3 && strcmp(pExp->childs[1]->nodeType,"ASSIGNOP") == 0) // Exp -> Exp ASSIGNOP EXP
	{
		//printf("Exp -> Exp ASSIGNOP EXP\n");
		pTemp = pExp->childs[0];
		/* 左值检查 */
		if(!((pTemp->numOfChilds == 1 && strcmp(pTemp->childs[0]->nodeType,"ID") == 0)	//ID
		     || (pTemp->numOfChilds == 4 && strcmp(pTemp->childs[1]->nodeType,"LB") == 0)  //Exp LB Exp RB
		     || (pTemp->numOfChilds == 3 && strcmp(pTemp->childs[1]->nodeType,"DOT") == 0))) // Exp Dot ID
		{
			printf("Error type 6 at line %d: The left-hand side of an assignment must be L-value\n",pTemp->lineno);
			return NULL;
		}
		
		/* 赋值号两边类型检查[假设赋值号两边仅出现INT/FLOAT类型]*/
		type1 = getExpType(pExp->childs[0]);
		type2 = getExpType(pExp->childs[2]);
		
		if(type1 == NULL || type2 == NULL)	// 底层若出错，则本层不再检查
			return NULL;
		
		if(type1->kind == BASIC && type2->kind == BASIC && type1->u.basic == type2->u.basic)
			return type1;
	
		
		printf("Error type 5 at line %d: Type missmatched\n",pExp->lineno);
		return NULL;
		
	}
	else if((pExp->numOfChilds == 2 && strcmp(pExp->childs[0]->nodeType,"MINUS") == 0)	// Exp -> MINUS Exp,算术运算符：取负,+/-/*/除
		|| (pExp->numOfChilds == 3 && (strcmp(pExp->childs[1]->nodeType,"PLUS") == 0 	// Exp -> EXP PLUS EXP
					   || strcmp(pExp->childs[1]->nodeType,"MINUS") == 0	// Exp -> EXP MINUS EXP 
					   || strcmp(pExp->childs[1]->nodeType,"STAR") == 0	// Exp -> EXP STAR EXP
					   || strcmp(pExp->childs[1]->nodeType,"DIV") == 0))) 	// Exp -> EXP DIV EXP
	{
		/* 只有int和float类型才能执行算术运算[根据假设2] */
		//printf("算术运算操作\n");
		if(pExp->numOfChilds == 2)	// Exp -> MINUS Exp
		{
			type = getExpType(pExp->childs[1]);
			if(type == NULL)
				return NULL;
			if(type->kind == BASIC)
				return type;	
					
			printf("Error type 7 at line %d: Operands type missmatched\n",pExp->childs[1]->lineno);
			return NULL;
		}
		
		type1 = getExpType(pExp->childs[0]);
		type2 = getExpType(pExp->childs[2]);
	
		if(type1 == NULL || type2 == NULL)	// 底层若出错，则本层不再检查
			return NULL;
			
		if(type1->kind == BASIC && type2->kind == BASIC && type1->u.basic == type2->u.basic)
			return type1;
		
		printf("Error type 7 at line %d: Operands type missmatched\n",pExp->lineno);
		return NULL;
	}
	else if(pExp->numOfChilds == 4 && strcmp(pExp->childs[1]->nodeType,"LB") == 0) // Exp -> Exp LB Exp RB,数组访问
	{
		//printf("Exp -> Exp LB Exp RB\n");
		type1 = getExpType(pExp->childs[0]);
		type2 = getExpType(pExp->childs[2]);
		
		if(type1 == NULL || type2 == NULL)	// 底层若出错，则本层不再检查
			return NULL;
		
		if(type1->kind == ARRAY && type2->kind == BASIC && type2->u.basic == INT_TYPE)
			return type1->u.array.elem;			// [注意 :降一个维度]
			
		if(type1->kind != ARRAY)
			printf("Error type 10 at line %d: Illegal use of \"[]\"\n",pExp->childs[0]->lineno);
		
		if(!(type2->kind == BASIC && type2->u.basic == INT_TYPE))
			printf("Error type 12 at line %d: Operands type mistaken\n",pExp->childs[2]->lineno);	
		
		return 	NULL;
	}
	else if(pExp->numOfChilds == 3 && strcmp(pExp->childs[1]->nodeType,"DOT") == 0) // Exp -> Exp DOT ID,结构体访问
	{
		//printf("Exp -> Exp DOT ID\n");
		
		type1 = getExpType(pExp->childs[0]);
		if(type1 == NULL)		// 底层若出错，则本层不再检查
			return NULL;
			
		if(type1->kind != STRUCTURE)
		{																								
			printf("Error type 13 at line %d: Illegal use of \".\"\n",pExp->childs[1]->lineno);
			return NULL;
		}
		fieldName = pExp->childs[2]->type_string;
		FieldList p = type1->u.structure.fieldList;
		
		while(p != NULL)
		{
			if(strcmp(p->name,fieldName) == 0)
				return p->type;
			p = p->tail;
		}
		
		printf("Error type 14 at line %d: Unexisted field \"%s\"\n",pExp->childs[2]->lineno,fieldName);
		return NULL;
	}
	else if(pExp->numOfChilds == 3 && strcmp(pExp->childs[1]->nodeType,"RELOP") == 0) // Exp -> Exp RELOP Exp 关系操作符
	{
		/* 这里应该不会到来*/
		//printf("Exp -> Exp RELOP Exp\n");
		type1 = getExpType(pExp->childs[0]);
		type2 = getExpType(pExp->childs[2]);
		
		if(type1 == NULL || type2 == NULL)
			return NULL;
		
		return type1;
	}
	else if(pExp->numOfChilds == 3 && strcmp(pExp->childs[0]->nodeType,"LP") == 0) // Exp -> LP Exp RP 括号
	{
		return getExpType(pExp->childs[1]);
	}
	else if(pExp->numOfChilds >= 2 && (strcmp(pExp->childs[1]->nodeType,"AND") == 0  // Exp -> Exp AND Exp 逻辑操作符[假设2]
					|| strcmp(pExp->childs[1]->nodeType,"OR")	 // Exp -> Exp OR Exp 
					|| strcmp(pExp->childs[0]->nodeType,"NOT")))	 // Exp -> NOT Exp 
	{
		if(pExp->numOfChilds == 3)	// &&,||
		{
			type1 = getExpType(pExp->childs[0]);
			type2 = getExpType(pExp->childs[2]);
			
			if(type1 == NULL || type2 == NULL)	// 底层若出错，则本层不再检查
				return NULL;
			
			if(type1->kind == BASIC && type2->kind == BASIC && type1->u.basic == INT_TYPE && type2->u.basic == INT_TYPE)
				return type1;
	
			printf("Error type 7 at line %d: Operands type missmatched\n",pExp->lineno);
			return NULL;
		}
		else	 // Exp -> NOT Exp 
		{
			type = getExpType(pExp->childs[1]);
			if(type == NULL)
				return NULL;
				
			if(type->kind == BASIC || type->u.basic == INT_TYPE)
				return type;
				
			printf("Error type 7 at line %d: Operands type missmatched\n",pExp->lineno);
			return NULL;
		}
	}
	
	printf("Program wrong ,here should never be reached!\n");
	assert(0);
}
/*
	计算数据类型
	Specifier的可能来源：
	ExtDef -> Specifier ExtDecList SEMI 	// 全局变量定义
		｜Specifier SEMI		// 结构体定义
		｜Specifier FunDec CompSt	// 函数返回值定义(可以顺带定义结构体类型)
	ParamDec -> Specifier VarDec		// 函数形参定义列表(可以顺带定义结构体类型)
	Def ->	Specifier DecList SEMI		// 局部变量定义
	
*/
Type 
getType(struct TreeNode* specifier)
{
	//printf("===== In func [getType] =====\n");
	assert(specifier->type == SPECIFIER_NODE);
	struct TreeNode *p,*pTemp,*pDefList,*pDecList,*pDec,*pVarDec,*pID,*pSpecifier;
	FieldList pField = NULL;	// 结构体域扫描指针
	char *name = NULL;
	Type type = (Type)malloc(sizeof(struct Type_));
	assert(type != NULL);
	if(strcmp(specifier->childs[0]->nodeType,"TYPE") == 0)	// Specifier -> TYPE
	{
		type->kind = BASIC;
		type->u.basic = (strcmp(specifier->childs[0]->type_string,"int") == 0) ? INT_TYPE : FLOAT_TYPE;
		return type;
	}
	
	assert(specifier->childs[0]->type == STRUCTSPECIFIER_NODE);	// Specifier ->StructSpecifier
	p = specifier->childs[0];	// p == StructSpecifier
	if(p->numOfChilds == 2)	// StructSpecifier -> STRUCT Tag [注：这中写法在定义时也是可以的(域为空，但是这种情况没有意义)]
	{			// 所以一律将这种情况看作结构类型的使用
		p = p->childs[1]->childs[0];
		assert(strcmp(p->nodeType,"ID") == 0);
		type = LookUpVarAtHigherLevel(p->type_string,top);
		if(type == NULL)	//使用的结构类型没有定义
		{
			printf("Error Type 17 at line %d: Undefined struct \'%s\'\n",p->lineno,p->type_string);
			return NULL;
		}
		else			//否则返回已定义的结构体类型[注意：返回的是新的私有的地址空间]
			return typeCopy(type);		
	}
	else	// StructSpecifier -> STRUCT OptTag LC DefList RC; 结构体类型的定义
	{
		if(p->childs[1]->numOfChilds == 1) // OptTag -> ID, 非匿名结构体
		{
			pTemp = p->childs[1]->childs[0];
			assert(strcmp(pTemp->nodeType,"ID") == 0);
			if(LookUpVarAtSameLevel(pTemp->type_string,top) != NULL)
				printf("Error Type 16 at line %d: Dulplicated name \'%s\'\n",pTemp->lineno,pTemp->type_string);							
			else
			{
				name = pTemp->type_string;	// 新结构体的名字
				type->u.structure.struct_name = (char *)malloc(strlen(name) + 1);
				strcpy(type->u.structure.struct_name, name);	// 结构体的名字
			}
		}
		
		/*下面填写结构体的类型*/				
		type->kind = STRUCTURE;
		pDefList = p->childs[3];
		assert(pDefList->type == DEFLIST_NODE);
		if(pDefList->numOfChilds == 0)	/*DefList -> 空 结构体的域为空*/
		{
			//printf("field of \'%s\'(at line %d)is empty\n",pTemp->type_string,pTemp->lineno);
			type->u.structure.fieldList = NULL;
			if(p->childs[1]->numOfChilds == 1 && name != NULL) // OptTag -> ID:非匿名结构体,加入符号表[注意：当结构体重名时不插入符号表]
				InsertVar(name,type,top);
			return type;
			
		}
		
		/* 以下处理结构体域非空： DefList -> Def DefList */
		
		//EnterALevel();  /* 注意：左花括号 */
		
		type->u.structure.fieldList = NULL;		// 初始化
	
		while(pDefList->numOfChilds == 2)	// DefList -> Def DefList
		{
			pSpecifier = pDefList->childs[0]->childs[0];
			pDecList = pDefList->childs[0]->childs[1];	
			assert(pDecList->type == DECLIST_NODE && pSpecifier->type == SPECIFIER_NODE);
			while(1)
			{
				if(type->u.structure.fieldList == NULL)
				{
					type->u.structure.fieldList = (FieldList)malloc(sizeof(struct FieldList_));
					pField = type->u.structure.fieldList;	// pField指向当前处理的结构体域
				}
				else
				{
					pField->tail = (FieldList)malloc(sizeof(struct FieldList_));
					pField = pField->tail;
				}
				pField->tail = NULL;
				
				assert(pField != NULL);
				
				pDec = pDecList->childs[0];
				assert(pDec->type == DEC_NODE);
				if(pDec->numOfChilds == 3) // Dec -> VarDec ASSIGNOP EXP
					printf("Error Type 15 at line %d: Cannot initialize variable in structure\n",pDec->lineno);
								
				pVarDec = pDec->childs[0];
				assert(pVarDec->type == VARDEC_NODE);
				
				pField->type = getType2(pSpecifier,pVarDec);	// 计算每个结构体域的类型
				
				while(pVarDec->numOfChilds == 4)
					pVarDec = pVarDec->childs[0];
					
				pID = pVarDec->childs[0];
				
				FieldList t = type->u.structure.fieldList;
				while(t->tail != NULL)
				{
					if(strcmp(t->name,pID->type_string) == 0)
					{
						printf("Error Type 15 at line %d: Redifined field \'%s\'\n",pID->lineno,pID->type_string);
						break;
					}
					t = t->tail;
				}
				
				assert(strcmp(pID->nodeType,"ID") == 0);
				pField->name = (char *)malloc(strlen(pID->type_string) + 1);
				assert(pField->name != NULL);																	
				strcpy(pField->name,pID->type_string);
				
				/* 将结构体中定义的变量插入符号表 */
				// InsertVar(pField->name,pField->type,top + 1); // [注意：这里插入如何处理]
				
				if(pDecList->numOfChilds == 1) // DecList -> Dec
					break;
				
				pDecList = pDecList->childs[2]; // DecList -> Dec COMMA DECLIST
				assert(pDecList->type == DECLIST_NODE);
			}
		
			pDefList = pDefList->childs[1];
		}
		
		if(p->childs[1]->numOfChilds == 1 && name != NULL) // 向符号表插入新的有名字的结构体类型
			InsertVar(name,type,top);		
			
		//OutALevel();	/* 右花括号 */
		
		return type;
			
	}	
}
/*
	使用已经定义的结构体类型定义变量时，
	深度拷贝已定义结构体变量的类型。
	srcType: 拷贝类型的源
	
*/
Type 
typeCopy(Type srcType)
{
	Type dstType = (Type)malloc(sizeof(struct Type_));
	FieldList pSrc,pDst;
	assert(dstType != NULL);
	if(srcType->kind == BASIC)
	{
		dstType->kind = BASIC;
		dstType->u.basic = srcType->u.basic;
		return dstType;
	}
	
	if(srcType->kind == ARRAY)
	{
		dstType->kind = ARRAY;
		dstType->u.array.size = srcType->u.array.size;
		dstType->u.array.elem = typeCopy(srcType->u.array.elem);	// 递归调用自身解决高维数组的类型
		return dstType;
	}
	
	assert(srcType->kind == STRUCTURE);
	dstType->kind = STRUCTURE;
	dstType->u.structure.struct_name = (char *)malloc(strlen(srcType->u.structure.struct_name) + 1);
	strcpy(dstType->u.structure.struct_name, srcType->u.structure.struct_name); // 拷贝结构体的名字
	dstType->u.structure.fieldList = NULL;	// 初始化
	pSrc = srcType->u.structure.fieldList;
	
	while(pSrc != NULL)
	{
		if(dstType->u.structure.fieldList == NULL)
		{
			pDst = (FieldList)malloc(sizeof(struct FieldList_));
			dstType->u.structure.fieldList = pDst;
		}
		else
		{
			pDst->tail = (FieldList)malloc(sizeof(struct FieldList_));
			pDst = pDst->tail;
		}
		assert(pDst != NULL);
		
		pDst->name = (char *)malloc(strlen(pSrc->name) + 1);
		strcpy(pDst->name,pSrc->name);
		
		pDst->type = typeCopy(pSrc->type);	// 递归调用解决结构体域的变量定义
		
		pSrc = pSrc->tail;
	}
	pDst->tail = NULL;	// 置链表结尾标记
	
	return dstType;
}
/*
	释放申请的内存空间
*/
void 
freeType(Type type)
{
	if(type == NULL)
		return ;
	//printf("===== In func [freeType], type->kind [%d]====\n",type->kind);
	if(type->kind == BASIC)
	{
		free(type);
		type = NULL;
		return ;
	}
	
	if(type->kind == ARRAY)
	{
		freeType(type->u.array.elem);	//递归释放数组申请的空间
		free(type);
		type->u.array.elem = NULL;
		type = NULL;
		return ;
	}
	assert(type->kind == STRUCTURE);
	free(type->u.structure.struct_name);
	type->u.structure.struct_name = NULL;
	FieldList p = type->u.structure.fieldList;
	while(p != NULL)
	{
		free(p->name);
		freeType(p->type);
		p->name = NULL;
		p->type = NULL;		// 
		p = p->tail;
	}
	free(type);
	type = NULL;
}
/*
	pSpecifier:
	pVarDec:	
*/
Type getType2(struct TreeNode* pSpecifier,struct TreeNode* pVarDec)
{
	//printf("**************In function getType2****************\n");
	assert(pVarDec->type == VARDEC_NODE && pSpecifier->type == SPECIFIER_NODE);
	if(pVarDec->numOfChilds == 1)	// VarDec -> ID
	{
		assert(strcmp(pVarDec->childs[0]->nodeType,"ID") == 0);
		//InsertVar(pVarDec->childs[0]->type_string,type);		// 注意，这里插入的可能是函数参数列表内的局部变量
		return getType(pSpecifier);
	}
	else				// VarDec -> VarDec LB INT RB
	{
		Type type = (Type)malloc(sizeof(struct Type_));
		assert(type != NULL);
		type->kind = ARRAY;
		assert(strcmp(pVarDec->childs[2]->nodeType,"INT") == 0);
		type->u.array.size = pVarDec->childs[2]->type_int;
		
		type->u.array.elem = getType2(pSpecifier,pVarDec->childs[0]);		// 递归调用,解决高维数组的定义
		
		return  type;
	}
	
}
/*
	判断两个类型是否名等价(name equivalence)
	返回值:true:等价； falase：不等价
*/
bool
isTypesEqual(Type t1,Type t2)
{
	//printf("===== in func [isTypesEqual] =====\n");
	//printf("t1->kind: %d,t2->kind: %d\n",t1->kind, t2->kind);
	if(t1 == NULL && t2 == NULL)
		return TRUE;
	if((t1 == NULL && t2 != NULL) || (t1 != NULL && t2 == NULL))
		return FALSE;
	if(t1->kind != t2->kind)
		return FALSE;
	if(t1->kind == BASIC)
		return (t1->u.basic == t2->u.basic);
	if(t1->kind == STRUCTURE)
	{
		return (strcmp(t1->u.structure.struct_name, t2->u.structure.struct_name) == 0) ? TRUE : FALSE;	
	}
		
	assert(t1->kind == ARRAY);
	return isTypesEqual(t1->u.array.elem, t2->u.array.elem);	// 递归调用
		
}
// 符号表释放,这里需要释放函数名符号表FuncTable和变量名符号表的第0层定义的变量（其余层在退出该层时空间自动释放）
void
destroy()
{
	
}










