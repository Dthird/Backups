/*
 * 中间代码生成头文件
 *
 */
#ifndef _TRANSLATE_H_
#define _TRANSLATE_H_

#include "semantic.h"

typedef struct Operand_ *Operand;

struct Operand_
{
	enum { VARIABLE, CONSTANT, TEMP_VAR, LABEL, ADDRESS, FUNCNAME } kind;	
	union
	{
		unsigned int var_no;			// 变量编号(包括用户定义的变量和临时变量),VARIABLE,TEMP_VAR,ADDRESS
		int value;					// 常量只可能是int类型,CONSTANT
		unsigned int label_no;			// 跳转到的标号编号，LABEL
		char *func_name;				// 函数名，FUNCNAME
	} u;
};
 
struct InterCode
{
	enum { IR_LABEL, IR_FUNCTION, IR_ASSIGN, IR_ADD, IR_SUB, IR_MUL, IR_DIV ,IR_ADDR, IR_MEM_R, IR_MEM_L, IR_GOTO, 
		IR_RELOP, IR_RETURN, IR_DEC, IR_ARG_VAL, IR_ARG_REF,IR_CALL, IR_PARAM, IR_READ, IR_WRITE} kind;
	union
	{
		Operand op;	 // 只有一个操作数的中间代码：IR_LABEL,IR_FUNCTION,IR_GOTO,IR_RETURN,IR_ARG_VAL,IR_ARG_REF,IR_PARAM,IR_READ,IR_WRITE
		struct { Operand result, op; } unaop;			// 单目运算:IR_ASSIGN,IR_ADDR,IR_MEM_R,IR_MEM_L,IR_CALL,
		struct { Operand result, op1, op2; } binop;		// 双目运算：IR_ADD,IR_SUB,IR_MUL,IR_DIV
		struct { Operand op; int size; } dec;						// 函数内部数组变量空间申请,IR_DEC
		struct { Operand op1, op2, label; char* relop;} relop;	// IR_RELOP, if(x [relop] y) then jump to Lable z	
	} u;

};


// 使用双向循环链表的线性结构
typedef struct InterCodes
{
	struct InterCode code;		// 中间代码
	struct InterCodes *prev;	// 前向指针
	struct InterCodes *next; 	// 后向指针
} InterCodes;


char* SIGN[6];			// 打印的符号：常量前加 '#', 用户定义的变量前加 'v', 临时变量前加 't'
extern InterCodes *IR_LIST_HEAD;	// 中间代码列表头指针
extern int TRANSLATE_RIGHT;		// 读入文件能正确解析并生成中间代码标志位

InterCodes* join_InterCodes(InterCodes *head1, InterCodes *head2);	// 连接两个中间代码块
InterCodes* translate_Program(struct TreeNode *root);
InterCodes* translate_ExtDefList(struct TreeNode *pExtDefList);
InterCodes* translate_ExtDef(struct TreeNode *pExtDef);
InterCodes* translate_ExtDecList(struct TreeNode* pExtDecList);
InterCodes* translate_VarDec(struct TreeNode* pVarDec);
InterCodes* translate_Array_DEF(struct TreeNode* pID);					// 数组类型的翻译(定义时)
InterCodes* translate_Array_USE(struct TreeNode *pExp, Operand place, Type* type);					// 数组类型的翻译(使用时))
InterCodes* translate_FunDec(struct TreeNode* pFunDec);
InterCodes* translate_VarList(struct TreeNode* pVarList);
InterCodes* translate_ParamDec(struct TreeNode* pParamDec);
InterCodes* translate_CompSt(struct TreeNode* pCompSt);
InterCodes* translate_DefList(struct TreeNode* pDefList);
InterCodes* translate_Def(struct TreeNode* pDef);
InterCodes* translate_DecList(struct TreeNode* pDecList);
InterCodes* translate_Dec(struct TreeNode* pDec);
InterCodes* translate_StmtList(struct TreeNode *pStmtList);
InterCodes* translate_Stmt(struct TreeNode *pStmt);
InterCodes* translate_Exp(struct TreeNode *pExp, Operand place);
InterCodes* translate_Cond(struct TreeNode *pExp, Operand label_true, Operand label_false);
InterCodes* translate_Args(struct TreeNode *pArgs, FuncEntry p);

// 创建一个操作数
Operand new_Operand(unsigned int operand_kind, unsigned int no_val, char* func_name);
Operand new_temp();
Operand new_func(char *func_name);
Operand get_var(char *name);
Operand new_const(int constant);

// 中间代码创建
InterCodes* new_ir_op(unsigned int ir_type, Operand op);
InterCodes* new_ir_unaop(unsigned int ir_type, Operand result, Operand op);
InterCodes* new_ir_binop(unsigned int ir_type, Operand result, Operand op1, Operand op2);
InterCodes* new_ir_dec(Operand op, int size);
InterCodes* new_ir_relop(Operand op1, Operand op2, Operand label, char *relop);
// 打印操作数
void printOperand(Operand operand);	



// 中间代码打印
void printIR(InterCodes *head);
unsigned int get_TEMP_VAR_NO();			// 给新创建的临时变量进行编号
unsigned int get_LABEL_NO();			// 给新创建的标号Label进行编号

#endif




