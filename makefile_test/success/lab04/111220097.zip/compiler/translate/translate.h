#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "../DList/DList.h"
#include "../node.h"

typedef struct symTable_* symTable;
struct symTable_{
	char *id;
	int field;			//0==var,1==param,2=func
	Operand op;
	symTable next;
};

symTable table;				//变量表

static int varNum=0;			//编译变量数
static int tNum=0;			//临时变量
static int labelNum=0;			//目标地址数

int init_symTable();
char *getrelop(Node* n);
int insertSym(Operand op,char* id,int field);
Operand lookup(char* id);
int do_write();
