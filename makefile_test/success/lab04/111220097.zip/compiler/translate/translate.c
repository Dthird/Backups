#include "translate.h"
int do_translate(Node* node){
	if(!(init_symTable()+1)){
		printf("init symtable failed!\n");
		exit(-1);
	}
	if(!(init_InterCodes()+1)){
		printf("init interCodes failed!\n");
		exit(-1);
	}
	if(!(mend_funcTable()+1)){
		printf("init funcTable failed!\n");
		exit(-1);
	}
	return translate(node);
}

int translate(Node* node){
	if(node->n_node.num==0){//printf("NULL in main!\n");
		return 0;
	}
	//printf("%s\n",node->n_node.name);
	if(node->type==TYPE_NTERMINAL&&node->n_node.num!=0){
		int i=0;
		if(strcmp(node->n_node.name,"Program")==0){
			translate(node->n_node.node[0]);
		}else if(strcmp(node->n_node.name,"ExtDefList")==0){
			if(node->n_node.num==0){//bs:->
				return 0;
			}
			if(node->n_node.num==2){//bs:->ExtDef ExtDefList
				for(i=0;i<2;i++){
					translate(node->n_node.node[i]);
				}
			}
		}else if(strcmp(node->n_node.name,"ExtDef")==0){
			if(node->n_node.num==2){//bs:->Specifier SEMI
				case_structSpec(node->n_node.node[0]);
			}
			if(node->n_node.num==3&&node->n_node.node[2]->type==TYPE_NTERMINAL){//bs:->Specifier FunDec CompSt
				translate_FunDec(node->n_node.node[1]);
				translate(node->n_node.node[2]);
			}
			else if(node->n_node.num==3){//bs:->Specifier ExtDecList SEMI
				case_define(node);
			}
		}else if(strcmp(node->n_node.name,"Specifier")==0){
			printf("Unexpected Existence: spec in main!\n");
		}
		else if(strcmp(node->n_node.name,"Def")==0){//bs:->Specifier DecList SEMI
			translate_Def(node);
		}
		else if(strcmp(node->n_node.name,"CompSt")==0){//bs:->LC DefList StmtList RC
			translate(node->n_node.node[1]);
			translate(node->n_node.node[2]);
		}
		else if(strcmp(node->n_node.name,"StmtList")==0||
				strcmp(node->n_node.name,"DefList")==0){
			translate(node->n_node.node[0]);
			translate(node->n_node.node[1]);
		}
		else if(strcmp(node->n_node.name,"Stmt")==0){
			translate_Stmt(node);
		}
		else if(strcmp(node->n_node.name,"Exp")==0){
			printf("Unexpected Existence: Exp in main!\n");
		}
		else if(strcmp(node->n_node.name,"Dec")==0){
			printf("Unexpected Existence: Dec in main!\n");
		}else{
			printf("!!!:unexpected un ter: %s !\n",node->n_node.name);
		}
		return 0;
	}else{
		printf("Unexpected Existence: ter in main!\n");
		exit(-1);
		return -1;
	}
}

int case_structSpec(Node* n){
	printf("struct\n");
	return 0;
}

int case_define(Node *n){
	//printf("%s\n",n->n_node.node[1]->n_node.name);
	Node *ec=n->n_node.node[1];//ExtDecList
	return translate_Extc(ec);
}

int translate_Extc(Node *n){
	//case:VarDec
	if(strcmp(n->n_node.name,"ExtDecList")==0){
		InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
			temp->kind=DEC_;
			Operand op=(Operand)malloc(sizeof(struct Operand_));
			op->kind=VARIABLE_;
			varNum++;	
			op->u.var_no=varNum;
			op->size=1;
			
			if(n->n_node.node[0]->n_node.node[0]->type==TYPE_ID){//ID
				printf("==:)ID DEC  %s ",n->n_node.node[0]->n_node.node[0]->node_id);
				insertSym(op,n->n_node.node[0]->n_node.node[0]->node_id,0);
			}else{//shuzu
				int count=0;int i=0;int size[10];
				while(n->type!=TYPE_ID){
					n=n->n_node.node[0];
					if(n->n_node.num==4){
						size[i]=n->n_node.node[2]->node_int;
						i++;
					}
					count++;
				}
				int asize=1;
				int w=0;
				for(;w<i;w++){
					asize=asize*size[w];
				}
				printf("==:)Array DEC  %s depth %d size %d :",n->node_id,count-2,asize);
				op->kind= VARIABLE_;
				op->size=asize;
				op->add=1;
				op->depth=count-2;
				
				insertSym(op,n->node_id,0);
			}
			temp->c.dec.var=op;
		t->code=temp;
		t->prev=NULL;
		t->next=NULL;
		if(!insertNode(t)){
			printf("A dec inserted!\n");
		}else{return -1;}
	}
	//case:VarDec COMMA ExtDecList
	if(n->n_node.num==3){
		translate_Extc(n->n_node.node[2]);
	}
	return 0;
}

int translate_Exp1(Node* n,Operand op){//bs:->INT ;FLOAT ;ID
	if(n->n_node.node[0]->type==TYPE_INT||n->n_node.node[0]->type==TYPE_FLOAT){
		InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
			temp->kind=ASSIGN_;
			temp->u.assign.left=op;
			Operand c=(Operand)malloc(sizeof(struct Operand_));
			c->kind=CONSTANT_;
			if(n->n_node.node[0]->type!=TYPE_INT){printf("float : ");}
			c->u.value=n->n_node.node[0]->node_int;
			temp->u.assign.right=c;
		t->code=temp;
		t->prev=NULL;
		t->next=NULL;
		if(!insertNode(t)){
			printf("A Assign inserted!value :%d\n",temp->u.assign.right->u.value);
		}else{return -1;}
	}else if(n->n_node.node[0]->type==TYPE_ID){
		InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
			temp->kind=ASSIGN_;
			temp->u.assign.left=op;
			Operand id=(Operand)malloc(sizeof(struct Operand_));
			id=lookup(n->n_node.node[0]->node_id);
			if(id==NULL){printf("ID not find!\n");return -1;}
			temp->u.assign.right=id;
		t->code=temp;
		t->prev=NULL;
		t->next=NULL;
		if(!insertNode(t)){
			printf("A Assign inserted! \n");
		}else{return -1;}
	}
}
int translate_Exp2(Node* n,Operand op){//bs:->NOT Exp ;MINUS Exp ;
	if(n->n_node.num==3||strcmp(n->n_node.node[0]->node_other_ter,"NOT")==0){
		Operand op1=(Operand)malloc(sizeof(struct Operand_));
		Operand op2=(Operand)malloc(sizeof(struct Operand_));
		op1->kind=LABEL;
		op2->kind=LABEL;
		op1->u.label_no=(++labelNum);
		op2->u.label_no=(++labelNum);
		
		InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
			Operand c=(Operand)malloc(sizeof(struct Operand_));
			c->kind=CONSTANT_;
			c->u.value=0;
			InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
			temp->kind=ASSIGN_;
			temp->u.assign.left=op;
			temp->u.assign.right=c;
		t->code=temp;
		t->prev=NULL;
		t->next=NULL;
		if(!insertNode(t)){
			printf("A Assign inserted! \n");
		}else{return -1;}
		
		translate_Cond(n,op1,op2);
		
		InterCodes t1=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp1=(InterCode)malloc(sizeof(struct InterCode_));
			temp1->kind=LABEL_;
			temp1->s.label.label=op1;
		t1->code=temp1;
		t1->prev=NULL;
		t1->next=NULL;
		if(!insertNode(t1)){
			printf("A new label inserted!label:%d\n",temp1->s.label.label->u.label_no);
		}else{return -1;}	

		InterCodes t3=(InterCodes)malloc(sizeof(struct InterCodes_));
			Operand c1=(Operand)malloc(sizeof(struct Operand_));
			c1->kind=CONSTANT_;
			c1->u.value=1;
			InterCode temp3=(InterCode)malloc(sizeof(struct InterCode_));
			temp3->kind=ASSIGN_;
			temp3->u.assign.left=op;
			temp3->u.assign.right=c1;
		t3->code=temp;
		t3->prev=NULL;
		t3->next=NULL;
		if(!insertNode(t3)){
			printf("A Assign inserted! \n");
		}else{return -1;}

		InterCodes t2=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp2=(InterCode)malloc(sizeof(struct InterCode_));
			temp2->kind=LABEL_;
			temp2->s.label.label=op2;
		t2->code=temp2;
		t2->prev=NULL;
		t2->next=NULL;
		if(!insertNode(t2)){
			printf("A new label inserted!label:%d\n",temp2->s.label.label->u.label_no);
		}else{return -1;}
		
	}
	else if(strcmp(n->n_node.node[0]->node_other_ter,"MINUS")==0){
		Operand t1=(Operand)malloc(sizeof(struct Operand_));
		t1->kind=TEMP_;
		t1->u.tem_no=(++tNum);

		translate_Exp(n->n_node.node[1],t1);
		InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
			Operand c=(Operand)malloc(sizeof(struct Operand_));
			c->kind=CONSTANT_;
			c->u.value=0;
			InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
			temp->kind=MINUS_;
			temp->u.binop.op1=c;
			temp->u.binop.op2=t1;
			temp->u.binop.result=op;
		t->code=temp;
		t->prev=NULL;
		t->next=NULL;
		if(!insertNode(t)){
			printf("A MINUS inserted! ");
		}else{return -1;}
	}else{
		printf("unexpected problem in Exp2!\n");
	}
}
int translate_Exp3(Node* n,Operand op){
	//printf("%d\n",n->n_node.node[1]->n_node.num);
	if(strcmp(n->n_node.node[1]->node_other_ter,"PLUS")==0
		||strcmp(n->n_node.node[1]->node_other_ter,"DIV")==0
			||strcmp(n->n_node.node[1]->node_other_ter,"MINUS")==0
				||strcmp(n->n_node.node[1]->node_other_ter,"STAR")==0){//bs:->Exp PLUS Exp
		Operand t1=(Operand)malloc(sizeof(struct Operand_));
		Operand t2=(Operand)malloc(sizeof(struct Operand_));
		t1->kind=TEMP_;
		t2->kind=TEMP_;
		t1->u.tem_no=(++tNum);
		t2->u.tem_no=(++tNum);
		printf("\n");
		translate_Exp(n->n_node.node[0],t1);
		translate_Exp(n->n_node.node[2],t2);

		InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
			//四则运算
			if(strcmp(n->n_node.node[1]->node_other_ter,"PLUS")==0){
				temp->kind=ADD_;
			}else if(strcmp(n->n_node.node[1]->node_other_ter,"STAR")==0){
				temp->kind=MUL_;
			}else if(strcmp(n->n_node.node[1]->node_other_ter,"DIV")==0){
				temp->kind=DIV_;
			}else if(strcmp(n->n_node.node[1]->node_other_ter,"MINUS")==0){
				temp->kind=MINUS_;
			}else{
				printf("unexpected case in CLC!\n");
				return -1;
			}
			temp->u.binop.result=op;
			//printf("%d %d\n\n",op->u.tem_no,op->u.var_no);
			temp->u.binop.op1=t1;
			temp->u.binop.op2=t2;
		t->code=temp;
		t->prev=NULL;
		t->next=NULL;
		if(!insertNode(t)){
			printf("A CLC: %s inserted! \n",n->n_node.node[1]->node_other_ter);
		}else{return -1;}
	}else if(strcmp(n->n_node.node[1]->node_other_ter,"RELOP")==0){//bs:->Exp RELOP Exp
		translate_Exp2(n,op);
	}else if(strcmp(n->n_node.node[1]->node_other_ter,"AND")==0){//bs:->Exp AND Exp
		translate_Exp2(n,op);
	}else if(strcmp(n->n_node.node[1]->node_other_ter,"OR")==0){//bs:->Exp OR Exp
		translate_Exp2(n,op);
	}else if(strcmp(n->n_node.node[0]->node_other_ter,"LP")==0){//bs:->LP Exp RP
		translate_Exp(n->n_node.node[1],op);
	}else if(strcmp(n->n_node.node[1]->node_other_ter,"DOT")==0){//bs:->Exp Dot ID
		printf("DON'T ACCEPT STRUCT VARIABLE!\n");
		exit(-1);
	}else if(strcmp(n->n_node.node[1]->node_other_ter,"ASSIGNOP")==0){//bs:->Exp1 = Exp2
		if(n->n_node.node[0]->n_node.node[0]->type!=TYPE_NTERMINAL){//Exp1->ID
			Operand t1=(Operand)malloc(sizeof(struct Operand_));
			t1->kind=TEMP_;
			t1->u.tem_no=(++tNum);
			Operand v=(Operand)malloc(sizeof(struct Operand_));
			//printf("id: %s\n",n->n_node.node[0]->n_node.node[0]->node_id);
			v=lookup(n->n_node.node[0]->n_node.node[0]->node_id);
			if(v==NULL){printf("ID not find!\n");}

			translate_Exp(n->n_node.node[2],t1);

			InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
				temp->kind=ASSIGN_;
				temp->u.assign.left=v;
				temp->u.assign.right=t1;
			t->code=temp;
			t->prev=NULL;
			t->next=NULL;
			if(!insertNode(t)){
				printf("A Assign inserted! \n");
			}else{return -1;}
		}else{//TODO:数组元素
			Node* node1=n->n_node.node[0];//Exp
			if(node1->n_node.num==4&&strcmp(node1->n_node.node[1]->node_other_ter,"LB")==0){
				Node* node=node1;
				while(node->type!=TYPE_ID){
					node=node->n_node.node[0];
				}
				Operand v=lookup(node->node_id);//获取*（&v+x*#4）;需要x大小;
				if(v==NULL){printf("Not find!\n");}
					Operand tp1=(Operand)malloc(sizeof(struct Operand_));
					tp1->add=1;
					tp1->kind=TEMP_;
					tp1->u.tem_no=(++tNum);
					Operand tp2=(Operand)malloc(sizeof(struct Operand_));
					tp2->kind=TEMP_;
					tp2->u.tem_no=(++tNum);

				if(node1->n_node.node[0]->n_node.num!=4){//一维数组								
					translate_Exp(node1->n_node.node[2],tp2);
					Operand c=(Operand)malloc(sizeof(struct Operand_));
					c->kind=CONSTANT_;
					c->u.value=4;
					
					InterCodes t3=(InterCodes)malloc(sizeof(struct InterCodes_));
						InterCode temp3=(InterCode)malloc(sizeof(struct InterCode_));
						temp3->kind=MUL_;
						temp3->u.binop.result=tp2;
						temp3->u.binop.op1=tp2;
						temp3->u.binop.op2=c;
					t3->code=temp3;
					t3->prev=NULL;
					t3->next=NULL;
					if(!insertNode(t3)){
						printf("A CLC mul inserted! \n");
					}else{return -1;}
				
					InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
						InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
						temp->kind=ADD_;
						temp->u.binop.result=tp1;
						temp->u.binop.op1=v;
						temp->u.binop.op2=tp2;
					t->code=temp;
					t->prev=NULL;
					t->next=NULL;
					if(!insertNode(t)){
						printf("A CLC plus inserted! \n");
					}else{return -1;}

					InterCodes t2=(InterCodes)malloc(sizeof(struct InterCodes_));
						InterCode temp1=(InterCode)malloc(sizeof(struct InterCode_));
						temp1->kind=ASSIGN_;
						temp1->u.assign.left=tp1;
						op=(Operand)malloc(sizeof(struct Operand_));
						op->kind=TEMP_;
						translate_Exp(n->n_node.node[2],op);
						temp1->u.assign.right=op;
					t2->code=temp1;
					t2->prev=NULL;
					t2->next=NULL;
					if(!insertNode(t2)){
						printf("A Assign inserted! \n");
					}else{return -1;}
				}else{//TODO:
					printf("left case: a[i][j] to be solved!\n");
				}
			}else{
				printf("struct!\n");
			}
		}
	}
	else if(strcmp(n->n_node.node[1]->node_other_ter,"LP")==0){//bs:->ID LP RP
		Operand f=(Operand)malloc(sizeof(struct Operand_));
		printf("func: %s\n",n->n_node.node[0]->node_id);
		f=lookup(n->n_node.node[0]->node_id);
		if(f!=NULL&&strcmp(f->u.id,"read")==0){//read
			printf("function : read!\n");
			InterCodes t2=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp1=(InterCode)malloc(sizeof(struct InterCode_));
				temp1->kind=READ_;
				temp1->p.rd.rd=op;
			t2->code=temp1;
			t2->prev=NULL;
			t2->next=NULL;
			if(!insertNode(t2)){
				printf("A READ inserted! \n");
			}else{return -1;}
		}else{
			InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
				temp->kind=CALL_;
				temp->c.call.func=f;
				temp->c.call.rst=op;
			t->code=temp;
			t->prev=NULL;
			t->next=NULL;
			if(!insertNode(t)){
				printf("A CALL inserted! \n");
			}else{return -1;}
		}
	}else{
		printf("here!\n");
	}
}

int translate_Args(Node* n,symTable st,char*func){
		Operand t1=(Operand)malloc(sizeof(struct Operand_));
		symTable st1=(symTable)malloc(sizeof(struct symTable_));
		Node* nn=n->n_node.node[0];
		while(nn->type!=TYPE_ID&&nn->type==TYPE_NTERMINAL){
			nn=nn->n_node.node[0];
		}
		if(nn->type==TYPE_ID){t1=lookup(nn->node_id);}
		Operand t2=(Operand)malloc(sizeof(struct Operand_));
		t2=lookup(func);
		if(t2->add==1){//需要参数类型为数组地址
			if(n->n_node.node[0]->n_node.node[0]->type!=TYPE_ID){//数组元素
				printf("mismatch!\n");
			}else{//判断是否数组符号
				if(t1->add==1){
					printf("array name!\n");
					st1->id=n->n_node.node[0]->n_node.node[0]->node_id;
					printf("%s\n",st1->id);
					st1->op=t1;
					symTable a=st;
					while(a->next!=NULL){
						a=a->next;
					}
					a->next=st1;
				}else{
					printf("just a id \n");
				}
			}
		}else{//需要参数类型为整数
			if(n->n_node.node[0]->n_node.node[0]->type==TYPE_NTERMINAL){//是数组元素
				printf("array node!\n");
				Operand tp=(Operand)malloc(sizeof(struct Operand_));
				tp->kind=TEMP_;
				tp->add=0;
				tp->u.tem_no=(++tNum);
				translate_Exp(n->n_node.node[0],tp);
				
				st1->id=n->n_node.node[0]->n_node.node[0]->node_id;
				st1->op=tp;
				symTable a=st;
				while(a->next!=NULL){
					a=a->next;
				}
				a->next=st1;
			}else{  //判断是否整数/数组地址
				if(t1->add==1){
					printf("a address!\n");
				}else{
					Operand tp=(Operand)malloc(sizeof(struct Operand_));
					tp->kind=TEMP_;
					tp->add=0;
					tp->u.tem_no=(++tNum);
					translate_Exp(n->n_node.node[0],tp);
					st1->id=n->n_node.node[0]->n_node.node[0]->node_id;
					st1->op=tp;
					symTable a=st;
					while(a->next!=NULL){
						a=a->next;
					}
					a->next=st1;
				}
			}
		}	
	if(n->n_node.num==3){//bs:->Exp COMMA Args
		translate_Args(n->n_node.node[2],st,func);
	}
}

int translate_Exp4(Node* n,Operand op){
	if(n->n_node.node[0]->type==TYPE_ID){//bs:->ID LP Args RP
		Operand f=(Operand)malloc(sizeof(struct Operand_));
		f=lookup(n->n_node.node[0]->node_id);//
		
		symTable arglist=(symTable)malloc(sizeof(struct symTable_));
		translate_Args(n->n_node.node[2],arglist,n->n_node.node[0]->node_id);
		
		if(f!=NULL&&strcmp(f->u.id,"write")==0){
			printf("function : write!\n");
			InterCodes t2=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp1=(InterCode)malloc(sizeof(struct InterCode_));
				temp1->kind=WRITE_;
				temp1->p.wt.wt=arglist->next->op;//
			t2->code=temp1;
			t2->prev=NULL;
			t2->next=NULL;
			if(!insertNode(t2)){
				printf("A WRITE inserted! \n");
			}else{return -1;}
		}else if(f!=NULL){
			symTable arg=(symTable)malloc(sizeof(struct symTable_));
			arg=arglist;
			while(arg->next!=NULL){//
				InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
					InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
					temp->kind=ARG_;
					temp->s.arg.arg=arg->next->op;
				t->code=temp;
				t->prev=NULL;
				t->next=NULL;
				if(!insertNode(t)){
					printf("A ARG inserted! \n");
				}else{return -1;}
				arg=arg->next;
			}
			
			InterCodes t1=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp2=(InterCode)malloc(sizeof(struct InterCode_));
				temp2->kind=CALL_;
				temp2->c.call.func=f;
				temp2->c.call.rst=op;
			t1->code=temp2;
			t1->prev=NULL;
			t1->next=NULL;
			if(!insertNode(t1)){
				printf("A CALL inserted! \n");
			}else{return -1;}
		}
	}else if(n->n_node.node[0]->type==TYPE_NTERMINAL){//bs:->Exp LB Exp RB
		if(n->n_node.node[0]->n_node.num!=4){
			Operand op1=(Operand)malloc(sizeof(struct Operand_));
			Operand op2=(Operand)malloc(sizeof(struct Operand_));
			Operand op3=(Operand)malloc(sizeof(struct Operand_));
			if(n->n_node.node[2]->n_node.node[0]->node_int==0){
				op2->kind=TEMP_;
				op2->u.tem_no=(++tNum);
				//printf("%s\n",n->n_node.node[0]->n_node.node[0]->node_id);
				op1=lookup(n->n_node.node[0]->n_node.node[0]->node_id);
				if(op1==NULL){printf("shuzu NULL!\n");}
				InterCodes t1=(InterCodes)malloc(sizeof(struct InterCodes_));
					InterCode temp2=(InterCode)malloc(sizeof(struct InterCode_));
					temp2->kind=ASSIGN_;
					temp2->u.assign.left=op;
					temp2->u.assign.right=op1;
				t1->code=temp2;
				t1->prev=NULL;
				t1->next=NULL;
				if(!insertNode(t1)){
					printf("A ASSIGN inserted! \n");
				}else{return -1;}
			}else{
				op3=lookup(n->n_node.node[0]->n_node.node[0]->node_id);
				if(op3==NULL){printf("shuzu NULL!\n");}
				op2->kind=TEMP_;
				op2->add=1;
				op2->u.tem_no=(++tNum);
				op1->kind=CONSTANT_;
				op1->u.value=n->n_node.node[2]->n_node.node[0]->node_int*4;
				InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
					InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
					temp->kind=ADD_;
					temp->u.binop.result=op2;
					temp->u.binop.op1=op3;
					temp->u.binop.op2=op1;
				t->code=temp;
				t->prev=NULL;
				t->next=NULL;
				if(!insertNode(t)){
					printf("A ADD inserted! \n");
				}else{return -1;}
				
				//printf("%s\n",n->n_node.node[0]->n_node.node[0]->node_id);
				op1=lookup(n->n_node.node[0]->n_node.node[0]->node_id);
				if(op1==NULL){printf("shuzu NULL!\n");}
				InterCodes t1=(InterCodes)malloc(sizeof(struct InterCodes_));
					InterCode temp2=(InterCode)malloc(sizeof(struct InterCode_));
					temp2->kind=ASSIGN_;
					temp2->u.assign.left=op;
					temp2->u.assign.right=op2;
				t1->code=temp2;
				t1->prev=NULL;
				t1->next=NULL;
				if(!insertNode(t1)){
					printf("A ASSIGN inserted! \n");
				}else{return -1;}
			}
		}else{//TODO:
			printf("gao wei shu zu!\n");
			Node * m=n->n_node.node[0];
			while(m->type!=TYPE_ID){
				m=m->n_node.node[0];
			}
			char* id=m->node_id;
			Operand tp=(Operand)malloc(sizeof(struct Operand_));
			tp=lookup(id);
			if(tp==NULL){
				printf("id not find!\n");
			}else{
				printf("%s\n",id);
			}
		}
	}else{
		printf("unexpected case in transExp4 !\n");
		return -1;
	}
}
int translate_Exp(Node* n,Operand op){
	//if(op!=NULL)printf("%d\n\n",op->u.tem_no);
	if(n->n_node.num==1){
		//printf("exp:1\n");
		return translate_Exp1(n,op);
	}else if(n->n_node.num==2){
		//printf("exp:2\n");
		return translate_Exp2(n,op);
	}else if(n->n_node.num==3){
		//printf("exp:3\n");
		return translate_Exp3(n,op);
	}else if(n->n_node.num==4){
		//printf("exp:4\n");
		return translate_Exp4(n,op);
	}else{
		printf("unexpected case in Exp!\n");
		return -1;
	}
}

int translate_CompSt(Node* n){
	return translate(n);
}

int translate_Cond(Node* n,Operand op1,Operand op2){
	if(n->n_node.num==2){//bs:->Not Exp
		return translate_Cond(n,op2,op1);
	}else{
		if(n->n_node.num!=1&&strcmp(n->n_node.node[1]->node_other_ter,"RELOP")==0){
			Operand t1=(Operand)malloc(sizeof(struct Operand_));
			Operand t2=(Operand)malloc(sizeof(struct Operand_));
			t1->kind=TEMP_;
			t1->u.tem_no=(++tNum);
			t2->kind=TEMP_;
			t2->u.tem_no=(++tNum);
			
			translate_Exp(n->n_node.node[0],t1);			//code1
			translate_Exp(n->n_node.node[2],t2);			//code2
										//code3
			InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
				temp->kind=IF_;
				temp->c.as.relop=(char*)malloc(sizeof(char)*10);
				temp->c.as.relop=getrelop(n->n_node.node[1]);
				temp->c.as.op1=t1;
				temp->c.as.op2=t2;
				temp->c.as.label=op1;
			t->code=temp;
			t->prev=NULL;
			t->next=NULL;
			if(!insertNode(t)){
				printf("A IF inserted!right label:%d\n",temp->c.as.label->u.label_no);
			}else{return -1;}
										//code4
			InterCodes tp1=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp1=(InterCode)malloc(sizeof(struct InterCode_));
				temp1->kind=GOTO_;
				temp1->c.gt.gt=op2;
			tp1->code=temp1;
			tp1->prev=NULL;
			tp1->next=NULL;
			if(!insertNode(tp1)){
				printf("A GOTO inserted!targ label:%d\n",temp1->c.gt.gt->u.label_no);
			}else{return -1;}
		}else if(n->n_node.num!=1&&strcmp(n->n_node.node[1]->node_other_ter,"AND")==0){
			Operand label=(Operand)malloc(sizeof(struct Operand_));
			label->kind=LABEL;
			label->u.label_no=(++labelNum);
			
			translate_Cond(n->n_node.node[0],label,op2);		//code1
			
			InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
				temp->kind=LABEL_;
				temp->s.label.label=label;
			t->code=temp;
			t->prev=NULL;
			t->next=NULL;
			if(!insertNode(t)){
				printf("A new label inserted!label:%d\n",temp->s.label.label->u.label_no);
			}else{return -1;}					//label1
			
			translate_Cond(n->n_node.node[2],op1,op2);		//code2
			
		}else if(n->n_node.num!=1&&strcmp(n->n_node.node[1]->node_other_ter,"OR")==0){
			Operand label=(Operand)malloc(sizeof(struct Operand_));
			label->kind=LABEL;
			label->u.label_no=(++labelNum);
			
			translate_Cond(n->n_node.node[0],op1,label);		//code1
			
			InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
				temp->kind=LABEL_;
				temp->s.label.label=label;
			t->code=temp;
			t->prev=NULL;
			t->next=NULL;
			if(!insertNode(t)){
				printf("A new label inserted!label:%d\n",temp->s.label.label->u.label_no);
			}else{return -1;}					//label1
			
			translate_Cond(n->n_node.node[2],op1,op2);		//code2
		}else{//Exp
			Operand t1=(Operand)malloc(sizeof(struct Operand_));
			t1->kind=TEMP_;
			t1->u.tem_no=(++tNum);
			//printf("%s\n",n->n_node.name);
			translate_Exp(n,t1);					

			InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
				Operand c1=(Operand)malloc(sizeof(struct Operand_));
				c1->kind=CONSTANT_;
				c1->u.value=0;
				InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
				temp->kind=IF_;
				temp->c.as.op1=t1;
				temp->c.as.op2=c1;
				temp->c.as.relop=(char*)malloc(sizeof(char)*10);
				strcpy(temp->c.as.relop,"!=");
				temp->c.as.label=op1;
			t->code=temp;
			t->prev=NULL;
			t->next=NULL;
			if(!insertNode(t)){
				printf("A IF inserted!targ label:%d\n",temp->c.as.label->u.label_no);
			}else{return -1;}
			
			InterCodes t2=(InterCodes)malloc(sizeof(struct InterCodes_));
				InterCode temp1=(InterCode)malloc(sizeof(struct InterCode_));
				temp1->kind=GOTO_;
				temp1->c.gt.gt=op2;
			t2->code=temp1;
			t2->prev=NULL;
			t2->next=NULL;
			if(!insertNode(t2)){
				printf("A GOTO inserted!targ label:%d\n",temp1->c.gt.gt->u.label_no);
			}else{return -1;}
		}
	}
	return 0;
}

int translate_Stmt(Node* n){
	if(strcmp(n->n_node.node[0]->n_node.name,"Exp")==0){//bs:->Exp SEMI
		return translate_Exp(n->n_node.node[0],NULL);
	}
	else if(strcmp(n->n_node.node[0]->n_node.name,"CompSt")==0){//bs:->CompSt
		return translate_CompSt(n->n_node.node[0]);
	}
	else if(strcmp(n->n_node.node[1]->n_node.name,"Exp")==0){//bs:->RETURN Exp SEMI	
		Operand temp1=(Operand)malloc(sizeof(struct Operand_));
		temp1->kind=TEMP_;
		temp1->u.tem_no=(++tNum);			//temp:temp1

		translate_Exp(n->n_node.node[1],temp1);
		InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
			temp->kind=RETURN_;
			temp->c.rt.rt=temp1;
		t->code=temp;
		t->prev=NULL;
		t->next=NULL;
		if(!insertNode(t)){
			printf("A return Node inserted!\n");
		}else{return -1;}
	}
	else if(n->n_node.num==5&&strcmp(n->n_node.node[0]->node_other_ter,"IF")==0){//bs:->IF LP Exp RP Stmt
		Operand op1=(Operand)malloc(sizeof(struct Operand_));
		Operand op2=(Operand)malloc(sizeof(struct Operand_));
		op1->kind=LABEL;
		op2->kind=LABEL;
		op1->u.label_no=(++labelNum);
		op2->u.label_no=(++labelNum);
								//translate_Cond
		translate_Cond(n->n_node.node[2],op1,op2);	//LABEL: label
		InterCodes t1=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp1=(InterCode)malloc(sizeof(struct InterCode_));
			temp1->kind=LABEL_;
			temp1->s.label.label=op1;
		t1->code=temp1;
		t1->prev=NULL;
		t1->next=NULL;
		if(!insertNode(t1)){
			printf("A new label inserted!label:%d\n",temp1->s.label.label->u.label_no);
		}else{return -1;}

		translate_Stmt(n->n_node.node[4]);		//translate_Stmt
		InterCodes t2=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp2=(InterCode)malloc(sizeof(struct InterCode_));
			temp2->kind=LABEL_;
			temp2->s.label.label=op2;
		t2->code=temp2;
		t2->prev=NULL;
		t2->next=NULL;
		if(!insertNode(t2)){
			printf("A new label inserted!label:%d\n",temp2->s.label.label->u.label_no);
		}else{return -1;}				//LABEL:label
	}
	else if(n->n_node.num==7){//bs:->IF LP Exp RP Stmt ELSE Stmt
		Operand op1=(Operand)malloc(sizeof(struct Operand_));
		Operand op2=(Operand)malloc(sizeof(struct Operand_));
		Operand op3=(Operand)malloc(sizeof(struct Operand_));
		op1->kind=LABEL;
		op2->kind=LABEL;
		op3->kind=LABEL;
		op1->u.label_no=(++labelNum);
		op2->u.label_no=(++labelNum);
		op3->u.label_no=(++labelNum);
		
		translate_Cond(n->n_node.node[2],op1,op2);	//translate_Cond
		InterCodes t1=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp1=(InterCode)malloc(sizeof(struct InterCode_));
			temp1->kind=LABEL_;
			temp1->s.label.label=op1;
		t1->code=temp1;
		t1->prev=NULL;
		t1->next=NULL;
		if(!insertNode(t1)){
			printf("A new label inserted!label:%d\n",temp1->s.label.label->u.label_no);
		}else{return -1;}				//LABEL:label
		translate_Stmt(n->n_node.node[4]);		//translate_Stmt
		InterCodes t2=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp2=(InterCode)malloc(sizeof(struct InterCode_));
			temp2->kind=LABEL_;
			temp2->s.label.label=op2;
		t2->code=temp2;
		t2->prev=NULL;
		t2->next=NULL;
		if(!insertNode(t2)){
			printf("A new label inserted!label:%d\n",temp2->s.label.label->u.label_no);
		}else{return -1;}				//LABEL:label
		translate_Stmt(n->n_node.node[6]);		//translate_Stmt
		InterCodes t3=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp3=(InterCode)malloc(sizeof(struct InterCode_));
			temp3->kind=LABEL_;
			temp3->s.label.label=op3;
		t3->code=temp3;
		t3->prev=NULL;
		t3->next=NULL;
		if(!insertNode(t3)){
			printf("A new label inserted!label:%d\n",temp3->s.label.label->u.label_no);
		}else{return -1;}				//LABEL:label
	}
	else if(n->n_node.num==5){//bs:->WHILE LP Exp RP Stmt
		Operand op1=(Operand)malloc(sizeof(struct Operand_));
		Operand op2=(Operand)malloc(sizeof(struct Operand_));
		Operand op3=(Operand)malloc(sizeof(struct Operand_));
		op1->kind=LABEL;
		op2->kind=LABEL;
		op3->kind=LABEL;
		op1->u.label_no=(++labelNum);
		op2->u.label_no=(++labelNum);
		op3->u.label_no=(++labelNum);
		
		InterCodes t1=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp1=(InterCode)malloc(sizeof(struct InterCode_));
			temp1->kind=LABEL_;
			temp1->s.label.label=op1;
		t1->code=temp1;
		t1->prev=NULL;
		t1->next=NULL;
		if(!insertNode(t1)){
			printf("A new label inserted!label:%d\n",temp1->s.label.label->u.label_no);
		}else{return -1;}				//LABEL:label
		
		translate_Cond(n->n_node.node[2],op2,op3);	//translate_Cond
		InterCodes t2=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp2=(InterCode)malloc(sizeof(struct InterCode_));
			temp2->kind=LABEL_;
			temp2->s.label.label=op2;
		t2->code=temp2;
		t2->prev=NULL;
		t2->next=NULL;
		if(!insertNode(t2)){
			printf("A new label inserted!label:%d\n",temp2->s.label.label->u.label_no);
		}else{return -1;}				//LABEL:label
		translate_Stmt(n->n_node.node[4]);		//translate_Stmt
								//goto
		InterCodes t4=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp4=(InterCode)malloc(sizeof(struct InterCode_));
			temp4->kind=GOTO_;
			temp4->c.gt.gt=op1;
		t4->code=temp4;
		t4->prev=NULL;
		t4->next=NULL;
		if(!insertNode(t4)){
			printf("A GOTO inserted!targ label:%d\n",temp4->c.gt.gt->u.label_no);
		}else{return -1;}
		InterCodes t3=(InterCodes)malloc(sizeof(struct InterCodes_));
			InterCode temp3=(InterCode)malloc(sizeof(struct InterCode_));
			temp3->kind=LABEL_;
			temp3->s.label.label=op3;
		t3->code=temp3;
		t3->prev=NULL;
		t3->next=NULL;
		if(!insertNode(t3)){
			printf("A new label inserted!label:%d\n",temp3->s.label.label->u.label_no);
		}else{return -1;}				//LABEL:label
	}else{
		printf("case unexpected in stmt!\n");
	}
	return 0;
}

int translate_Def(Node* n){//bs->Specifier DecList SEMI
	while(strcmp(n->n_node.name,"DecList")!=0){
		n=n->n_node.node[1];
	}
	//Deal with Dec
	Node* m=n->n_node.node[0];//dec
	Node* v=m->n_node.node[0];//vardec
	InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
		InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
		Operand var=(Operand)malloc(sizeof(struct Operand_));
		var->kind=VARIABLE_;
		var->size=1;
		var->u.var_no=(++varNum);
		if(v->n_node.num==1){//var->id
			printf("==:) ID Dec %s ",v->n_node.node[0]->node_id);		
			insertSym(var,v->n_node.node[0]->node_id,0);
		}else{//array
			int count=0;int size[10];
			while(v->type!=TYPE_ID){
				if(v->n_node.num==4){
					size[count]=v->n_node.node[2]->node_int;
				}
				v=v->n_node.node[0];
				count++;
			}
			int asize=1;int i=0;
			for(;i<count-1;i++){
				asize=asize*size[i];
			}
			printf("==:) Array Dec %s depth %d size %d ",v->node_id,count-1,asize);
			var->depth=count-1;
			var->size=asize;
			var->kind=VARIABLE_;
			var->len=size;
			var->add=1;
			insertSym(var,v->node_id,0);
		}
		temp->kind=DEC_;
		temp->c.dec.var=var;
	t->code=temp;
	t->prev=NULL;
	t->next=NULL;
	if(!insertNode(t)){
		printf(" A dec Inserted !\n");
	}else{return -1;}
	if(m->n_node.num==3){
		printf("Deal with dec assign!\n");
		translate_Exp(m->n_node.node[2],var);
	}
	if(n->n_node.num==3){//Dec COMMA DecList
		translate_Def(n->n_node.node[2]);
	}
	return 0;
}

int translate_FunDec(Node* n){
	InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
		InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
		temp->kind=FUNC_;
			Operand op=(Operand)malloc(sizeof(struct Operand_));
			op->kind=FUNC;
			op->u.id=(char*)malloc(sizeof(char)*10);
			strcpy(op->u.id,n->n_node.node[0]->node_id);
			insertSym(op,op->u.id,2);
		temp->s.func.func=op;
		
		printf("==:) FUNCTION %s : ",op->u.id);
	t->code=temp;
	t->prev=NULL;
	t->next=NULL;
	if(!insertNode(t)){
		printf("A Func Inserted !\n");
	}else{return -1;}
	if(n->n_node.num==4){
		translate_Para(n->n_node.node[2],op->u.id);//VarList
	}
	return 0;
}

int translate_Para(Node* n,char*func){
	InterCodes t=(InterCodes)malloc(sizeof(struct InterCodes_));
		InterCode temp=(InterCode)malloc(sizeof(struct InterCode_));
		temp->kind=PARA_;

		Operand op=(Operand)malloc(sizeof(struct Operand_));
		if(n->n_node.node[0]->n_node.node[1]->n_node.node[0]->type==TYPE_ID){
			Operand f=(Operand)malloc(sizeof(struct Operand_));
			f=lookup(func);
			f->add=0;
			//printf("\nID\n");
			op->kind=VARIABLE_;
			printf("==:) PARA %s : ",n->n_node.node[0]->n_node.node[1]->n_node.node[0]->n_node.name);
			varNum++;
			op->u.var_no=varNum;
			op->size=1;
			insertSym(op,n->n_node.node[0]->n_node.node[1]->n_node.node[0]->n_node.name,1);
		}else{
			Operand f=(Operand)malloc(sizeof(struct Operand_));
			f=lookup(func);
			f->add=1;
			//printf("%s\n",n->n_node.node[0]->n_node.node[1]->n_node.node[0]->n_node.node[0]->n_node.name);
			op->kind=VARIABLE_;
			varNum++;
			op->u.var_no=varNum;
			op->add=1;
			printf("==:) PARA %s : ",n->n_node.node[0]->n_node.node[1]->n_node.node[0]->n_node.node[0]->n_node.name);
			//printf("%d\n",n->n_node.node[0]->n_node.node[1]->n_node.node[2]->node_int);
			op->size=n->n_node.node[0]->n_node.node[1]->n_node.node[2]->node_int;
			insertSym(op,n->n_node.node[0]->n_node.node[1]->n_node.node[0]->n_node.node[0]->n_node.name,1);
		}
		temp->s.Para.Para=op;
	t->code=temp;
	t->prev=NULL;
	t->next=NULL;
	if(!insertNode(t)){
		printf("A Para Inserted !\n");
	}else{return -1;}
	
	if(n->n_node.num==3){//bs:->ParamDec COMMA VarList
		translate_Para(n->n_node.node[2],func);
	}
	return 0;
}

