#include "./translate.h"

char *getrelop(Node* n){						//TODO:			
	return n->text;
}

int init_symTable(){
	//table=(symTable)malloc(sizeof(struct symTable_));
	//table->next=NULL;
	Operand op1=(Operand)malloc(sizeof(struct Operand_));
	Operand op2=(Operand)malloc(sizeof(struct Operand_));
	op1->kind=FUNC;
	op1->u.id=(char*)malloc(sizeof(char)*5);
	strcpy(op1->u.id,"read");
	insertSym(op1,"read",2);
	op2->kind=FUNC;
	op2->u.id=(char*)malloc(sizeof(char)*5);
	strcpy(op2->u.id,"write");
	insertSym(op2,"write",2);
	return 0;
}

int insertSym(Operand op,char* id,int field){
	symTable s=(symTable)malloc(sizeof(struct symTable_));
	s->id=id;
	s->op=op;
	s->field=field;
	s->next=NULL;
	symTable temp=table;
	if (table==NULL) { table=s; table->next=NULL;}
	else
	{
	 while(temp->next!=NULL){
	 	temp=temp->next;
	 }
	 temp->next=s;
	}
}

Operand lookup(char* id){
	symTable temp=(symTable)malloc(sizeof(struct symTable_));
	temp=table;
	//printf("%s %s\n",temp->id,id);
	while(temp!=NULL){
		if(strcmp(temp->id,id)==0){
			//printf("find\n");
			return temp->op;
		}else{
			temp=temp->next;
		}
	}
	return NULL;
}

int do_write(){
	InterCodes s=Container;
	//ASSIGN_, ADD_, MUL_,DIV_,MINUS_,/**/LABEL_,FUNC_,PARA_,ARG_,
	//		/**/GOTO_,IF_,RETURN_,DEC_,CALL_,/**/READ_,WRITE_} kind;
	
	//
	printf("==========================================================\n");
	printf("		strat to write!\n");
	FILE* f=fopen("./iris.ir","w");
	if(f==NULL){printf("open failed!\n");}
	while(s->next!=Container){
		//fprintf(f,"%d\n",s->next->code->kind);
		if(s->next->code->kind==FUNC_){
			fprintf(f,"FUNCTION  %s :\n",s->next->code->s.func.func->u.id);
		}
		if(s->next->code->kind==RETURN_){
			fprintf(f,"RETURN t%d \n",s->next->code->c.rt.rt->u.tem_no);
		}
		if(s->next->code->kind==IF_){
			if(s->next->code->c.as.op1->kind==VARIABLE_){
				if(s->next->code->c.as.op2->kind==CONSTANT_){
					fprintf(f,"IF v%d %s #%d GOTO label%d\n",s->next->code->c.as.op1->u.var_no,
						s->next->code->c.as.relop,s->next->code->c.as.op2->u.value,
							s->next->code->c.as.label->u.label_no);
				}else if(s->next->code->c.as.op2->kind==VARIABLE_){
					fprintf(f,"IF v%d %s v%d GOTO label%d\n",s->next->code->c.as.op1->u.var_no,
						s->next->code->c.as.relop,s->next->code->c.as.op2->u.var_no,
							s->next->code->c.as.label->u.label_no);
				}else if(s->next->code->c.as.op2->kind==TEMP_){
					fprintf(f,"IF v%d %s t%d GOTO label%d\n",s->next->code->c.as.op1->u.var_no,
						s->next->code->c.as.relop,s->next->code->c.as.op2->u.tem_no,
							s->next->code->c.as.label->u.label_no);
				}
			}else if(s->next->code->c.as.op1->kind==TEMP_){
				if(s->next->code->c.as.op2->kind==CONSTANT_){
					fprintf(f,"IF t%d %s #%d GOTO label%d\n",s->next->code->c.as.op1->u.tem_no,
						s->next->code->c.as.relop,s->next->code->c.as.op2->u.value,
							s->next->code->c.as.label->u.label_no);
				}else if(s->next->code->c.as.op2->kind==VARIABLE_){
					fprintf(f,"IF t%d %s v%d GOTO label%d\n",s->next->code->c.as.op1->u.tem_no,
						s->next->code->c.as.relop,s->next->code->c.as.op2->u.var_no,
							s->next->code->c.as.label->u.label_no);
				}else if(s->next->code->c.as.op2->kind==TEMP_){
					fprintf(f,"IF t%d %s t%d GOTO label%d\n",s->next->code->c.as.op1->u.tem_no,
						s->next->code->c.as.relop,s->next->code->c.as.op2->u.tem_no,
							s->next->code->c.as.label->u.label_no);
				}
			}else{
				printf("err!\n\n");
			}
		}
		if(s->next->code->kind==PARA_){		
			fprintf(f,"PARAM v%d \n",s->next->code->s.Para.Para->u.var_no);
		}
		if(s->next->code->kind==LABEL_){
			fprintf(f,"LABEL label%d :\n",s->next->code->s.label.label->u.label_no);
		}
		if(s->next->code->kind==GOTO_){
			fprintf(f,"GOTO label%d\n",s->next->code->c.gt.gt->u.label_no);
		}
		if(s->next->code->kind==CALL_){
			fprintf(f,"t%d := CALL %s \n",s->next->code->c.call.rst->u.tem_no,s->next->code->c.call.func->u.id);
		}
		if(s->next->code->kind==READ_){//TODO:
			fprintf(f,"READ t%d\n",s->next->code->p.rd.rd->u.tem_no);
		}
		if(s->next->code->kind==WRITE_){
			if(s->next->code->p.wt.wt==NULL){printf("!!!err:write arg NULL!\n");}
			else fprintf(f,"WRITE t%d\n",s->next->code->p.wt.wt->u.tem_no);
		}
		if(s->next->code->kind==DEC_){
			fprintf(f,"DEC v%d %d\n",s->next->code->c.dec.var->u.var_no,s->next->code->c.dec.var->size*4);
		}
		if(s->next->code->kind==ASSIGN_){
			if(s->next->code->u.assign.left==NULL){printf("!!!err:assign left null!\n");}
			else if(s->next->code->u.assign.left->kind==VARIABLE_){
				if(s->next->code->u.assign.right->kind==CONSTANT_){
					fprintf(f,"v%d := #%d \n",s->next->code->u.assign.left->u.var_no,
						s->next->code->u.assign.right->u.value);
				}else if(s->next->code->u.assign.right->kind==VARIABLE_){
					if(s->next->code->u.assign.right->add==1){
						fprintf(f,"v%d := *v%d \n",s->next->code->u.assign.left->u.var_no,
							s->next->code->u.assign.right->u.var_no);
					}else
						fprintf(f,"v%d := v%d \n",s->next->code->u.assign.left->u.var_no,
							s->next->code->u.assign.right->u.var_no);
				}else if(s->next->code->u.assign.right->kind==TEMP_){
					if(s->next->code->u.assign.right->add==1){
						fprintf(f,"v%d := *t%d \n",s->next->code->u.assign.left->u.var_no,
							s->next->code->u.assign.right->u.tem_no);
					}else
						fprintf(f,"v%d := t%d \n",s->next->code->u.assign.left->u.var_no,
							s->next->code->u.assign.right->u.tem_no);
				}
			}else if(s->next->code->u.assign.left->kind==TEMP_){
				if(s->next->code->u.assign.right->kind==CONSTANT_){
					fprintf(f,"t%d := #%d \n",s->next->code->u.assign.left->u.tem_no,
						s->next->code->u.assign.right->u.value);
				}else if(s->next->code->u.assign.right->kind==VARIABLE_){
					if(s->next->code->u.assign.right->add==1){
						fprintf(f,"t%d := *v%d \n",s->next->code->u.assign.left->u.tem_no,
							s->next->code->u.assign.right->u.var_no);
					}else
						fprintf(f,"t%d := v%d \n",s->next->code->u.assign.left->u.tem_no,
							s->next->code->u.assign.right->u.var_no);
				}else if(s->next->code->u.assign.right->kind==TEMP_){
					if(s->next->code->u.assign.left->add==1){
						if(s->next->code->u.assign.right->add==1){
							fprintf(f,"*t%d := *t%d \n",s->next->code->u.assign.left->u.tem_no,
								s->next->code->u.assign.right->u.tem_no);
						}else
							fprintf(f,"*t%d := t%d \n",s->next->code->u.assign.left->u.tem_no,
								s->next->code->u.assign.right->u.tem_no);
					}else{
						if(s->next->code->u.assign.right->add==1){
							fprintf(f,"t%d := *t%d \n",s->next->code->u.assign.left->u.tem_no,
								s->next->code->u.assign.right->u.tem_no);
						}else
							fprintf(f,"t%d := t%d \n",s->next->code->u.assign.left->u.tem_no,
								s->next->code->u.assign.right->u.tem_no);
					}
				}
			}
		}
		if(s->next->code->kind==ADD_||s->next->code->kind==MINUS_
			||s->next->code->kind==MUL_||s->next->code->kind==DIV_){
			char ss[5]={};
			if(s->next->code->kind==ADD_){strcpy(ss,"+");}
			else if(s->next->code->kind==MINUS_){strcpy(ss,"-");}
			else if(s->next->code->kind==MUL_){strcpy(ss,"*");}
			else if(s->next->code->kind==DIV_){strcpy(ss,"/");}
			if(s->next->code->u.binop.op1->kind==TEMP_){
				if(s->next->code->u.binop.op2->kind==TEMP_){
					fprintf(f,"t%d := t%d %s t%d \n",s->next->code->u.binop.result->u.tem_no,
						s->next->code->u.binop.op1->u.tem_no,ss,
							s->next->code->u.binop.op2->u.tem_no);
				}else if(s->next->code->u.binop.op2->kind==CONSTANT_){
					fprintf(f,"t%d := t%d %s #%d \n",s->next->code->u.binop.result->u.tem_no,
						s->next->code->u.binop.op1->u.tem_no,ss,
							s->next->code->u.binop.op2->u.value);
				}
			}else if(s->next->code->u.binop.op1->kind==CONSTANT_){
				if(s->next->code->u.binop.op2->kind==TEMP_){
					fprintf(f,"t%d := #%d %s t%d \n",s->next->code->u.binop.result->u.tem_no,
						s->next->code->u.binop.op1->u.value,ss,
							s->next->code->u.binop.op2->u.tem_no);
				}else if(s->next->code->u.binop.op2->kind==CONSTANT_){
					fprintf(f,"t%d := #%d %s #%d \n",s->next->code->u.binop.result->u.tem_no,
						s->next->code->u.binop.op1->u.value,ss,
							s->next->code->u.binop.op2->u.value);
				}else if(s->next->code->u.binop.op2->kind==VARIABLE_){
					fprintf(f,"t%d := #%d %s v%d \n",s->next->code->u.binop.result->u.tem_no,
							s->next->code->u.binop.op1->u.value,ss,
								s->next->code->u.binop.op2->u.var_no);
				}
			}else if(s->next->code->u.binop.op1->kind==VARIABLE_){
				if(s->next->code->u.binop.op2->kind==TEMP_){
					fprintf(f,"t%d := v%d %s t%d \n",s->next->code->u.binop.result->u.tem_no,
						s->next->code->u.binop.op1->u.var_no,ss,
							s->next->code->u.binop.op2->u.tem_no);
				}else if(s->next->code->u.binop.op2->kind==CONSTANT_){
					fprintf(f,"t%d := v%d %s #%d \n",s->next->code->u.binop.result->u.tem_no,
						s->next->code->u.binop.op1->u.var_no,ss,
							s->next->code->u.binop.op2->u.value);
				}else if(s->next->code->u.binop.op2->kind==VARIABLE_){
					if(s->next->code->u.binop.op2->add==1){
						fprintf(f,"t%d := v%d %s *v%d \n",s->next->code->u.binop.result->u.tem_no,
							s->next->code->u.binop.op1->u.var_no,ss,
								s->next->code->u.binop.op2->u.var_no);
					}else{
						fprintf(f,"t%d := v%d %s v%d \n",s->next->code->u.binop.result->u.tem_no,
							s->next->code->u.binop.op1->u.var_no,ss,
								s->next->code->u.binop.op2->u.var_no);
					}
				}
			}
		}
		if(s->next->code->kind==ARG_){
			InterCodes s1=s;
			while(s1->next->code->kind!=CALL_&&s1->next!=Container){
				printf("%d\n",s1->next->code->kind);
				s1=s1->next;
			}if(s1->next!=Container){
				printf("%d\n",s1->next->code->kind);
			}
			printf("%s\n",s1->next->code->c.call.func->u.id);
			printf("%d\n",s1->next->code->c.call.func->add);
			if(s1->next->code->c.call.func->add==1){
				if(s->next->code->s.arg.arg->kind==1){
					if(s->next->code->s.arg.arg->kind==VARIABLE_){
						fprintf(f,"ARG v%d\n",s->next->code->s.arg.arg->u.var_no);
					}else
						fprintf(f,"ARG t%d\n",s->next->code->s.arg.arg->u.tem_no);
				}else{
					if(s->next->code->s.arg.arg->kind==VARIABLE_){
						fprintf(f,"ARG &v%d\n",s->next->code->s.arg.arg->u.var_no);
					}else
						fprintf(f,"ARG &t%d\n",s->next->code->s.arg.arg->u.tem_no);
				}
				
			}else{
				if(s->next->code->s.arg.arg->kind==1){
					if(s->next->code->s.arg.arg->kind==VARIABLE_){
						fprintf(f,"ARG *v%d\n",s->next->code->s.arg.arg->u.var_no);
					}else
						fprintf(f,"ARG *t%d\n",s->next->code->s.arg.arg->u.tem_no);
				}else{
					if(s->next->code->s.arg.arg->kind==VARIABLE_){
						fprintf(f,"ARG v%d\n",s->next->code->s.arg.arg->u.var_no);
					}else
						fprintf(f,"ARG t%d\n",s->next->code->s.arg.arg->u.tem_no);
				}
			}
		}
		s=s->next;
	}
	printf("			closed!\n");
	
	fclose(f);
}
