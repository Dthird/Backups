#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "node.h"
#include "type.h"

FieldList getFuncField(Node *n,Type t);
Type getStructType(Node *n);
FieldList getStrucField(Node *n,Type t);
Type getOtherType(Node *n,Type t);
Type getExpType(Node *n);
int validateReType(Node* n,Type tp) ;

int trace(Node* node){
	int i=0;
	if(node->type==TYPE_NTERMINAL){		//nterminal
		if(strcmp(node->n_node.name,"Program")==0){
			trace(node->n_node.node[0]);
		}
		if(strcmp(node->n_node.name,"ExtDefList")==0){
			if(node->n_node.num==0){//bs:->
				return 0;
			}
			if(node->n_node.num==2){//bs:->ExtDef ExtDefList
				for(i=0;i<2;i++){
					trace(node->n_node.node[i]);
				}
			}
		}
		if(strcmp(node->n_node.name,"ExtDef")==0){
			if(node->n_node.num==2){//bs:->Specifier SEMI
				trace(node->n_node.node[0]);
			}
			if(node->n_node.num==3&&node->n_node.node[2]->type==TYPE_NTERMINAL){//bs:->Specifier FunDec CompSt
				Type temp=(Type)malloc(sizeof(struct Type_));
				temp=getOtherType(node->n_node.node[0],temp);
				validateFunc(node->n_node.node[1],temp);
				trace(node->n_node.node[2]);
				validateReType(node->n_node.node[2],temp);
			}
			else if(node->n_node.num==3){//bs:->Specifier ExtDecList SEMI
				Type temp=(Type)malloc(sizeof(struct Type_));
				temp=getOtherType(node->n_node.node[0],temp);
				validateExtDecList(node->n_node.node[1],temp);
			}
		}
		if(strcmp(node->n_node.name,"Specifier")==0){
			if(node->n_node.node[0]->type==TYPE_NTERMINAL){//bs:->StructSpecifier
				trace(node->n_node.node[0]);
			}
			else{
				return 0;//bs:Specifier->type
			}
		}
		if(strcmp(node->n_node.name,"StructSpecifier")==0){
			vNode v=(vNode)malloc(sizeof(struct vNode_));
			//处理struct定义相关问题
			if(node->n_node.num==2){//bs:->STRUCT Tag
				//先插入该声明的结构体，后面再检查对应域是不是为空
				v->id=node->n_node.node[1]->n_node.node[0]->node_id;
				v->elem=NULL;
				v->next=NULL;
				if(insertvNode(v,0,node->n_node.node[1]->n_node.node[0]->lineno)==0){
					//printf("insert a new struct in struct tag\n");
				}				
			}
			if(node->n_node.num==5){//bs:->STRUCT OptTag LC DefList RC
				//插入结构体，进入自定义结构体表,检查重复名字
				Type t;
				v->id=node->n_node.node[1]->n_node.node[0]->node_id;
				v->elem=getStructType(node);
				v->next=NULL;
				if(insertvNode(v,0,node->n_node.node[1]->n_node.node[0]->lineno)==0){
					//printf("insert a struct in struct optag\n");
				}
			}
		}
		if(strcmp(node->n_node.name,"Def")==0){//bs:->Specifier DecList SEMI
			Type temp=(Type)malloc(sizeof(struct Type_));
			temp=getOtherType(node->n_node.node[0],temp);
			validateDecList(node->n_node.node[1],temp);
		}
		if(strcmp(node->n_node.name,"CompSt")==0){//bs:->LC DefList StmtList RC
			trace(node->n_node.node[1]);//DefList
			trace(node->n_node.node[2]);//StmtList
		}
		if(strcmp(node->n_node.name,"StmtList")==0||
				strcmp(node->n_node.name,"DefList")==0){
			if(node->n_node.num==2){
				trace(node->n_node.node[0]);
				trace(node->n_node.node[1]);
			}
			return 0;
		}
		if(strcmp(node->n_node.name,"Stmt")==0){
			if(node->n_node.num==1){//bs:->CompSt
				trace(node->n_node.node[0]);
			}
			if(node->n_node.num==2){//bs:->Exp SEMI
				trace(node->n_node.node[0]);
			}
			if(node->n_node.num==3){//bs:->RETURN Exp SEMI
				trace(node->n_node.node[1]);
			}
			if(node->n_node.num==7){//bs:->IF LP Exp RP Stmt ELSE Stmt
				trace(node->n_node.node[2]);
				trace(node->n_node.node[4]);
				trace(node->n_node.node[6]);
			}
			if(node->n_node.num==5){//bs:->WHILE LP Exp RP Stmt||IF LP Exp RP Stmt	%prec LOWER_THAN_ELSE
				trace(node->n_node.node[2]);
				trace(node->n_node.node[4]);
			}
		}
		if(strcmp(node->n_node.name,"Exp")==0){
			return validateExp(node);
		}
		if(strcmp(node->n_node.name,"Dec")==0){
			return validateDec(node);
		}
		return 0;
	}else{
		//printf("ERR EXIST!\n");
	}
}

int compareType(Type tp1,Type tp2){
	if ( tp1 == NULL || tp2 == NULL )
		return 0;
	if ( tp1->kind == tp2->kind ) {
		if ( tp1->kind ==basic) {
			if ( tp1->basic == tp2->basic ) 
				return 0;
		}
		if (tp1->kind == array) {
			if ( tp1->array.size == tp2->array.size)
				return compareType(tp1->array.elem, tp2->array.elem);
			else return -1;
		} 
		return compareField(tp1->structure, tp2->structure);
	}
	return -1;	
}

int compareField(FieldList l1, FieldList l2){
	if(l1 == NULL && l2 ==NULL)
		return 0;
	else if(l1 == NULL || l2 ==NULL)
		return -1;
	else if ( compareType(l1->type,l2->type)==0){
			return compareField(l1->tail, l2->tail);
	}
	return -1;
}

int validatestrucEq(FieldList l1, FieldList l2){
	if(l1 == NULL && l2 ==NULL)
		return 0;
	else if(l1 == NULL || l2 ==NULL)
		return -1;
	if(compareType(l1->type,l2->type)==0){
		return validatestrucEq(l1->tail, l2->tail);
	}
	return -1;
}

FieldList getArgs(Node *n){
	FieldList fd = (FieldList)malloc(sizeof(struct FieldList_));
	if ( strcmp(n->n_node.name, "Args") == 0 ) {// bs:Args->Exp / Args->Exp, Args
		Node *left = n->n_node.node[0];
		if ( validateExp(left) == 0 ) {
			Type type = getExpType(left);
			fd->name = NULL;
			fd->type = type;
		}
		else
			return NULL;
		if ( n->n_node.num == 1 ) {	
			fd->tail = NULL;
		}
		else {// bs:Args->Exp, Args
			fd->tail = getArgs(n->n_node.node[2]);
		}
		return fd;
	}
}

int validateDecList(Node *n,Type type){
	if(n->n_node.num==1){//dec
		return validateDec(n->n_node.node[0],type);
	}
	if(n->n_node.num==3){//bs:->Dec COMMA DecList
		validateDec(n->n_node.node[0],type);
		validateDecList(n->n_node.node[0],type);
		return 0;
	}
}

int validateExtDecList(Node *n,Type type){
	if(n->n_node.num==1){//bs:->VarDec
		return validateVarDec(n->n_node.node[0],type);
	}
	if(n->n_node.num==3){//bs:->VarDec COMMA ExtDecList
		validateVarDec(n->n_node.node[0],type);
		validateExtDecList(n->n_node.node[0],type);
		return 0;
	}
}


int validateDec(Node *n,Type type){
	if(n->n_node.num==1){//bs:->VarDec
		return validateVarDec(n->n_node.node[0],type);
	}
	if(n->n_node.num==3){//bs:->VarDec ASSIGNOP Exp
		validateVarDec(n->n_node.node[0],type);
		if ( n->n_node.node[0]->n_node.num != 1 ){//dec ->id
			printf("Err type 5 at line %d: dec define can't be initialized \n", n->lineno);
		}
		else{
			//比较VarDec 和Exp的类型
			Type type1 = getExpType(n->n_node.node[2]);
			if (compareType(type, type1)!=0) {
				//printf("%d,%d\n",type1->kind,type2->kind);
				if (type->kind != basic||type1->kind!= basic)
					printf("Err type 5 at line %d: assignop type must be int or float\n", n->lineno);
				else
					printf("Err type 5 at line %d: assignop type doesn't match\n", n->lineno);
			}
		}
	}
	return 0;
}

int validateVarDec(Node *n,Type type){
	if(n->n_node.num==1){//bs->ID
		Node *t=n->n_node.node[0];
		//将变量插入表中
		vNode tp=(vNode)malloc(sizeof(struct vNode_));
		tp->id=t->node_id;
		tp->elem=type;
		tp->next=NULL;
		if(insertvNode(tp,1,n->lineno)==0){
			//printf("insert an ID into the table! named: %s\n",tp->id);
		}else{
			//printf("%d\n",type->kind);
		}
	}
	else if(n->n_node.num == 4){//bs:->VarDec LB INT RB
		return validateVarDec(n->n_node.node[0],type);
	}
	return 0;
}

int validateFunc(Node *n,Type type){
	fNode temp = (fNode)malloc(sizeof(struct fNode_));
	temp->return_type = type;
	temp->id = n->n_node.node[0]->node_id;
	temp->next = NULL;
	if(n->n_node.num == 3) {//bs:->ID LP RP
		temp->num = 0;
		temp->parameter = NULL;
	}
	if(n->n_node.num == 4){//bs:->ID LP VarList RP
		Type t = (Type)malloc(sizeof(struct Type_));
		temp->parameter = getFuncField(n->n_node.node[2], t);
		int count=0;
		FieldList templist=temp->parameter;
		while(templist!=NULL){//TODO:
			count++;
			templist = templist->tail;
		}
		temp->num=count;
	}
	if(insertfNode(temp,n->lineno)==0){
		//printf("inserted a new func into table!\n");
	}
	return 0;
}

int validateExp(Node *n){
	if(n->type != TYPE_NTERMINAL){
		return 0;
	}else{
		if(strcmp(n->n_node.name,"Exp")==0){
			if(n->n_node.num==1){
				if(n->n_node.node[0]->type==TYPE_INT||n->n_node.node[0]->type==TYPE_EIGHT||
						n->n_node.node[0]->type==TYPE_SIXTEEN||n->n_node.node[0]->type==TYPE_FLOAT){
					return 0;
				}
				else if(n->n_node.node[0]->type==TYPE_ID){
					vNode v=(vNode)malloc(sizeof(struct vNode_));
					v=variableTable;
					//printf("%s\n",variableTable->id);
					while(v!=NULL){
						if(strcmp(v->id,n->n_node.node[0]->node_id)==0){
							break;
						}else{
							v=v->next;
						}
					}
					if(v==NULL){
						printf("Err type 1: variable %s has not been declaired at line %d\n",n->n_node.node[0]->node_id,n->lineno);
					}
				}
			}
			else if(n->n_node.num==2){
				if(validateExp(n->n_node.node[1])==0){
					if(strcmp(n->n_node.node[0]->node_other_ter,"NOT")==0){
						Type t=getExpType(n->n_node.node[1]);
						if(t->kind==basic&&t->basic==0){//TODO:int only
							//printf("okay\n");
							return 0;
						}else{
							printf("Err type 7: operator type doesn't match at line %d\n",n->lineno);
							return -1;
						}
					}
					else if(strcmp(n->n_node.node[0]->node_other_ter,"MINUS")==0){
						Type t=getExpType(n->n_node.node[1]);
						if(t->kind!=basic){
							printf("Err type 7: operator type doesn't match at line %d\n",n->lineno);
							return -1;
						}
					}
				}else return -1;
			}
			else if(n->n_node.num==3){
				return validateExps(n);
			}
			else if(n->n_node.num==4){
				FieldList pra=(FieldList)malloc(sizeof(struct FieldList_));
				if(n->n_node.node[0]->type==TYPE_ID){//ID LP Args RP
					//check the func id
					fNode f=(fNode)malloc(sizeof(struct fNode_));
					f=functionTable;
					while(f!=NULL){
						if(strcmp(f->id,n->n_node.node[0]->node_id)==0){
							//找到
							pra=f->parameter;
							break;
						}else{
							f=f->next;
						}
					}
					if(f==NULL){
						printf("Err type 2 : Function %s is not defined. at line %d \n ",n->n_node.node[0]->node_id,n->lineno);
						vNode v=(vNode)malloc(sizeof(struct vNode_));
						
						v=variableTable;
						while(v!=NULL){
							if(strcmp(v->id,n->n_node.node[0]->node_id)==0){
								printf("Err type 11 : variable %s is not a function at line %d \n ",n->n_node.node[0]->node_id,n->lineno);return -1;
							}else{
								v=v->next;
							}
						}
					}
					//check the Args
					if(compareField(getArgs(n->n_node.node[2]), pra)!=0){
						printf("Err type 9 : misuse of function %s at line %d\n",n->n_node.node[0]->node_id,n->lineno);return -1;
					}
					return 0;
				}else{//Exp LB Exp RB
					if (validateExp(n->n_node.node[2])!=0)return -1;
					else{
						Type tp = getExpType(n->n_node.node[2]);
						if(tp->kind==basic&&tp->basic==0){//int only
							
						}else{
							printf("Err type 12 : Operands type mistaken at line %d\n",n->lineno);
							return -1;
						}
						if(validateExp(n->n_node.node[0])!=0){
							return -1;
						}else{
							Type tp1=getExpType(n->n_node.node[0]);
							if(tp1!= NULL && tp1->kind != array){
								printf("Err type 10 : It should be an array at line %d\n",n->lineno);
								return -1;
							}
						}
					}
					return 0;
				}
			}
		}else{
			//ID&&other
		}
	}
	return 0;
}

int validateExps(Node *n){
	Node *next = n->n_node.node[1];
	if ( next->type == TYPE_OTHER_TER ) {
		if( strcmp(next->node_other_ter, "ASSIGNOP") == 0 ) {
			Node *left = n->n_node.node[0];	
			Node *right = n->n_node.node[2];
			if ( left->n_node.num == 1 ) {			//ID=Exp
				if ( left->n_node.node[0]->type!=TYPE_ID) {
					printf("Err type 6: left of assignop type doesn't match at line %d\n", n->lineno);
					return -1;
				}
			}
			if ( left->n_node.num == 3 ) {			//EXP->[id]=Exp
				if ( left->n_node.node[2]->type != TYPE_ID ) {
					printf("Err type 6: left of assignop type doesn't match at line %d\n", n->lineno);
					return -1;
				}
			}
			if ( left->n_node.num == 4 ) {			//EXP->id[id]=Exp
				if ( left->n_node.node[0]->type != TYPE_NTERMINAL ) {
					printf("Err type 6: left of assignop type doesn't match at line %d\n", n->lineno);
					return -1;
				}
			}
			if (validateExp(left) == 0 && validateExp(right) == 0 ) {
				Type type1 = getExpType(left);
				Type type2 = getExpType(right);
				if(type1==NULL||type2==NULL){return 0;}
				if(type1->kind != basic&&type2->kind != basic){
					if(type1->kind==structure&&type2->kind==structure){
						//printf("to compare struct!\n");
						if(validatestrucEq(type1->structure,type2->structure)==0){
						}else{
							printf("Err type 5:type mismatched at line %d\n",n->lineno);return -1;
						}
					}else{
						printf("you did what?!!\n");
					}
				}
				else if ( type1->kind != basic || type2->kind != basic ) {
					printf("Err type 5: assignop type must be int or float at line %d\n", n->lineno);
					return -1;
				}
				else if ( compareType(type1, type2) == -1) {
					printf("Err type 5: type mismatched at line %d\n", n->lineno);
					return -1;
				}
				return 0;
			}
		}			
		else if ( strcmp(next->node_other_ter, "LP") == 0 ) {	// Exp -> ID LP RP
			//Func judge
			fNode f=(fNode)malloc(sizeof(struct fNode_));
			f=functionTable;
			while(f!=NULL){
				if(strcmp(f->id,n->n_node.node[0]->node_id)==0){
					//找到
					break;
				}else{
					f=f->next;
				}
			}
			if(f==NULL){
				printf("Err type 2 : Function %s is not defined. at line %d \n ",n->n_node.node[0]->node_id,n->lineno);
				vNode v=(vNode)malloc(sizeof(struct vNode_));
				v=variableTable;
				while(v!=NULL){
					if(strcmp(v->id,n->n_node.node[0]->node_id)==0){
						printf("Err type 11 : variable %s is not a function at line %d \n ",n->n_node.node[0]->node_id,n->lineno);return -1;
					}else{
						v=v->next;
					}
				}
			}
			return 0;
		}		
		else if ( strcmp(next->node_other_ter, "DOT") == 0 ) {
			if ( validateExp(n->n_node.node[0]) != 0 ) return -1;
			else{
				Type type1 = getExpType(n->n_node.node[0]);	
				if ( type1 != NULL && type1->kind != structure ) {
					printf("Err type 13: Illegal use of \".\" at line %d\n", n->lineno);
					return -1;
				}
				if(type1!=NULL&&type1->kind==structure){
					Node *id = n->n_node.node[2];
					FieldList q= type1->structure ;
					while(q->tail != NULL){
						if(strcmp(q->name,id->node_id)==0)return 0;
						q = q->tail;
					}
					printf("Err type 14: wrong structure field at line %d \n",n->lineno);	
					return -1;
							
				}
			}
		}
		else if ( strcmp(next->node_other_ter, "AND") == 0 
			|| ( strcmp(next->node_other_ter, "OR") == 0 )) {
			if ( validateExp(n->n_node.node[0]) != 0 ||validateExp(n->n_node.node[2]) != 0 )return -1; 
			else{
				Type type1 = getExpType(n->n_node.node[0]);
				Type type2 = getExpType(n->n_node.node[2]);
				if ( type1->kind!=basic ||type2->kind!=basic||type1->basic!=0||type2->basic!=0 ) {
					printf("Err type 7 : operator type doesn't match at line %d\n", n->lineno);
					return -1;
				}
				if ( compareType(type1, type2) != 0 ) {
					printf("Err type 7 : operator type doesn't match at line %d\n", n->lineno);
					return -1;
				}
				return 0;
			}
		}
		else {
			if ( validateExp(n->n_node.node[0])!=0||validateExp(n->n_node.node[2])!=0)return -1;
			else {
				Type type1 = getExpType(n->n_node.node[0]);
				Type type2 = getExpType(n->n_node.node[2]);
				if ( type1->kind != basic ) {
					printf("Err type 7 : operator type doesn't match at line %d\n", n->lineno);
					return -1;
				}
				if ( compareType(type1, type2) != 0 ) {
					printf("Err type 7: operator type doesn't match at line %d\n", n->lineno);
					return -1;
				}
				return 0;
			}
		}
	}		
	else {
		return validateExp(n->n_node.node[1]);//exp
	}
}

int insertvNode(vNode v,int tab,int line){//插入成功返回0，否则-1；
	if(tab==1){//variableTable
		vNode i=variableTable;
		while ( i != NULL ){
			if ( strcmp(i->id, v->id) == 0 )break;
			i = i->next;
		}
		if(i!=NULL){//已有该变量
			printf("Err type 3: variable redefined : %s at line %d\n",i->id,line);
			printf("Err type 15 :struct variable redefined : %s at line %d\n",i->id,line);
			printf("one of the upper errors took place\n");
			return -1;
		}
		v->next=variableTable;
		variableTable=v;
		/*v=variableTable;
		while(v!=NULL){printf("In variableTable : %s\n",v->id);v=v->next;}*/
		return 0;
	}
	if(tab==0){//structTable
		vNode i=structTable;
		while(i!=NULL){
			if(strcmp(i->id, v->id) == 0)break;
			i=i->next;
		}
		if(i!=NULL){
			//printf("struct name: %s exsisted before!\n",i->id);
			if(i->elem!=NULL){
				printf("Err type 16: Duplicated struct  %s at line %d\n",i->id,line);
				return -1;
			}
			//声明过，这里实现，补齐
			if(v->elem!=NULL){
				//printf("declaired before!\n");
				i->elem=(Type)malloc(sizeof(struct Type_));
				i->elem=v->elem;
				return 0;
			}
			else{
				//printf("redeclaired ,not completed!\n");
			}
		}
		//没出现过，这里插入
		v->next=(vNode)malloc(sizeof(struct vNode_));
		v->next=structTable;
		structTable=v;
		/*v=structTable;
		while(v!=NULL){printf("In structTable : %s\n",v->id);v=v->next;}*/
		return 0;
	}
}

int insertfNode(fNode f,int line){
	fNode i=functionTable;
	while(i!=NULL){
		if(strcmp(i->id, f->id) == 0)break;
		i=i->next;
	}
	if(i!=NULL){//出现过这个函数
		printf("Err type 4: function  %s redefined at line %d\n",i->id,line);
		return -1;
	}//没出现过
	f->next=functionTable;
	functionTable=f;
	/*f=functionTable;
	while(f!=NULL){printf("In functionTable : %s\n",f->id);f=f->next;}*/
	return 0;
}

Type getStructType(Node *n){//从当前节点获取填写type信息
	Type t=(Type)malloc(sizeof(struct Type_));
	if(strcmp(n->n_node.name,"StructSpecifier")==0){//struct实现
		t->kind=structure;
		Node *v=n->n_node.node[3];//deflist
		//填写structure field的内容
		t->structure=getStrucField(v,t);
	}
	return t;
}

FieldList getStrucField(Node *n,Type t){//获取struct相关时的field
	FieldList fd = (FieldList)malloc(sizeof(struct FieldList_));
	if(n==NULL){/*printf("NULL\n");*/}
	if(strcmp(n->n_node.name,"DefList")==0){
		if( n->n_node.num != 0 ) {
			fd = getStrucField(n->n_node.node[0], t);// bs:->Def DefList
			FieldList temp = fd;
			while ( temp->tail != NULL ) {
				temp = temp->tail;
			}
			temp->tail = getStrucField(n->n_node.node[1], t);
		}
	}
	else if(strcmp(n->n_node.name,"Def")==0){//bs:->Specifier DecList SEMI
		t = getOtherType(n->n_node.node[0], t);	
		fd = getStrucField(n->n_node.node[1], t);
	}
	else if(strcmp(n->n_node.name,"DecList")==0){//bs:->Dec COMMA DecList||Dec
		Node *node = n->n_node.node[0];				// Dec
		fd = getStrucField(node->n_node.node[0], t);
		if ( n->n_node.num == 1 )fd->tail = NULL;							
		if ( n->n_node.num == 3 )fd->tail = getStrucField(n->n_node.node[2], t);
	}
	else if(strcmp(n->n_node.name,"VarDec")==0){
		t = getOtherType(n, t);
		fd = getStrucField(n->n_node.node[0], t);
	}
	else{//ID:varDec->ID
		if(n->type==TYPE_ID){
			fd->name = n->node_id;
			fd->type = t;
			fd->tail = NULL;
		}
		else{
			//printf("getStrucField:Routing msg: %s !\n",n->n_node.name);
		}
	}
	return fd;
}

FieldList getFuncField(Node *n,Type t){//获取func相关时的field
	FieldList fd = (FieldList)malloc(sizeof(struct FieldList_));
	if(strcmp(n->n_node.name,"VarDec")==0){
		t = getOtherType(n, t);
		fd = getStrucField(n->n_node.node[0], t);
	}
	if(strcmp(n->n_node.name,"VarList")==0){
		Node *node = n->n_node.node[0];	// ParamDec
		t = getOtherType(node->n_node.node[0], t);
		fd = getFuncField(node->n_node.node[1], t);
		if ( n->n_node.num == 1)fd->tail = NULL; 	
		if ( n->n_node.num == 3)fd->tail = getFuncField(n->n_node.node[2], t);// VarList
	}
	else{//ID:varDec->ID
		if(n->type==TYPE_ID){
			fd->name = n->node_id;
			fd->type = t;
			fd->tail = NULL;
		}                                                                                                                                                                                                            
		else{
			//printf("getFuncField:Routing msg: %s !\n",n->n_node.name);
		}                                                                     
	}
	return fd;
}

Type getOtherType(Node *n,Type t){//获取其他需要的的type
	Type tp=(Type)malloc(sizeof(struct Type_));
	if(strcmp(n->n_node.name,"Specifier")==0){
		if(n->n_node.node[0]->type!=TYPE_NTERMINAL){//TYPE
			tp->kind=basic;
			if(strcmp(n->n_node.node[0]->node_other_ter,"FLOAT")==0){
				tp->basic=1;
			}else{tp->basic=0;}
		}
		else{//结构内定义的结构体:structspecifier
			vNode v=(vNode)malloc(sizeof(struct vNode_));
			Node *tm=n->n_node.node[0];//structspec
			if(strcmp(tm->n_node.node[1]->n_node.name,"Tag")==0){//STRUCT Tag
				//
				//printf("a declaire\n");
				v=structTable;
				while(v!=NULL){
					if(strcmp(v->id,tm->n_node.node[1]->n_node.node[0]->node_id)==0){
						return v->elem;
					}
					else{
						v=v->next;
					}
				}
				printf("Err type 17 :undefined struct %s at line %d\n",tm->n_node.node[1]->n_node.node[0]->node_id,tm->lineno);
			}
			if(strcmp(tm->n_node.node[1]->n_node.name,"OptTag")==0){//STRUCT OptTag LC DefList RC
				v->id=tm->n_node.node[1]->n_node.node[0]->node_id;
				v->elem=getStructType(tm);
				v->next=NULL;
				if(insertvNode(v,0,tm->n_node.node[1]->n_node.node[0]->lineno)==0){
					//printf("insert a new struct in struct tag\n");
				}
				return v->elem;
			}
		}
	}
	if(strcmp(n->n_node.name,"VarDec")==0){
		if ( n->n_node.num==4) {
			tp->kind = array;
			tp->array.elem =t;
			tp->array.size = n->n_node.node[2]->node_int;
		}else{
			validateVarDec(n,t);
		}
	}
	else{
	}
	return tp;
}

Type getExpType(Node *n){
	Type tp=(Type)malloc(sizeof(struct Type_));
	if(n->n_node.num==1){
		if(n->n_node.node[0]->type==TYPE_FLOAT){
			tp->kind = basic;
			tp->basic = 1;
		}
		else if(n->n_node.node[0]->type!=TYPE_ID){
			tp->kind = basic;
			tp->basic = 0;
		}
		if(n->n_node.node[0]->type==TYPE_ID){
			vNode v=(vNode)malloc(sizeof(struct vNode_));
			v=variableTable;
			while(v!=NULL){
				if(strcmp(v->id,n->n_node.node[0]->node_id)==0){
					return v->elem;
				}else{
					v=v->next;
				}
			}
			printf("Err type 1: variable %s has not been defined at line %d\n",n->n_node.node[0]->node_id,n->lineno);
			return NULL;
		}	
	}
	else if(n->n_node.num==2){
		if(n->n_node.node[1]->type==TYPE_FLOAT){
			tp->kind = basic;
			tp->basic = 1;
		}
		if(n->n_node.node[1]->type!=TYPE_ID){
			tp->kind = basic;
			tp->basic = 0;
		}
		if(n->n_node.node[1]->type==TYPE_ID){
			vNode v=(vNode)malloc(sizeof(struct vNode_));
			v=variableTable;
			while(v!=NULL){
				if(strcmp(v->id,n->n_node.node[0]->node_id)==0){
					return v->elem;
				}
			}
			printf("Err type 1: variable %s has not been defined at %d\n",n->n_node.node[0]->node_id,n->lineno);
			return NULL;
		}
	}
	else if(n->n_node.num==3){
		if ( n->n_node.node[0]->type == TYPE_ID ) {//Exp-> ID LP RP
			fNode f=(fNode)malloc(sizeof(struct fNode_));
			f=functionTable;
			while(f!=NULL){
				if(strcmp(f->id,n->n_node.node[0]->node_id)==0){
					return f->return_type;
				}else{
					f=f->next;
				}
			}
			return NULL;//找不到就返回空
		}
		else if (n->n_node.node[2]->type == TYPE_ID ) {//Exp->Exp DOT ID
			tp->kind = 0;
			tp->basic = 1;
		}
		else
			tp = getExpType(n->n_node.node[0]);//EXP
	}
	else{
		/*int i = 0;
		int j = 0;
		Node *left = n->n_node.node[0];
		while(left->n_node.node[0]->type!= TYPE_ID ) {
			i++;
			left = left->n_node.node[0];
		}
		//printf("left->type:%d\n",left->type);
		Type temp = getExpType(left);
		if ( temp != NULL ) {
			for ( j = 0; j < i; j++ ) {
				if ( temp->kind != array && j != i -1 ) {
					printf("Err type 10: %s must be an array at line %d\n",left->node_id, n->lineno);
					return NULL;
				}
				temp = temp->array.elem;
			}
		}
		tp=temp;*/
	}
	return tp;
}

int validateReType(Node* n,Type type) {
	if (n->type != TYPE_NTERMINAL)
		return 0;
	else if (strcmp(n->n_node.name, "Stmt") == 0 &&n->n_node.num==3) {
		Type temp = getExpType(n->n_node.node[1]);
		if ( temp != NULL && compareType(type, temp) == -1 ) {
			printf("Err type  8 : return type doesn't match at line %d\n", n->n_node.node[1]->lineno);
			return -1;
		}
	}
	int i=0;
	for ( ; i < n->n_node.num; i++ )validateReType(n->n_node.node[i],type); 
}


