#include "stdlib.h"
#include "stdio.h"
#include "string.h"
#include "DList.h"
#include "../type.h"
//正常返回0，否则返回-1；
int insertNode(InterCodes node){//双向链表插入，尾部插入
	if(Container==NULL){
		printf("init first!\n");
		return -1;
	}else{
		InterCodes temp=Container;
		while(temp->next!=Container){
			temp=temp->next;
		}
		temp->next=node;
		Container->prev=node;
		node->prev=temp;
		node->next=Container;
	}
	return 0;
}

int traceTheNode(){//打印存储的节点
	InterCodes temp=Container->next;
	while(temp->next!=Container){
		printf("%d \n",temp->code->kind);
		temp=temp->next;
	}
	printf("%d \n",temp->code->kind);
	return 0;
}
//正常返回0，否则返回-1；
int init_InterCodes(){
	Container=(InterCodes)malloc(sizeof(struct InterCodes_));
	if(!Container){
		printf("init failed!\n");
		return -1;
	}
	Container->code=NULL;
	Container->next=Container;
	Container->prev=Container;
	return 0;
}
/*
int main(){//for test
	if(!init_InterCodes()){
		Operand left=(Operand)malloc(sizeof(struct Operand_));
		Operand right=(Operand)malloc(sizeof(struct Operand_));
		left->kind=CONSTANT_;
		right->kind=CONSTANT_;


		InterCodes node=(InterCodes)malloc(sizeof(struct InterCodes_));
		InterCodes node1=(InterCodes)malloc(sizeof(struct InterCodes_));
		InterCodes node2=(InterCodes)malloc(sizeof(struct InterCodes_));

		node->code=(InterCode)malloc(sizeof(struct InterCode_));
		node->code->kind=MUL_;
		node->code->u.assign.left=left;
		node->code->u.assign.right=right;

		node1->code=(InterCode)malloc(sizeof(struct InterCode_));
		node1->code->kind=DIV_;
		node1->code->u.assign.left=left;
		node1->code->u.assign.right=right;

		node2->code=(InterCode)malloc(sizeof(struct InterCode_));
		node2->code->kind=ADD_;
		node2->code->u.assign.left=left;
		node2->code->u.assign.right=right;

		insertNode(node);
		insertNode(node1);
		insertNode(node2);

		traceTheNode();
	}
}*/

int mend_funcTable(){

	Type t=(Type)malloc(sizeof(struct Type_));
	t->kind=basic;
	t->basic=0;

	fNode temp1=(fNode)malloc(sizeof(struct fNode_));
	temp1->return_type=t;
	temp1->id=(char*)malloc(sizeof(char)*10);
	strcpy(temp1->id,"write");
	temp1->num=1;
	FieldList feild=(FieldList)malloc(sizeof(struct FieldList_));
	feild->type=t;
	feild->tail=NULL;
	temp1->parameter=feild;
	temp1->next=NULL;

	fNode temp2=(fNode)malloc(sizeof(struct fNode_));
	temp2->return_type=t;
	temp2->id=(char*)malloc(sizeof(char)*10);
	strcpy(temp2->id,"read");
	temp2->num=0;
	temp2->parameter=NULL;
	temp2->next=NULL;
	if(insertfNode(temp1)==0&&insertfNode(temp2)==0){
		return 0;
	}else{
		return -1;
	}
}


















