
typedef struct Operand_* Operand;
typedef struct InterCode_* InterCode;
typedef struct InterCodes_* InterCodes;

struct Operand_ {
	enum { VARIABLE_, CONSTANT_,TEMP_,LABEL,FUNC} kind;
	union {
		int var_no;
		int tem_no;
		int value;
		int label_no;
		char*id;
	} u;
	int *len;
	int size;
	int depth;
	int add;//add=0;add=1;1为数组首地址
};

struct InterCode_{
	enum { ASSIGN_, ADD_, MUL_,DIV_,MINUS_,/**/LABEL_,FUNC_,PARA_,ARG_,
			/**/GOTO_,IF_,RETURN_,DEC_,CALL_,/**/READ_,WRITE_} kind;
	union {
		struct { Operand tar;}sin;			//单目操作符
		struct { Operand right, left; } assign;		//赋值
		struct { Operand result, op1, op2; } binop;	//三元操作
	} u;//运算符相关
	union {
		struct {Operand gt;}gt;				//goto语句
		struct {Operand rt;}rt;				//return 
		struct {char *relop;Operand op1,op2,label; }as;	//if语句
		struct {Operand rst,func;}call;			//call
		struct {Operand var;}dec;			//dec
	}c;//控制相关
	union {
		struct {Operand label;}label;			//label
		struct {Operand func;}func;			//funcdec
		struct {Operand Para;}Para;			//Para
		struct {Operand arg;}arg;			//arg
	}s;//函数名参数label等
	union {
		struct {Operand rd;}rd;				//read
		struct {Operand wt;}wt;				//write
	}p;//规定函数
};

struct InterCodes_{ 
	InterCode code; 
	InterCodes prev,next;
};

InterCodes Container;				//双向链表的第一个节点

int insertNode(InterCodes node);		//节点插入
int traceTheNode();				//输出节点相关信息
int init_InterCodes();				//初始化第一个节点



