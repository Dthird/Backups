#ifndef _TYPE_H_
#define _TYPE_H_

typedef struct Type_* Type;
typedef struct FieldList_* FieldList;
typedef struct vNode_* vNode;
typedef struct fNode_* fNode;

struct Type_
{
	enum { basic, array, structure } kind;
	union
	{
		// 基本类型，0表示整数（int，八进制，十六进制），1表示浮点数
		int basic;
		// 数组类型信息包括元素类型与数组大小构成
		struct { Type elem; int size; } array;
		// 结构体类型信息是一个链表
		FieldList structure;
	};
};

struct FieldList_
{
	char* name;		// 域的名字
	Type type;		// 域的类型
	FieldList tail;		// 下一个域
};

struct vNode_		// 变量符号表结构
{
	char* id;		// 变量名
	Type elem;		// 变量类型
	vNode next;
};

struct fNode_		// 函数符号表结构
{
	Type return_type;	// 返回类型
	char* id;			// 函数名
	int num;			// 参数个数
	FieldList parameter;	// 参数类型
	fNode next;
};

vNode variableTable;	// 定义变量表
fNode functionTable;	// 定义函数表
vNode structTable;	// 定义结构体表



#endif
