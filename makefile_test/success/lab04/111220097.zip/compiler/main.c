#include <stdlib.h>
#include <stdio.h>
#include "last.h"
extern FILE* yyin;

int main(int argc, char** argv)
{
	if ( argc <= 1 ) return 1;
	if(argc!=3){
		printf("you should input in target input & output file name at a time!\n ");
		exit(1);
	}
	FILE* f = fopen(argv[1], "r");
	if ( !f )
	{
		perror(argv[1]);
		return 1;
	}
	yyrestart(f);
	yyparse();
	
	mips_main(argv[2]);
	return 0;
}
