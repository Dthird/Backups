#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>
#include "translate/translate.h"

int mips_main(char* filename);
void FormIfCode(int x, int y, int label, char *data) ;
void FormJalCode(char *func, char* data);
void FormJCode(int label, char* data);
void FormSwCode(int x, int y, int offset, char* data);
void FormLwCode(int x, int y, int offset, char* data);
void FormDivCode(int x, int y, int z, char* data);
void FormAddiCode(int op,int x, int y, int k, char* data);
void FormMoveCode(int x, int y, char* data) ;
void FormLiCode(int x, int k, char* data);
void FormLabelCode(int label, char* data) ;



