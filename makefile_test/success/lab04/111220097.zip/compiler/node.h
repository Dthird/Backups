#ifndef _NODE_H_
#define _NODE_H_

typedef enum { TYPE_INT, TYPE_FLOAT, TYPE_ID, TYPE_OTHER_TER, TYPE_NTERMINAL,TYPE_EIGHT,TYPE_SIXTEEN } NodeEnum;

typedef struct {
	char* name; 				
	int num;			
	struct NodeTag **node;		
} Nterminal_Node;

typedef struct NodeTag {
	NodeEnum type;				
	int lineno;
	char* text;
	union{
		int node_int;
		float node_float;
		char* node_id;
		char* node_eight;
		char* node_sixteen;
		char* node_other_ter;
		Nterminal_Node n_node; 
	};
} Node;

#endif
