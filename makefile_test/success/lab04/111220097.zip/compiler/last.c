#include "last.h"

void FormLabelCode(int label, char* data) {
	strcat(data, "label");
	char buf[4];
	snprintf(buf,4,"%d",label);
	strcat(data, buf);
	strcat(data, ":\n");
}

void FormLiCode(int x, int k, char* data) {
	strcat(data, "    li ");
	
	strcat(data, "$");
	char buf[4];
	snprintf(buf,4,"%d",x);
	strcat(data, buf);

	strcat(data, ", ");
	strcpy(buf,"");
	snprintf(buf,4,"%d",k);
	strcat(data, buf);
	strcat(data, "\n");
}

void FormMoveCode(int x, int y, char* data) {
	strcat(data, "    move ");
	
	strcat(data, "$");
	char buf[4];
	snprintf(buf,4,"%d",x);
	strcat(data, buf);
	
	strcat(data, ", ");
	
	strcat(data, "$");
	strcpy(buf,"");
	snprintf(buf,4,"%d",y);
	strcat(data, buf);
	
	strcat(data, "\n");
}
//op=0,addi;op=1,add;op=2,sub;op=3,mul;
void FormBinCode(int op,int x, int y, int k, char* data) {
	if(op==0)	strcat(data, "    addi ");
	else if(op==1)  strcat(data, "    add ");
	else if(op==2)  strcat(data, "    sub ");
	else if(op==3)  strcat(data, "    mul ");
	
	strcat(data, "$");
	char buf[4];
	snprintf(buf,4,"%d",x);
	strcat(data, buf);

	strcat(data, ", ");
	
	strcat(data, "$");
	strcpy(buf,"");
	snprintf(buf,4,"%d",y);
	strcat(data, buf);

	strcat(data, ", ");
	strcpy(buf,"");
	snprintf(buf,4,"%d",k);
	strcat(data, buf);
	strcat(data, "\n");
}

void FormDivCode(int x, int y, int z, char* data) {
	strcat(data, "    div ");

	strcat(data, "$");
	char buf[4];
	snprintf(buf,4,"%d",y);
	strcat(data, buf);

	strcat(data, ", ");
	
	strcat(data, "$");
	strcpy(buf,"");
	snprintf(buf,4,"%d",z);
	strcat(data, buf);

	strcat(data, "\n    mflo ");

	strcat(data, "$");
	strcpy(buf,"");
	snprintf(buf,4,"%d",x);
	strcat(data, buf);

	strcat(data, "\n");
}

void FormLwCode(int x, int y, int offset, char* data) {
	strcat(data, "    lw ");

	strcat(data, "$");
	char buf[4];
	snprintf(buf,4,"%d",x);
	strcat(data, buf);

	strcat(data, ", ");

	strcpy(buf,"");
	snprintf(buf,4,"%d",offset);
	strcat(data, buf);
	strcat(data, "($");
	strcpy(buf,"");
	snprintf(buf,4,"%d",y);
	strcat(data, buf);
	strcat(data, ")\n");
}

void FormSwCode(int x, int y, int offset, char* data) {
	strcat(data, "    sw ");

	strcat(data, "$");
	char buf[4];
	snprintf(buf,4,"%d",y);
	strcat(data, buf);

	strcat(data, ", ");

	strcpy(buf,"");
	snprintf(buf,4,"%d",offset);
	strcat(data, buf);
	strcat(data, "($");
	strcpy(buf,"");
	snprintf(buf,4,"%d",x);
	strcat(data, buf);
	strcat(data, ")\n");
}

void FormJCode(int label, char* data) {
	strcat(data, "    j label");
	char buf[4];
	snprintf(buf,4,"%d",label);
	strcat(data, buf);
	strcat(data, "\n");
}

void FormJalCode(char *func, char* data) {
	strcat(data, "    jal ");
	strcat(data, func);
	strcat(data, "\n");
}

void FormIfCode(int x, int y, int label, char *data) {
	strcat(data, "$");
	char buf[4];
	snprintf(buf,4,"%d",x);
	strcat(data, buf);
	strcat(data, ", $");
	strcpy(buf,"");
	snprintf(buf,4,"%d",y);
	strcat(data, buf);
	strcat(data, ", label");
	strcpy(buf,"");
	snprintf(buf,4,"%d",label);
	strcat(data, buf);
	strcat(data, "\n");
}
/*
 * reg related def and functions
 */
typedef struct _reg{
	int var;
	int used;
}reg;

// shared vars
reg regs[18];
char buff[1000];
int temp_offset[50];

int setReg(int i){
	int j=0;
	for(;j<18;j++){
		if(regs[j].used==0){
			regs[j].used=1;
			regs[j].var=i;
			break;
		}else {
			if(j==17)printf("MEM ERR: all regs used!\n");
			return -1;
		}
	}
	return 0;
}

int  varOffset(int varno){
    symTable temp;
    temp=table;
    while (temp!=NULL)
    {
        if (temp->op->u.var_no==varno) return temp->op->size;
        temp=temp->next;
    }
}
/*
 *main structure related functions
 */
int parseRead(InterCode code,char* data);//read
int parseAdd(InterCode code,char* data);//add
int parseSub(InterCode code,char* data);//sub
int parseMul(InterCode code,char* data);//mul
int parseDiv(InterCode code,char* data);//div
int parseIf(InterCode code,char* data);//if
int parseAssign(InterCode code,char* data);//assign
int parseReturn(InterCode code, char *data);
int parseFunc(InterCode code, char *data);
/*
 *enterance function
 */
int mips_main(char * filename){
	printf("target: %s\n",filename);
	int i=0;
	for(;i<18;i++){
		regs[i].var=0;
		regs[i].used=0;
	}
	printf("==:) regs inited!\n");
	
	FILE *fp = fopen(filename, "w");//TODO:
	InterCodes temp= Container;
	//写入第一段
	fputs(".data\n \
_prompt: .asciiz \"Enter an integer:\"\n \
_ret: .asciiz \"\\n\"\n \
.globl main\n \
.text\n \
read:\n \
	li $v0, 4\n \
	la $a0, _prompt\n \
	syscall\n \
	li $v0, 5\n \
	syscall\n \
	jr $ra\n\n \
write:\n \
	li $v0, 1\n \
	syscall\n \
	li $v0, 4\n \
	la $a0, _ret\n \
	syscall\n \
	move $v0, $0\n \
	jr $ra\n\n", fp);
	while(temp->next!=Container){
		InterCode code=temp->next->code;
		if(code->kind==ASSIGN_){
			printf("code->kind: assign.\n");
			memset(buff,0,1000);
			strcpy(buff,"");
			parseAssign(code,buff);
			fputs(buff, fp);
			printf("%s",buff);
		}else if(code->kind==ADD_){
			printf("code->kind: add.\n");
			memset(buff,0,1000);
			strcpy(buff,"");
			parseAdd(code,buff);
			fputs(buff, fp);
			printf("%s",buff);
		}else if(code->kind==MINUS_){
			printf("code->kind: minus.\n");
			memset(buff,0,1000);
			strcpy(buff,"");
			parseSub(code,buff);
			fputs(buff, fp);
			printf("%s",buff);
		}else if(code->kind==MUL_){
			printf("code->kind: mul.\n");
			memset(buff,0,1000);
			strcpy(buff,"");
			parseMul(code,buff);
			fputs(buff, fp);
			printf("%s",buff);
		}else if(code->kind==DIV_){
			printf("code->kind: div.\n");
			memset(buff,0,1000);
			strcpy(buff,"");
			parseDiv(code,buff);
			fputs(buff, fp);
			printf("%s",buff);
		}else if(code->kind==READ_){
			printf("code->kind: read.\n");
			memset(buff,0,1000);
			strcpy(buff,"");
			parseRead(code,buff);
			fputs(buff, fp);
			printf("%s",buff);
		}else if(code->kind==LABEL_){
			printf("code->kind: label.\n");
			memset(buff,0,1000);
			strcpy(buff,"label");
			char buf[10];
			//itoa(code->s.label.label->u.label_no,buf,10);
			snprintf(buf,2,"%d",code->s.label.label->u.label_no);
			strcat(buff, buf);
			strcat(buff,":\n");
			fputs(buff, fp);
			printf("%s",buff);
		}else if(code->kind==IF_){
			printf("code->kind: if.\n");
			memset(buff,0,1000);
			strcpy(buff,"");
			parseIf(code,buff);
			fputs(buff, fp);
			printf("%s",buff);
		}else if(code->kind==GOTO_){
			printf("code->kind: goto.\n");
			strcpy(buff,"   j label");
			char buf[10];
			//itoa(code->c.gt.gt->u.label_no,buf,10);
			snprintf(buf,2,"%d",code->c.gt.gt->u.label_no);
			strcat(buff, buf);
			strcat(buff,"\n");
			fputs(buff, fp);
			printf("%s", buff);
		}else if(code->kind==WRITE_){
			printf("code->kind: write.\n");
		}else if(code->kind==FUNC_){
			printf("code->kind: FUNC.\n");
			parseFunc(code,buff);
		}else if(code->kind==RETURN_){
			printf("code->kind: return .\n");
			parseReturn(code,buff);
		}
		for(i=0;i<18;i++){
			regs[i].var=0;
			regs[i].used=0;
		}
		printf("==:) regs reseted!\n");
		temp=temp->next;
	}
	fclose(fp);
}

/*
 *implements of mips translating 
 */
//read
int parseRead(InterCode code,char* data){
	//!!!no need then 
}
//add
int parseAdd(InterCode code,char* data){		//TODO:
	int reg_r,reg_l,offset1,offset2,offset3;
	if (code->u.binop.result->kind==TEMP_){
		reg_l=setReg(code->u.binop.result->u.tem_no);
		offset1=temp_offset[code->u.binop.result->u.tem_no];
	}
	if (code->u.binop.op1->kind==TEMP_){
		reg_r=setReg(code->u.binop.op1->u.tem_no);
		offset2=temp_offset[code->u.binop.op1->u.tem_no];
		FormLwCode(reg_r,30-8,offset2,data);
	}
	if (code->u.binop.op1->add==1){
		reg_r=setReg(code->u.binop.op1->u.var_no);
		offset2=varOffset(code->u.binop.op1->u.var_no);
		FormBinCode(0,reg_r,30-8,offset2,data);
	}
	if (code->u.binop.op2->kind==TEMP_){
		int reg=setReg(code->u.binop.op2->u.tem_no);
		offset3=temp_offset[code->u.binop.op2->u.tem_no];
		FormLwCode(reg,30-8,offset3,data);
		FormBinCode(1,reg_l,reg_r,reg,data);
	}
	if (code->u.binop.op2->kind==CONSTANT_){
		FormBinCode(0,reg_l,reg_r,code->u.binop.op2->u.value,data);
	}
	
	FormSwCode(30-8,reg_l,offset1,data);
}
//sub
int parseSub(InterCode code,char* data){
	int reg_r,reg_l,offset1,offset2,offset3;
	if (code->u.binop.result->kind==TEMP_){
		reg_l=setReg(code->u.binop.result->u.tem_no);
		offset1=temp_offset[code->u.binop.result->u.tem_no];
	}
	if (code->u.binop.op1->kind==TEMP_){
		reg_r=setReg(code->u.binop.op1->u.tem_no);
		offset2=temp_offset[code->u.binop.op1->u.tem_no];
		FormLwCode(reg_r,30-8,offset2,data);
	}
	if (code->u.binop.op1->add==1){
		reg_r=setReg(code->u.binop.op1->u.var_no);
		offset2=varOffset(code->u.binop.op1->u.var_no);
		FormBinCode(0,reg_r,30-8,offset2,data);
	}
	if (code->u.binop.op2->kind==TEMP_){
		int reg=setReg(code->u.binop.op2->u.tem_no);
		offset3=temp_offset[code->u.binop.op2->u.tem_no];
		FormLwCode(reg,30-8,offset3,data);
		FormBinCode(2,reg_l,reg_r,reg,data);
	}
	if (code->u.binop.op2->kind==CONSTANT_){
		FormBinCode(0,reg_l,reg_r,code->u.binop.op2->u.value,data);
	}
	FormSwCode(30-8,reg_l,offset1,data);
}
//mul
int parseMul(InterCode code,char* data){
	int reg_r,reg_l,offset1,offset2,offset3;
	if (code->u.binop.result->kind==TEMP_){
		reg_l=setReg(code->u.binop.result->u.tem_no);
		offset1=temp_offset[code->u.binop.result->u.tem_no];
	}
	if (code->u.binop.op1->kind==TEMP_){
		reg_r=setReg(code->u.binop.op1->u.tem_no);
		offset2=temp_offset[code->u.binop.op1->u.tem_no];
		FormLwCode(reg_r,30-8,offset2,data);
	}
	if (code->u.binop.op2->kind==TEMP_){
		int reg=setReg(code->u.binop.op2->u.tem_no);
		offset3=temp_offset[code->u.binop.op2->u.tem_no];
		FormLwCode(reg,30-8,offset3,data);
		//TODO:
		FormBinCode(3,reg_l,reg_r,reg,data);
	}
	if (code->u.binop.op2->kind==CONSTANT_){
        	int reg=setReg(0);
		//TODO:
        	FormLiCode(reg, code->u.binop.op2->u.value,data);
	    	FormBinCode(3,reg_l,reg_r,reg,data);
	}
	
	FormSwCode(30-8,reg_l,offset1,data);
}
//div
int parseDiv(InterCode code,char* data){
	int reg_r,reg_l,offset1,offset2,offset3;
	if (code->u.binop.result->kind==TEMP_){
		reg_l=setReg(code->u.binop.result->u.tem_no);
		offset1=temp_offset[code->u.binop.result->u.tem_no];
	}
	if (code->u.binop.op1->kind==TEMP_){
		reg_r=setReg(code->u.binop.op1->u.tem_no);
		offset2=temp_offset[code->u.binop.op1->u.tem_no];
		FormLwCode(reg_r,30-8,offset2,data);
	}
	
	if (code->u.binop.op2->kind==TEMP_){
		int reg=setReg(code->u.binop.op2->u.tem_no);
		offset3=temp_offset[code->u.binop.op2->u.tem_no];
		FormLwCode(reg,30-8,offset3,data);
		//TODO:
		FormDivCode(reg_l,reg_r,reg,data);
	}
	
	FormSwCode(30-8,reg_l,offset1,data);
}
//if
int parseIf(InterCode code,char* data){
	int reg_l,reg_r;
	reg_l = setReg(code->c.as.op1->u.tem_no);
	FormLwCode(reg_l,30-8,temp_offset[code->c.as.op1->u.tem_no],data);
	if (code->c.as.op2->kind==TEMP_){
		reg_r = setReg(code->c.as.op2->u.tem_no);
		FormLwCode(reg_r,30-8,temp_offset[code->c.as.op2->u.tem_no],data);
	}
	
	if (code->c.as.op2->kind==CONSTANT_){
		reg_r = setReg(0);
		//TODO:
		FormLiCode(reg_r,code->c.as.op2->u.value,data);
	}
    
	strcat(data, "   ");
	//switch(){
	//}
	if (strcmp(code->c.as.relop, "==") == 0)strcat(data, "beq ");
	if (strcmp(code->c.as.relop, "<") == 0)strcat(data, "blt ");
	if (strcmp(code->c.as.relop, "!=") == 0)strcat(data, "bne ");
	if (strcmp(code->c.as.relop, ">") == 0)strcat(data, "bgt ");
	if (strcmp(code->c.as.relop, ">=") == 0)strcat(data, "bge ");
	if (strcmp(code->c.as.relop, "<=") == 0)strcat(data, "ble "); 
	//TODO:
	FormIfCode(reg_l, reg_r,code->c.as.label->u.label_no,data);
}
//assign
int parseAssign(InterCode code,char* data){
	int reg_l,reg_r,offset;
	if(code->u.assign.left->kind==VARIABLE_&&code->u.assign.left->add!=1){
		reg_l=setReg(code->u.assign.left->u.var_no);
		if(code->u.assign.right->kind==VARIABLE_&&code->u.assign.right->add!=1){//var->var
			reg_r= setReg(code->u.assign.right->u.var_no);
			offset=varOffset(code->u.assign.right->u.var_no);
			FormLwCode(reg_r,30-8,offset,data);
			FormMoveCode(reg_l,reg_r,data);
			FormSwCode(30-8,reg_l,varOffset(code->u.assign.left->u.var_no),data);
		}else if(code->u.assign.right->kind==TEMP_&&code->u.assign.right->add!=1){//temp->var
			reg_r=setReg(code->u.assign.right->u.tem_no);
			offset=temp_offset[code->u.assign.right->u.tem_no];
			FormLwCode(reg_r,30-8,offset,data);
			FormMoveCode(reg_l,reg_r,data);
			FormSwCode(30-8,reg_l,varOffset(code->u.assign.left->u.var_no),data);
		}else if(code->u.assign.right->kind==CONSTANT_){//const->var
			FormLiCode(reg_l, code->u.assign.right->u.value,data);
			FormSwCode(30-8,reg_l,varOffset(code->u.assign.left->u.var_no),data);
		}else{//add->var
			
		}//TODO:
	}else if(code->u.assign.left->kind==TEMP_&&code->u.assign.left->add!=1){
		reg_l=setReg(code->u.assign.left->u.var_no);
		if(code->u.assign.right->kind==VARIABLE_&&code->u.assign.right->add!=1){//var->var
			reg_r= setReg(code->u.assign.right->u.var_no);
			offset=varOffset(code->u.assign.right->u.var_no);
			FormLwCode(reg_r,30-8,offset,data);
			FormMoveCode(reg_l,reg_r,data);
			FormSwCode(30-8,reg_l,varOffset(code->u.assign.left->u.var_no),data);
		}else if(code->u.assign.right->kind==TEMP_&&code->u.assign.right->add!=1){//temp->var
			reg_r=setReg(code->u.assign.right->u.tem_no);
			offset=temp_offset[code->u.assign.right->u.tem_no];
			FormLwCode(reg_r,30-8,offset,data);
			FormMoveCode(reg_l,reg_r,data);
			FormSwCode(30-8,reg_l,varOffset(code->u.assign.left->u.var_no),data);
		}else if(code->u.assign.right->kind==CONSTANT_){//const->var
			FormLiCode(reg_l, code->u.assign.right->u.value,data);
			FormSwCode(30-8,reg_l,varOffset(code->u.assign.left->u.var_no),data);
		}else{//add->var
			
		}
	}else{
		reg_l=setReg(code->u.assign.left->u.var_no);
		if(code->u.assign.right->kind==VARIABLE_&&code->u.assign.right->add!=1){//var->var
			reg_r= setReg(code->u.assign.right->u.var_no);
			offset=varOffset(code->u.assign.right->u.var_no);
			FormLwCode(reg_r,30-8,offset,data);
			FormMoveCode(reg_l,reg_r,data);
			FormSwCode(30-8,reg_l,varOffset(code->u.assign.left->u.var_no),data);
		}else if(code->u.assign.right->kind==TEMP_&&code->u.assign.right->add!=1){//temp->var
			reg_r=setReg(code->u.assign.right->u.tem_no);
			offset=temp_offset[code->u.assign.right->u.tem_no];
			FormLwCode(reg_r,30-8,offset,data);
			FormMoveCode(reg_l,reg_r,data);
			FormSwCode(30-8,reg_l,varOffset(code->u.assign.left->u.var_no),data);
		}else if(code->u.assign.right->kind==CONSTANT_){//const->var
			FormLiCode(reg_l, code->u.assign.right->u.value,data);
			FormSwCode(30-8,reg_l,varOffset(code->u.assign.left->u.var_no),data);
		}else{//add->var
			
		}
	}
}

int parseFunc(InterCode code, char *data) {
	strcat(data, code->s.func.func->u.id);
	strcat(data, ":\n");
	strcat(data, "    move $30, $29\n");
	
	//fNode f = functionTable;
	//while(strcmp(f->id, code->s.func.func->u.id)!=0)
	//	f= f->next;

	FormBinCode(0,29, 29, 8, data);
}

int parseReturn(InterCode code, char *data) {
	int rz = 0;
	regs[rz].used = 1;

	FormMoveCode(2, rz+8, data);

	//fNode f = functionTable;
	//if (f->id != NULL) {
	//	while(strcmp(f->id, "")!=0)
	//		f = f->next;
	//	FormBinCode(0,29, 29, -8, data);
	//}

	strcat(data, "    jr $ra\n");
}

