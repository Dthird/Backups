#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>
#include "struct.h"


int high_level=0;
InterCode whole_code=NULL;
symbol_table head=NULL,tail=NULL;
int label_count=0,temp_count=-1,var_count=0;
int offset=0;
FILE *f1;




InterCode translate_FunDec(Node * tree)
{
	char data[100];
	if (high_level==0) printf("FUNCTION %s :\n",tree->n_node.node[0]->node_id);
	/*strcpy(data,"FUNCTION ");
	strcat(data,tree->n_node.node[0]->node_id);
	strcat(data," :\n");
	fputs(data,f1);*/
	InterCode code=NULL;
	InterCode code1=(InterCode)malloc(sizeof(struct InterCode_));
	code1->kind=FUNCN_I;
	code1->func_.func_n=tree->n_node.node[0]->node_id;
	if (tree->create==1)  code=translate_VarList(tree->n_node.node[0]->node_id);
	code1->next=code;
	/*if ((high_level==0)&&(code1!=NULL)) 
	{
		printf_code(code1,0);
	}*/
	
}


/*
int y=0;
test(&y);
printf("test=%d \n",y);
void test(int *x)
{
 *x=1;
}
*/

InterCode translate_VarList(char * name)
{
	symbol_table temp_var=head;
	FieldList tp;
	InterCode code=NULL,temp,search;
	while (temp_var->next!=NULL)
	{
	   if (strcmp(temp_var->symbol_info->name,name)==0) break;
	   temp_var=temp_var->next;
	}
	tp=temp_var->symbol_varlist;
	while (tp!=NULL)
	{
		//printf("123\n");
		temp_var=head;
		while (temp_var->next!=NULL)
		{
	   		if (strcmp(temp_var->symbol_info->name,tp->name)==0) break;
	   		temp_var=temp_var->next;
		}
		temp=(InterCode)malloc(sizeof(struct InterCode_));
		temp->kind=PARAM_I;
		temp->param.op=temp_var->op;
		//printf("12%d\n",temp->param.op->var_no);
		if (code==NULL) code=temp;
		else 
		{
			search=code;
			while (search->next!=NULL) search=search->next;
			search->next=temp;
		}
		tp=tp->tail;
	}
	return code;
}











InterCode translate_CompSt(Node *tree)
{
	InterCode code,code1,code2,code_tail;
	//printf("4567\n");
	code1=translate_DefList(tree->n_node.node[1]);
	//printf("3213\n");
	code2=translate_StmtList(tree->n_node.node[2]);
	if (code1!=NULL) 
	{
		code=code1;
		if (code2!=NULL) 
		{
		code_tail=code;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;
		}
	}
	else 
	{
		if (code2!=NULL) code=code2;
		else return NULL;
	}
	
	//if (high_level==0) printf_code(code,0);

	return code;
}









InterCode translate_DefList(Node * tree)
{
	InterCode code_comma,code=NULL,code_tail;
	
	if (tree->create==1) {
							code_comma=translate_DefList(tree->n_node.node[1]);
							//printf_code(code_comma,0);
							code=translate_Def(tree->n_node.node[0]);
							if (code==NULL) code=code_comma;
							else 
							{
								code_tail=code;
								while (code_tail->next!=NULL) code_tail=code_tail->next;
								code_tail->next=code_comma;
							}
							
							return code;
						 }
	if (tree->create==2) return NULL;
}

InterCode translate_Def(Node * tree)
{
	InterCode code=NULL;
	if (tree->n_node.node[0]->create==2) code=translate_DecList(tree->n_node.node[1],3);
	else 
   code=translate_DecList(tree->n_node.node[1],0);
	return code;
}

InterCode translate_DecList(Node * tree,int is_dec)
{
	InterCode code=NULL,code_comma=NULL,code_tail;
	if (tree->create==1) code=translate_Dec(tree->n_node.node[0],is_dec);
	if (tree->create==2) {
							code_comma=translate_DecList(tree->n_node.node[2],is_dec);
							code=translate_Dec(tree->n_node.node[0],is_dec);
							
							if (code!=NULL)
							{
							  code_tail=code;
							  while (code_tail->next!=NULL) code_tail=code_tail->next;
							  code_tail->next=code_comma;
							}
							else 	code=code_comma;
						 }
	return code;
}

InterCode translate_Dec(Node * tree,int is_dec)
{
	InterCode code=NULL,code_tail;
	if (tree->create==1) code=translate_VarDec(tree->n_node.node[0],is_dec);
	if (tree->create==2) 
	{
	   code=(InterCode)malloc(sizeof(struct InterCode_));
	   code->kind=ASSINGN_I;
	  // printf("123%s\n",tree->n_node.node[0]->n_node.node[0]->node_id);
	   code->assign.left=find_opfrom_name(tree->n_node.node[0]->n_node.node[0]->node_id);
	   if (tree->n_node.node[2]->create!=17)
	   {
	   	Operand t1;
	  		t1=new_temp();
	   	InterCode code1=translate_Exp(tree->n_node.node[2],t1);

	   	code_tail=code1;
			while (code_tail->next!=NULL) code_tail=code_tail->next;
			code_tail->next=code;
	   	code->assign.right=t1;
	   	return code1;
	   }
	   else
	   code->assign.right=get_value(tree->n_node.node[2]->n_node.node[0]->node_int);
	}
	return code;
}

InterCode translate_VarDec(Node * tree,int is_dec)
{
	InterCode code=NULL;
	//printf("is_dec %d %d\n",is_dec,tree->create);
	if (is_dec==3)
	{
		if (tree->create==1) code=translate_Size(tree->n_node.node[0]->node_id);
		/*if (tree->create==2) {
										code=translate_Size(tree->n_node.node[0]->node_id);
										//code->dec.size=code->dec.size*tree->n_node.node[2]->node_int;
									}*/
	}
	else 
	if (tree->create==2) 
	{
		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=DEC_I;
		code->dec.op=find_opfrom_name(tree->n_node.node[0]->n_node.node[0]->node_id);
		code->dec.size=4*tree->n_node.node[2]->node_int;
		return code;
	}
	
	return code;
}

Operand find_opfrom_name(char *name)
{
	symbol_table temp=head;
	while (temp->next!=NULL)
	{
		if (strcmp(temp->symbol_info->name,name)==0) break;
		temp=temp->next;
	}
	return temp->op;
}
InterCode translate_Size(char * name)
{
	InterCode code=(InterCode)malloc(sizeof(struct InterCode_));
	symbol_table temp=head;
	while (temp->next!=NULL)
	{
		if (strcmp(temp->symbol_info->name,name)==0) break;
		temp=temp->next;
	}	
	code->kind=DEC_I;
	code->dec.op=temp->op;
	code->dec.size=count_struct(temp->symbol_info->Field_type->structure->Field_type->structure,0);
	return code;
}

int count_struct(FieldList tp,int deep)
{
	int sum=0;
	FieldList temp;
	//printf("123\n");
	if (tp->Field_type->kind==basic) { //tp->address=sum;
	 sum=sum+4; };
	if (tp->Field_type->kind==array) { //tp->address=sum; 
	sum=sum+4*tp->Field_type->size; }
	if (tp->Field_type->kind==structure) {//tp->address=sum; 
	sum=sum+count_struct(tp->Field_type->structure,0); }
	
	if (deep==0)
	{
		temp=tp;
		while (temp->tail!=NULL)
		{
			temp->tail->address=sum;
			sum=sum+count_struct(temp->tail,1);
			temp=temp->tail;
		}
	}
	
	return sum;
}

InterCode translate_StmtList(Node * tree)
{
	InterCode code=NULL,code_comma=NULL,code_tail;
	if (tree->create==1) {
							code_comma=translate_StmtList(tree->n_node.node[1]);
							code=translate_Stmt(tree->n_node.node[0]);
							if (code!=NULL)
							{
								code_tail=code;
								while (code_tail->next!=NULL) code_tail=code_tail->next;
								code_tail->next=code_comma;
							}
							//code->next=code_comma;
						 }

	return code;
}

InterCode translate_Stmt(Node * tree)
{
	InterCode code=NULL,code1,code2,code3,code4,code_tail,code_label1,code_label2,code_label3,code_goto;
	Operand t1,label1,label2,label3;
	if (tree->create==1) { 
							//printf("123\n");
							code=translate_Exp(tree->n_node.node[0],NULL);
							return code;
						 }
	if (tree->create==2) {
							code=translate_CompSt(tree->n_node.node[0]);
							return code;
						 }			
	if (tree->create==3) {
							t1=new_temp();
							code=translate_Exp(tree->n_node.node[1],t1);
							code2=(InterCode)malloc(sizeof(struct InterCode_));
							code2->kind=RETURN_I;
							code2->return_.op=t1;
							
							code_tail=code;
							while (code_tail->next!=NULL) code_tail=code_tail->next;
							code_tail->next=code2;
							
							
							return code;
						 }	
	if (tree->create==4){
							label1=new_label();
							label2=new_label();
							code1=translate_Cond(tree->n_node.node[2],label1,label2);
							code2=translate_Stmt(tree->n_node.node[4]);

							code3=(InterCode)malloc(sizeof(struct InterCode_));
							code3->kind=LABEL_I;
							code3->label.no=label1;
							code3->next=code2;

							code4=(InterCode)malloc(sizeof(struct InterCode_));
							code4->kind=LABEL_I;
							code4->label.no=label2;

							code_tail=code3;
							while (code_tail->next!=NULL) code_tail=code_tail->next;
							code_tail->next=code4;

							code_tail=code1;
							while (code_tail->next!=NULL) code_tail=code_tail->next;
							code_tail->next=code3;

							return code1;

						}							 
	if (tree->create==5){	
							label1=new_label();
							label2=new_label();
							label3=new_label();
							code1=translate_Cond(tree->n_node.node[2],label1,label2);
							code2=translate_Stmt(tree->n_node.node[4]);
							code3=translate_Stmt(tree->n_node.node[6]);

							code_label1=(InterCode)malloc(sizeof(struct InterCode_));
							code_label2=(InterCode)malloc(sizeof(struct InterCode_));
							code_label3=(InterCode)malloc(sizeof(struct InterCode_));
							code_label1->kind=LABEL_I;
							code_label1->label.no=label1;
							code_label2->kind=LABEL_I;
							code_label2->label.no=label2;
							code_label3->kind=LABEL_I;
							code_label3->label.no=label3;

							code_goto=(InterCode)malloc(sizeof(struct InterCode_));
							code_goto->kind=GOTO_I;
							code_goto->goto_.go_label=label3;

							code_tail=code3;
							while (code_tail->next!=NULL) code_tail=code_tail->next;
							code_tail->next=code_label3;

							code_label2->next=code3;

							code_goto->next=code_label2;

							code_tail=code2;
							while (code_tail->next!=NULL) code_tail=code_tail->next;
							code_tail->next=code_goto;

							code_label1->next=code2;

							code_tail=code1;
							while (code_tail->next!=NULL) code_tail=code_tail->next;
							code_tail->next=code_label1;

							return code1;
						}
	if (tree->create==6){	
							label1=new_label();
							label2=new_label();
							label3=new_label();
							code1=translate_Cond(tree->n_node.node[2],label2,label3);
							code2=translate_Stmt(tree->n_node.node[4]);

							code_label1=(InterCode)malloc(sizeof(struct InterCode_));
							code_label2=(InterCode)malloc(sizeof(struct InterCode_));
							code_label3=(InterCode)malloc(sizeof(struct InterCode_));	
							code_label1->kind=LABEL_I;
							code_label1->label.no=label1;
							code_label2->kind=LABEL_I;
							code_label2->label.no=label2;
							code_label3->kind=LABEL_I;
							code_label3->label.no=label3;
							code_goto=(InterCode)malloc(sizeof(struct InterCode_));
							code_goto->kind=GOTO_I;
							code_goto->goto_.go_label=label1;

							code_goto->next=code_label3;

							code_tail=code2;
							while (code_tail->next!=NULL) code_tail=code_tail->next;
							code_tail->next=code_goto;

							code_label2->next=code2;

							code_tail=code1;
							while (code_tail->next!=NULL) code_tail=code_tail->next;
							code_tail->next=code_label2;

							code_label1->next=code1;

							return code_label1;
						}
	return code;

}

InterCode translate_Exp(Node * tree,Operand place)
{
	symbol_table temp;
	InterCode code=NULL,code1=NULL,code2=NULL,code_tail,code3,code4;
	Operand op=NULL,op1=NULL,op2=NULL,t1=NULL,t2=NULL,t3=NULL;
	Operand label1,label2;
	//printf("%d\n",tree->create);
	if (tree->create==1) //assignop
	{
		t1=new_temp();
		
		if(tree->n_node.node[0]->create==16) {
												//printf("%s\n",tree->n_node.node[0]->n_node.node[0]->node_id);
												op=lookup(tree->n_node.node[0]->n_node.node[0]->node_id);
												//printf("123\n");
												//printf("123%d\n",tree->n_node.node[2]->create);
												
												code=translate_Exp(tree->n_node.node[2],t1);
												//printf_code(code,0);
												//printf("123\n");
												code1=(InterCode)malloc(sizeof(struct InterCode_));
												code1->kind=ASSINGN_I;
												code1->assign.left=op;
												code1->assign.right=t1;
												
												if (code!=NULL)
												{
													code_tail=code;
													while (code_tail->next!=NULL) code_tail=code_tail->next;
													code_tail->next=code1;
												}
												
												
												if (place!=NULL)
												{
													code2=(InterCode)malloc(sizeof(struct InterCode_));
													code2->kind=ASSINGN_I;
													code2->assign.left=place;
													code2->assign.right=op;
													//printf_code(code2);
													
													code_tail=code;
													while (code_tail->next!=NULL) code_tail=code_tail->next;
													code_tail->next=code2;										
												}
												return code;
											 }
		if(tree->n_node.node[0]->create==15) {
												t1=new_temp();
												code=translate_Exp(tree->n_node.node[0],t1);
												op=code->binop.result;
												//printf_code(code,0);
												t2=new_temp();
												code1=translate_Exp(tree->n_node.node[2],t2);
												code_tail=code;
												while (code_tail->next!=NULL) code_tail=code_tail->next;
												code_tail->next=code1;

												op1=(Operand)malloc(sizeof(struct Operand_));
												op1->kind=POINT;
												op1->point_var=op;


												code2=(InterCode)malloc(sizeof(struct InterCode_));
												code2->kind=ASSINGN_I;
												code2->assign.left=op1;
												code2->assign.right=t2;
												
												code_tail=code;
												while (code_tail->next!=NULL) code_tail=code_tail->next;
												code_tail->next=code2;

												return code;
											 
											 }									 
		if(tree->n_node.node[0]->create==14) {
												t1=new_temp();
												t2=new_temp();
												t3=new_temp();
												code=translate_Exp(tree->n_node.node[2],t1);

												code1=translate_Exp(tree->n_node.node[0]->n_node.node[2],t2);
												code_tail=code;
												while (code_tail->next!=NULL) code_tail=code_tail->next;
												code_tail->next=code1;

												InterCode code3=(InterCode)malloc(sizeof(struct InterCode_));
												code3->kind=MUL_I;
												code3->binop.result=t2;
												code3->binop.op1=t2;
												code3->binop.op2=get_value(4);
												code_tail=code;
												while (code_tail->next!=NULL) code_tail=code_tail->next;
												code_tail->next=code3;


												op=find_opfrom_name(tree->n_node.node[0]->n_node.node[0]->n_node.node[0]->node_id);		
												//printf("%s\n",tree->n_node.node[0]->node_id);						
												//printf("%s\n",tree->n_node.node[0]->n_node.node[0]->n_node.node[0]->node_id);										
												op1=(Operand)malloc(sizeof(struct Operand_));
												op1->kind=ADDRESS;
												op1->address_var=op;

												code2=(InterCode)malloc(sizeof(struct InterCode_));
												code2->kind=ADD_I;
												code2->binop.op1=op1;
												code2->binop.op2=t2;
												code2->binop.result=t3;


											   op2=(Operand)malloc(sizeof(struct Operand_));
												op2->kind=POINT;
												op2->point_var=t3;

												InterCode code4=(InterCode)malloc(sizeof(struct InterCode_));
												code4->kind=ASSINGN_I;
												code4->assign.left=op2;
												code4->assign.right=t1;
												code2->next=code4;



												code_tail=code;
												while (code_tail->next!=NULL) code_tail=code_tail->next;
												code_tail->next=code2;

												return code;

											 }	
		return code;									 
	}
	
	/*if (tree->create==2)
	{
		label1=new_label;
		label2=
	}*/
	if (tree->create==2)
	{
		label1=new_label();
		label2=new_label();
		code3=(InterCode)malloc(sizeof(struct InterCode_));
		code3->kind=ASSINGN_I;
		code3->assign.left=place;
		code3->assign.right=get_value(0);
		code1=translate_Cond(tree,label1,label2);

		code2=(InterCode)malloc(sizeof(struct InterCode_));
		code2->kind=LABEL_I;
		code2->label.no=label1;

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=ASSINGN_I;
		code->assign.left=place;
		code->assign.right=get_value(1);

	
		code4=(InterCode)malloc(sizeof(struct InterCode_));
		code4->kind=LABEL_I;
		code4->label.no=label2;

		code->next=code4;
		code2->next=code;

		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;

		code3->next=code1;
		return code3;

	}

	if (tree->create==3)
	{
		label1=new_label();
		label2=new_label();
		code3=(InterCode)malloc(sizeof(struct InterCode_));
		code3->kind=ASSINGN_I;
		code3->assign.left=place;
		code3->assign.right=get_value(0);
		code1=translate_Cond(tree,label1,label2);

		code2=(InterCode)malloc(sizeof(struct InterCode_));
		code2->kind=LABEL_I;
		code2->label.no=label1;

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=ASSINGN_I;
		code->assign.left=place;
		code->assign.right=get_value(1);

	
		code4=(InterCode)malloc(sizeof(struct InterCode_));
		code4->kind=LABEL_I;
		code4->label.no=label2;

		code->next=code4;
		code2->next=code;

		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;

		code3->next=code1;
		return code3;		
	}


	if (tree->create==4)
	{
		label1=new_label();
		label2=new_label();
		code3=(InterCode)malloc(sizeof(struct InterCode_));
		code3->kind=ASSINGN_I;
		code3->assign.left=place;
		code3->assign.right=get_value(0);
		code1=translate_Cond(tree,label1,label2);

		code2=(InterCode)malloc(sizeof(struct InterCode_));
		code2->kind=LABEL_I;
		code2->label.no=label1;

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=ASSINGN_I;
		code->assign.left=place;
		code->assign.right=get_value(1);

	
		code4=(InterCode)malloc(sizeof(struct InterCode_));
		code4->kind=LABEL_I;
		code4->label.no=label2;

		code->next=code4;
		code2->next=code;

		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;

		code3->next=code1;
		return code3;
	}

	if (tree->create==5)
	{
		t1=new_temp();
		t2=new_temp();
		//printf("%d ",tree->n_node.node[0]->create);
		code1=translate_Exp(tree->n_node.node[0],t1);
		code2=translate_Exp(tree->n_node.node[2],t2);

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=ADD_I;
		code->binop.op1=t1;
		code->binop.op2=t2;
		code->binop.result=place;

		code_tail=code2;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code;
		
		
		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;
		
		
		return code1;
	}

if (tree->create==6)
	{
		t1=new_temp();
		t2=new_temp();
		//printf("%d ",tree->n_node.node[0]->create);
		code1=translate_Exp(tree->n_node.node[0],t1);
		code2=translate_Exp(tree->n_node.node[2],t2);

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=SUB_I;
		code->binop.op1=t1;
		code->binop.op2=t2;
		code->binop.result=place;

		code_tail=code2;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code;
		
		
		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;
		
		
		return code1;
	}


	if (tree->create==7)
	{
		t1=new_temp();
		t2=new_temp();
		//printf("%d ",tree->n_node.node[0]->create);
		code1=translate_Exp(tree->n_node.node[0],t1);
		code2=translate_Exp(tree->n_node.node[2],t2);

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=MUL_I;
		code->binop.op1=t1;
		code->binop.op2=t2;
		code->binop.result=place;

		code_tail=code2;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code;
		
		
		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;
		
		
		return code1;
	}


	if (tree->create==8)
	{
		t1=new_temp();
		t2=new_temp();
		//printf("%d ",tree->n_node.node[0]->create);
		code1=translate_Exp(tree->n_node.node[0],t1);
		code2=translate_Exp(tree->n_node.node[2],t2);

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=DIV_I;
		code->binop.op1=t1;
		code->binop.op2=t2;
		code->binop.result=place;

		code_tail=code2;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code;
		
		
		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;
		
		
		return code1;
	}
	if (tree->create==9)
	{
		code=translate_Exp(tree->n_node.node[1],place);
		return code;
	}

	if (tree->create==10)
	{
		t1=new_temp();
		//printf("%d ",tree->n_node.node[0]->create);
		code1=translate_Exp(tree->n_node.node[1],t1);

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=SINGLEOP_I;
		code->singleop.op=t1;
		code->singleop.result=place;
		code->singleop.flag="-";

		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code;
		
		
		return code1;
	}
	
	if (tree->create==11)
	{
		t1=new_temp();
		//printf("%d ",tree->n_node.node[0]->create);
		code1=translate_Exp(tree->n_node.node[1],t1);

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=SINGLEOP_I;
		code->singleop.op=t1;
		code->singleop.result=place;
		code->singleop.flag="!";

		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code;
		
		
		return code1;
	}
	
	
	if (tree->create==12)
	{
		//printf("123\n");
		args_num=-1;
		code1=translate_Args(tree->n_node.node[2]);
		//printf("123\n");
		if (strcmp(tree->n_node.node[0]->node_id,"write")==0)
		{
			code2=(InterCode)malloc(sizeof(struct InterCode_));
			code2->kind=WRITE_I;
			code2->write.op=args[0];

			code_tail=code1;
			while (code_tail->next!=NULL) code_tail=code_tail->next;
			code_tail->next=code2;
			return code1;
		}
		else
		{
			int i;
			code2=(InterCode)malloc(sizeof(struct InterCode_));
			code2->kind=ARG_I;
			code2->arg.op=args[0];
			
			
			/*for (i=args_num-1;i>=0;i--)
			{
				code=(InterCode)malloc(sizeof(struct InterCode_));
				code->kind=ARG_I;
				code->arg.op=args[i];

				code_tail=code2;
				while (code_tail->next!=NULL) code_tail=code_tail->next;
				code_tail->next=code;
			}*/
			for (i=1;i<=args_num;i++)
			{
				code=(InterCode)malloc(sizeof(struct InterCode_));
				code->kind=ARG_I;
				code->arg.op=args[i];

				code_tail=code2;
				while (code_tail->next!=NULL) code_tail=code_tail->next;
				code_tail->next=code;
			}
						
			code_tail=code1;
			while (code_tail->next!=NULL) code_tail=code_tail->next;
			code_tail->next=code2;

			code3=(InterCode)malloc(sizeof(struct InterCode_));
			code3->kind=CALL_I;
			code3->call.result=place;
			code3->call.func_name=tree->n_node.node[0]->node_id;

			code_tail=code1;
			while (code_tail->next!=NULL) code_tail=code_tail->next;
			code_tail->next=code3;
			return code1;
		}
		
	}




	if (tree->create==13)
	{
		code=(InterCode)malloc(sizeof(struct InterCode_));
		//code1=(InterCode)malloc(sizeof(struct InterCode_));
		if (strcmp(tree->n_node.node[0]->node_id,"read")==0) 
		{
			code->kind=READ_I;
			code->read.op=place;
		}
		else 
		{
			code->kind=CALL_I;
			code->call.func_name=tree->n_node.node[0]->node_id;
			code->call.result=place;
		}
		return code;
	}
	if (tree->create==14)
	{
		t1=new_temp();
		t2=new_temp();
		code1=translate_Exp(tree->n_node.node[2],t1);
		op=find_opfrom_name(tree->n_node.node[0]->n_node.node[0]->node_id);
		//printf("%s\n",tree->n_node.node[0]->n_node.node[0]->node_id);
		
		op1=(Operand)malloc(sizeof(struct Operand_));
		op1->kind=ADDRESS;
		op1->address_var=op;

		InterCode code3=(InterCode)malloc(sizeof(struct InterCode_));
		code3->kind=MUL_I;
		code3->binop.result=t1;
		code3->binop.op1=t1;
		code3->binop.op2=get_value(4);
		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code3;



		code2=(InterCode)malloc(sizeof(struct InterCode_));
		code2->kind=ADD_I;
		code2->binop.op1=op1;
		code2->binop.op2=t1;
		code2->binop.result=t2;

	   op2=(Operand)malloc(sizeof(struct Operand_));
		op2->kind=POINT;
		op2->point_var=t2;

		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=ASSINGN_I;
		code->assign.left=place;
		code->assign.right=op2;

		code2->next=code;

		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;

		return code1;

	}
	
	if (tree->create==15)
	{
		t1=new_temp();
		temp=head;
		while (temp->next!=NULL)
		{
			if (strcmp(temp->symbol_info->name,tree->n_node.node[0]->n_node.node[0]->node_id)==0) break;
			temp=temp->next;
		}
		//printf("%s %s\n",temp->symbol_info->name,tree->n_node.node[0]->node_id);
		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=ADD_I;
		code->binop.op1=temp->op;
		FieldList tp=temp->symbol_info->Field_type->structure->Field_type->structure;

		while (tp->tail!=NULL)
		{
			if (strcmp(tp->name,tree->n_node.node[2]->node_id)==0) break;
			tp=tp->tail;
		}
	
		code->binop.op2=get_value(tp->address);
		//printf_Operand(code->binop.op1);
		code->binop.result=t1;

		op2=(Operand)malloc(sizeof(struct Operand_));
		op2->kind=POINT;
		op2->point_var=t1;

		code2=(InterCode)malloc(sizeof(struct InterCode_));
		code2->kind=ASSINGN_I;
		code2->assign.left=place;
		code2->assign.right=op2;
		code->next=code2;

		return code;
	}
	
	if (tree->create==16)
	{
		temp=head;
		//printf("%s %s \n",temp->symbol_info->name,tree->n_node.node[0]->node_id);
		while (temp->next!=NULL)
		{
			if (strcmp(temp->symbol_info->name,tree->n_node.node[0]->node_id)==0) break;
			temp=temp->next;
		}
		//printf("%s %s \n",temp->symbol_info->name,tree->n_node.node[0]->node_id);
		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=ASSINGN_I;
		code->assign.left=place;
		code->assign.right=temp->op;
		//printf("123\n");
		return code;
		//printf("123312\n");
	}

	if (tree->create==17)
	{
		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=ASSINGN_I;
		code->assign.left=place;
		//printf("constants is :%d\n",tree->n_node.node[0]->node_int);
		code->assign.right=get_value(tree->n_node.node[0]->node_int);
		return code;
	}

	return code;
}

int args_num=-1;
Operand args[50];
InterCode translate_Args(Node * tree)
{
	Operand t1;
	InterCode code1,code,code2,code_tail;
	//printf("123\n");
	if (tree->create==2)
	{
		t1=new_temp();
		code1=translate_Exp(tree->n_node.node[0],t1);
		args_num++;
		args[args_num]=t1;
		return code1;
	}
	if (tree->create==1)
	{
		t1=new_temp();
		code1=translate_Exp(tree->n_node.node[0],t1);
		args_num++;
		args[args_num]=t1;
		code2=translate_Args(tree->n_node.node[2]);
		
		
		//printf("123\n");
		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;

		return code1;
	}
}
InterCode translate_Cond(Node * tree,Operand label_true,Operand label_false)
{
	Operand t1,t2,op,label1;;
	InterCode code1,code2,code,code_tail,code3,code4;
	if (tree->create==4)
	{
		t1=new_temp();
		t2=new_temp();
		code1=translate_Exp(tree->n_node.node[0],t1);
		code2=translate_Exp(tree->n_node.node[2],t2);
		
		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=IF_I;
		code->if_.op1=t1;
		code->if_.op2=t2;
		code->if_.relop_name=tree->n_node.node[1]->node_id;
		code->if_.goto_label=label_true->label_no;

		/*code3=(InterCode)malloc(sizeof(struct InterCode_));
		code3->kind=GOTO_I;
		code3->goto_.go_label=label_true;*/

		code4=(InterCode)malloc(sizeof(struct InterCode_));
		code4->kind=GOTO_I;
		code4->goto_.go_label=label_false;

		//code3->next=code4;
		//code->next=code3;
		code->next=code4;

		code_tail=code2;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code;

		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code2;

		return code1;
	}
		if (tree->create==11) return translate_Cond(tree->n_node.node[1],label_false,label_true);
	if (tree->create==2)
	{
		label1=new_label();
		code1=translate_Cond(tree->n_node.node[0],label1,label_false);
		code2=translate_Cond(tree->n_node.node[2],label_true,label_false);
		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=LABEL_I;
		code->label.no=label1;
		code->next=code2;

		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code;

		return code1;
	}
	if (tree->create==3)
	{
		label1=new_label();
		code1=translate_Cond(tree->n_node.node[0],label_true,label1);
		code2=translate_Cond(tree->n_node.node[2],label_true,label_false);
		code=(InterCode)malloc(sizeof(struct InterCode_));
		code->kind=LABEL_I;
		code->label.no=label1;
		code->next=code2;

		code_tail=code1;
		while (code_tail->next!=NULL) code_tail=code_tail->next;
		code_tail->next=code;

		return code1;
	}

	t1=new_temp();
	//printf("tree%d\n",tree->create);
	code1=translate_Exp(tree,t1);
	//printf_code(code1,0);
	code2=(InterCode)malloc(sizeof(struct InterCode_));
	code2->kind=IF_I;
	code2->if_.op1=t1;
	code2->if_.op2=get_value(0);
	code2->if_.relop_name="!=";
	code2->if_.goto_label=label_true->label_no;
	

	/*code3=(InterCode)malloc(sizeof(struct InterCode_));
	code3->kind=GOTO_I;
	code3->goto_.go_label=label_true;*/

	code=(InterCode)malloc(sizeof(struct InterCode_));
	code->kind=GOTO_I;
	code->goto_.go_label=label_false;

	//code3->next=code;
	//code2->next=code3;
	code2->next=code;

	code_tail=code1;
	while (code_tail->next!=NULL) code_tail=code_tail->next;
	code_tail->next=code2;
	return code1; 
}


Operand get_value(int node_int)
{
	Operand op=(Operand)malloc(sizeof(struct Operand_));
	op->kind=CONSTANTS;
	op->value=node_int;
	return op;
}

int temp_offset[100];
Operand new_temp()
{
	Operand op=(Operand)malloc(sizeof(struct Operand_));
	temp_count++;
	op->kind=TEMP;
	op->temp_no=temp_count;
	temp_offset[temp_count]=offset-4;
	offset=offset-4;
	return op;
}

Operand new_label()
{
	Operand op=(Operand)malloc(sizeof(struct Operand_));
	label_count++;
	op->kind=LABEL;
	op->label_no=label_count;
	return op;
}

Operand lookup(char * name)
{
	Operand op;
	//printf("find\n");
	symbol_table temp=head;
	//printf("find\n");
	while (temp->next!=NULL)
	{
		if (strcmp(temp->symbol_info->name,name)==0) break;
		temp=temp->next;
	}
	op=temp->op;
	//printf("find\n");
	return op;
}




void printf_code(InterCode code,int is_root)
{
  char data[100];
  char vb[100];
  if (is_root==1)
  {
	if (code->kind==PARAM_I)  {
								//printf("PARAM ");
								//printf_Operand(code->param.op);
								//printf(" \n");
								
								strcpy(data,"PARAM ");
								strcat(data,printf_Operand(code->param.op));
								strcat(data," \n");
								fputs(data,f1);
								
							}
	if (code->kind==DEC_I) {
								//printf("DEC ");
								//printf_Operand(code->dec.op);
								//printf(" ",code->dec.size);
								//printf(" \n");
								char string[10];
								strcpy(data,"DEC ");
								strcat(data,printf_Operand(code->dec.op));
								sprintf(string, "%d", code->dec.size);  
								strcat(data,string);
								strcat(data," \n");
								fputs(data,f1);
	}
	
	if (code->kind==ASSINGN_I){
										//printf_Operand(code->assign.left);
										//printf(" := ");
										//printf_Operand(code->assign.right);
										//printf("\n");
										
										strcpy(data,printf_Operand(code->assign.left));
										strcat(data," := ");
										strcat(data,printf_Operand(code->assign.right));
										strcat(data," \n");
										fputs(data,f1);
	}
	if (code->kind==ADD_I){
										//printf_Operand(code->binop.result);
										//printf(" := ");
										//printf_Operand(code->binop.op1);
										//printf(" + ");
										//printf_Operand(code->binop.op2);
										//printf("\n");
										
										strcpy(data,printf_Operand(code->binop.result));
										strcat(data," := ");
										strcat(data,printf_Operand(code->binop.op1));
										strcat(data," + ");
										strcat(data,printf_Operand(code->binop.op2));
										strcat(data," \n");
										fputs(data,f1);
										
		}
	if (code->kind==AND_I){
										//printf_Operand(code->binop.result);
										//printf(" := ");
										//printf_Operand(code->binop.op1);
										//printf(" && ");
										//printf_Operand(code->binop.op2);
										
										strcpy(data,printf_Operand(code->binop.result));
										strcat(data," := ");
										strcat(data,printf_Operand(code->binop.op1));
										strcat(data," && ");
										strcat(data,printf_Operand(code->binop.op2));
										strcat(data," \n");
										fputs(data,f1);
		}
	if (code->kind==OR_I){
										//printf_Operand(code->binop.result);
										//printf(" := ");
										//printf_Operand(code->binop.op1);
										//printf(" || ");
										//printf_Operand(code->binop.op2);
										
										strcpy(data,printf_Operand(code->binop.result));
										strcat(data," := ");
										strcat(data,printf_Operand(code->binop.op1));
										strcat(data," || ");
										strcat(data,printf_Operand(code->binop.op2));
										strcat(data," \n");
										fputs(data,f1);
										//printf("\n");
		}
	if (code->kind==MUL_I){
										//printf_Operand(code->binop.result);
										//printf(" := ");
										//printf_Operand(code->binop.op1);
										//printf(" * ");
										//printf_Operand(code->binop.op2);
										//printf("\n");
										
										strcpy(data,printf_Operand(code->binop.result));
										strcat(data," := ");
										strcat(data,printf_Operand(code->binop.op1));
										strcat(data," * ");
										strcat(data,printf_Operand(code->binop.op2));
										strcat(data," \n ");
										fputs(data,f1);
		}
	if (code->kind==SUB_I){
										//printf_Operand(code->binop.result);
										//printf(" := ");
										//printf_Operand(code->binop.op1);
										//printf(" - ");
										//printf_Operand(code->binop.op2);
										//printf("\n");
										strcpy(data,printf_Operand(code->binop.result));
										strcat(data," := ");
										strcat(data,printf_Operand(code->binop.op1));
										strcat(data," - ");
										strcat(data,printf_Operand(code->binop.op2));
										strcat(data," \n ");
										fputs(data,f1);
										
		}
	if (code->kind==DIV_I){
										//printf_Operand(code->binop.result);
										//printf(" := ");
										//printf_Operand(code->binop.op1);
										//printf(" / ");
										//printf_Operand(code->binop.op2);
										//printf("\n");
										strcpy(data,printf_Operand(code->binop.result));
										strcat(data," := ");
										strcat(data,printf_Operand(code->binop.op1));
										strcat(data," / ");
										strcat(data,printf_Operand(code->binop.op2));
										strcat(data," \n ");
										fputs(data,f1);
		}
	if (code->kind==RELOP_I){
										//printf_Operand(code->relop_t.op1);
										printf(" %s \n",code->relop_t.content);
										//printf_Operand(code->relop_t.op2);
										
										strcpy(data,printf_Operand(code->relop_t.op1));
										strcat(data," ");
										strcat(data,code->relop_t.content);
										strcat(data," ");
										strcat(data,printf_Operand(code->relop_t.op2));
										fputs(data,f1);
										
										
		}
	if (code->kind==SINGLEOP_I){
										if(code->singleop.result!=NULL)
										{
										//printf_Operand(code->singleop.result);
										//printf(" := %s",code->singleop.flag);
										//printf_Operand(code->singleop.op);
										//printf("\n");
										strcpy(data,printf_Operand(code->singleop.result));
										strcat(data," := ");
										strcat(data,code->singleop.flag);
										strcat(data,printf_Operand(code->singleop.op));
										strcat(data," \n ");
										fputs(data,f1);
										}
										else
										{
										//printf(" %s",code->singleop.flag);
										//printf_Operand(code->singleop.op);
										//printf(" ");
										strcpy(data,printf_Operand(code->singleop.flag));
										strcat(data,printf_Operand(code->singleop.op));
										strcat(data," ");
										fputs(data,f1);									
										}
										
	}
	if (code->kind==READ_I) {
										//printf("READ ");
										//printf_Operand(code->read.op);
										//printf("\n");
										
										strcpy(data,"READ ");
										strcat(data,printf_Operand(code->read.op));
										strcat(data,"\n");
										fputs(data,f1);
										
	}
	if (code->kind==ARG_I){
										//printf("ARG ");
										//printf_Operand(code->arg.op);
										//printf("\n");
										strcpy(data,"ARG ");
										strcat(data,printf_Operand(code->arg.op));
										strcat(data,"\n");
										fputs(data,f1);
	
	}
	if (code->kind==WRITE_I){
										//printf("WRITE ");
										//printf_Operand(code->write.op);
										//printf("\n");
										strcpy(data,"WRITE ");
										strcat(data,printf_Operand(code->write.op));
										strcat(data,"\n");
										fputs(data,f1);
	}
	if (code->kind==RETURN_I){
										//printf("RETURN ");
										//printf_Operand(code->return_.op);
										//printf("\n");
										strcpy(data,"RETURN ");
										strcat(data,printf_Operand(code->return_.op));
										strcat(data,"\n");
										fputs(data,f1);
	}
	if (code->kind==CALL_I){
										//printf_Operand(code->call.result);
										//printf(" := CALL %s",code->call.func_name);
										//printf("\n");
										if (code->call.result!=NULL)
										strcpy(data,printf_Operand(code->call.result));
										else strcpy(data,"t0");
										strcat(data," := CALL ");
										strcat(data,code->call.func_name);
										strcat(data,"\n");
										fputs(data,f1);
	}
	if (code->kind==LABEL_I){
										//printf("LABEL ");
										//printf_Operand(code->label.no);
										//printf("\n");
										strcpy(data,"LABEL ");
										strcat(data,printf_Operand(code->label.no));
										strcat(data,":\n");
										fputs(data,f1);
										
	}
	if (code->kind==GOTO_I){
										//printf("GOTO ");
										//printf_Operand(code->goto_.go_label);
										//printf("\n");
										strcpy(data,"GOTO ");
										strcat(data,printf_Operand(code->goto_.go_label));
										strcat(data,"\n");
										fputs(data,f1);
	}
	if (code->kind==IF_I) {
										//printf("IF ");
										//printf_Operand(code->if_.op1);
										//printf(" %s 123123\n",code->if_.relop_name);
										//printf_Operand(code->if_.op2);
										
										strcpy(data,"IF ");
										strcat(data,printf_Operand(code->if_.op1));
										strcat(data," ");
										strcat(data,code->if_.relop_name);
										strcat(data," ");
										strcat(data,printf_Operand(code->if_.op2));
										strcat(data,"GOTO label");
										sprintf(vb, "%d ", code->if_.goto_label);
										strcat(data,vb);
										strcat(data,"\n");
										fputs(data,f1);									
	}
	if (code->kind==FUNCN_I) {
										strcpy(data,"FUNCTION ");
										strcat(data,code->func_.func_n);
										strcat(data," :\n");
										fputs(data,f1);									
	}
  }
  else
  {
  	 InterCode temp=code;
  	 while (temp!=NULL)
  	 {
  	 	printf_code(temp,1);
  	 	temp=temp->next;
  	 }
  }

}

char *printf_Operand(Operand op)
{
	char *data,*va;
	data = (char*)malloc(10);
	va   = (char*)malloc(10);
   if (op!=NULL)
   {
	if (op->kind==VARIABLE) 
	{
		//printf("v%d ",op->var_no);
		sprintf(va, "%d ", op->var_no);
		strcpy(data, "v");
		strcat(data, va);
	}	
	
	if (op->kind==CONSTANTS) 
	{
		//printf("#%d ",op->value);
		sprintf(va, "%d ", op->value);
		strcpy(data, "#");
		strcat(data, va);
	}
	if (op->kind==ADDRESS) 
	{	
	 	//printf("&"); 
		
		sprintf(va, "%s ",printf_Operand(op->address_var));
		strcpy(data, "&");
		strcat(data, va);
	} 
	if (op->kind==POINT) 
	{ 
		//printf("*");
		//printf_Operand(op->point_var);
		sprintf(va, "%s ",printf_Operand(op->point_var));
		strcpy(data, "*");
		strcat(data, va);
	}
	if (op->kind==LABEL) 
	{
		//printf("label%d ",op->label_no);
		sprintf(va, "%d ", op->label_no);
		strcpy(data, "label");
		strcat(data, va);
	}
	if (op->kind==TEMP) 
	{
		//printf("t%d ",op->temp_no);
		sprintf(va, "%d ", op->temp_no);
		strcpy(data, "t");
		strcat(data, va);
	}
	if (op->kind==FUNC) 
	{
		//printf("%s ",op->func_name);
		sprintf(va, "%s ", op->func_name);
		strcpy(data, va);
	}
	}
	return data;
}














void semantic_analysis(Node * tree)
{
	f1 = fopen("out1.ir","w");
	int i;
	ExtDefList(tree->n_node.node[0]);
	symbol_table temp=head;
	FieldList tp;
	Type transfer;
	
	fill_offset(offset);
	while (temp!=NULL)
	{
	   printf("name is %s dis is %d  ",temp->symbol_info->name,temp->symbol_dis);
	   if (temp->symbol_dis==1)
	   {
	     printf("v%d ",temp->op->var_no);
	     printf("offset is : %d\n\n",temp->offset);
	   }
		
		if (temp->symbol_dis==2)
		{
			printf("offset is : %d\n\n",temp->offset);
		}
		temp=temp->next;
	}
	for (i=0;i<=temp_count;i++)
	printf("t%d: offset %d\n\n",i,temp_offset[i]);
	
	printf_code(whole_code,0);
	mips(whole_code);
	if (high_level==1) 
	{
		char data[100];
		strcpy(data,"Can not translate the code: Contain multidimensional array and function parameters of array type!");
		fputs(data,f1);
	}	
	fclose(f1); 


}

void ExtDefList(Node * tree)
{
	InterCode code_tail,code;
	
	if (tree->create==1) { 
								code=ExtDef(tree->n_node.node[0]);
								if (tree->n_node.node[0]->create==3)
								{
								if (whole_code==NULL) whole_code=code; 
								else 
								{ 
								 code_tail=whole_code;
								 while (code_tail->next!=NULL) 
								   code_tail=code_tail->next;
								 code_tail->next=code; 
								 printf("123\n");
								}
								}
			      			ExtDefList(tree->n_node.node[1]); 
			     }    
}

InterCode ExtDef(Node * tree)
{
	Type transfer;
	InterCode code1,code2,code_tail;
	//printf("ExtDef\n");
	if (tree->create==1) { 	   		   transfer=Specifier(tree->n_node.node[0]); 
						   //printf("leixing %d\n",transfer->basic);
						   ExtDecList(tree->n_node.node[1],transfer); 
	}
	if (tree->create==2) {
						   transfer=Specifier(tree->n_node.node[0]);
	}
	if (tree->create==3) {
						   transfer=Specifier(tree->n_node.node[0]);

						   FunDec(tree->n_node.node[1],transfer);
						   code1=translate_FunDec(tree->n_node.node[1]);
						   
						   CompSt(tree->n_node.node[2],transfer);
						   code2=translate_CompSt(tree->n_node.node[2]);
						   
						   code_tail=code1;
							while (code_tail->next!=NULL) code_tail=code_tail->next;
							code_tail->next=code2;
							return code1;
						   //printf_code(code1,0);
						   
	}
	if (tree->create==4)
	{
  	 //printf("Error type B at line : Incomplete definition of function “%s",tree->n_node.node[1]->n_node.node[0]->node_id);
	}
	
}

void ExtDecList(Node *tree,Type transfer)
{
   FieldList tp,tp_comma;
   //printf("ExtDecList\n");
   if (tree->create==1)  {  tp=VarDec(tree->n_node.node[0],transfer);
   						if (transfer->kind=basic)
   					   Fill_in(tp,tree->lineno,NULL,1);
   					   else  Fill_in(tp,tree->lineno,NULL,3);
   					   //printf("%d\n",tp->symbol_dis);
   				     }

   if (tree->create==2) { 
   						tp=VarDec(tree->n_node.node[0],transfer); 
   						Fill_in(tp,tree->lineno,NULL,1);
   						ExtDecList(tree->n_node.node[2],transfer);
   				    }
}

Type Specifier(Node *tree)
{
	Type transfer=(Type)malloc(sizeof(struct Type_));
	FieldList tp;
	if (tree->create==1) { 
							transfer->kind=basic;
		  					if (strcmp(tree->n_node.node[0]->node_other,"INT")==0) transfer->basic=1; //INT
		  					else transfer->basic=2;									  //FLOAT
		  					return transfer;
		  			 }
	if (tree->create==2) {
						tp=StructSpecifier(tree=tree->n_node.node[0]);
						transfer->kind=structure;
						transfer->structure=tp;
						return transfer;
	}

}

FieldList StructSpecifier(Node *tree)
{
	//printf("StructSpecifier\n");
	FieldList tp=(FieldList)malloc(sizeof(struct FieldList_));
	if (tree->create==1) {		
							if (tree->n_node.node[1]->create==1)	
								tp->name=tree->n_node.node[1]->n_node.node[0]->node_id;
							tp->Field_type=(Type)malloc(sizeof(struct Type_));
							tp->Field_type->kind=structure;
							tp->Field_type->structure=DefList(tree->n_node.node[3],5);
							tp->tail=NULL;
							if (tree->n_node.node[1]->create==1)	 Fill_in(tp,tree->lineno,NULL,3);
							return tp;
	}
	if (tree->create==2) {				
							tp=find_struct(tree->n_node.node[1]->n_node.node[0]->node_id);
							//printf("struct name is here %s\n",tree->n_node.node[1]->n_node.node[0]->node_id);
							if (tp==NULL) 
							{
								//printf("Error type 17 at line %d: Undefined struct ‘%s’\n",tree->lineno,tree->n_node.node[1]->n_node.node[0]->node_id);
								return NULL;
							}
							tp->tail=NULL;
							return tp;
	} 

}

FieldList DefList(Node *tree,int dis)
{
	//printf("DefList\n");
	FieldList tp,tp_comma,tp_tail;
	if (tree->create==1) {
					     tp_comma=DefList(tree->n_node.node[1],dis);
					     tp=Def(tree->n_node.node[0],dis);
					     tp_tail=tp;
					     while (tp_tail->tail!=NULL)
					     tp_tail=tp_tail->tail;
					     tp_tail->tail=tp_comma;
					     return tp;
					     
	}
	else return NULL;
return NULL;
}

FieldList Def(Node *tree,int dis)
{
	//printf("Def\n");
	FieldList tp;
	Type transfer;
	transfer=Specifier(tree->n_node.node[0]);
	tp=DecList(tree->n_node.node[1],transfer,dis);
	return tp;
}

FieldList DecList(Node *tree,Type transfer,int dis)
{
     FieldList tp,tp_comma;
     	//printf("DecList\n");
	if (tree->create==1) { tp=Dec(tree->n_node.node[0],transfer);
						if (transfer->kind==basic)
					   Fill_in(tp,tree->lineno,NULL,dis);
					   else Fill_in(tp,tree->lineno,NULL,3);
					   return tp;
					 }

	if (tree->create==2) {
							tp_comma=DecList(tree->n_node.node[2],transfer,dis);
						     tp=Dec(tree->n_node.node[0],transfer);
						   if (transfer->kind==basic)
						     Fill_in(tp,tree->lineno,NULL,dis);
						   else Fill_in(tp,tree->lineno,NULL,3);
							tp->tail=tp_comma;
							return tp;
					 }
}





FieldList Dec(Node *tree,Type transfer)
{
	//printf("Dec\n");
	Type exp_type;
   if (tree->create==1) {
   						return  VarDec(tree->n_node.node[0],transfer);
   } 
   if (tree->create==2)
   {
   	exp_type=Exp(tree->n_node.node[2]);
   	if (equal(exp_type,transfer)==0) 
   	{ //printf("Error type 5 at line %d: Type mismatched\n",tree->lineno);
		  //return NULL;
		}
   	return VarDec(tree->n_node.node[0],transfer);
   }

}

FieldList VarDec(Node *tree,Type transfer)
{
   //printf("VarDec\n");
   FieldList tp=(FieldList)malloc(sizeof(struct FieldList_));

   Type transfer1=(Type)malloc(sizeof(struct Type_));
   if (tree->create==1) { 
   						  tp->name=tree->n_node.node[0]->node_id;
   						  tp->Field_type=transfer;
   						  //printf("%s\n",tp->name);
   						  tp->tail=NULL;
   						  return tp;
   }

   if (tree->create==2) {
   						  if (tree->n_node.node[0]->create==2) high_level=1;
   						  transfer1->kind=array;
   						  transfer1->size=tree->n_node.node[2]->node_int;
   						  transfer1->elem=transfer;
   						  tp=VarDec(tree->n_node.node[0],transfer1);
   						  return tp;
   }
}

void Fill_in(FieldList tp,int lineno,FieldList varlist,int dis)
{
  int flag=0;
  symbol_table current;
  if (head==NULL) {
  				head=(symbol_table)malloc(sizeof(struct symbol_table_));
  				head->symbol_info=tp;				
  				head->symbol_lineno=lineno;
  				head->symbol_varlist=varlist;
  				head->symbol_dis=dis;
  				if (tp->Field_type->kind==basic) 
  				{
  					head->offset=offset-4;
					offset=offset-4;
				}
				
				if (tp->Field_type->kind==array)
				{
					head->offset=offset-4*tp->Field_type->size;
					offset=offset-4*tp->Field_type->size;
				}
  				
  					
				Operand op1=(Operand)malloc(sizeof(struct Operand_));
	   		if (dis==1)
	   		{
	   			var_count++;
	   			op1->kind=VARIABLE;
	   			op1->var_no=var_count;
	   		}
	   	
				if (dis==3)
				{
					var_count++;
	   			op1->kind=VARIABLE;
	   			op1->var_no=var_count;
				}
  				head->op=op1;
  				head->next=NULL;
  				tail=head;
  			   }
  else 		{
  				current=head;
               	while (current!=NULL) 
               	{
               		
               		if (redefine(tp,current->symbol_info)==1)   
               					  {
               					  	if (dis==1)
									printf("Error type 3 at line %d: Redefined variable “%s”\n",lineno,tp->name); 

									if (dis==2)
									printf("Error type 4 at line %d: Redefined function “%s”\n",lineno,tp->name); 

									if (dis==3) 
									printf("Error type 16 at line %d: Duplicated name ‘%s’\n",lineno,tp->name);

									flag=1;
									break;
               					  }
               		else current=current->next;
               	}
               	if (flag==0)
               	{
               		current=(symbol_table)malloc(sizeof(struct symbol_table_));
               		current->symbol_info=tp;
               		//printf("%s ",current->symbol_info->name);
               		current->symbol_lineno=lineno;
               		current->symbol_varlist=varlist;
               		current->symbol_dis=dis;
               		if (tp->Field_type->kind==basic) 
  							{
  								current->offset=offset-4;
								offset=offset-4;
							}
				
							if (tp->Field_type->kind==array)
							{
								current->offset=offset-4*tp->Field_type->size;
								offset=offset-4*tp->Field_type->size;
							}
  				
               		
               		//printf("new added %s %d %d\n",tp->name,dis,tp->Field_type->kind);
							tail->next=current;
							//printf("%s\n",tail->symbol_info->name);
							tail=current;
               		current->next=NULL;
               		
               		Operand op1=(Operand)malloc(sizeof(struct Operand_));
	   					if (dis==1)
	   					{
	   						var_count++;
	   						op1->kind=VARIABLE;
	   						op1->var_no=var_count;
	   					}
	   	
							if (dis==3)
							{
								var_count++;
	   						op1->kind=VARIABLE;
	   						op1->var_no=var_count;
							}
							current->op=op1;
               	}      
  }

}

void fill_offset(int offset)
{
	symbol_table temp=head,record;
	while (temp!=NULL)
	{
		if (temp->symbol_dis==2) record=temp;
		temp=temp->next;
	}
	if (record!=NULL) 
		record->offset=offset;
}

void FunDec(Node *tree,Type transfer)
{
  FieldList tp=(FieldList)malloc(sizeof(struct FieldList_));
  FieldList varlist;
  tp->name=tree->n_node.node[0]->node_id;
  fill_offset(offset);
  offset=0;
  
  //printf("123%s\n",tp->name);
  tp->Field_type=transfer;
  tp->tail=NULL;
  if (tree->create==1)
  {
    varlist=VarList(tree->n_node.node[2]);
    Fill_in(tp,tree->lineno,varlist,2);
  }
  if (tree->create==2)
  {
    Fill_in(tp,tree->lineno,NULL,2);
  }
  
  
  
}

FieldList VarList(Node *tree)
{
  FieldList tp,tp_comma;
  if (tree->create==1) 
  {
  	tp_comma=VarList(tree->n_node.node[2]);
  	tp=ParamDec(tree->n_node.node[0]);
  	tp->tail=tp_comma;
  	return tp;
  }
  if (tree->create==2)
  {
  	tp=ParamDec(tree->n_node.node[0]);
  	tp->tail=NULL;
  	return tp;
  }

}

FieldList ParamDec(Node *tree)
{
	Type transfer;
	FieldList tp;
	transfer=Specifier(tree->n_node.node[0]);
	tp=VarDec(tree->n_node.node[1],transfer);
	//printf("about to %s\n",tp->name);
	if (transfer->kind==structure) Fill_in(tp,tree->lineno,NULL,3);
	else Fill_in(tp,tree->lineno,NULL,1);
	return tp;
}


void CompSt(Node *tree,Type transfer)
{
	FieldList tp;
	tp=DefList(tree->n_node.node[1],1);
	
	StmtList(tree->n_node.node[2],transfer);
}

void StmtList(Node *tree,Type transfer)
{
	if (tree->create==1) { Stmt(tree->n_node.node[0],transfer);
					   StmtList(tree->n_node.node[1],transfer);
					 }

}

void Stmt(Node *tree,Type transfer)
{
 Type exp_type;

 if (tree->create==1) { 
 								exp_type=Exp(tree->n_node.node[0]);
 							 }
 if (tree->create==2) CompSt(tree->n_node.node[0],transfer);
 if (tree->create==3) 
 { 
 	exp_type=Exp(tree->n_node.node[1]);
 	
 	/*if (equal(exp_type,transfer)==0) 
 	printf("Error type 8 at line %d: The return type mismatched\n",tree->lineno);*/
 }

 if (tree->create==4) 
 {	
 	exp_type=Exp(tree->n_node.node[2]);
 	Stmt(tree->n_node.node[4],transfer);
 }
 if (tree->create==5) 
 {
 	exp_type=Exp(tree->n_node.node[2]);
 	Stmt(tree->n_node.node[4],transfer);
 	Stmt(tree->n_node.node[6],transfer);
 }
 if (tree->create==6) 
 {	
 	exp_type=Exp(tree->n_node.node[2]);
 	Stmt(tree->n_node.node[4],transfer);
 		
 }

}


Type Exp(Node *tree)
{
	//printf("%d\n",tree->create);
	Type transfer,exp_type1,exp_type2;
	FieldList tp,tp_arg,tp_r,tp_arg_r;
	symbol_table func,struct_f;
	int flag=1;
	if (tree->create==1)
	{
		if (!((tree->n_node.node[0]->create==16)||(tree->n_node.node[0]->create==15)||(tree->n_node.node[0]->create==14)))      
		{
		//printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n",tree->lineno);
		return NULL;
		}
		
		exp_type1=Exp(tree->n_node.node[0]);
		//printf("4567\n");
		exp_type2=Exp(tree->n_node.node[2]);
		//printf("4567\n");
		//if ((equal(exp_type1,exp_type2)==0)&&(exp_type1!=NULL)&&(exp_type2!=NULL)) 
		// printf("Error type 5 at line %d: Type mismatched\n",tree->lineno);
		return exp_type1;
	}

	if (tree->create==2)
	{
		exp_type1=Exp(tree->n_node.node[0]);
		exp_type2=Exp(tree->n_node.node[2]);
		return exp_type1;
	}	

	if (tree->create==3)
	{
		exp_type1=Exp(tree->n_node.node[0]);
		exp_type2=Exp(tree->n_node.node[2]);
		return exp_type1;
	}	

	if (tree->create==4)
	{
		exp_type1=Exp(tree->n_node.node[0]);
		exp_type2=Exp(tree->n_node.node[2]);
		return exp_type1;
	}	

	if (tree->create==5)
	{
		exp_type1=Exp(tree->n_node.node[0]);
		exp_type2=Exp(tree->n_node.node[2]);
		if (equal(exp_type1,exp_type2)==0) 
		//printf("Error type 7 at line %d: Operands type mismatched\n",tree->lineno);
		return exp_type1;
	}	

	if (tree->create==6)
	{
		exp_type1=Exp(tree->n_node.node[0]);
		exp_type2=Exp(tree->n_node.node[2]);
		return exp_type1;
	}	

	if (tree->create==7)
	{
		exp_type1=Exp(tree->n_node.node[0]);
		exp_type2=Exp(tree->n_node.node[2]);
		return exp_type1;
	}	

	if (tree->create==8)
	{
		exp_type1=Exp(tree->n_node.node[0]);
		exp_type2=Exp(tree->n_node.node[2]);
		return exp_type1;
	}	

	if (tree->create==9)
	{
		exp_type1=Exp(tree->n_node.node[1]);
		return exp_type1;
	}

	if (tree->create==10)
	{
		exp_type1=Exp(tree->n_node.node[1]);
		return exp_type1;

	}

	if (tree->create==11)
	{
		exp_type1=Exp(tree->n_node.node[1]);
		return exp_type1;
	}

	if (tree->create==12)
	{
		transfer=(Type)malloc(sizeof(struct Type_));
		func=find_whole(tree->n_node.node[0]->node_id);
		
		if (func!=NULL)
		{
	   	tp=func->symbol_varlist;
		   tp_r=tp;
		}
		if (func==NULL) 
		{
			//printf("Error type 2 at line %d: Undefined function “%s”\n",tree->lineno,tree->n_node.node[0]->node_id);
			return NULL;
		}
		else 
		{
		 if (func->symbol_dis!=2) 
		 {
		 //printf("Error type 11 at line %d: “%s” must be a function\n",tree->lineno,tree->n_node.node[0]->node_id);
		 }
		 else 
		 {		 		
			flag=1;
			
			tp_arg=Args(tree->n_node.node[2]);	
			tp_arg_r=tp_arg;
			
			if (tp_arg->Field_type!=NULL)
			{
			
			while ((tp!=NULL)||(tp_arg!=NULL))
			{
			  if((tp_arg==NULL)||(tp==NULL)) {flag=0; break;}
			  else
			  {
				if (equal(tp_arg->Field_type,tp->Field_type)==0) { flag=0; break; } }
				tp=tp->tail;
				tp_arg=tp_arg->tail;
			}
			
			if (flag==0) 
			{	
				tp=tp_r;
				tp_arg=tp_arg_r;
				//printf("Error type 9 at line 8: The method func ");
				if (tp->Field_type->basic==1) printf("int");
				else printf("float");
				tp=tp->tail;
				while (tp!=NULL)
				{
					if (tp->Field_type->basic==1) printf(",int");
					else printf(",float");
					tp=tp->tail;
				}


				printf(" is not applicable for the arguments  ");


				if (tp_arg->Field_type->basic==1) printf("int");
				else printf("float");
				tp_arg=tp_arg->tail;
				while (tp_arg!=NULL)
				{
					if (tp_arg->Field_type->basic==1) printf(",int");
					else printf(",float");
					tp_arg=tp_arg->tail;
				}
				printf("\n");
			}
			
		 }
		 }
		}
		//printf("123\n");
		
		return func->symbol_info->Field_type;
	}

	if (tree->create==13)
	{
		transfer=(Type)malloc(sizeof(struct Type_));
		func=find_whole(tree->n_node.node[0]->node_id);
		if (func==NULL) 
		{
			//printf("Error type 2 at line %d: Undefined function “%s”\n",tree->lineno,tree->n_node.node[0]->node_id);
			return NULL;
		}
		else 
		{
		 if (func->symbol_dis!=2){ printf("Error type 11 at line %d: “%s” must be a function\n",tree->lineno,func->symbol_info->name);}
		 else
		 {	
			return tp->Field_type;
		 }
		}

	}

	if (tree->create==14)
	{
		exp_type1=Exp(tree->n_node.node[0]);
		if (exp_type1->kind!=array) 
		{
		//printf("Error type 10 at line %d: “%s” must be an array\n",tree->lineno,tree->n_node.node[0]->n_node.node[0]->node_id);
		}
	   else return exp_type1->elem;
		exp_type2=Exp(tree->n_node.node[2]);
		
		//if (exp_type2->basic==2) printf("Error type 12 at line %d: Operands type mistaken\n",tree->lineno);
		return NULL;
	}

	if (tree->create==15)
	{
		struct_f=find_whole(tree->n_node.node[0]->n_node.node[0]->node_id);
		if (struct_f->symbol_dis!=3) 
		{
		 //printf("Error type 13 at line %d: Illegal use of “.”\n",tree->lineno);
		 }
		else 
		{
			flag=0;
			//printf("%s\n",struct_f->symbol_info->Field_type->structure->name);
			tp=struct_f->symbol_info->Field_type->structure->Field_type->structure;
			while (tp!=NULL)
			{
				//printf("start to cmp: %s %s\n",tp->name,tree->n_node.node[2]->node_id);
				if (strcmp(tp->name,tree->n_node.node[2]->node_id)==0) {flag=1;break;}
				else tp=tp->tail;
			}
			if (flag==0) 
			{
				//printf("Error type 14 at line %d: Un-existed field %s\n",tree->lineno,tree->n_node.node[0]->node_id);
				return NULL;
			}
		}
		return tp->Field_type;
	}

	if (tree->create==16)
	{
		transfer=(Type)malloc(sizeof(struct Type_));
		//printf("%s\n",tree->n_node.node[0]->node_id);
		//printf("4567\n");
		tp=NULL;
		tp=find_struct(tree->n_node.node[0]->node_id);
		if (tp==NULL) 
		{
			//printf("Error type 1 at line %d: Undefined variable “%s”\n",tree->lineno,tree->n_node.node[0]->node_id);
			return NULL;
		}
		else return tp->Field_type;

	}

	if (tree->create==17)
	{
		transfer=(Type)malloc(sizeof(struct Type_));
		transfer->kind=basic;
		transfer->basic=1;
		return transfer;
	}

	if (tree->create==18)
	{
		transfer=(Type)malloc(sizeof(struct Type_));
		transfer->kind=basic;
		transfer->basic=2;
		return transfer;
	}
/*
	if (tree->create==19)
	{
		exp_type1=Exp(tree->n_node.node[0]);
		exp_type2=Exp(tree->n_node.node[3]);
		return NULL;		
	}
*/
}


FieldList Args(Node *tree)
{
	Type exp_type;
	FieldList tp_comma;
	FieldList tp=(FieldList)malloc(sizeof(struct FieldList_));
	if (tree->create==1) {
						tp_comma=Args(tree->n_node.node[2]);
						//printf("zhuanxiang %d\n",tree->n_node.node[0]->create);

						exp_type=Exp(tree->n_node.node[0]);
						
						tp->Field_type=exp_type;
						tp->tail=tp_comma;
						
						return tp;
	}
	
	if (tree->create==2) {
		           
						tp=(FieldList)malloc(sizeof(struct FieldList_));
						exp_type=Exp(tree->n_node.node[0]);
						tp->Field_type=exp_type;

						//tp->name=NULL;
						//tp->tail=NULL;
						return tp;
					 }
}





int equal(Type f1_t,Type f2_t)
{
    /*Type f1=f1_t,f2=f2_t;
    FieldList t1,t2;
    if ((f1==NULL)||(f2==NULL)) return 0;
    else 
    {
     if (f1->kind!=f2->kind) return 0;
     else 
     {
    	 if (f1->kind==basic) 
    	 {	
    	 	if (f1->basic!=f2->basic) return 0;
    	 	else 
    	 	{ 
    	 		return 1;
    	 	}
    	 }
    	 if (f1->kind==array)
    	 {
    	 	if (f1->size!=f2->size) return 0;
    	 	else  {
    	 			
    	 			return equal(f1->elem,f2->elem);
    	 		 }
    	 }

    	 if (f1->kind==structure)
    	 {
    	 	if (equal(f1->structure->Field_type,f2->structure->Field_type)==0) return 0;
    	 	else
    	 	{
    	 		t1=f1->structure;
    	 		t2=f2->structure;
    	 		while ((t1->tail!=NULL)&&(t2->tail!=NULL))
    	 		{
    	 			if (equal(t1->tail->Field_type,t2->tail->Field_type)==0) 	return 0;
    	 			else 
    	 			{
    	 				t1=t1->tail;
    	 				t2=t2->tail;
    	 			}			
    	 		}
    	 		
    	 		if ((t1->tail==NULL)&&(t2->tail!=NULL)) return 0;
    	 		if ((t1->tail!=NULL)&&(t2->tail==NULL)) return 0;
    	 		return 1;
    	 			
    	 	}
		
    	 }
    	 
    	 
     }
    }*/
    return 1;

}


int redefine(FieldList f1,FieldList f2)
{
     if (strcmp(f1->name,f2->name)==0) return 1;
	else return 0;
}

FieldList find_struct(char *name)
{
   symbol_table current=head;
   if (head==NULL) return NULL;
   else {
   		while (current!=NULL)
   		{
   		  if (strcmp(current->symbol_info->name,name)==0)
   		  {
   		  // printf("find %s: \n",current->symbol_info->Field_type->structure->name);
   		   return current->symbol_info;
   		  }
   		  current=current->next;
   		}
   }
   return NULL;
}



symbol_table find_whole(char *name)
{
   symbol_table current=head;
   if (head==NULL) return NULL;
   else {
   		while (current!=NULL)
   		{
   		  if (strcmp(current->symbol_info->name,name)==0) return current;
   		  current=current->next;
   		}
   }
   return NULL;
}	
	

	
	
	
