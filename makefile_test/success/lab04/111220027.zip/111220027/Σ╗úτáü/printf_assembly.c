#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>
#include "struct.h"

void printf_Lw(int r1,int r2,int offset)
{
	char string[10];
	r1=r1+8;
	r2=r2+8;
	strcat(fdata, "   lw ");

	strcat(fdata, "$");
	sprintf(string, "%d", r1);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	sprintf(string, "%d", offset);  
	strcat(fdata, string);
	strcat(fdata, "($");

	sprintf(string, "%d", r2);  
   strcat(fdata, string);
	strcat(fdata, ")\n");

}

void printf_sw(int r1, int r2,int offset) 
{
   char string[10];
   r1=r1+8;
   r2=r2+8;
	strcat(fdata, "   sw ");

	strcat(fdata, "$");
	sprintf(string, "%d", r2);  
	strcat(fdata, string);

	strcat(fdata, ", ");

	sprintf(string, "%d", offset);  
	strcat(fdata, string);
	strcat(fdata, "($");
	sprintf(string, "%d", r1);  
	strcat(fdata, string);
	strcat(fdata, ")\n");
}

void printf_move(int rx,int ry)
{
	char string[10];
	rx=rx+8;
	ry=ry+8;
	strcat(fdata,"   move ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", rx);  
	strcat(fdata, string);
	
	strcat(fdata, ", ");
	
	strcat(fdata, "$");

	sprintf(string, "%d", ry);  
	strcat(fdata, string);
	
	strcat(fdata, "\n");
}

void printf_Li(int rx,int constants)
{
   char string[10];
   rx=rx+8;
	strcat(fdata,"   li ");
	strcat(fdata,"$");
	sprintf(string, "%d", rx);  
	strcat(fdata, string);
	strcat(fdata,", ");
	
	sprintf(string, "%d", constants);  
	strcat(fdata, string);
	strcat(fdata,"\n");
	
}
void printf_Addi(int rx,int ry,int k)
{
   char string[10];
   rx=rx+8;
   ry=ry+8;
  	strcat(fdata, "   addi ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", rx);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", ry);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	sprintf(string, "%d", k);  
	strcat(fdata, string);
	strcat(fdata, "\n");
}

void printf_add(int rx, int ry, int rz) {
   char string[10];
   rx=rx+8;
   ry=ry+8;
   rz=rz+8;
	strcat(fdata, "   add ");

	strcat(fdata, "$");
	sprintf(string, "%d", rx);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", ry);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", rz);  
	strcat(fdata, string);
	strcat(fdata, "\n");
}

void printf_sub(int rx, int ry, int rz) {
   char string[10];
   rx=rx+8;
   ry=ry+8;
   rz=rz+8;
	strcat(fdata, "   sub ");

	strcat(fdata, "$");
	sprintf(string, "%d", rx);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", ry);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", rz);  
	strcat(fdata, string);
	strcat(fdata, "\n");
}
void printf_mul(int rx, int ry, int rz) {
   char string[10];
   rx=rx+8;
   ry=ry+8;
   rz=rz+8;
	strcat(fdata, "   mul ");

	strcat(fdata, "$");
	sprintf(string, "%d", rx);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", ry);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", rz);  
	strcat(fdata, string);
	strcat(fdata, "\n");
}

void printf_div(int rx, int ry, int rz) {
   char string[10];
   rx=rx+8;
   ry=ry+8;
   rz=rz+8;
	strcat(fdata, "    div ");

	strcat(fdata, "$");
	sprintf(string, "%d", ry);  
	strcat(fdata, string);

	strcat(fdata, ", ");
	
	strcat(fdata, "$");
	sprintf(string, "%d", rz);  
	strcat(fdata, string);

	strcat(fdata, "\n    mflo ");

	strcat(fdata, "$");
	sprintf(string, "%d", rx);  
	strcat(fdata, string);

	strcat(fdata, "\n");
}

void printf_if(int rx, int ry, int label) 
{
	char string[10];
	rx=rx+8;
	ry=ry+8;
	strcat(fdata, "$");
	sprintf(string, "%d", rx);  
	strcat(fdata, string);
	strcat(fdata, ", $");
	sprintf(string, "%d", ry);  
	strcat(fdata, string);
	
	strcat(fdata, ", label");
	sprintf(string, "%d", label);  
	strcat(fdata, string);
	strcat(fdata, "\n");
}

void printf_jal(char *name)
{
	strcat(fdata,"   jal ");
	strcat(fdata,name);
	strcat(fdata,"\n");
}
