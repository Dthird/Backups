#ifndef _NODE_H_
#define _NODE_H_
#define Func 0
#define Var  1
//int=1 float=2 id=3 other=4; Non=5; type=6;
typedef struct
{
  char* name;
  int num;
  struct NodeDef **node;
}Nonter_Node;

typedef struct NodeDef
{
  int type;
  int lineno;
  
  union
  {
  	int    		node_int;
  	char*  		node_id;
  	char* 		node_other;
  	float  		node_float;
  	Nonter_Node     n_node;
  };

  int create;

}Node;


typedef struct Type_* Type;
typedef struct FieldList_* FieldList;

typedef struct Type_
{
  enum {basic,array,structure} kind;

    int basic; //basic=1 INT   basic=2 FLOAT
    Type elem;
    int size;
    FieldList structure;
};



struct FieldList_
{
  char* name;
  Type Field_type;
  FieldList tail;
  int address;
}FieldList1;

typedef struct Operand_* Operand;
struct Operand_
{
	enum{VARIABLE,CONSTANTS,ADDRESS,POINT,LABEL,TEMP,FUNC}kind;
	//变量
	int var_no; 
	char var_name[10];
	//常量
	int value;
	//地址
	Operand address_var;
	//指针
	Operand point_var;
	//LABEL
	int label_no;
	//临时变量
	int temp_no;
	//函数名
	char func_name[10];
}; 


typedef struct symbol_table_* symbol_table;
struct symbol_table_
{
  //enum {var_t,struct_t,fun_t} symbol_kind;
  int symbol_lineno;  
  int symbol_dis;             //var=1 fun=2 struct=3
  FieldList symbol_info;
  FieldList symbol_varlist;
  symbol_table next;
  Operand op;
  int offset;
};

typedef struct InterCode_* InterCode;
struct InterCode_
{
	enum{ASSINGN_I,AND_I,OR_I,RELOP_I,LABEL_I,ADD_I,SUB_I,MUL_I,DIV_I,GOTO_I,SINGLEOP_I,RETURN_I,DEC_I,ARG_I,CALL_I,PARAM_I,READ_I,WRITE_I,IF_I,FUNCN_I}kind;
	struct {Operand right,left;}		assign;  //赋值
	struct {Operand result,op1,op2;}	binop;	 //双操作数
	struct {Operand op1,op2; char * content} relop_t;
	struct {Operand no;}				label;	 //标签
	struct {Operand go_label;}			goto_;	 //goto
	struct {Operand result,op;char * flag;}			singleop;//单操作数
	struct {Operand op;}				return_;
	struct {Operand op;int size;}		dec;
	struct {Operand op;}				arg;
	struct {Operand result;char * func_name}			call;
	struct {Operand op;}				param;
	struct {Operand op;}				read;	
	struct {Operand op;}				write;
	struct {Operand op1,op2;char * relop_name;int goto_label;}		if_;
	struct {char * func_n;} func_;

	InterCode next;
};
FILE *f;
char fdata[2000];
int temp_offset[100];
symbol_table head;
void semantic_analysis(Node * tree);
Type Specifier(Node *tree);
void ExtDefList(Node * tree);
InterCode ExtDef(Node * tree);
void ExtDecList(Node *tree,Type transfer);
FieldList StructSpecifier(Node *tree);
FieldList DefList(Node *tree,int dis);
FieldList Def(Node *tree,int dis);
FieldList DecList(Node *tree,Type transfer,int dis);
FieldList Dec(Node *tree,Type transfer);
FieldList VarDec(Node *tree,Type transfer);
void Fill_in(FieldList tp,int lineno,FieldList varlist,int dis);
void FunDec(Node *tree,Type transfer);
FieldList VarList(Node *tree);
FieldList ParamDec(Node *tree);
void CompSt(Node *tree,Type transfer);
void StmtList(Node *tree,Type transfer);
void Stmt(Node *tree,Type transfer);
Type Exp(Node *tree);
FieldList Args(Node *tree);
int equal(Type f1,Type f2);
int redefine(FieldList f1,FieldList f2);
FieldList find_struct(char *name);
symbol_table find_whole(char *name);

InterCode translate_FunDec(Node * tree);
InterCode translate_VarList(char * name);

void printf_code(InterCode code,int is_root);
char * printf_Operand(Operand op);
int args_num;
Operand args[50];
InterCode translate_CompSt(Node *tree);
InterCode translate_DefList(Node * tree);
InterCode translate_Def(Node * tree);
InterCode translate_DecList(Node * tree,int is_dec);
InterCode translate_Dec(Node * tree,int is_dec);
InterCode translate_VarDec(Node * tree,int is_dec);
Operand find_opfrom_name(char *name);
InterCode translate_Size(char * name);
int count_struct(FieldList tp,int deep);
InterCode translate_StmtList(Node * tree);
InterCode translate_Cond(Node * tree,Operand label_true,Operand label_false);
InterCode translate_Stmt(Node * tree);


InterCode translate_Exp(Node * tree,Operand place);	
InterCode translate_Args(Node * tree);
Operand get_value(int node_int);
Operand new_temp();
Operand new_label();
Operand lookup(char * name);



void mips_assign(InterCode code);
int ensure(int x);
int allocate(int x);
void mips(InterCode code);
void printf_Lw(int r1,int r2,int offset);
void printf_move(int rx,int ry);
void printf_Li(int rx,int constants);

#endif
