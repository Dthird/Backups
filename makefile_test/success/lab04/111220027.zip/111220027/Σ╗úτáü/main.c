#include <stdio.h>
#include "struct.h"

extern FILE* yyin;
extern FILE * yyout;
extern int yylineno;
//extern int yydebug;
//#define YYDEBUG 1
	
int main(int argc,char** argv)
{
	
	FILE* f=fopen(argv[1],"r");
	if (!f)
	{
		perror(argv[1]);
		return 1;
	}	
	
	yyrestart(f);
//	yydebug=1;
	yyparse();
	return 0;
}
	
yyerror(char* msg)
{
	printf("Error Type B at line %d: %s\n",yylineno,msg);
}
	
