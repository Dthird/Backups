int fact(int n)
{
	int a;
	if (n == 1)
	{
		return n;
	} 
	else
	{
		a=fact(1);
		return (n*fact(n-1));
	}
}
int main()
{
	int m,result;
	m = read();
	if(m>1)
		result = fact(m);
	else
		result = -1;
	write(result);
	return 0;
}
