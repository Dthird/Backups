#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>
#include <ctype.h>
#include "struct.h"

int reg_var[18];  
int used[18];
char fdata[2000];
int arg_no=0;
int arg_list[100];
char *whole_name;
int offset_change;

int find_offset(int var_no)
{
  symbol_table temp;
  temp=head;
  while (temp!=NULL)
  {
  	 if (temp->op->var_no==var_no) return temp->offset;
    temp=temp->next;
  }
}

void mips_assign(InterCode code)
{
	int rx,ry,offset;
	if (code->assign.left->kind==VARIABLE)
	{
		rx = allocate(code->assign.left->var_no);

		if (code->assign.right->kind==VARIABLE)
		{
			ry= allocate(code->assign.right->var_no);
			offset=find_offset(code->assign.right->var_no);
			printf_Lw(ry,30-8,offset);
			printf_move(rx,ry);
			printf_sw(30-8,rx,find_offset(code->assign.left->var_no));
		}
		if (code->assign.right->kind==CONSTANTS)
		{
			printf_Li(rx, code->assign.right->value);
			printf_sw(30-8,rx,find_offset(code->assign.left->var_no));
		}
		if (code->assign.right->kind==TEMP)
		{
			ry=allocate(code->assign.right->temp_no);
			offset=temp_offset[code->assign.right->temp_no];
			printf_Lw(ry,30-8,offset);
			printf_move(rx,ry);
			offset=find_offset(code->assign.left->var_no);
			printf_sw(30-8,rx,offset);
		}
		if (code->assign.right->kind==POINT)
		{
			ry=allocate(code->assign.right->point_var->temp_no);
			printf_Lw(ry,30-8,temp_offset[code->assign.right->point_var->temp_no]);
			//printf_move(rx,ry);
			printf_Lw(rx,ry,0);
			offset=find_offset(code->assign.left->var_no);
			printf_sw(30-8,rx,offset);
		}
		if (code->assign.right->kind==ADDRESS)
		{
			offset=find_offset(code->assign.right->address_var->var_no);
			printf_Addi(rx, 30-8, offset);
			printf_sw(30-8,rx,find_offset(code->assign.left->var_no));
		}
	}


	if (code->assign.left->kind==TEMP)
	{
		rx=allocate(code->assign.left->temp_no);
		
		if (code->assign.right->kind==VARIABLE)
		{
			ry= allocate(code->assign.right->var_no);
			offset=find_offset(code->assign.right->var_no);
			printf_Lw(ry,30-8,offset);
			printf_move(rx,ry);
		}
		if (code->assign.right->kind==CONSTANTS)
		{
			printf_Li(rx, code->assign.right->value);
		}
		if (code->assign.right->kind==TEMP)
		{
			ry=allocate(code->assign.right->temp_no);
			offset=temp_offset[code->assign.right->temp_no];
			printf_Lw(ry,30-8,offset);
			printf_move(rx,ry);
		}
		
		if (code->assign.right->kind==POINT)
		{
			ry=allocate(code->assign.right->point_var->temp_no);
			printf_Lw(ry,30-8,temp_offset[code->assign.right->point_var->temp_no]);
			printf_Lw(rx,ry,0);
			//printf_move(rx,ry);
		}
		if (code->assign.right->kind==ADDRESS)
		{
			offset=find_offset(code->assign.right->address_var->var_no);
			printf_Addi(rx, 30-8, offset);
		}
		offset=temp_offset[code->assign.left->temp_no];
		printf_sw(30-8,rx,offset);
	}

	if (code->assign.left->kind==POINT)
	{
		rx = allocate(code->assign.left->point_var->temp_no);
		int offset = temp_offset[code->assign.left->point_var->temp_no];
		//printf_Addi(rx, 30-8, offset);
		printf_Lw(rx,30-8,offset);
		/*if (code->assign.right->kind==VARIABLE)
		{
			ry=allocate(code->assign.right->var_no);
			printf_Lw(ry,30-8,find_offset(code->assign.right->var_no));
			printf_move(rx,ry);
		}
		if (code->assign.right->kind==CONSTANTS)
		{
			printf_Li(rx,code->assign.right->value);
		}*/
		if (code->assign.right->kind==TEMP)
		{
			ry=allocate(code->assign.right->temp_no);
			offset=temp_offset[code->assign.right->temp_no];
			printf_Lw(ry,30-8,offset);
			//printf_move(rx,ry);
			printf_sw(rx,ry,0);
			
		} 
		/*if (code->assign.right->kind==ADDRESS)
		{
			offset=find_offset(code->assign.right->address_var->var_no);
			printf_Addi(rx, 30-8, offset);
		}*/
		
		printf_sw(30-8,rx, temp_offset[code->assign.left->point_var->temp_no]);
	}
}

void mips_add(InterCode code)
{
	int rx=0,ry,rz,offset_rx=0,offset_ry=0,offset_rz=0;
	if (code->binop.result->kind==TEMP)
	{
		rx=allocate(code->binop.result->temp_no);
		offset_rx=temp_offset[code->binop.result->temp_no];
	}
	
	if (code->binop.op1->kind==TEMP)
	{
		ry=allocate(code->binop.op1->temp_no);
		offset_ry=temp_offset[code->binop.op1->temp_no];
		printf_Lw(ry,30-8,offset_ry);
	}
	if (code->binop.op1->kind==ADDRESS)
	{
		ry=allocate(code->binop.op1->address_var->var_no);
		offset_ry=find_offset(code->binop.op1->address_var->var_no);
		printf_Addi(ry,30-8,offset_ry);
	}
	
	if (code->binop.op2->kind==TEMP)
	{
		rz=allocate(code->binop.op2->temp_no);
		offset_rz=temp_offset[code->binop.op2->temp_no];
		printf_Lw(rz,30-8,offset_rz);
		printf_add(rx,ry,rz);
	}
	
	if (code->binop.op2->kind==CONSTANTS)
	{
		printf_Addi(rx,ry,code->binop.op2->value);
	}
	
	printf_sw(30-8,rx,offset_rx);
}


void mips_sub(InterCode code)
{
	int rx=0,ry,rz,offset_rx=0,offset_ry=0,offset_rz=0;
	if (code->binop.result->kind==TEMP)
	{
		rx=allocate(code->binop.result->temp_no);
		offset_rx=temp_offset[code->binop.result->temp_no];
	}
	
	if (code->binop.op1->kind==TEMP)
	{
		ry=allocate(code->binop.op1->temp_no);
		offset_ry=temp_offset[code->binop.op1->temp_no];
		printf_Lw(ry,30-8,offset_ry);
	}
	if (code->binop.op1->kind==ADDRESS)
	{
		ry=allocate(code->binop.op1->address_var->var_no);
		offset_ry=find_offset(code->binop.op1->address_var->var_no);
		printf_Addi(ry,30-8,offset_ry);
	}
	
	if (code->binop.op2->kind==TEMP)
	{
		rz=allocate(code->binop.op2->temp_no);
		offset_rz=temp_offset[code->binop.op2->temp_no];
		printf_Lw(rz,30-8,offset_rz);
		printf_sub(rx,ry,rz);
	}
	
	if (code->binop.op2->kind==CONSTANTS)
	{
		printf_Addi(rx,ry,-code->binop.op2->value);
	}
	
	printf_sw(30-8,rx,offset_rx);
}

void mips_mul(InterCode code)
{
	int rx=0,ry,rz,offset_rx=0,offset_ry=0,offset_rz=0;
	if (code->binop.result->kind==TEMP)
	{
		rx=allocate(code->binop.result->temp_no);
		offset_rx=temp_offset[code->binop.result->temp_no];
	}
	
	if (code->binop.op1->kind==TEMP)
	{
		ry=allocate(code->binop.op1->temp_no);
		offset_ry=temp_offset[code->binop.op1->temp_no];
		printf_Lw(ry,30-8,offset_ry);
	}
	
	if (code->binop.op2->kind==TEMP)
	{
		rz=allocate(code->binop.op2->temp_no);
		offset_rz=temp_offset[code->binop.op2->temp_no];
		printf_Lw(rz,30-8,offset_rz);
		printf_mul(rx,ry,rz);
	}
	
	if (code->binop.op2->kind==CONSTANTS)
	{
		 rz=allocate(0);
		 printf_Li(rz, code->binop.op2->value);
	    printf_mul(rx,ry,rz);
	}
	
	printf_sw(30-8,rx,offset_rx);
}

void mips_div(InterCode code)
{
	int rx=0,ry,rz,offset_rx=0,offset_ry=0,offset_rz=0;
	if (code->binop.result->kind==TEMP)
	{
		rx=allocate(code->binop.result->temp_no);
		offset_rx=temp_offset[code->binop.result->temp_no];
	}
	
	if (code->binop.op1->kind==TEMP)
	{
		ry=allocate(code->binop.op1->temp_no);
		offset_ry=temp_offset[code->binop.op1->temp_no];
		printf_Lw(ry,30-8,offset_ry);
	}
	
	if (code->binop.op2->kind==TEMP)
	{
		rz=allocate(code->binop.op2->temp_no);
		offset_rz=temp_offset[code->binop.op2->temp_no];
		printf_Lw(rz,30-8,offset_rz);
		printf_div(rx,ry,rz);
	}
	
	printf_sw(30-8,rx,offset_rx);
}

void mips_if(InterCode code)
{
	int rx,ry;
	rx = allocate(code->if_.op1->temp_no);
	printf_Lw(rx,30-8,temp_offset[code->if_.op1->temp_no]);
	
	if (code->if_.op2->kind==TEMP)
	{
		ry = allocate(code->if_.op2->temp_no);
		printf_Lw(ry,30-8,temp_offset[code->if_.op2->temp_no]);
	}
	
	if (code->if_.op2->kind==CONSTANTS)
	{
		ry = allocate(0);
		printf_Li(ry,code->if_.op2->value);
	}

	strcat(fdata, "   ");
	if (strcmp(code->if_.relop_name, "==") == 0)
		strcat(fdata, "beq ");
	
	if (strcmp(code->if_.relop_name, "!=") == 0)
		strcat(fdata, "bne ");
	
	if (strcmp(code->if_.relop_name, ">") == 0)
		strcat(fdata, "bgt ");
	
	if (strcmp(code->if_.relop_name, "<") == 0)
		strcat(fdata, "blt ");
	
	if (strcmp(code->if_.relop_name, ">=") == 0)
		strcat(fdata, "bge ");
	
	if (strcmp(code->if_.relop_name, "<=") == 0)
		strcat(fdata, "ble ");

	printf_if(rx, ry,code->if_.goto_label);
}
void mips_read(InterCode code)
{
	int rx;
	printf_Addi(29-8, 29-8, -8);
	printf_sw(29-8, 31-8, 0);
	printf_sw(29-8, 30-8, 4);

	rx = allocate(code->read.op->temp_no);
	
	printf_jal("read");
	printf_move(rx, 2-8);
	printf_sw(30-8,rx,temp_offset[code->read.op->temp_no]);

	printf_Lw(30-8, 29-8, 4);
	printf_Lw(31-8, 29-8, 0);
	printf_Addi(29-8, 29-8, 8);
	
}
void mips_write(InterCode code)
{
	int rx;
	
	rx =allocate(code->write.op->temp_no);
	printf_Lw(rx,30-8,temp_offset[code->write.op->temp_no]);
	printf_move(4-8, rx);
	printf_Addi(29-8, 29-8, -8);
	printf_sw(29-8, 31-8, 0);
	printf_sw(29-8, 30-8, 4);

	printf_jal("write");

	printf_Lw(30-8, 29-8, 4);
	printf_Lw(31-8, 29-8, 0);
	printf_Addi(29-8, 29-8, 8);
	
	
}
void mips_func(InterCode code)
{
	int offset;
	strcat(fdata," ");
	strcat(fdata, code->func_.func_n);
	strcat(fdata, ":\n");
	strcat(fdata, "   move $30, $29\n");
	symbol_table temp=head;
	while (temp!=NULL)
	{
		if (strcmp(temp->symbol_info->name,code->func_.func_n)==0) break;
		temp=temp->next;
	}
	whole_name=code->func_.func_n;
	printf_Addi(29-8, 29-8, temp->offset);
	
}

void mips_call(InterCode code)
{
	printf_Addi(29-8, 29-8, -8);
	printf_sw(29-8, 31-8, 0);
	printf_sw(29-8, 30-8, 4);

	if (arg_no > 0) printf_Addi(29-8, 29-8, arg_no*(-4));

	int offset = 0;
	int i;
	for (i=0;i<arg_no;i++)
	{
		int rx = allocate(arg_list[i]);
		printf_Lw(rx,30-8,temp_offset[arg_list[i]]);
		printf_sw(29-8, rx, offset);
		offset+=4;
	}	
	

	int ry = allocate(0);
	
	printf_jal(code->call.func_name);
	printf_move(ry, 2-8);
	
	if (arg_no > 0) printf_Addi(29-8, 29-8, arg_no*(4));

	printf_Lw(30-8, 29-8, 4);
	printf_Lw(31-8, 29-8, 0);
	printf_Addi(29-8, 29-8, 8);
	if (code->call.result!=NULL)
		printf_sw(30-8,ry,temp_offset[code->call.result->temp_no]);
	
}

void mips_return(InterCode code)
{
	int rx = allocate(code->return_.op->temp_no);
	printf_Lw(rx,30-8,temp_offset[code->return_.op->temp_no]);
	printf_move(2-8, rx);

	symbol_table temp=head;
	while (temp!=NULL)
	{
		if (strcmp(temp->symbol_info->name,whole_name)==0)
		{
			printf_Addi(29-8, 29-8, -temp->offset);
			break;
		}
		temp=temp->next;
	}
	
	strcat(fdata, "   jr $ra\n");
	
}
void mips_single(InterCode code)
{
	int rx,ry;
	
	rx=allocate(code->singleop.result->temp_no);
	ry=allocate(code->singleop.op->temp_no);
	printf_Lw(ry,30-8,temp_offset[code->singleop.op->temp_no]);
	printf_sub(rx,0-8,ry);
	printf_sw(30-8,rx,temp_offset[code->singleop.result->temp_no]);
	
}
void init_reg() 		//初始化寄存器，全部为空
{
	int i;
	for (i=0;i<18;i++)
	{
		reg_var[i]=0;
		used[i]=0;
	}
}
void clean_reg()
{
   int i;
	for (i=0;i<18;i++)
	{
		reg_var[i]=0;
		used[i]=0;
	}
}



int allocate(int x)
{
	int i;
	for (i=0;i<18;i++)
	  if (used[i]==0) 
	  {
	  	used[i]=1;
	  	reg_var[i]=x;
	  	return i;
	  }
}

void mips(InterCode code)
{
	int i;
	init_reg();

	FILE *fp;
	char *va;
   char string[10];
	fp = fopen("out.s", "w");
	fputs(".data\n \
_prompt: .asciiz \"Enter an integer:\"\n \
_ret: .asciiz \"\\n\"\n \
.globl main\n \
.text\n \
read:\n \
	li $v0, 4\n \
	la $a0, _prompt\n \
	syscall\n \
	li $v0, 5\n \
	syscall\n \
	jr $ra\n\n \
write:\n \
	li $v0, 1\n \
	syscall\n \
	li $v0, 4\n \
	la $a0, _ret\n \
	syscall\n \
	move $v0, $0\n \
	jr $ra\n\n", fp);
	
	printf(".data\n \
_prompt: .asciiz \"Enter an integer:\"\n \
_ret: .asciiz \"\\n\"\n \
.globl main\n \
.text\n \
read:\n \
	li $v0, 4\n \
	la $a0, _prompt\n \
	syscall\n \
	li $v0, 5\n \
	syscall\n \
	jr $ra\n\n \
write:\n \
	li $v0, 1\n \
	syscall\n \
	li $v0, 4\n \
	la $a0, _ret\n \
	syscall\n \
	move $v0, $0\n \
	jr $ra\n\n");

	InterCode temp=code;
	while (temp!=NULL)
	{
		if (temp->kind==ASSINGN_I) 
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_assign(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		} 
		
		if (temp->kind==ADD_I) 
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_add(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		}
		if (temp->kind==SUB_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_sub(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		}
		if (temp->kind==MUL_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_mul(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		}
		if (temp->kind==DIV_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_div(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		}
		
		if (temp->kind==GOTO_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"   j label");
			sprintf(string, "%d", temp->goto_.go_label->label_no);  
			strcat(fdata, string);
			strcat(fdata,"\n");
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		}
		
		if (temp->kind==IF_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_if(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		}
		if (temp->kind==SINGLEOP_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_single(temp);
			fputs(fdata,fp);
			printf("%s",fdata);
			clean_reg();
		}
		if (temp->kind==LABEL_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"label");
			sprintf(string, "%d", temp->label.no->label_no);  
			strcat(fdata, string);
			strcat(fdata,":\n");
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		}
		if (temp->kind==READ_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_read(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		}
		if (temp->kind==WRITE_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_write(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
		}
		if (temp->kind==FUNCN_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_func(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
			offset_change=-4;
		}
		if (temp->kind==ARG_I)
		{
			arg_list[arg_no]=temp->arg.op->temp_no;
			arg_no++;
			
		}
		if (temp->kind==CALL_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			
			mips_call(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();
			int clear;
			for (clear=0;clear<arg_no;clear++) arg_list[clear]=0;
			arg_no=0;
		}
		if (temp->kind==RETURN_I)
		{
			memset(fdata,0,1000);
			strcpy(fdata,"");
			mips_return(temp);
			fputs(fdata, fp);
			printf("%s", fdata);
			clean_reg();	
		}
		if (temp->kind==PARAM_I)
		{
			  symbol_table find;
 			  find=head;
  			  while (find!=NULL)
 			  {
  	 			if (find->op->var_no==temp->param.op->var_no) 
  	 			{
  	 				offset_change=offset_change+4;
  	 				find->offset=offset_change;
  	 				break;
  	 			}
    			find=find->next;
 			  }
		}
		temp=temp->next;
	}
	
	fclose(fp);
}



