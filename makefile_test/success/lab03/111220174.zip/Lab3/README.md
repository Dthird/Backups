#Lab3

编译`parser`请先进入source文件夹，在该文件夹中还有一份README.md，和这份相同。

输入 `make parser` 来编译 **parser**。

然后输入 `./parser 文件名` 以获得中间代码，中间代码会被存储在 **code.ir** 文件中。

输入 `bash irsim.sh` 来启动irsim。

虽然这次的程序吸取了lab2的教训，经过了一些包括快排在内的测试，但仍会有一些问题，如果发生问题请联系mattzhang9@gmail.com。 



Input `make parser` to compile the **parser**.

Then input `./parser filename` to generate the ir code. The result is saved in **code.ir**

Input `bash irsim.sh` to run the irsim.

Although the parser has went through some basic tests and even the quicksort, in some special cases there will also be something wrong. If any problem occurs, please contact mattzhang9@gmail.com. 
