#ifndef __OPTIMIZE_H__
#define __OPTIMIZE_H__
#include "common.h"
#include "translate.h"

void optimize();



#endif
