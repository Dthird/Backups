#ifndef __COMMON_H__
#define __COMMON_H__

#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>
enum bool{false,true};
typedef enum bool bool;
#define MAX_NAME 32
#define MAX_ARG 32
#define debug(str) fprintf(stderr, str)



	

#endif
