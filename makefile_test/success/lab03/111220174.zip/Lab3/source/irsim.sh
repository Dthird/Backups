python ../irsim/irsim.py
cp ./code.ir ../irsim
