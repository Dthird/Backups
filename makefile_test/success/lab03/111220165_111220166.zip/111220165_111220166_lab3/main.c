#include "tree.h"
//#include "syntax.tab.h"
#include "semantics.h"
#include "intermediate_code.h"
//extern int yydebug;

int main(int argc, char** argv) {
	error_num = 0;
	if(argc <= 1) return 1;
	FILE* fr = fopen(argv[1], "r");
	if(!fr) {
			perror(argv[1]);
			return 1;
	}
	yyrestart(fr);
	//yydebug = 1;	
	yyparse();
	tree_check(tree_root);
//	print_tree(tree_root,0);
	printf("---------------IC-code--------------\n");
	printf("%d error(s)\n", error_num);
	FILE* fw = fopen(argv[2], "w");
	IC_tree(tree_root);
	printIC(ic_list);
	printIC2File(ic_list, fw);
	fclose(fr);
	fclose(fw);
	return 0;
}
