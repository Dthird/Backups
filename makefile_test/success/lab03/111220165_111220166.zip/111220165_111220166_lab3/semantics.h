#ifndef _SEMANTICS_H
#define _SEMANTICS_H
#include <stdio.h>

typedef struct Type_* Type;
typedef struct FieldList_* FieldList;

struct Type_ {
	enum {basic, array, structure} kind;
	union {
		int basic;			
		struct {			
			Type elem;
			int size;
		} array;			
		FieldList structure;	
	} u;
};

struct FieldList_{
	char* name;		
	Type type;		
	FieldList tail;	
};

struct variable{
	char* name;			
	int no;					
	Type type;			
	struct variable* next;	
};

struct function{
	char* name;			
	Type type;			
	FieldList parameter;	
	struct function* next;	
};

struct variable* var_root;	
struct function* func_root;		

void tree_check(struct node *root);
void handle_ExtDecList(struct Type_* type, struct node* ExtDecList);
struct Type_* handle_Specifier(struct node* Specifier);
struct FieldList_* handle_ParamDec(struct FieldList_* parameter, struct node* ParamDec);
void handle_FunDec(struct Type_* type, struct node* FunDec);
void handle_DecList(struct Type_* type, struct node* DecList);
void handle_ExtDefList(struct node* ExtDefList);
void handle_ExtDef(struct node* ExtDef);
void handle_Dec(struct Type_* type, struct node* Dec);
struct FieldList_* handle_VarDec(struct Type_* type, struct node* VarDec, struct FieldList_* parameter, int flag);
struct FieldList_* handle_VarList(struct FieldList_* parameter, struct node* VarList);
void handle_DefList(struct node* DefList);
void handle_Def(struct node* Def);
void handle_StmtList(struct Type_* type, struct node* StmtList, char* id);
void handle_Stmt(struct Type_* type, struct node* Stmt, char* id);
int handle_Exp(struct node* Exp, char* id);
int compare_type(struct Type_* type1, struct Type_* type2);
int check_variable(char* name);
int check_function(char* name);
int check_array(char* name);
int check_assignop(struct node* node);
int check_match(struct node* operator1, struct node* operator2);
int check_assignop_type(struct node* node1, struct node* node2);
int check_function_parameter(struct node* func_node);
int check_function_parameter(struct node* func_node);
int check_integer(struct node* node);
int check_variable_parameter(char* id, struct node* var_id);
struct Type_* check_Exp_type(struct node* Exp);

#endif
