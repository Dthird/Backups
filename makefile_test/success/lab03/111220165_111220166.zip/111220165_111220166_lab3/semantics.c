#include "tree.h"
#include "semantics.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

int variable_no = 1;

void tree_check(struct node* root) {
	if(root == NULL)
		exit(-1);
	struct function* temp_func1 = (struct function*)malloc(sizeof(struct function));
	temp_func1 -> name = "read";
	temp_func1 -> type = (struct Type_*)malloc(sizeof(struct Type_));
	temp_func1 -> type -> kind = basic;
	temp_func1 -> type -> u.basic = 0;
	temp_func1 -> parameter = NULL;
	temp_func1 -> next = func_root;
	func_root = temp_func1;
	struct function* temp_func2 = (struct function*)malloc(sizeof(struct function));
	temp_func2 -> name = "write";
	temp_func2 -> type = (struct Type_*)malloc(sizeof(struct Type_));
	temp_func2 -> type -> kind = basic;
	temp_func2 -> type -> u.basic = 0;
	temp_func2 -> parameter = (struct FieldList_*)malloc(sizeof(struct FieldList_));
	temp_func2 -> parameter -> name = "int";
	temp_func2 -> parameter -> type = (struct Type_*)malloc(sizeof(struct Type_));
	temp_func2 -> parameter -> type -> kind = basic;
	temp_func2 -> parameter -> type -> u.basic = 0;
	temp_func2 -> next = func_root;
	func_root = temp_func2;
	
	struct node* temp;
	if (strcmp(root->content, "Program") == 0) {
		temp = root->child;
		handle_ExtDefList(root->child);
	}		
	else{
		if (root->child != NULL)
			tree_check(root->child);
		if (root->brother != NULL)
			tree_check(root->brother);
	}
}
void handle_ExtDefList(struct node* ExtDefList) {
	if (ExtDefList->child != NULL) {
		handle_ExtDef(ExtDefList->child);
		handle_ExtDefList(ExtDefList->child->brother);
	}
}


void handle_ExtDef(struct node* ExtDef) {
	struct node* temp = ExtDef->child;
	struct Type_* new_type = handle_Specifier(temp);
	if (strcmp(temp->brother->content, "ExtDecList") == 0)
		handle_ExtDecList(new_type, temp->brother);
	else if (strcmp(temp->brother->content, "FunDec") == 0) {
		handle_FunDec(new_type, temp->brother);
		if (strcmp(temp->brother->brother->content, "CompSt") == 0) {
			if (strcmp(temp->brother->brother->child->brother->content, "DefList") == 0) {
				handle_DefList(temp->brother->brother->child->brother);
				handle_StmtList(new_type, temp->brother->brother->child->brother->brother, temp->brother->child->content);
			}
		}
	}
}

void handle_ExtDecList(struct Type_* type, struct node* ExtDecList) {
	struct node* temp_node = ExtDecList->child;
	if (strcmp(temp_node->content, "VarDec") == 0)
		handle_VarDec(type, temp_node, NULL, 0);

	if (temp_node->brother != NULL) {
		temp_node = temp_node->brother;
		if (strcmp(temp_node->content, "COMMA") == 0) {
			temp_node = temp_node->brother;
			handle_ExtDecList(type, temp_node);
		}
	}
}


struct Type_* handle_Specifier(struct node* Specifier) {
	struct Type_* new_type = (struct Type_*)malloc(sizeof(struct Type_));
	if (strcmp(Specifier->type, "type") == 0) {
		if (strcmp(Specifier->child->content, "int") == 0) {
			new_type->kind = 0;
			new_type->u.basic = 0;
		}
		else if (strcmp(Specifier->child->content, "float") == 0) {
			new_type->kind = 0;
			new_type->u.basic = 1;
		}
	}
	return new_type;
}


struct FieldList_* handle_VarDec(struct Type_* type, struct node* VarDec, struct FieldList_* parameter, int flag) {
	struct node* temp_node = VarDec->child;
	if (flag == 0) {
		if (strcmp(temp_node->type, "id") == 0 && temp_node->brother == NULL) {
			struct variable* new_var = (struct variable*)malloc(sizeof(struct variable));
			if (check_variable(temp_node->content) != 0) {
				new_var->name = temp_node->content;
				new_var->no = variable_no++;
				new_var->type = type;
				new_var->next = var_root;
				var_root = new_var;
			}
			else{
				printf("Error type 3 at line %d: redecleared variable '%s'\n", temp_node->lineno, temp_node->content);
				error_num++;
			}
		}
		else {
			printf("Can not translate the code: Contain multidimensional array and function parameters of array type!\n");
			exit(-1);
			}
	}
	else if (flag == 1) {
		if (strcmp(temp_node->type, "id") == 0 && temp_node->brother == NULL) {
			struct variable* new_var = (struct variable*)malloc(sizeof(struct variable));
			if (check_variable(temp_node->content) != 0) {
				new_var->name = temp_node->content;
				new_var->no = variable_no++;
				new_var->type = type;
				new_var->next = var_root;
				var_root = new_var;
			}
			else{
				printf("Error type 3 at line %d: redecleared variable '%s'\n", temp_node->lineno, temp_node->content);
				error_num++;
			}			
			struct FieldList_* new_field = (struct FieldList_*)malloc(sizeof(struct FieldList_));
			new_field->name = temp_node->content;
			new_field->type = type;
			new_field->tail = parameter;
			return new_field;
		}
		else{
			printf("Can not translate the code: Contain multidimensional array and function parameters of array type!\n");
			exit(-1);
			}
	}
	return NULL;
}

void handle_FunDec(struct Type_* type, struct node* FunDec) {
	struct node* temp_node = FunDec->child;
	if (strcmp(temp_node->type, "id") == 0) {
		struct function* new_func = (struct function*)malloc(sizeof(struct function));
		if (check_function(temp_node->content) != 0) {
			new_func->name = temp_node->content;
			new_func->type = type;
			if (strcmp(temp_node->brother->brother->content, "VarList") == 0) {
				new_func->parameter = handle_VarList(new_func->parameter, temp_node->brother->brother);
			}
			new_func->next = func_root;
			func_root = new_func;
		}
		else{
			printf("Error type 4 at line %d: redecleared function '%s'\n", temp_node->lineno, temp_node->content);
			error_num++;
		}
	}
}

struct FieldList_* handle_VarList(struct FieldList_* parameter, struct node* VarList) {
	struct node* temp_node = VarList->child;
	struct FieldList_* new_para = handle_ParamDec(parameter, temp_node);
	if (temp_node->brother == NULL)
		return new_para;
	else
		return  handle_VarList(new_para, temp_node->brother->brother);
}

struct FieldList_* handle_ParamDec(struct FieldList_* parameter, struct node* ParamDec) {
	struct node* temp_node = ParamDec->child;
	struct Type_* new_type = handle_Specifier(temp_node);
	struct FieldList_* new_field = handle_VarDec(new_type, temp_node->brother, parameter, 1);
	return new_field;
}

void handle_StmtList(struct Type_* type, struct node* StmtList, char* id) {
	if (StmtList->child != NULL) {
		struct node* temp_node = StmtList->child;
		handle_Stmt(type, temp_node, id);
		handle_StmtList(type, temp_node->brother, id);
	}
}

void handle_Stmt(struct Type_* type, struct node* Stmt, char* id) {
	if (Stmt->child != NULL) {
		struct node* temp_node = Stmt->child;
		if (strcmp(temp_node->content, "Exp") == 0)
			handle_Exp(temp_node, id);
		else if (strcmp(temp_node->content, "RETURN") == 0) {
			struct Type_* temp_type = check_Exp_type(temp_node->brother);
			/*printf("hhhhhhh\n");
			printf("%d%d\n", type->kind, type->u.basic);
			printf("%d%d\n", temp_type->kind,temp_type->u.basic);
			printf("%d\n", compare_type(type, temp_type));*/
			if (compare_type(type, temp_type) != 0) {
				printf("Error type 8 at line %d: return type unmatch\n", temp_node->lineno);
				error_num++;
			}
		}
		else if (strcmp(temp_node->content, "WHILE") == 0) {
			handle_Exp(temp_node->brother->brother, id);
			handle_Stmt(type, temp_node->brother->brother->brother->brother, id);
		}
		else if (strcmp(temp_node->content, "CompSt") == 0) {
			handle_DefList(temp_node->child->brother);
			handle_StmtList(type, temp_node->child->brother->brother, id);
		}
		else if (strcmp(temp_node->content, "IF") == 0) {
			if (temp_node->brother->brother->brother->brother->brother == NULL) {
				handle_Exp(temp_node->brother->brother, id);
				handle_Stmt(type, temp_node->brother->brother->brother->brother, id);
			}
			else{
				handle_Exp(temp_node->brother->brother, id);
				handle_Stmt(type, temp_node->brother->brother->brother->brother, id);
				handle_Stmt(type, temp_node->brother->brother->brother->brother->brother->brother, id);
			}
		}
	}
}

void handle_DefList(struct node* DefList) {
	if (DefList->child != NULL) {
		struct node* temp_node = DefList->child;
		if (strcmp(temp_node->content, "Def") == 0) {
			handle_Def(temp_node);
			if (temp_node->brother != NULL) {
				temp_node = temp_node->brother;
				handle_DefList(temp_node);
			}
		}
	}
}

void handle_Def(struct node* Def) {
	struct node* temp_node = Def->child;
	struct Type_* type = handle_Specifier(temp_node);
	temp_node = temp_node->brother;
	handle_DecList(type, temp_node);
}

void handle_DecList(struct Type_* type, struct node* DecList) {
	struct node* temp_node = DecList->child;
	handle_Dec(type, temp_node);
	if (temp_node->brother != NULL) {
		temp_node = temp_node->brother;
		temp_node = temp_node->brother;
		handle_DecList(type, temp_node);
	}
}

void handle_Dec(struct Type_* type, struct node* Dec) {
	struct node* temp_node = Dec->child;
	if (strcmp(temp_node->content, "VarDec") == 0)
		handle_VarDec(type, temp_node, NULL, 0);
}

int handle_Exp(struct node* Exp, char* id) {
	if (Exp->child != NULL) {
		struct node* temp_node = Exp->child;
		if (strcmp(temp_node->type, "id") == 0) {
			if (temp_node->brother != NULL) {
				if (check_function(temp_node->content) != 0) {
					if (check_variable(temp_node->content) == 0) {
						printf("Error type 11 at line %d: variable can not use '()'\n", temp_node->lineno);
						error_num++;
						return -1;
					}
					else{
						printf("Error type 2 at line %d: undecleared function '%s'\n", temp_node->lineno, temp_node->content);
						error_num++;
						return -1;
					}
				}
				else if (check_function_parameter(temp_node) != 0 ) {
					printf("Error type 9 at line %d: function parameter error\n", temp_node->lineno);
					error_num++;
					return -1;
				}
			}
			else{
				if (check_variable(temp_node->content) != 0) {
					if (check_variable_parameter(id, temp_node) != 0) {
						printf("Error type 1 at line %d: undecleared variable '%s'\n", temp_node->lineno, temp_node->content);
						error_num++;
						return -1;
					}
				}
			}
		}
		else if (temp_node->brother != NULL && strcmp(temp_node->brother->content, "LB") == 0) {
			if (strcmp(temp_node->child->type, "id") == 0) {
				if (check_array(temp_node->child->content) != 0) {
					printf("Error type 10 at line %d: '%s' is not array\n", temp_node->child->lineno, temp_node->child->content);
					error_num++;
					return -1;
				}
			}
			if (check_integer(temp_node->brother->brother->child) != 0) {
				printf("Error type 12 at line %d: array size is not an integer\n", temp_node->brother->brother->lineno);
				error_num++;
				return -1;
			}
			
			handle_Exp(temp_node, id);		
		}
		else if (temp_node->brother != NULL && strcmp(temp_node->brother->content, "ASSIGNOP") == 0) {
			int i = handle_Exp(temp_node, id);
			int j = handle_Exp(temp_node->brother->brother, id);
			if (i == 0 && j == 0) {
				if (check_assignop(temp_node) != 0) {
					printf("Error type 6 at line %d: assignop expression error\n", temp_node->lineno);
					error_num++;
					return -1;
				}
				else if (check_assignop_type(temp_node, temp_node->brother->brother) == -1) {
					printf("Error type 5 at line %d: assignop type unmatch\n", temp_node->lineno);
					error_num++;
					return -1;
				}
			}
		}
		else if (temp_node->brother != NULL && (strcmp(temp_node->brother->content, "PLUS") == 0 || strcmp(temp_node->brother->content, "MINUS") == 0)) {
			if (check_match(temp_node, temp_node->brother->brother) == -1) {
				printf("Error type 7 at line %d: operator type unmatch\n", temp_node->lineno);
				error_num++;
				return -1;
			}
			handle_Exp(temp_node, id);
			handle_Exp(temp_node->brother->brother, id);
		}
		else if (temp_node->brother != NULL && strcmp(temp_node->brother->content, "DOT") == 0) {
			handle_Exp(temp_node, id);
		}
		return 0;
	}
	return -1;
}

struct Type_* check_Exp_type(struct node* Exp) {
	struct Type_* type = (struct Type_*)malloc(sizeof(struct Type_));
	if (Exp->child != NULL) {
		struct node* temp_node = Exp->child;
		if (strcmp(temp_node->type, "int") == 0) {
			type->kind = 0;
			type->u.basic = 0;
		}
		else if (strcmp(temp_node->type, "float") == 0) {
			type->kind = 0;
			type->u.basic = 1;
		}
		return type;
	}
	else
		return NULL;
}

int check_assignop_type(struct node* node1, struct node* node2) {
	struct variable* pointer = var_root;
	struct function* func_pointer = func_root;
	struct node* temp_node1 = node1;
	struct node* temp_node2 = node2;
	struct Type_* type1;
	struct Type_* type2;
	while (strcmp(temp_node1->type, "id") != 0) {
		if (temp_node1->child == NULL)
			return -2;
		else
			temp_node1 = temp_node1->child;
	}
	while (pointer != NULL) {
		if (strcmp(temp_node1->content, pointer->name) == 0) {
			type1 = pointer->type;
			break;
		}
		pointer = pointer->next;
	}
	if (pointer == NULL)
		return -2;
	while (temp_node1->parent->brother != NULL) {
		if (strcmp(temp_node1->parent->brother->content, "LB") == 0) {
			type1 = type1->u.array.elem;
			temp_node1 = temp_node1->parent;
		}
		else
			break;
	}
	
	if (strcmp(node2->child->content, "int") == 0) {
	//	printf("int\n");
		type2->kind = 0;
		type2->u.basic = 0;
	}
	else if (strcmp(node2->child->content, "float") == 0) {
		//printf("float\n");		
		type2->kind = 0;
		type2->u.basic = 1;
	}
	else {
		while (strcmp(temp_node2->type, "id") != 0) {
			if (temp_node2->child == NULL)
				return -2;
			else
				temp_node2 = temp_node2->child;
		}
		pointer = var_root;
		while (pointer != NULL) {
			if (strcmp(temp_node2->content, pointer->name) == 0) {
				type2 = pointer->type;
				break;
			}
			pointer = pointer->next;
		}

		if (pointer == NULL) {
			while (func_pointer != NULL) {
				if (strcmp(func_pointer->name, temp_node2->content) == 0) {
					type2 = func_pointer->type;
					break;
				}
				func_pointer = func_pointer->next;
			}
		}

		if (func_pointer == NULL)
			return -2;
	
		while (temp_node2->parent->brother != NULL) {
			if(strcmp(temp_node2->parent->brother->content, "LB") == 0) {
				type2 = type2->u.array.elem;
				temp_node2 = temp_node2->parent;
			}
			else
				break;
		}
	}

	while (type1 != NULL && type2 != NULL) {
		if (type1->kind == 0 && type2->kind == 0)
			return 0;
		else if ((type1->kind == 0 && type2->kind == 1) || (type1->kind == 1 && type2->kind == 0))
			return -1;
		else if (type1->kind == 1 && type2->kind == 1) {
			if (type1->u.array.size == type2->u.array.size) {
				type1 = type1->u.array.elem;
				type2 = type2->u.array.elem;
			}
			else
				return -1;
		}
	}
	if (type1 == NULL && type2 == NULL)
		return 0;
	else
		return -1;
}

int check_variable_parameter(char* id, struct node* var_id) {
	struct function* pointer = func_root;
	struct FieldList_* parameter;
	while (pointer != NULL) {
		if (strcmp(pointer->name, id) == 0)
			parameter = pointer->parameter;
		pointer = pointer->next;
	}
	while (parameter != NULL) {
		if (strcmp(parameter->name, var_id->content) == 0)
			return 0;
		parameter = parameter->tail;
	}
	return -1;
}

int check_function_parameter(struct node* func_node) {
	struct function* pointer = func_root;
	struct variable* var_pointer = var_root;
	struct node* func_args = func_node->brother->brother;//Exp
	struct node* temp_node;
	struct FieldList_* parameter;
	struct Type_* temp_type;
	while (pointer != NULL) {
		if (strcmp(pointer->name, func_node->content) == 0) {
			parameter = pointer->parameter;
			break;
		}
		pointer = pointer->next;
	}
	if (pointer == NULL)
		return -2;
	if (strcmp(func_args->content, "RP") == 0) {
		if (parameter != NULL) {
			return -1;
		}
	}
	else{
		temp_node = func_args->child;
		func_args = temp_node;
	}
	while (parameter != NULL) {
		while (temp_node->child != NULL) {
			temp_node = temp_node->child;
			if (strcmp(temp_node->type, "id") == 0) {
				while (var_pointer != NULL) {
					if (strcmp(temp_node->content, var_pointer->name) == 0) {
						if (compare_type(var_pointer->type, parameter->type) != 0) {
							return -1;
						}
						else
							break;
					}
					var_pointer = var_pointer->next;
				}
				var_pointer = var_root;
			}
			else if (strcmp(temp_node->type, "int") == 0) {
				temp_type->kind = 0;
				temp_type->u.basic = 0;
				if (compare_type(temp_type, parameter->type) != 0)
					return -1;
			}
			else if (strcmp(temp_node->type, "float") == 0) {
				temp_type->kind = 0;
				temp_type->u.basic = 1;
				if (compare_type(temp_type, parameter->type) != 0)
					return -1;
			}
		}
		if (func_args->brother != NULL) {
			temp_node = func_args->brother->brother->child;
			func_args = temp_node;
		}
		else if (parameter->tail != NULL)
			return -1;
		parameter = parameter->tail;
	}
	if (func_args->brother != NULL)
		return -1;
	return 0;
}

int check_match(struct node* operator1, struct node* operator2) {
	struct variable* pointer = var_root;
	int kind1 = -1, kind2 = -1;
	while (strcmp(operator1 ->type, "id") != 0) {
		if (operator1->child == NULL)
			return -2;
		else
			operator1 = operator1->child;
	}
	while (strcmp(operator2 ->type, "id") != 0) {
		if (operator2->child == NULL)
			return -2;
		else
			operator2 = operator2->child;
	}
	while (pointer != NULL) {
		if (strcmp(operator1->content, pointer->name) == 0)
			kind1 = pointer->type->kind;
		if (strcmp(operator2->content, pointer->name) == 0)
			kind2 = pointer->type->kind;
		pointer = pointer->next;
	}
	if (kind1 == kind2)
		return 0;
	else
		return -1;
}

int check_assignop(struct node* node) {
	if (node->child != NULL) {
		struct node* temp_node = node->child;
		if (strcmp(temp_node->type, "id") == 0 && temp_node->brother == NULL)
			return 0;
		else if (strcmp(temp_node->content, "Exp") == 0 && strcmp(temp_node->brother->content, "LB") == 0 && strcmp(temp_node->brother->brother->content, "Exp") == 0 && strcmp(temp_node->brother->brother->brother->content, "RB") == 0)
			return 0;
		else if (strcmp(temp_node->content, "Exp") == 0 && strcmp(temp_node->brother->content, "DOT") == 0 && strcmp(temp_node->brother->brother->type, "id") == 0)
			return 0;
		return -1;
	}
}

int check_array(char* name) {
	struct variable* pointer = var_root;
	while (pointer != NULL) {
		if (strcmp(pointer->name, name) == 0) {
			if (pointer->type->kind != 1)
				return -1;
			
		}
		pointer = pointer->next;
	}
	return 0;
}

int compare_type(struct Type_* type1, struct Type_* type2) {
	int flag;
	/*printf("%d1\n", type1->kind);
	printf("%d2\n", type2->kind);
	printf("%d1\n", type1->u.basic);
	printf("%d2\n", type2->u.basic);*/
	if (type1->kind != type2->kind) {
		return -1;
	}
	else if (type1->kind == 0) {
		if (type1->u.basic != type2->u.basic)
			return -1;
		else
			return 0;
	}
	else if (type1->kind == 1) {
		if (type1->u.array.size != type2->u.array.size)
			return -1;
		else
			flag = compare_type(type1->u.array.elem, type2->u.array.elem);
	}
	else{
		if (strcmp(type1->u.structure->name, type2->u.structure->name) != 0)
			return -1;
		else
			flag = compare_type(type1->u.structure->type, type2->u.structure->type);
	}
	return flag;
}

int check_variable(char* name) {
	struct variable* pointer = var_root;
	while(pointer != NULL) {
		if (strcmp(pointer->name, name) == 0)
			return 0;
		pointer = pointer->next;
	}
	return -1;
}

int check_integer(struct node* node) {
	if (strcmp(node->content, "int") == 0)
		return 0;
	else if (strcmp(node->type, "id") == 0) {
		struct variable* pointer = var_root;
		while (pointer != NULL) {
			if (strcmp(pointer->name, node->content) == 0) {
				if (pointer->type->kind == 0 && pointer->type->u.basic == 0)
					return 0;
				else
					return -1;
			}
			pointer = pointer->next;
		}
		if (pointer == NULL)
			return -2;
	}
	else if (strcmp(node->content, "Exp") == 0)
		check_integer(node->child);
	return -1;
}

int check_function(char* name) {
	struct function* pointer = func_root;
	while (pointer != NULL) {
		if (strcmp(pointer->name, name) == 0)
			return 0;
		pointer = pointer->next;
	}
	return -1;
}
