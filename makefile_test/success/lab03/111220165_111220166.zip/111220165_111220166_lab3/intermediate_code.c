#include "intermediate_code.h"

int temp_no = 0;
int new_temp() {
	temp_no++;
	return temp_no;
}

int label_no = 0;
int new_label() {
	label_no++;
	return label_no;
}
void kind_no(enum FieldKind kind,int no,char* str,int function,struct ICNode*ic_node){
	if(kind==0|| kind==2){//VARIABLE=0,ADDRESS=2
		if(function==0)//target
			ic_node->ic.target.content.variable_no=no;
		else if(function==1)//arg1
			ic_node->ic.arg1.content.variable_no=no;
		else//arg2
			ic_node->ic.arg2.content.variable_no=no;
	}
	else if(kind==1 || kind==3){//TEMP=1,POINTER=3
		if(function==0)//target
			ic_node->ic.target.content.temp_no=no;
		else if(function==1)//arg1
			ic_node->ic.arg1.content.temp_no=no;
		else//arg2
			ic_node->ic.arg2.content.temp_no=no;
	}
	else if(kind==4){//CONSTANT=4
		if(function==0)//target
			ic_node->ic.target.content.constant_value=no;
		else if(function==1)//arg1
			ic_node->ic.arg1.content.constant_value=no;
		else//arg2
			ic_node->ic.arg2.content.constant_value=no;
	}
	else if (kind==5){//IDNAME=5
		if(function==0)//target
			ic_node->ic.target.content.id_name=str;
		else if(function==1)//arg1
			ic_node->ic.arg1.content.id_name=str;
		else//arg2
			ic_node->ic.arg2.content.id_name=str;
	}
}
struct ICNode* genIC(enum ICKind kind, enum FieldKind target_kind, int target_i, char* target_s, enum FieldKind arg1_kind, int arg1_i, char* arg1_s,
		enum FieldKind arg2_kind, int arg2_i, char* arg2_s, char* op) {
	struct ICNode* ic_node = (struct ICNode*)malloc(sizeof(struct ICNode));
	ic_node->ic.kind = kind;
	ic_node->ic.target.kind = target_kind;
	kind_no(target_kind,target_i,target_s,0,ic_node);
	ic_node->ic.arg1.kind = arg1_kind;
	kind_no(arg1_kind,arg1_i,arg1_s,1,ic_node);
	ic_node->ic.arg2.kind = arg2_kind;
	kind_no(arg2_kind,arg2_i,arg2_s,2,ic_node);
	ic_node->ic.op = op;
	ic_node->prev = NULL;
	ic_node->next = NULL;
	return ic_node;	
}

void insertList(struct ICNode* ic_node) {
	if(!ic_list)
		ic_list = ic_node;
	else {
		struct ICNode* temp = ic_list;
		while(temp->next != NULL)
			temp = temp->next;
		temp->next = ic_node;
		ic_node->prev = temp;
	}
}
void print_arg(struct Field arg,char *a){
	if(a==NULL){
	switch(arg.kind){
		case VARIABLE:	
			printf(" v%d ", arg.content.variable_no);
			break;
		case CONSTANT:
			printf(" #%d ", arg.content.constant_value);
			break;
		case TEMP: 
			printf(" t%d ", arg.content.temp_no);
			break;
		case ADDRESS:
			printf(" &v%d ", arg.content.variable_no);
			break;
		case POINTER: 
			printf(" *t%d ", arg.content.temp_no);
			break;	
		}
	}
	else{
		switch(arg.kind){
		case VARIABLE:	
			printf("%s v%d\n", a,arg.content.variable_no);
			break;
		case CONSTANT:
			printf("%s #%d\n", a,arg.content.constant_value);
			break;
		case TEMP: 
			printf("%s t%d\n", a,arg.content.temp_no);
			break;
		case ADDRESS:
			printf("%s &v%d\n", a,arg.content.variable_no);
			break;
		case POINTER: 
			printf("%s *t%d\n", a,arg.content.temp_no);
			break;	
		}

		}
}
void print_arg_file(struct Field arg,char *a,FILE* f){
	if(a==NULL){
	switch(arg.kind){
		case VARIABLE:	
			fprintf(f," v%d ", arg.content.variable_no);
			break;
		case CONSTANT:
			fprintf(f," #%d ", arg.content.constant_value);
			break;
		case TEMP: 
			fprintf(f," t%d ", arg.content.temp_no);
			break;
		case ADDRESS:
			fprintf(f," &v%d ", arg.content.variable_no);
			break;
		case POINTER: 
			fprintf(f," *t%d ", arg.content.temp_no);
			break;	
		}
	}
	else{
		switch(arg.kind){
		case VARIABLE:	
			fprintf(f,"%s v%d\n", a,arg.content.variable_no);
			break;
		case CONSTANT:
			fprintf(f,"%s #%d\n", a,arg.content.constant_value);
			break;
		case TEMP: 
			fprintf(f,"%s t%d\n", a,arg.content.temp_no);
			break;
		case ADDRESS:
			fprintf(f,"%s &v%d\n", a,arg.content.variable_no);
			break;
		case POINTER: 
			fprintf(f,"%s *t%d\n", a,arg.content.temp_no);
			break;	
		}

		}
}

void printIC(struct ICNode* ic_list) {
	struct ICNode* head = ic_list;
	while(head != NULL) {
		switch(head->ic.kind){
			case LABEL://LABLE
				printf("LABEL label%d :\n", head->ic.arg1.content.constant_value);
				break;
			case FUNCTION://FUNCTION
				printf("FUNCTION %s :\n", head->ic.arg1.content.id_name);
				break;
			case ASSIGN://ASSIGN
				if(head->ic.arg1.kind==VARIABLE){
					if(head->ic.arg2.kind==CONSTANT)
						printf("v%d := #%d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.constant_value);
					else if(head->ic.arg2.kind==TEMP)
						printf("v%d := t%d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.temp_no);
					else if(head->ic.arg2.kind == ADDRESS)
						printf("v%d := &v%d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.variable_no);
					else if(head->ic.arg2.kind == POINTER)
						printf("v%d := *t%d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.temp_no);
					}
				else if(head->ic.arg1.kind == IDNAME && head->ic.arg2.kind == TEMP)
					printf("%s := t%d\n", head->ic.arg1.content.id_name, head->ic.arg2.content.temp_no);	
				else if(head->ic.arg1.kind==TEMP){
					if(head->ic.arg2.kind == VARIABLE)
						printf("t%d := v%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.variable_no);
					else if(head->ic.arg2.kind == CONSTANT)
						printf("t%d := #%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.constant_value);
					else if(head->ic.arg2.kind == IDNAME)
						printf("t%d := %s\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.id_name);
					else if(head->ic.arg2.kind == TEMP)
						printf("t%d := t%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.temp_no);
					else if(head->ic.arg2.kind == ADDRESS)
						printf("t%d := &v%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.variable_no);
					else if(head->ic.arg2.kind == POINTER)
						printf("t%d := *t%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.temp_no);
				}
				else if(head->ic.arg1.kind==POINTER){
					if(head->ic.arg2.kind == CONSTANT)
						printf("*t%d := #%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.constant_value);
					else if(head->ic.arg2.kind == TEMP)
						printf("*t%d := t%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.temp_no);
					else if(head->ic.arg2.kind == POINTER)
						printf("*t%d := *t%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.temp_no);
				}
				break;
			case ADD:
			case SUB:
			case MUL:
			case DIV:
			//ADD\SUB\MUL\DIV
				//target
				if(head->ic.target.kind == VARIABLE)
					printf("v%d :=", head->ic.target.content.variable_no);
				if(head->ic.target.kind == TEMP)
					printf("t%d :=", head->ic.target.content.temp_no);
				if(head->ic.target.kind == POINTER) 
					printf("*t%d :=",head->ic.target.content.temp_no);
				//arg1
				print_arg(head->ic.arg1,NULL);
				//op
				if(head->ic.kind == ADD)
					printf("+");
				if(head->ic.kind == SUB)
					printf("-");
				if(head->ic.kind == MUL)
					printf("*");
				if(head->ic.kind == DIV)
					printf("/");
				//arg2
				print_arg(head->ic.arg2,NULL);
				printf("\n");
				break;
			case GOTO://GOTO
				printf("GOTO label%d\n", head->ic.arg1.content.constant_value);
				break;
			case IF://IF
				printf("IF");
				//arg1 op
				if(head->ic.arg1.kind == VARIABLE)
					printf(" v%d %s", head->ic.arg1.content.variable_no, head->ic.op);
				if(head->ic.arg1.kind == CONSTANT)
					printf(" #%d %s", head->ic.arg1.content.constant_value, head->ic.op);
				if(head->ic.arg1.kind == TEMP)
					printf(" t%d %s", head->ic.arg1.content.temp_no, head->ic.op);
				if(head->ic.arg1.kind == ADDRESS)
					printf(" &v%d %s", head->ic.arg1.content.variable_no, head->ic.op);
				if(head->ic.arg1.kind == POINTER)
					printf(" *t%d %s", head->ic.arg1.content.temp_no, head->ic.op);

			//arg2
				print_arg(head->ic.arg2,NULL);
				printf(" GOTO label%d\n",head->ic.target.content.constant_value);
				break;
			case RETURN://RETURN
				print_arg(head->ic.arg1,"RETURN");
				break;
			case DEC://DEC
				printf("DEC v%d %d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.constant_value);
				break;
			case ARG://ARG
				print_arg(head->ic.arg1,"ARG");	
				break;
			case CALL://CALL
				if(head->ic.arg1.kind == E)
					printf("CALL %s\n", head->ic.arg2.content.id_name);
				else
					printf("t%d := CALL %s\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.id_name);
				break;
			case PARAM://PARAM	
				print_arg(head->ic.arg1,"PARAM");
				break;
			case READ://READ
				printf("READ t%d\n", head->ic.arg1.content.temp_no);
				break;
			case WRITE://WRITE
				print_arg(head->ic.arg1,"WRITE");
				break;
		}
		head = head->next;
	}
}

void printIC2File(struct ICNode* ic_list, FILE* f) {	
		struct ICNode* head = ic_list;
	while(head != NULL) {
		switch(head->ic.kind){
			case LABEL://LABLE
				fprintf(f,"LABEL label%d :\n", head->ic.arg1.content.constant_value);
				break;
			case FUNCTION://FUNCTION
				fprintf(f,"FUNCTION %s :\n", head->ic.arg1.content.id_name);
				break;
			case ASSIGN://ASSIGN
				if(head->ic.arg1.kind==VARIABLE){
					if(head->ic.arg2.kind==CONSTANT)
						fprintf(f,"v%d := #%d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.constant_value);
					else if(head->ic.arg2.kind==TEMP)
						fprintf(f,"v%d := t%d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.temp_no);
					else if(head->ic.arg2.kind == ADDRESS)
						fprintf(f,"v%d := &v%d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.variable_no);
					else if(head->ic.arg2.kind == POINTER)
						fprintf(f,"v%d := *t%d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.temp_no);
					}
				else if(head->ic.arg1.kind == IDNAME && head->ic.arg2.kind == TEMP)
					fprintf(f,"%s := t%d\n", head->ic.arg1.content.id_name, head->ic.arg2.content.temp_no);	
				else if(head->ic.arg1.kind==TEMP){
					if(head->ic.arg2.kind == VARIABLE)
						fprintf(f,"t%d := v%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.variable_no);
					else if(head->ic.arg2.kind == CONSTANT)
						fprintf(f,"t%d := #%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.constant_value);
					else if(head->ic.arg2.kind == IDNAME)
						fprintf(f,"t%d := %s\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.id_name);
					else if(head->ic.arg2.kind == TEMP)
						fprintf(f,"t%d := t%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.temp_no);
					else if(head->ic.arg2.kind == ADDRESS)
						fprintf(f,"t%d := &v%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.variable_no);
					else if(head->ic.arg2.kind == POINTER)
						fprintf(f,"t%d := *t%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.temp_no);
				}
				else if(head->ic.arg1.kind==POINTER){
					if(head->ic.arg2.kind == CONSTANT)
						fprintf(f,"*t%d := #%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.constant_value);
					else if(head->ic.arg2.kind == TEMP)
						fprintf(f,"*t%d := t%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.temp_no);
					else if(head->ic.arg2.kind == POINTER)
						fprintf(f,"*t%d := *t%d\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.temp_no);
				}
				break;
			case ADD:
			case SUB:
			case MUL:
			case DIV:
			//ADD\SUB\MUL\DIV
				//target
				if(head->ic.target.kind == VARIABLE)
					fprintf(f,"v%d :=", head->ic.target.content.variable_no);
				if(head->ic.target.kind == TEMP)
					fprintf(f,"t%d :=", head->ic.target.content.temp_no);
				if(head->ic.target.kind == POINTER) 
					fprintf(f,"*t%d :=",head->ic.target.content.temp_no);
				//arg1
				print_arg_file(head->ic.arg1,NULL,f);
				//op
				if(head->ic.kind == ADD)
					fprintf(f,"+");
				if(head->ic.kind == SUB)
					fprintf(f,"-");
				if(head->ic.kind == MUL)
					fprintf(f,"*");
				if(head->ic.kind == DIV)
					fprintf(f,"/");
				//arg2
				print_arg_file(head->ic.arg2,NULL,f);
				fprintf(f,"\n");
				break;
			case GOTO://GOTO
				fprintf(f,"GOTO label%d\n", head->ic.arg1.content.constant_value);
				break;
			case IF://IF
				fprintf(f,"IF");
				//arg1 op
				if(head->ic.arg1.kind == VARIABLE)
					fprintf(f," v%d %s", head->ic.arg1.content.variable_no, head->ic.op);
				if(head->ic.arg1.kind == CONSTANT)
					fprintf(f," #%d %s", head->ic.arg1.content.constant_value, head->ic.op);
				if(head->ic.arg1.kind == TEMP)
					fprintf(f," t%d %s", head->ic.arg1.content.temp_no, head->ic.op);
				if(head->ic.arg1.kind == ADDRESS)
					fprintf(f," &v%d %s", head->ic.arg1.content.variable_no, head->ic.op);
				if(head->ic.arg1.kind == POINTER)
					fprintf(f," *t%d %s", head->ic.arg1.content.temp_no, head->ic.op);

			//arg2
				print_arg_file(head->ic.arg2,NULL,f);
				fprintf(f," GOTO label%d\n",head->ic.target.content.constant_value);
				break;
			case RETURN://RETURN
				print_arg_file(head->ic.arg1,"RETURN",f);
				break;
			case DEC://DEC
				fprintf(f,"DEC v%d %d\n", head->ic.arg1.content.variable_no, head->ic.arg2.content.constant_value);
				break;
			case ARG://ARG
				print_arg_file(head->ic.arg1,"ARG",f);	
				break;
			case CALL://CALL
				if(head->ic.arg1.kind == E)
					fprintf(f,"CALL %s\n", head->ic.arg2.content.id_name);
				else
					fprintf(f,"t%d := CALL %s\n", head->ic.arg1.content.temp_no, head->ic.arg2.content.id_name);
				break;
			case PARAM://PARAM	
				print_arg_file(head->ic.arg1,"PARAM",f);
				break;
			case READ://READ
				fprintf(f,"READ t%d\n", head->ic.arg1.content.temp_no);
				break;
			case WRITE://WRITE
				print_arg_file(head->ic.arg1,"WRITE",f);
				break;
		}
		head = head->next;
	}

}

int lookup_var(char* var_name) {
	struct variable* temp = var_root;
	while(temp != NULL) {
		if(strcmp(temp->name, var_name) == 0)
			return temp->no;
		temp = temp->next;
	}
	printf("Can't find the variable!\n");
	return -1;
}
struct ICNode* connect(struct ICNode* code1,struct ICNode* code2){
	struct ICNode* temp=code1;
	while(temp->next)
		temp=temp->next;
	temp->next=code2;
	code2->prev=temp;
	return code1;
	}
void IC_tree(struct node* tree_root) {
	if(!tree_root) {
		printf("Error: The tree is empty!\n");
		exit(-1);
	}
	if(strcmp(tree_root->content, "Program") == 0)
		ic_list = IC_ExtDefList(tree_root->child);
}

struct ICNode* IC_ExtDefList(struct node* ExtDefList) {
	if(ExtDefList->child != NULL) {	
		struct node* ExtDef = ExtDefList->child;
		struct node* ExtDefList_1 = ExtDef->brother;		
		struct ICNode* code1 = IC_ExtDef(ExtDef);
		struct ICNode* code2 = IC_ExtDefList(ExtDefList_1);
		return connect(code1,code2);
	}
	else	
		return genIC(EMPTY, E, -1, NULL, E, -1, NULL, E, -1, NULL, NULL);
}

struct ICNode* IC_ExtDef(struct node* ExtDef) {
	struct node* c2 = ExtDef->child->brother;
	if(strcmp(c2->content, "ExtDecList") == 0) {
		struct node* ExtDecList = c2;
		return IC_ExtDecList(ExtDecList);
	}
	else if(strcmp(c2->content, "FunDec") == 0) {
		struct node* FunDec = c2;
		struct node* CompSt = FunDec->brother;
		struct ICNode* code1 = IC_FunDec(FunDec);
		struct ICNode* code2 = IC_CompSt(CompSt);	
		return connect(code1,code2);
	}	
	else {
		exit(-1);

	}
}
struct ICNode* IC_ExtDecList(struct node* ExtDecList) {
	struct node* VarDec = ExtDecList->child;
	if(VarDec->brother == NULL)	
		return IC_VarDec(VarDec);
	else {	
		struct node* ExtDecList_1 = VarDec->brother->brother;
		struct ICNode* code1 = IC_VarDec(VarDec);
		struct ICNode* code2 = IC_ExtDecList(ExtDecList_1);
		return connect(code1,code2);
	}
}
/*

   struct ICNode* IC_Specifier(struct node* Specifier){
   struct ICNode* code;
   if(strcmp(Specifier->type,"StructSpecifier")==0){
   printf("[2]ICNode at line %d:'%s'\n",Specifier->child->lineno,Specifier->child->content);
   return IC_SpecifierStruct(Specifier->child);
   }
   else{
   return genIC(EMPTY,E,-1,NULL,E,-1,NULL,E,-1,NULL,NULL);	
   }
   }
   struct ICNode* IC_SpecifierStruct(struct node* SpecifierStruct){
   struct node* temp_node=SpecifierStruct->child->brother;
   if(temp_node->brother!=NULL){
   new_type->u.structure=manage_DefList(temp_node->brother->brother);
   return new_type;
   }
   printf("here\n");

   }*/
struct ICNode* IC_VarDec(struct node* VarDec) {
	struct node* c = VarDec->child;
	if(strcmp(c->content, "VarDec") == 0) {	
			printf("Can not translate the code: Contain multidimensional array and function parameters of array type!\n");
			exit(-1);
		}
	else
		return genIC(EMPTY, E, -1, NULL, E, -1, NULL, E, -1, NULL, NULL);
}

struct ICNode* IC_FunDec(struct node* FunDec) {
	struct node* ID = FunDec->child;
	struct node* c3 = FunDec->child->brother->brother;
	if(c3->brother == NULL)
		return genIC(FUNCTION, E, -1, NULL, IDNAME, -1, ID->content, E, -1, NULL, NULL);
	else {	
		struct node* VarList = c3;
		struct ICNode* code1 = genIC(FUNCTION, E, -1, NULL, IDNAME, -1, ID->content, E, -1, NULL, NULL);
		struct ICNode* code2 = IC_VarList(VarList);
		code1->next = code2;
		code2->prev = code1;
		return code1;
	}
}

struct ICNode* IC_VarList(struct node* VarList) {
	struct node* ParamDec = VarList->child;
	if(ParamDec->brother == NULL)
		return IC_ParamDec(ParamDec);		
	else {	
		struct node* VarList_1 = ParamDec->brother->brother;
		struct ICNode* code1 = IC_ParamDec(ParamDec);
		struct ICNode* code2 = IC_VarList(VarList_1);
		return connect(code1,code2);
	}
}

struct ICNode* IC_ParamDec(struct node* ParamDec) {
	struct node* VarDec = ParamDec->child->brother;
	if(strcmp(VarDec->child->content, "VarDec") == 0) {	
		printf("Can not translate the code: Contain function parameters of array type!\n");
		exit(-1);
	}
	else {	
		struct node* ID = VarDec->child;
		return genIC(PARAM, E, -1, NULL, VARIABLE, lookup_var(ID->content), NULL, E, -1, NULL, NULL);
	}
}

struct ICNode* IC_CompSt(struct node* CompSt) {
	struct node* DefList = CompSt->child->brother;
	struct node* StmtList = DefList->brother;
	struct ICNode* code1 = IC_DefList(DefList);
	struct ICNode* code2 = IC_StmtList(StmtList);	
	return connect(code1,code2);
}

struct ICNode* IC_StmtList(struct node* StmtList) {
	if(StmtList->child != NULL) {	
		struct node* Stmt = StmtList->child;
		struct node* StmtList_1 = Stmt->brother;
		struct ICNode* code1 = IC_Stmt(Stmt);
		struct ICNode* code2 = IC_StmtList(StmtList_1);
		return connect(code1,code2);
	}
	else	
		return genIC(EMPTY, E, -1, NULL, E, -1, NULL, E, -1, NULL, NULL);
}

struct ICNode* IC_Stmt(struct node* Stmt) {
	struct node* c = Stmt->child;
	if(strcmp(c->content, "Exp") == 0) {	
		struct node* Exp = c;
		return IC_Exp(Exp, 0);
	}
	else if(strcmp(c->content, "CompSt") == 0) {
		struct node* CompSt = c;
		return IC_CompSt(CompSt);
	}
	else if(strcmp(c->content, "RETURN") == 0) {	
		struct node* Exp = c->brother;
		int t1 = new_temp();
		struct ICNode* code1 = IC_Exp(Exp, t1);
		struct ICNode* code2 = genIC(RETURN, E, -1, NULL, TEMP, t1, NULL, E, -1, NULL, NULL);
		return connect(code1,code2);
	}
	else if(strcmp(c->content, "WHILE") == 0) { 
		struct node* Exp = c->brother->brother;
		struct node* Stmt_1 = Exp->brother->brother;
		int label1 = new_label();
		int label2 = new_label();
		int label3 = new_label();
		struct ICNode* code1 = IC_Cond(Exp, label2, label3);
		struct ICNode* code2 = IC_Stmt(Stmt_1);
		struct ICNode* label_1 = genIC(LABEL, E, -1, NULL, CONSTANT, label1, NULL, E, -1, NULL, "");
		struct ICNode* label_2 = genIC(LABEL, E, -1, NULL, CONSTANT, label2, NULL, E, -1, NULL, "");
		struct ICNode* label_3 = genIC(LABEL, E, -1, NULL, CONSTANT, label3, NULL, E, -1, NULL, "");
		struct ICNode* go_to = genIC(GOTO, E, -1, NULL, CONSTANT, label1, NULL, E, -1, NULL, "");
		//label_1 + code1 + label_2 + code2 + go_to + label_3
		label_1->next = code1;
		code1->prev = label_1;
		connect(code1,label_2);
		label_2->next = code2;
		code2->prev = label_2;
		connect(code2,go_to);
		go_to->next = label_3;
		label_3->prev = go_to; 	
		return label_1;
	}
	else if(strcmp(c->content, "IF") == 0) {
		struct node* Exp = c->brother->brother;
		struct node* Stmt_1 = Exp->brother->brother;
		if(Stmt_1->brother == NULL)	{		
			int label1 = new_label();
			int label2 = new_label();
			struct ICNode* code1 = IC_Cond(Exp, label1, label2);
			struct ICNode* code2 = IC_Stmt(Stmt_1);
			struct ICNode* label_1 = genIC(LABEL, E, -1, NULL, CONSTANT, label1, NULL, E, -1, NULL, NULL);
			struct ICNode* label_2 = genIC(LABEL, E, -1, NULL, CONSTANT, label2, NULL, E, -1, NULL, NULL);
			//code1 + label_1 + code2 + label_2
			connect(code1,label_1);
			label_1->next = code2;
			code2->prev = label_1;
			connect(code2,label_2);
			return code1;
		}
		else {
			struct node* Stmt_2 = Stmt_1->brother->brother;
			int label1 = new_label();
			int label2 = new_label();
			int label3 = new_label();
			struct ICNode* code1 = IC_Cond(Exp, label1, label2);
			struct ICNode* code2 = IC_Stmt(Stmt_1);
			struct ICNode* code3 = IC_Stmt(Stmt_2);
			struct ICNode* label_1 =  genIC(LABEL, E, -1, NULL, CONSTANT, label1, NULL, E, -1, NULL, NULL);
			struct ICNode* label_2 =  genIC(LABEL, E, -1, NULL, CONSTANT, label2, NULL, E, -1, NULL, NULL);
			struct ICNode* label_3 =  genIC(LABEL, E, -1, NULL, CONSTANT, label3, NULL, E, -1, NULL, NULL);
			struct ICNode* go_to =  genIC(GOTO, E, -1, NULL, CONSTANT, label3, NULL, E, -1, NULL, NULL);
			//code1 + label_1 + code2 + go_to + label_2 + code3 + label_3
			connect(code1,label_1);
			label_1->next = code2;
			code2->prev = label_1;
			connect(code2,go_to);
			go_to->next = label_2;
			label_2->prev = go_to;
			label_2->next = code3;
			code3->prev = label_2;
			connect(code3,label_3);
			return code1;				
		}
	}
}

struct ICNode* IC_DefList(struct node* DefList) {
	if(DefList->child != NULL) {	
		struct node* Def = DefList->child;
		struct node* DefList_1 = Def->brother;
		struct ICNode* code1 = IC_Def(Def);
		struct ICNode* code2 = IC_DefList(DefList_1);
		return connect(code1,code2);
	}
	else	
		return genIC(EMPTY, E, -1, NULL, E, -1, NULL, E, -1, NULL, NULL);
}

struct ICNode* IC_Def(struct node* Def) {
	struct node* DecList = Def->child->brother;
	return IC_DecList(DecList);
}

struct ICNode* IC_DecList(struct node* DecList) {
	struct node* Dec = DecList->child;
	if(Dec->brother == NULL)
		return IC_Dec(Dec);
	else {	
		struct node* DecList_1 = Dec->brother->brother;
		struct ICNode* code1 = IC_Dec(Dec);
		struct ICNode* code2 = IC_DecList(DecList_1);
		return connect(code1,code2);
	}
}

struct ICNode* IC_Dec(struct node* Dec) {
	struct node* VarDec = Dec->child;
	if(VarDec->brother == NULL)	
		return IC_VarDec(VarDec);
	else {	
		struct node* Exp = VarDec->brother->brother;
		struct ICNode* code1 = IC_VarDec(VarDec);
		int t1 = new_temp();
		struct ICNode* code2 = IC_Exp(Exp, t1);
		struct ICNode* code3 = genIC(ASSIGN, E, -1, NULL, VARIABLE, lookup_var(VarDec->child->content), NULL, TEMP, t1, NULL, NULL);
		connect(code1,code2);
		connect(code2,code3);
		return code1;
	}
}

struct ICNode* IC_Exp(struct node* Exp, int place) {
	int i;
	if(strcmp(Exp->child->type, "int10") == 0)	
		return genIC(ASSIGN, E, -1, NULL, TEMP, place, NULL, CONSTANT, Exp->child->int_value, NULL, NULL);
	if(strcmp(Exp->child->type, "id") == 0)	{
		if(Exp->child->brother == NULL)	
			return genIC(ASSIGN, E, -1, NULL, TEMP, place, NULL, VARIABLE, lookup_var(Exp->child->content), NULL, "");
		else if(Exp->child->brother->brother->brother == NULL) {	
			if(strcmp(Exp->child->content, "read") == 0)	
				return genIC(READ, E, -1, NULL, TEMP, place, NULL, E, -1, NULL, NULL);
			else {
				if(place == 0)
					return genIC(CALL, E, -1, NULL, E, -1, NULL, IDNAME, -1, Exp->child->content, NULL);
				else
					return genIC(CALL, E, -1, NULL, TEMP, place, NULL, IDNAME, -1, Exp->child->content, NULL);
			}
		}
		else {	
			struct ArgNode* arg_list = NULL;
			struct node* Args = Exp->child->brother->brother;
			struct ICNode* code1 = IC_Args(Args, &arg_list);
			if(strcmp(Exp->child->content, "write") == 0) {					
				struct ICNode* code2 = genIC(WRITE, E, -1, NULL, TEMP, arg_list->no, NULL, E, -1, NULL, NULL);
				return connect(code1,code2);
			}
			else {
				struct ICNode* code2 = NULL;
				struct ArgNode* a = arg_list;
				while(a != NULL) {
					struct ICNode* arg = genIC(ARG, E, -1, NULL, TEMP, a->no, NULL, E, -1, NULL, NULL);
					if(code2 == NULL)
						code2 = arg;
					else {
						struct ICNode* t = code2;
						while(t->next != NULL)
							t = t->next;
						t->next = arg;
						arg->prev = t;
					}
					a = a->next;
				}
				struct ICNode* code3;
				if(place != 0) {
					code3 = genIC(CALL, E, -1, NULL, TEMP, place, NULL, IDNAME, -1, Exp->child->content, NULL);
				}
				else {
					code3 = genIC(CALL, E, -1, NULL, E, -1, NULL, IDNAME, -1, Exp->child->content, NULL);
				}
				connect(code1,code2);
				connect(code2,code3);
				return code1;		
			}
		}
	}
	if(strcmp(Exp->child->brother->content, "ASSIGNOP") == 0) {
		struct node* Exp_1 = Exp->child;
		struct node* Exp_2 = Exp_1->brother->brother;
		int t1 = new_temp();
		struct ICNode* code1 = IC_Exp(Exp_2, t1);
		struct ICNode* code2_1;
		if(strcmp(Exp_1->child->type, "id") == 0) {		
			code2_1 = genIC(ASSIGN, E, -1, NULL, VARIABLE, lookup_var(Exp_1->child->content), NULL, TEMP, t1, NULL, NULL);
			if(place != 0) {
				struct ICNode* code2_2_m = genIC(ASSIGN, E, -1, NULL, TEMP, place, NULL, VARIABLE, lookup_var(Exp_1->child->content), NULL, NULL);
				connect(code2_1,code2_2_m);
				connect(code1,code2_1);
				return code1;
			}
			else {
				return connect(code1,code2_1);
			}
		}
		else {
			int t_1 = new_temp();
			int t2 = new_temp();
			int t3 = new_temp();		
			struct node* Exp_1_1 = Exp_1->child;
			struct node* ID = Exp_1_1->child;
			struct node* Exp_1_2 = Exp_1_1->brother->brother;
			code2_1 = IC_Exp(Exp_1_2, t_1);
			struct ICNode* code2_2 = genIC(MUL, TEMP, t2, NULL, CONSTANT, 4, NULL, TEMP, t_1, NULL, NULL);
			struct ICNode* code2_3 = genIC(ADD, TEMP, t3, NULL, TEMP, t2, NULL, ADDRESS, lookup_var(ID->content), NULL, NULL);
			struct ICNode* code2_4 = genIC(ASSIGN, E, -1, NULL, POINTER, t3, NULL, TEMP, t1, NULL, NULL);
			connect(code2_1,code2_2);
			code2_2->next = code2_3;
			code2_3->prev = code2_2;
			code2_3->next = code2_4;
			code2_4->prev = code2_3;
			if(place != 0) {
				struct ICNode* code2_2_m = genIC(ASSIGN, E, -1, NULL, TEMP, place, NULL, POINTER, t3, NULL, NULL);
				connect(code2_1,code2_2_m);
				return connect(code1,code2_1);
			}
			else {
				return connect(code1,code2_1);
			}
		}		
	}		
	if(strcmp(Exp->child->brother->content, "PLUS") == 0 || strcmp(Exp->child->brother->content, "MINUS") == 0 || strcmp(Exp->child->brother->content, "STAR") == 0 || strcmp(Exp->child->brother->content, "DIV") == 0) {
		int t1 = new_temp();
		int t2 = new_temp();
		struct node* Exp_1 = Exp->child;
		struct node* OP = Exp_1->brother;
		struct node* Exp_2 = OP->brother;
		struct ICNode* code1 = IC_Exp(Exp_1, t1);
		struct ICNode* code2 = IC_Exp(Exp_2, t2);
		struct ICNode* code3;
		if(strcmp(OP->content, "PLUS") == 0)
			code3 = genIC(ADD, TEMP, place, NULL, TEMP, t1, NULL, TEMP, t2, NULL, NULL);
		else if(strcmp(OP->content, "MINUS") == 0)
			code3 = genIC(SUB, TEMP, place, NULL, TEMP, t1, NULL, TEMP, t2, NULL, NULL);
		else if(strcmp(OP->content, "STAR") == 0)
			code3 = genIC(MUL, TEMP, place, NULL, TEMP, t1, NULL, TEMP, t2, NULL, NULL);
		else
			code3 = genIC(DIV, TEMP, place, NULL, TEMP, t1, NULL, TEMP, t2, NULL, NULL);
		connect(code1,code2);
		connect(code2,code3);
		return code1;
	}
	if(strcmp(Exp->child->content, "MINUS") == 0) {
		int t1 = new_temp();
		struct node* Exp_1 = Exp->child->brother;
		struct ICNode* code1 = IC_Exp(Exp_1, t1);
		struct ICNode* code2 = genIC(SUB, TEMP, place, NULL, CONSTANT, 0, NULL, TEMP, t1, NULL, NULL);
		return connect(code1,code2);
	}
	if(strcmp(Exp->child->content, "LP") == 0) {
		struct node* Exp_1 = Exp->child->brother;
		return IC_Exp(Exp_1, place);
	}
	if(strcmp(Exp->child->brother->content, "AND") == 0 || strcmp(Exp->child->brother->content, "OR") == 0 || strcmp(Exp->child->brother->content, "RELOP") == 0 || strcmp(Exp->child->content, "NOT") == 0) {
		int label1 = new_label();
		int label2 = new_label();
		struct ICNode* code0 = genIC(ASSIGN, E, -1, NULL, TEMP, place, NULL, CONSTANT, 0, NULL, "=");
		struct ICNode* code1 = IC_Cond(Exp, label1, label2);
		struct ICNode* code2_1 = genIC(LABEL, E, -1, NULL, CONSTANT, label1, NULL, E, -1, NULL, NULL);
		struct ICNode* code2_2 = genIC(ASSIGN, E, -1, NULL, TEMP, place, NULL, CONSTANT, 1, NULL, "=");
		code2_1->next = code2_2;
		code2_2->prev = code2_1;
		struct ICNode* label_2 = genIC(LABEL, E, -1, NULL, CONSTANT, label2, NULL, E, -1, NULL, NULL);
		//code0 + code1 + code2 + label_2
		code0->next = code1;
		code1->prev = code0;
			connect(code1,code2_1);
		code2_2->next = label_2;
		label_2->prev = code2_2;
		return code0;
	}
	if(strcmp(Exp->child->brother->content, "LB") == 0) {
		int t1 = new_temp();
		int t2 = new_temp();
		int t3 = new_temp();		
		struct node* Exp_1 = Exp->child;
		struct node* ID = Exp_1->child;
		struct node* Exp_2 = Exp_1->brother->brother;
		struct ICNode* code1 = IC_Exp(Exp_2, t1);
		struct ICNode* code2 = genIC(MUL, TEMP, t2, NULL, CONSTANT, 4, NULL, TEMP, t1, NULL, NULL);
		struct ICNode* code3 = genIC(ADD, TEMP, t3, NULL, TEMP, t2, NULL, ADDRESS, lookup_var(ID->content), NULL, NULL);
		struct ICNode* code4 = genIC(ASSIGN, E, -1, NULL, TEMP, place, NULL, POINTER, t3, NULL, NULL);
		connect(code1,code2);
		connect(code2,code3);
		connect(code3,code4);
		return code1;
	}
	if(strcmp(Exp->child->brother->content, "DOT") == 0) {
		printf("the structure function isn't completed!\n");
		exit(-1);
	}
	else {
		printf("Can not translate the code: Contain variables of float type!\n");
		exit(-1);
	}
}

struct ICNode* IC_Args(struct node* Args, struct ArgNode* *arg_list) {
	struct node* Exp = Args->child;
	if(Exp->brother == NULL) {	
		int t1 = new_temp();		
		struct ICNode* code1 = IC_Exp(Exp, t1);
		struct ArgNode* a = (struct ArgNode*)malloc(sizeof(struct ArgNode));
		a->no = t1;
		a->next = *arg_list;
		*arg_list = a;
		return code1;
	}
	else {
		int t1 = new_temp();
		struct node* Args_1 = Exp->brother->brother;
		struct ICNode* code1 = IC_Exp(Exp, t1);
		struct ArgNode* a = (struct ArgNode*)malloc(sizeof(struct ArgNode));
		a->no = t1;
		a->next = *arg_list;
		*arg_list = a;
		struct ICNode* code2 = IC_Args(Args_1, arg_list);
		return connect(code1,code2);
	}
}

struct ICNode* IC_Cond(struct node* Exp, int label_true, int label_false) {
	if(strcmp(Exp->child->brother->content, "RELOP") == 0) {
		int t1 = new_temp();
		int t2 = new_temp();
		struct node* Exp_1 = Exp->child;
		struct node* RELOP = Exp_1->brother;
		struct node* Exp_2 = RELOP->brother;
		struct ICNode* code1 = IC_Exp(Exp_1, t1);
		struct ICNode* code2 = IC_Exp(Exp_2, t2);
		char* op;
		switch(RELOP->int_value) {
			case 1:
				op = "<";
				break;
			case 2:
				op = ">";
				break;
			case 3:
				op = "<=";
				break;
			case 4:
				op = ">=";
				break;
			case 5:
				op = "==";
				break;
			case 6:
				op = "!=";
				break;
		}
		struct ICNode* code3 = genIC(IF, CONSTANT, label_true, NULL, TEMP, t1, NULL, TEMP, t2, NULL, op);
		struct ICNode* code4 = genIC(GOTO, E, -1, NULL, CONSTANT, label_false, NULL, E, -1, NULL, NULL);
		connect(code1,code2);
		connect(code2,code3);
		connect(code3,code4);
		return code1;
	}
	else if(strcmp(Exp->child->content, "NOT") == 0) { 
		struct node* Exp_1 = Exp->child->brother;
		return IC_Cond(Exp_1, label_false, label_true);
	}
	else if(strcmp(Exp->child->brother->content, "AND") == 0) {	
		int label1 = new_label();
		struct node* Exp_1 = Exp->child;
		struct node* Exp_2 = Exp_1->brother->brother;
		struct ICNode* code1 = IC_Cond(Exp_1, label1, label_false);
		struct ICNode* code2 = IC_Cond(Exp_2, label_true, label_false);
		struct ICNode* label_1 = genIC(LABEL, E, -1, NULL, CONSTANT, label1, NULL, E, -1, NULL, NULL);
		connect(code1,label_1);
		label_1->next = code2;
		code2->prev = label_1;
		return code1;
	}
	else if(strcmp(Exp->child->brother->content, "OR") == 0) {	
		int label1 = new_label();
		struct node* Exp_1 = Exp->child;
		struct node* Exp_2 = Exp_1->brother->brother;
		struct ICNode* code1 = IC_Cond(Exp_1, label_true, label1);
		struct ICNode* code2 = IC_Cond(Exp_2, label_true, label_false);
		struct ICNode* label_1 = genIC(LABEL, E, -1, NULL, CONSTANT, label1, NULL, E, -1, NULL, NULL);
		connect(code1,label_1);
		label_1->next = code2;
		code2->prev = label_1;
		return code1;
	}
	else {
		int t1 = new_temp();
		struct ICNode* code1 = IC_Exp(Exp, t1);
		struct ICNode* code2 = genIC(IF, CONSTANT, label_true, NULL, TEMP, t1, NULL, CONSTANT, 0, NULL, "!=");
		struct ICNode* code3 = genIC(GOTO, E, -1, NULL, CONSTANT, label_false, NULL, E, -1, NULL, NULL);
		connect(code1,code2);
		code2->next = code3;
		code3->prev = code2;
		return code1;
	}
}
