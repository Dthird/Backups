#ifndef _TREE_H
#define _TREE_H
#include <stdio.h>

struct node {
	char* type;
	char* content;
	int int_value;
	float float_value;
	int lineno;
	struct node* parent;
	struct node* child;
	struct node* brother;
};

struct node* tree_root;
int error_num;

struct node* create_node(char* type, char* content, int int_value, float float_value, int lineno);
void insert_node(struct node* parent, struct node* child);
void print_tree(struct node* root, int n);

int power(int a, int b);
int atoi8(char* s);
int atoi16(char* s);

#endif
