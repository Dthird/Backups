#ifndef _INTERMEDIATE_CODE_H
#define _INTERMEDIATE_CODE_H 
#include <stdlib.h>
#include <string.h>
#include "tree.h"
#include "semantics.h"

//������
enum FieldKind {VARIABLE, TEMP, ADDRESS, POINTER, CONSTANT, IDNAME, E};
//������
union FieldContent {
	int variable_no;
	int temp_no;
	int constant_value;
	char* id_name;
};
//��
struct Field {
	enum FieldKind kind;			//����
	union FieldContent content;		//����
};

//�м��������
enum ICKind {LABEL, FUNCTION, ASSIGN, ADD, SUB, MUL, DIV, GOTO, IF, RETURN, DEC, ARG, CALL, PARAM, READ, WRITE, EMPTY};
//�м����
struct IC {
	enum ICKind kind;
	struct Field target, arg1, arg2;
	char* op;
};

//�м����ڵ�
struct ICNode {
	struct IC ic;
	struct ICNode* prev;
	struct ICNode* next;
};

//�м�����б�
struct ICNode* ic_list;

//�����ڵ�
struct ArgNode {
	int no;
	struct ArgNode* next;
};

int new_temp();
int new_label();
void kind_no(enum FieldKind kind,int no,char* str,int function,struct ICNode* ic_node);
struct ICNode* genIC(enum ICKind kind, enum FieldKind target_kind, int target_i, char* target_s, enum FieldKind arg1_kind, int arg1_i, char* arg1_s,
	enum FieldKind arg2_kind, int arg2_i, char* arg2_s, char* op);
void insertList(struct ICNode* ic_node);
void print_arg(struct Field arg,char *a);
void print_arg(struct Field arg,char *a);
void printIC(struct ICNode* ic_list);
void printIC2File(struct ICNode* ic_list, FILE* f);
int lookup_var(char* var_name);
void IC_tree(struct node* tree_root);
struct ICNode* IC_ExtDefList(struct node* ExtDefList);
struct ICNode* IC_ExtDef(struct node* ExtDef);
struct ICNode* IC_ExtDecList(struct node* ExtDecList);
struct ICNode* IC_VarDec(struct node* VarDec);
struct ICNode* IC_FunDec(struct node* FunDec);
struct ICNode* IC_VarList(struct node* VarList);
struct ICNode* IC_ParamDec(struct node* ParamDec);
struct ICNode* IC_CompSt(struct node* CompSt);
struct ICNode* IC_StmtList(struct node* StmtList);
struct ICNode* IC_Stmt(struct node* Stmt);
struct ICNode* IC_DefList(struct node* DefList);
struct ICNode* IC_Def(struct node* Def);
struct ICNode* IC_DecList(struct node* DecList);
struct ICNode* IC_Dec(struct node* Dec);
struct ICNode* IC_Exp(struct node* Exp, int place);
struct ICNode* IC_Args(struct node* n, struct ArgNode* *arg_list);
struct ICNode* IC_Cond(struct node* Exp, int label_true, int label_false);

#endif
