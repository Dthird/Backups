#include "tree.h"
#include <stdlib.h>
#include <string.h>
#include <math.h>

struct node* create_node(char* type, char* content, int int_value, float float_value, int lineno) {
	struct node* temp = (struct node*)malloc(sizeof(struct node));
	if(temp == NULL) {
		printf("Problem in allocating memory!\n");
		exit(-1);
	}

	temp->type = (char*)malloc(strlen(type) + 1);
	strcpy(temp->type, type);
	temp->content = (char*)malloc(strlen(content) + 1);
	strcpy(temp->content, content);
	temp->int_value = int_value;
	temp->float_value = float_value;
	temp->lineno = lineno;

	return temp;
}

void insert_node(struct node* parent, struct node* child) {
	if(parent == NULL) {
		printf("Error: Parent node is NULL!\n");
		exit(-1);
	}

	if(parent->child == NULL) {
		parent->child = child;
		child->parent = parent;
	}
	else {
		struct node* temp = parent->child;

		while(temp->brother != NULL)
			temp = temp->brother;

		temp->brother = child;
		child->parent = temp;
	}
}

void print_tree(struct node* root, int n) {
	int i = 0;
	
	if(root == NULL) {
		exit(-1);
	}

	while(root != NULL) {
		/*if((strcmp(root->type, "syntax") == 0) || (root->lineno != 0)) {
			for(i = 0; i < n; i++)
				printf("  ");
			
			if(root->lineno != 0)
				printf("%s (%d)\n", root->content, root->lineno);
		}*/
		if ((strcmp(root->type, "syntax") == 0) || (root->lineno != 0)){
			for(; i < n; i++)
				printf("  ");
		}
		
		if (strcmp(root->type, "syntax") == 0)
			if(root->lineno != 0)
				printf("%s (%d)\n", root->content, root->lineno);

		if(strcmp(root->type, "id") == 0)
			printf("ID: %s\n", root->content);

		if(strcmp(root->type, "type") == 0)
			printf("TYPE: %s\n", root->content);

		if(strcmp(root->type, "int10") == 0)
			printf("INT: %d\n", root->int_value);
		if(strcmp(root->type, "int8") == 0)
			printf("INT: %d\n", root->int_value);
		if(strcmp(root->type, "int16") == 0)
			printf("INT: %d\n", root->int_value);

		if(strcmp(root->type, "float") == 0)
			printf("FLOAT: %f\n", root->float_value);

		if(strcmp(root->type, "lexical") == 0)
			printf("%s\n", root->content);

		root = root->child;
		
		while(root != NULL) {
			print_tree(root, n + 1);
			root = root->brother;
		}
	}
}

int power(int a, int b) {
	int result = 1;
	int i;
	for(i = 0; i < b; i++)
		result *= a;
	
	return result;
}

int atoi8(char* s) {
	int n = 0;
	int i;
	int len = strlen(s);
	
	for(i = 1; i < len; i++)
		n += (*((char*)(s + i)) - '0') * power(8.0, len - 1 - i);

	return n;
}

int atoi16(char* s) {
	int n = 0;
	int i;
	int len = strlen(s);

	for(i = 2; i < len; i++) {
		if(*((char*)(s + i)) >= '0' && *((char*)(s + i)) <= '9')
			n += (*((char*)(s + i)) - '0') * power(16.0, len - 1 - i);
		else {
			if(*((char*)(s + i)) == 'A' || *((char*)(s + i)) == 'a')
				n += (10 * power(16.0, len - 1 - i));
			else if(*((char*)(s + i)) == 'B' || *((char*)(s + i)) == 'b')
				n += (11 * power(16.0, len - 1 - i));
			else if(*((char*)(s + i)) == 'C' || *((char*)(s + i)) == 'c')
				n += (12 * power(16.0, len - 1 - i));
			else if(*((char*)(s + i)) == 'D' || *((char*)(s + i)) == 'd')
				n += (13 * power(16.0, len - 1 - i));
			else if(*((char*)(s + i)) == 'E' || *((char*)(s + i)) == 'e')
				n += (14 * power(16.0, len - 1 - i));
			else if(*((char*)(s + i)) == 'F' || *((char*)(s + i)) == 'f')
				n += (15 * power(16.0, len - 1 - i));
		}
	}

	return n;
}
