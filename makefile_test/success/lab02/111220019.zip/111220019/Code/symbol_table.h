#ifndef _SYMBOL_TABLE_H_
#define _SYMBOL_TABLE_H_

#define MAX_SYMBOL_TABLE 0x4000

//Type类型等
typedef enum { Int, Float } basic_type;

typedef struct Type_ {
    enum { Basic, Array, Structure } kind;
    union {
        basic_type basic;
        struct {
            struct Type_* elem;
            int size;
        } array;
        struct FieldList_* structure;
    } u;
}Type;

typedef struct FieldList_ {
    char id[32];
    Type* type;
	int lineno;
    struct FieldList_* next;
}FieldList;

typedef struct arg_node_ {
    Type *type;
    struct arg_node_ *next;
}arg_node;


//符号表变量
typedef struct var_symbol_{
    Type *type;      
    unsigned char is_param;
} var_symbol;

//符号表结构类型
typedef struct struct_symbol_{
    Type *structure;
} struct_symbol;

//符号表函数
typedef struct func_symbol_{
    arg_node *args;
    Type *ret_type;
    unsigned char is_defined;
    int lineno;
} func_symbol;

typedef struct symbol_node_{
    char key[32];
    enum { Var, Struct, Func } type;
    union {
        var_symbol var_val;			//变量
        struct_symbol struct_val;	//结构体
        func_symbol func_val;		//函数
    } u;
} symbol_node;

typedef struct hash_node_ {
    symbol_node *data;
    struct hash_node_ *next;
} hash_node;

//全局变量
int isAnyError;
Type *p_int_type, *p_float_type;
//Type* p_int_type = (Type*)malloc(sizeof(struct Type_));
//Type* p_float_type = (Type*)malloc(sizeof(struct Type_));
hash_node symbol_table[MAX_SYMBOL_TABLE];

extern unsigned int hash_pjw(char *name);			
extern void initSymbolTable();						
extern void insertSymbol(symbol_node *p_symbol);
extern symbol_node* getSymbol(char *name);

#endif