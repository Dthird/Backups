#include "symbol_table.h"
#include "syntax_tree.h"
#include "semantic.h"
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

#define MAX_NUMBER_OF_CHILDREN 8

void SDT(syntax_tree_node *p_node) {
	//printf("In SDT\n");
	//printf("%d %d\n", p_int_type, p_float_type);
    if (p_node == NULL)
        return;

    syntax_tree_node *children[MAX_NUMBER_OF_CHILDREN];
    syntax_tree_node *child = p_node->lchild;
    int child_num = 0;
    while (child) {
        children[child_num ++] = child;
        child = child->nextSibling;
    }
	
	//printf("%s: child_num %d\n", p_node->name, child_num);
	if (strcmp(p_node->name, "Program") == 0){
		Program(child_num, p_node, children);
	}
	else if (strcmp(p_node->name, "ExtDefList") == 0){
		ExtDefList(child_num, p_node, children);
	}
    else if (strcmp(p_node->name, "ExtDef") == 0) {
        ExtDef(child_num, p_node, children);
    }
	else if (strcmp(p_node->name, "ExtDecList") == 0) {
        ExtDecList(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "Specifier") == 0) {
        Specifier(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "StructSpecifier") == 0) {
        StructSpecifier(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "VarDec") == 0) {
        VarDec(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "FunDec") == 0) {
        FunDec(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "VarList") == 0) {
        VarList(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "ParamDec") == 0) {
        ParamDec(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "CompSt") == 0) {
        CompSt(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "StmtList") == 0) {
        StmtList(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "Stmt") == 0) {
        Stmt(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "DefList") == 0) {
        DefList(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "Def") == 0) {
        Def(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "DecList") == 0) {
        DecList(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "Dec") == 0) {
        Dec(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "Exp") == 0) {
        Exp(child_num, p_node, children);
    }
    else if (strcmp(p_node->name, "Args") == 0) {
        Args(child_num, p_node, children);
    }
}

void Program(int child_num, syntax_tree_node *p_node, syntax_tree_node **children){
	if (child_num == 1 && strcmp(children[0]->name, "ExtDefList") == 0){
		SDT(children[0]);
	}
}
void ExtDefList(int child_num, syntax_tree_node *p_node, syntax_tree_node **children){
	if (child_num == 2 && strcmp(children[0]->name, "ExtDef") == 0 && strcmp(children[1]->name, "ExtDefList") == 0){
		SDT(children[0]);
		SDT(children[1]);
	}
	else if(child_num == 0){
			
	}
}

void ExtDef(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In ExtDef handler\n");
	//printf("%d %d %d\n", strcmp(children[0]->name, "Specifier") == 0, children[1]->name == "FuncDec", children[2]->name == "CompSt");
    if (child_num == 3 && strcmp(children[0]->name, "Specifier") == 0 && strcmp(children[1]->name, "ExtDecList") == 0 && strcmp(children[2]->name, "SEMI") == 0) {
        SDT(children[0]);
        children[1]->attr.inh_type = children[0]->attr.type;
        SDT(children[1]);
    }
    else if (child_num == 2 && strcmp(children[0]->name, "Specifier") == 0 && strcmp(children[1]->name, "SEMI") == 0) { 
        SDT(children[0]);
    }

    else if (child_num == 3 && strcmp(children[0]->name, "Specifier") == 0 && strcmp(children[1]->name, "FunDec") == 0 && strcmp(children[2]->name, "CompSt") == 0) {
        SDT(children[0]);
        children[1]->attr.inh_type = children[0]->attr.type;
        children[1]->attr.is_definition = 1;
        SDT(children[1]);
        children[2]->attr.ret_type = children[0]->attr.type;
        SDT(children[2]);
    }
}

void ExtDecList(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In ExtDecList handler\n");
    if (child_num == 3 && children[0]->name == "VarDec" && children[1]->name == "COMMA" && children[2]->name == "ExtDecList") {
        children[0]->attr.inh_type = p_node->attr.inh_type;
        SDT(children[0]);
        children[1]->attr.inh_type = p_node->attr.inh_type;
        SDT(children[1]);
    }
    else if (child_num == 1 && children[0]->name == "VarDec") {
        children[0]->attr.inh_type = p_node->attr.inh_type;
        SDT(children[0]);
    }
}

void Specifier(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In Specifier handler\n");
    if (child_num == 1 && strcmp(children[0]->name, "TYPE") == 0) {
        if (children[0]->value.type == Int)
            p_node->attr.type = p_int_type;
        else
            p_node->attr.type = p_float_type;
        p_node->attr.is_legal = 1;
    }
    else if (child_num == 1 && strcmp(children[0]->name, "StructSpecifier") == 0) {
        SDT(children[0]);
        p_node->attr.type = children[0]->attr.type;
        p_node->attr.is_legal = children[0]->attr.is_legal;
    }
}

void StructSpecifier(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In StructSpecifier handler\n");
    if (child_num == 5 && strcmp(children[0]->name, "STRUCT") == 0 && strcmp(children[1]->name, "OptTag") == 0 && strcmp(children[2]->name, "LC") == 0 && strcmp(children[3]->name, "DefList") == 0 && strcmp(children[4]->name, "RC") == 0) {
        symbol_node *struct_node = getSymbol(children[1]->lchild->value.stringValue);
        if (struct_node == NULL ) {
            symbol_node *new_symbol = (symbol_node*)malloc(sizeof(symbol_node));
            strcpy(new_symbol->key, children[1]->lchild->value.stringValue);
            new_symbol->type = Struct;
            insertSymbol(new_symbol);
            p_node->attr.type = (Type*)malloc(sizeof(Type));
            p_node->attr.type->kind = Structure;
            new_symbol->u.struct_val.structure = p_node->attr.type;

            children[3]->attr.is_in_struct = 1;
            SDT(children[3]);
            FieldList *field = children[3]->attr.structure;
            while (field) {
                FieldList *pre_field = children[3]->attr.structure;
                while (pre_field != field) {
                    if (strcmp(pre_field->id, field->id) == 0) {
                        printError(15, field->lineno, "Redefined field.");
                        break;
                    }
                    pre_field = pre_field->next;
                }

                field = field->next;
            }
            p_node->attr.type->u.structure = children[3]->attr.structure;
            p_node->attr.is_legal = 1;
        }
        else {
            printError(16, children[1]->lineno, "Redefined structure.");
            p_node->attr.is_legal = 0;
        }
    }
    else if (child_num == 2 && strcmp(children[0]->name, "STRUCT") == 0 && strcmp(children[1]->name, "Tag") == 0) {
        symbol_node *struct_node;
        if (struct_node = getSymbol(children[1]->lchild->value.stringValue)) {
            p_node->attr.type = struct_node->u.struct_val.structure;
            p_node->attr.is_legal = 1;
        }
        else {
            printError(17, children[1]->lineno, "Undefined structure.");
            p_node->attr.is_legal = 0;
        }
    }
}

void OptTag(int child_num, syntax_tree_node *p_node, syntax_tree_node **children){
	if (child_num == 1 && strcmp(children[0]->name, "ID") == 0){
	
	}
	if (child_num == 0 ){
	
	}
}

void Tag(int child_num, syntax_tree_node *p_node, syntax_tree_node **children){
	if (child_num == 1 && strcmp(children[0]->name, "ID") == 0){
	
	}
}

void VarDec(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In VarDec handler\n");
    if (child_num == 1 && strcmp(children[0]->name, "ID") == 0) {
        p_node->attr.type = p_node->attr.inh_type;
        p_node->attr.id = children[0]->value.stringValue;
        if (p_node->attr.is_in_struct) {
            p_node->attr.structure = (FieldList*)malloc(sizeof(FieldList));
            p_node->attr.structure->next = NULL;
            p_node->attr.structure->type = p_node->attr.type;
            p_node->attr.structure->lineno = children[0]->lineno;
            strcpy(p_node->attr.structure->id, children[0]->value.stringValue);
            return;
        }
        symbol_node *var_node = getSymbol(children[0]->value.stringValue);
        if (var_node == NULL ) {
            symbol_node *new_symbol = (symbol_node*)malloc(sizeof(symbol_node));
            strcpy(new_symbol->key, children[0]->value.stringValue);
            new_symbol->type = Var;
            new_symbol->u.var_val.type = p_node->attr.inh_type;
            insertSymbol(new_symbol);       
        }
        else {
            printError(3, children[0]->lineno, "Redefined variable.");
        }
    }
    else if (child_num == 4 && strcmp(children[0]->name, "VarDec") == 0 && strcmp(children[1]->name, "LB") == 0 && strcmp(children[2]->name, "INT") == 0 && strcmp(children[3]->name, "RB") == 0) {
        Type *type_node = (Type*)malloc(sizeof(Type));
        type_node->kind = Array;
        type_node->u.array.elem = p_node->attr.inh_type;
        type_node->u.array.size = children[2]->value.intValue;
        children[0]->attr.inh_type = type_node;
        children[0]->attr.is_in_struct = p_node->attr.is_in_struct;
        SDT(children[0]);
        p_node->attr.structure = children[0]->attr.structure;
        p_node->attr.type = children[0]->attr.type;
        p_node->attr.id = children[0]->attr.id;
    }
}

void FunDec(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In FunDec handler\n");
    symbol_node *func_node = getSymbol(children[0]->value.stringValue);
    if (p_node->attr.is_definition && (func_node && func_node->type != Func || func_node && func_node->type == Func && func_node->u.func_val.is_defined)) {
        printError(4, children[0]->lineno, "Redefined function.");
        return;
    }
    if (func_node == NULL) {
        func_node = (symbol_node*)malloc(sizeof(symbol_node));
        strcpy(func_node->key, children[0]->value.stringValue);
        func_node->type= Func;
        func_node->u.func_val.ret_type = p_node->attr.inh_type;
        func_node->u.func_val.lineno = p_node->lineno;
        p_node->attr.is_declared = 0;
        insertSymbol(func_node);
    }
    else {
        if (!isEqual(func_node->u.func_val.ret_type, p_node->attr.inh_type)) {
            return;
        }
        p_node->attr.is_declared = 1;
    }
    if (child_num == 4 && strcmp(children[0]->name, "ID") == 0 && strcmp(children[1]->name, "LP") == 0 && strcmp(children[2]->name, "VarList") == 0 && strcmp(children[3]->name, "RP") == 0) {
        if (p_node->attr.is_declared) {
            children[2]->attr.args = func_node->u.func_val.args;
        }
        children[2]->attr.is_definition = p_node->attr.is_definition;
        children[2]->attr.is_declared = p_node->attr.is_declared;
        SDT(children[2]);
        if (!p_node->attr.is_declared)
            func_node->u.func_val.args = children[2]->attr.args;
        else
            p_node->attr.is_legal = children[2]->attr.is_legal;
    }
    else if (child_num == 3 && strcmp(children[0]->name, "ID") == 0 && strcmp(children[1]->name, "LP") == 0 && strcmp(children[2]->name, "RP") == 0) {
        if (p_node->attr.is_declared) {
            if (func_node->u.func_val.args) {
                return;
            }
        }
        else {
            func_node->u.func_val.args = NULL;
            p_node->attr.is_legal = 1;
        }
    }
    if (p_node->attr.is_definition) {
        if (p_node->attr.is_declared)
            func_node->u.func_val.is_defined = p_node->attr.is_legal;
        else
            func_node->u.func_val.is_defined = 1;
    }
}


void VarList(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In VarList handler\n");
    children[0]->attr.is_declared = p_node->attr.is_declared;
    children[0]->attr.is_definition = p_node->attr.is_definition;
    if (p_node->attr.is_declared) {
        if (p_node->attr.args == NULL) {
            p_node->attr.is_legal = 0;
            return;
        }
        p_node->attr.is_legal = 1;
        children[0]->attr.type = p_node->attr.args->type;
    }
    SDT(children[0]);
    if (!p_node->attr.is_declared) {
        p_node->attr.args = (arg_node*)malloc(sizeof(arg_node));
        p_node->attr.args->type = children[0]->attr.type;
    }
    else {
        if (!children[0]->attr.is_legal)
            p_node->attr.is_legal = 0;
    }
    if (child_num == 3 && strcmp(children[0]->name, "ParamDec") == 0 && strcmp(children[1]->name, "COMMA") == 0 && strcmp(children[2]->name, "VarList") == 0) {
        if (p_node->attr.is_declared) {
            children[2]->attr.args = p_node->attr.args->next;
        }
        children[2]->attr.is_declared = p_node->attr.is_declared;
        children[2]->attr.is_definition = p_node->attr.is_definition;
        SDT(children[2]);
        if (!p_node->attr.is_declared)
            p_node->attr.args->next = children[2]->attr.args;
        else {
            if (!children[2]->attr.is_legal)
                p_node->attr.is_legal = 0;
        }
    }
    else if (child_num == 1 && strcmp(children[0]->name, "ParamDec") == 0) {
        if (p_node->attr.is_declared) {
            if (p_node->attr.args->next)
				;
        }
        else
            p_node->attr.args->next = NULL;
    }
}

void ParamDec(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In ParamDec handler\n");
    if (child_num == 2 && strcmp(children[0]->name, "Specifier") == 0 && strcmp(children[1]->name, "VarDec") == 0) {
        SDT(children[0]);
        children[1]->attr.inh_type = children[0]->attr.type;
        SDT(children[1]);
        if (p_node->attr.is_declared) {
            if (!isEqual(p_node->attr.type, children[1]->attr.type)) {
                p_node->attr.is_legal = 0;
            }
        }
        else 
            p_node->attr.type = children[1]->attr.type;
    }
}

void CompSt(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In CompSt handler\n");
    if (child_num == 4 && strcmp(children[0]->name, "LC") == 0 && strcmp(children[1]->name, "DefList") == 0 && strcmp(children[2]->name, "StmtList") == 0 && strcmp(children[3]->name, "RC") == 0) {
        children[1]->attr.is_in_struct = 0;
        SDT(children[1]);
        children[2]->attr.ret_type = p_node->attr.ret_type;
        SDT(children[2]);
    }
}

void StmtList(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In StmtList handler\n");
    if (child_num == 2 && strcmp(children[0]->name, "Stmt") == 0 && strcmp(children[1]->name, "StmtList") == 0) {
        children[0]->attr.ret_type = p_node->attr.ret_type;
        SDT(children[0]);
        children[1]->attr.ret_type = p_node->attr.ret_type;
        SDT(children[1]);
    }
    else if (child_num == 0) {
	
    }
}

void Stmt(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In Stmt handler\n");
    if (child_num == 3 && strcmp(children[0]->name, "RETURN") == 0 && strcmp(children[1]->name, "Exp") == 0 && strcmp(children[2]->name, "SEMI") == 0) {
        SDT(children[1]);
        if (!isEqual(children[1]->attr.type, p_node->attr.ret_type)) {
            printError(8, children[1]->lineno, "The return type mismatched.");
        }
    }
    else if (child_num == 1 && strcmp(children[0]->name, "CompSt") == 0) {
        SDT(children[0]);
    }
    else {
        int i;
        for (i = 0; i < child_num; ++ i) {
            children[i]->attr.ret_type = p_node->attr.ret_type;
            SDT(children[i]);
        }
    }
}

void DefList(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In DefList handler\n");
    if (child_num == 2 && strcmp(children[0]->name, "Def") == 0 && strcmp(children[1]->name, "DefList") == 0) {
        children[0]->attr.is_in_struct = p_node->attr.is_in_struct;
        SDT(children[0]);
        children[1]->attr.is_in_struct = p_node->attr.is_in_struct;
        SDT(children[1]);
        if (p_node->attr.is_in_struct) {
            FieldList *field = p_node->attr.structure = children[0]->attr.structure;
            while (field->next)
                field = field->next;
            field->next = children[1]->attr.structure;
        }
    }
    else if (child_num == 0) {
        if (p_node->attr.is_in_struct) {
            p_node->attr.structure = NULL;
        }
    }
}

void Def(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In Def handler\n");
    if (child_num == 3 && strcmp(children[0]->name, "Specifier") == 0 && strcmp(children[1]->name, "DecList") == 0 && strcmp(children[2]->name, "SEMI") == 0) {
        SDT(children[0]);
        children[1]->attr.inh_type = children[0]->attr.type;
        children[1]->attr.is_in_struct = p_node->attr.is_in_struct;
        SDT(children[1]);
        if (p_node->attr.is_in_struct) {
            p_node->attr.structure = children[1]->attr.structure;
        }
    }
}

void DecList(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In DecList handler\n");
    children[0]->attr.is_in_struct = p_node->attr.is_in_struct;
    children[0]->attr.inh_type = p_node->attr.inh_type;
    SDT(children[0]);
    if (child_num == 1 && strcmp(children[0]->name, "Dec") == 0) {

    }
    else if (child_num == 3 && strcmp(children[0]->name, "Dec") == 0 && strcmp(children[1]->name, "COMMA") == 0 && strcmp(children[2]->name, "DecList") == 0) {
        children[2]->attr.is_in_struct = p_node->attr.is_in_struct;
        children[2]->attr.inh_type = p_node->attr.inh_type;
        SDT(children[2]);
        if (p_node->attr.is_in_struct)
            children[0]->attr.structure->next = children[2]->attr.structure;
    }
    if (p_node->attr.is_in_struct)
        p_node->attr.structure = children[0]->attr.structure;
}

void Dec(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In Dec handler\n");
    children[0]->attr.is_in_struct = p_node->attr.is_in_struct;
    children[0]->attr.inh_type = p_node->attr.inh_type;
    SDT(children[0]);
    if (p_node->attr.is_in_struct)
        p_node->attr.structure = children[0]->attr.structure;
    if (child_num == 1 && strcmp(children[0]->name, "VarDec") == 0) {

    }
    else if (child_num == 3 && strcmp(children[0]->name, "VarDec") == 0 && strcmp(children[1]->name, "ASSIGNOP") == 0 && strcmp(children[2]->name, "Exp") == 0) {

        SDT(children[2]);
        if (p_node->attr.is_in_struct) {
            printError(15, children[1]->lineno, "Cannot initialize a field of structure.");
            return;
        }
        if (children[2]->attr.is_legal) {
            if (isEqual(children[0]->attr.type, children[2]->attr.type)) 
                p_node->attr.type = children[0]->attr.type;
            else 
                printError(5, children[1]->lineno, "Type mismatched.");
        }
    }
}

void Exp(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In Exp handler\n");
    if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "ASSIGNOP") == 0 && strcmp(children[2]->name, "Exp") == 0) {
        SDT(children[0]);
        SDT(children[2]);
        syntax_tree_node *grand_children[4], *grand_child = children[0]->lchild;
        int grand_child_num = 0;
        while (grand_child) {
            grand_children[grand_child_num ++] = grand_child;
            grand_child = grand_child->nextSibling;
        }
        if (!(grand_child_num == 1 && strcmp(grand_children[0]->name, "ID") == 0 || grand_child_num == 4 && strcmp(grand_children[0]->name, "Exp") == 0 && strcmp(grand_children[1]->name, "LB") == 0 && strcmp(grand_children[2]->name, "Exp") == 0 && strcmp(grand_children[3]->name, "RB") == 0 || grand_child_num == 3 && strcmp(grand_children[0]->name, "Exp") == 0 && strcmp(grand_children[1]->name, "DOT") == 0 && strcmp(grand_children[2]->name, "ID") == 0)) {
            printError(6, children[0]->lineno, "The left-hand side of an assignment must be a variable.");
            p_node->attr.is_legal = 0;
            return;
        }
        if (children[0]->attr.is_legal && children[2]->attr.is_legal) {
            if (isEqual(children[0]->attr.type, children[2]->attr.type)) {
                p_node->attr.type = children[0]->attr.type;
                p_node->attr.is_legal = 1;
            }
            else {
                printError(5, children[1]->lineno, "Type mismatched.");
                p_node->attr.is_legal = 0;
            }
        }
        else
            p_node->attr.is_legal = 0;
    }
    else if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "AND") == 0 && strcmp(children[2]->name, "Exp") == 0) {
        checkTypeMatch(p_node, children);
    }
    else if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "OR") == 0 && strcmp(children[2]->name, "Exp") == 0) {
        checkTypeMatch(p_node, children);
    }
    else if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "RELOP") == 0 && strcmp(children[2]->name, "Exp") == 0) {
        checkTypeMatch(p_node, children);
    }
    else if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "PLUS") == 0 && strcmp(children[2]->name, "Exp") == 0) {
        checkTypeMatch(p_node, children);
    }
    else if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "MINUS") == 0 && strcmp(children[2]->name, "Exp") == 0) {
        checkTypeMatch(p_node, children);
    }
    else if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "STAR") == 0 && strcmp(children[2]->name, "Exp") == 0) {
        checkTypeMatch(p_node, children);
    }
    else if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "DIV") == 0 && strcmp(children[2]->name, "Exp") == 0) {
        checkTypeMatch(p_node, children);
    }
    else if (child_num == 3 && strcmp(children[0]->name, "LP") == 0 && strcmp(children[1]->name, "Exp") == 0 && strcmp(children[2]->name, "RP") == 0) {
        SDT(children[1]);
        p_node->attr.is_legal = children[1]->attr.is_legal;
        p_node->attr.type = children[1]->attr.type;
    }
    else if (child_num == 2 && strcmp(children[0]->name, "MINUS") == 0 && strcmp(children[1]->name, "Exp") == 0) {
        SDT(children[1]);
        p_node->attr.is_legal = children[1]->attr.is_legal;
        p_node->attr.type = children[1]->attr.type;
    }
    else if (child_num == 2 && strcmp(children[0]->name, "NOT") == 0 && strcmp(children[1]->name, "Exp") == 0) {
        SDT(children[1]);
        p_node->attr.is_legal = children[1]->attr.is_legal;
        p_node->attr.type = children[1]->attr.type;
    }
    else if (child_num == 4 && strcmp(children[0]->name, "ID") == 0 && strcmp(children[1]->name, "LP") == 0 && strcmp(children[2]->name, "Args") == 0 && strcmp(children[3]->name, "RP") == 0 || child_num == 3 && strcmp(children[0]->name, "ID") == 0 && strcmp(children[1]->name, "LP") == 0 && strcmp(children[2]->name, "RP") == 0) {
        syntax_tree_node *args = (child_num == 4) ? children[2] : NULL;
        symbol_node *func_node;
        if (func_node = getSymbol(children[0]->value.stringValue)) {
            if (func_node->type == Var) {
                printError(11, children[0]->lineno, "The ID must be a function.");
                p_node->attr.is_legal = 0;
            }
            else  {
                p_node->attr.type = func_node->u.func_val.ret_type;

                if (args) {
                    args->attr.inh_args = func_node->u.func_val.args;
                    SDT(args);
                    p_node->attr.is_legal = args->attr.is_legal;
                }
                else {
                    if (func_node->u.func_val.args) {
                        printError(9, p_node->lineno, "Function's argument number mismatched.");
                        p_node->attr.is_legal = 0;
                    }
                    else
                        p_node->attr.is_legal = 1;
                }
            }
        }
        else {
            printError(2, children[0]->lineno, "Undefined function.");
            p_node->attr.is_legal = 0;
        }
    }
    else if (child_num == 4 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "LB") == 0 && strcmp(children[2]->name, "Exp") == 0 && strcmp(children[3]->name, "RB") == 0) {
        SDT(children[0]);
        if (!children[0]->attr.is_legal) {
            p_node->attr.is_legal = 0;
            return;
        }
        if (children[0]->attr.type->kind != Array) {
            printError(10, children[0]->lineno, "The ID must be an array.");
            p_node->attr.is_legal = 0;
            return;
        }
        SDT(children[2]);
        if (!children[2]->attr.is_legal) {
            p_node->attr.is_legal = 0;
            return;
        }
        if (children[2]->attr.type->kind == Basic && children[2]->attr.type->u.basic == Int) {
            p_node->attr.type = children[0]->attr.type->u.array.elem;
            p_node->attr.is_legal = 1;
        }
        else {
            printError(12, children[2]->lineno, "Operands type mistaken.");
            p_node->attr.is_legal = 0;
        }
    }
    else if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "DOT") == 0 && strcmp(children[2]->name, "ID") == 0) {
        SDT(children[0]);
        if (!children[0]->attr.is_legal) {
            p_node->attr.is_legal = 0;
            return;
        }
        if (children[0]->attr.type->kind != Structure) {
            printError(13, children[1]->lineno, "Illegal use of DOT.");
            p_node->attr.is_legal = 0;
            return;
        }
        FieldList *field = children[0]->attr.type->u.structure;
        while (field) {
            if (strcmp(field->id, children[2]->value.stringValue) == 0)
                break;
            field = field->next;
        }

        if (field) {
            p_node->attr.type = field->type;
            p_node->attr.is_legal = 1;
        }
        else {
            printError(14, children[2]->lineno, "Un-existed field.");
            p_node->attr.is_legal = 0;
        }
    }
    else if (child_num == 1 && strcmp(children[0]->name, "ID") == 0) {
        symbol_node *var_node;
        if (var_node = getSymbol(children[0]->value.stringValue)) {
            p_node->attr.type = var_node->u.var_val.type;
            p_node->attr.is_legal = 1;
        }
        else {
            printError(1, children[0]->lineno, "Undefined variable.");
            p_node->attr.is_legal = 0;
        }
    }
    else if (child_num == 1 && strcmp(children[0]->name, "INT") == 0) {
        p_node->attr.type = p_int_type;
        p_node->attr.is_legal = 1;
    }
    else if (child_num == 1 && strcmp(children[0]->name, "FLOAT") == 0) {
        p_node->attr.type = p_float_type;
        p_node->attr.is_legal = 1;
    }
}

void Args(int child_num, syntax_tree_node *p_node, syntax_tree_node **children) {
	//printf("In Args handler\n");
    SDT(children[0]);
    if (p_node->attr.inh_args == NULL) {
        printError(9, children[0]->lineno, "Function's argument number mismatched.");
        p_node->attr.is_legal = 0;
        return;
    }
    if (!isEqual(p_node->attr.inh_args->type, children[0]->attr.type)) {
        printError(9, children[0]->lineno, "Function's argument type mismatched.");
        p_node->attr.is_legal = 0;
        return;
    }

    if (child_num == 3 && strcmp(children[0]->name, "Exp") == 0 && strcmp(children[1]->name, "COMMA") == 0 && strcmp(children[2]->name, "Args") == 0) {
        children[2]->attr.inh_args = p_node->attr.inh_args->next;     
        SDT(children[2]);
        p_node->attr.is_legal = children[2]->attr.is_legal;
    }
    else if (child_num == 1 && strcmp(children[0]->name, "Exp") == 0) {
        if (p_node->attr.inh_args->next) {
            printError(9, p_node->lineno, "Function's argument number mismatched.");
            p_node->attr.is_legal = 0;
        }
        else
            p_node->attr.is_legal = 1;
    }
}

int isEqual(Type *a, Type *b) {
    if (a == NULL && b == NULL)
        return 1;
    if (a == NULL || b == NULL)
        return 0;
    if (a->kind != b->kind)
        return 0;
    if (a->kind == Basic){
        return a->u.basic == b->u.basic;
	}
    else if (a->kind == Array)
        return isEqual(a->u.array.elem, b->u.array.elem);
    else {
        FieldList *a_field = a->u.structure, *b_field = b->u.structure;
        while (a_field && b_field) {
            if (!isEqual(a_field->type, b_field->type))
                return 0;
            a_field = a_field->next;
            b_field = b_field->next;
        }
        if (a_field || b_field)
            return 0;
        return 1;
    }
}

void checkTypeMatch(syntax_tree_node *p_node, syntax_tree_node **children) {
    SDT(children[0]);
    SDT(children[2]);
    if (children[0]->attr.is_legal && children[2]->attr.is_legal) {
        if (isEqual(children[0]->attr.type, children[2]->attr.type)) {
            p_node->attr.type = children[0]->attr.type;
            p_node->attr.is_legal = 1;
        }
        else {
            printError(7, children[1]->lineno, "Operands type mismatched.");
            p_node->attr.is_legal = 0;
        }
    }
    else
        p_node->attr.is_legal = 0;
}

void printError(int type, int lineno, char *msg) {
    isAnyError = 1;
    printf("Error type %d at line %d: %s\n", type, lineno, msg); 
}