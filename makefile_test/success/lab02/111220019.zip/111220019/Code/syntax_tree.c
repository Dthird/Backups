#include <stdarg.h>					//for va_list, va_arg, va_start and va_end
#include <malloc.h>
#include "syntax_tree.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

extern int yylineno;

struct syntax_tree_node* createTokenNode(char *name)
{
	struct syntax_tree_node* p = (struct syntax_tree_node*)malloc(sizeof( struct syntax_tree_node));
    p->isTerminator = 1;
    p->name = name;
    p->lchild = NULL;
    p->nextSibling = NULL;
    p->lineno = yylineno;
    return p;
}

struct syntax_tree_node* createSyntaxNode(char *name, int childNumber, ...) 
{
	int i;
	struct syntax_tree_node* temp = NULL;
    struct syntax_tree_node* p = (struct syntax_tree_node*)malloc(sizeof(struct syntax_tree_node));
    p->lchild = NULL;
	p->nextSibling = NULL;
	
    p->name = name;
	p->isTerminator = 0;
	
	//Variable parameters code
    va_list args;
    
    va_start(args, childNumber);
    if (childNumber > 0) 
	{
        p->lchild = va_arg(args, struct syntax_tree_node*);
		temp = p->lchild;
    }
    for (i=1; i<childNumber; i++) 
	{
        temp->nextSibling = va_arg(args, struct syntax_tree_node*);
		temp = temp->nextSibling;
    }
    va_end(args);

    if (childNumber == 0) 
	{
        p->lineno = yylineno;
    }
    else 
	{
        p->lineno = p->lchild->lineno;
    }

    return p;
}

void traversalSyntaxTree(int spaceNumber, struct syntax_tree_node* p) 
{
    if (p == NULL)
        return;
    if (!p->isTerminator && p->lchild == NULL) 
	{
        traversalSyntaxTree(spaceNumber, p->nextSibling);
        return;
    }
    int i;
    for (i = 0; i < spaceNumber; i++) 
	{
        printf(" ");
    }
    if (p->isTerminator) 
	{
        if (strcmp(p->name, "INT") == 0) 
		{
            printf("%s: %d\n", p->name, p->value.intValue);
        }
        else if (strcmp(p->name, "FLOAT") == 0) 
		{
            printf("%s: %f\n", p->name, p->value.floatValue);
        }
        else if (strcmp(p->name, "ID") == 0) 
		{
            printf("%s: %s\n", p->name, p->value.stringValue);
        }
        else if (strcmp(p->name, "TYPE") == 0) 
		{
            //if (strcmp(p->value.type, "int") == 0)
			if(p->value.type == Int)
                printf("%s: int\n", p->name);
			if(p->value.type == Float)
            //if (strcmp(p->value.type, "float") == 0)
                printf("%s: float\n", p->name);
        }
        else 
		{
            printf("%s\n", p->name);
        }
    }
    else 
	{
        printf("%s (%d)\n", p->name, p->lineno); 
        traversalSyntaxTree(spaceNumber + 2, p->lchild);
    }
    traversalSyntaxTree(spaceNumber, p->nextSibling);
}

void destorySyntaxTree(struct syntax_tree_node* p) 
{
    if (p == NULL)
        return;
    destorySyntaxTree(p->lchild);
    destorySyntaxTree(p->nextSibling);
    free(p);
}
