#include "symbol_table.h"
#include <stdlib.h>
#include <malloc.h>
#include <string.h>

//P. J. Weinberger hash function
unsigned int hash_pjw(char *name) {
    unsigned int val = 0, i;
    for (; *name; ++ name) {
        val = (val << 2) + *name;				//左移1/8的位数后与指向name的那个字节对应的ASCAII码相加
        if (i = val & ~0x3fff) 					//获取高位（1/8）的位数
			val = (val ^ (i >> 2)) & 0x3fff;	//移位后异或，最后进行与操作
    }
	/*	由于当if为假时，val < 0x4000 ; 
		当if为真时， if里面最后一步是与操作，所以val < 0x4000 ;
		所以符号表大小至少为0x4000。
	*/
    return val;
}


void initSymbolTable() {
	
	//初始化int和float类型对应的全局变量
	p_int_type = (Type*)malloc(sizeof(Type));
    p_float_type = (Type*)malloc(sizeof(Type));
    p_int_type->kind = p_float_type->kind = Basic;
    p_int_type->u.basic = Int;
    p_float_type->u.basic = Float;

    int i;
    for (i = 0; i < MAX_SYMBOL_TABLE; ++ i) {
        symbol_table[i].data = NULL;
        symbol_table[i].next = NULL;
    }
}

void insertSymbol(symbol_node *p_symbol) {
    int index = hash_pjw(p_symbol->key);
    hash_node *new_node = (hash_node*)malloc(sizeof(hash_node));
    new_node->data = p_symbol;
    new_node->next = symbol_table[index].next;
    symbol_table[index].next = new_node;
}

symbol_node* getSymbol(char *name) {
    int index = hash_pjw(name);
    hash_node *p_node = symbol_table[index].next;
    while (p_node) {
        if (strcmp(name, p_node->data->key) == 0)
            return p_node->data;
        p_node = p_node->next;
    }
    return NULL;
}

