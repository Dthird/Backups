#ifndef _SEMANTIC_H_
#define _SEMANTIC_H_

extern void Program(int, syntax_tree_node*, syntax_tree_node**);
extern void ExtDefList(int, syntax_tree_node*, syntax_tree_node**);
extern void ExtDef(int, syntax_tree_node*, syntax_tree_node**);
extern void ExtDecList(int, syntax_tree_node*, syntax_tree_node**);
extern void Specifier(int, syntax_tree_node*, syntax_tree_node**);
extern void StructSpecifier(int, syntax_tree_node*, syntax_tree_node**);
extern void OptTag(int, syntax_tree_node*, syntax_tree_node**);
extern void Tag(int, syntax_tree_node*, syntax_tree_node**);
extern void VarDec(int, syntax_tree_node*, syntax_tree_node**);
extern void FunDec(int, syntax_tree_node*, syntax_tree_node**);
extern void VarList(int, syntax_tree_node*, syntax_tree_node**);
extern void ParamDec(int, syntax_tree_node*, syntax_tree_node**);
extern void CompSt(int, syntax_tree_node*, syntax_tree_node**);
extern void StmtList(int, syntax_tree_node*, syntax_tree_node**);
extern void Stmt(int, syntax_tree_node*, syntax_tree_node**);
extern void DefList(int, syntax_tree_node*, syntax_tree_node**);
extern void Def(int, syntax_tree_node*, syntax_tree_node**);
extern void DecList(int, syntax_tree_node*, syntax_tree_node**);
extern void Dec(int, syntax_tree_node*, syntax_tree_node**);
extern void Exp(int, syntax_tree_node*, syntax_tree_node**);
extern void Args(int, syntax_tree_node*, syntax_tree_node**);

extern int isEqual(Type*, Type*); 
extern void checkTypeMatch(syntax_tree_node*, syntax_tree_node**);
extern void printError(int type, int lineno, char *msg);

extern void SDT(syntax_tree_node*);

#endif