#ifndef _SYNTAX_TREE_H_
#define _SYNTAX_TREE_H_

#include "symbol_table.h"

typedef struct attribute_{
    Type *inh_type;				//继承属性
    Type *type;					//类型
    FieldList *structure;		//类型链表
    arg_node *args, *inh_args;	//参数链表
	Type *ret_type;				//返回值类型
	char *id;
	int is_legal;
    int is_definition;
    int is_declared;
	int is_in_struct;
} attribute;


typedef struct syntax_tree_node {
    char* name;
    struct syntax_tree_node *lchild, *nextSibling;
    union {
        int intValue;
        float floatValue;
        char* stringValue;
		//char* type;			//int or float
		basic_type type;
    } value; 
    int lineno;
	int isTerminator;		// 0 represents NO and 1 represents YES
	attribute attr;
}syntax_tree_node;

extern struct syntax_tree_node* createTokenNode(char *name);								
extern struct syntax_tree_node* createSyntaxNode(char* name, int childNumber, ...);			//Variable parameters
extern void traversalSyntaxTree(int spaceNumber, struct syntax_tree_node* p);				//based on DFS
extern void destorySyntaxTree(struct syntax_tree_node* p);								

struct syntax_tree_node* root;     

#endif
