#ifndef __SYMBOLTABLE_H_
#define __SYMBOLTABLE_H_

#include <malloc.h>
#include <string.h>

extern int intindex ;
extern int inttable[10000] ;
extern int floatindex ;
extern float floattable[10000] ;
extern int strindex  ;
extern char *strtable[10000] ;

int insinttab( int x ) ;
int getinttab( int ind );
int insfloattab( float x ) ;
float getfloattab( int ind ) ;
int insstrtab( char *s );
char *getstrtab( int ind ) ;

#endif


