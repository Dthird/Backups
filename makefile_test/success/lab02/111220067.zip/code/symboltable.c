#include "symboltable.h"

int intindex =0;
int inttable[10000] ;
int floatindex=0 ;
float floattable[10000] ;
int strindex = 0 ;
char *strtable[10000] ;

int insinttab( int x ) 
{
	if( intindex < 10000 )
	{
		inttable[intindex++] = x ;
		return intindex-1 ;
	}
	return -1 ;
}

int getinttab( int ind )
{
	return inttable[ind] ;
	return -1 ;
}

int insfloattab( float x )
{
	if( floatindex < 10000 )
	{
		floattable[floatindex++] = x ;
		return floatindex-1 ;
	}
	return -1 ;
}

float getfloattab( int ind )
{
	return floattable[ind] ;
	return -1;
}

int insstrtab( char *s )
{
	if( strindex < 10000 )
	{
		strtable[strindex++]=(char *)malloc(strlen(s)+1 );
		strcpy( strtable[strindex-1] , s );
		return strindex -1 ;
	}
	return -1;
}

char *getstrtab( int ind )
{
	return strtable[ind] ;
}



