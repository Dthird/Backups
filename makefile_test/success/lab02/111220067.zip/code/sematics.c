#include "sematics.h"

// global 
struct depthlist *curvarlist = NULL;
struct symboltable *hashtable[1<<14];

int anonymousstruct = 0; 

unsigned int mystrhash( char *name )
{
	unsigned int val = 0;
	unsigned int i; 
	for( ; *name ; ++ name )
	{
		val = ( val << 2 ) + *name;
		if((i = (val & (~0x3fff))))
		  	val = ((val ^(i >> 12)) & 0x3fff);
	}
	return val;
}

int initsymtable()
{
	memset( hashtable , 0 , sizeof(hashtable) );
	curvarlist = NULL;
	curvarlist = createdeplist();
	return 1;
}

struct depthlist *createdeplist()
{
	struct depthlist *p = (struct depthlist *)malloc( sizeof(struct depthlist));
	p->list = NULL;
	p->depth = NULL;
	p->list = curvarlist;
	return p;
}

void adddepthlist( struct depthlist *t)
{
	t->list=curvarlist;
	curvarlist = t;
}

struct symboltable *createsymtable()
{
	struct symboltable *t = (struct symboltable *)malloc(sizeof(struct symboltable));
	t->next = NULL;
	t->depth = NULL;
	t->name = NULL;
	t->data = NULL;
	t->size = t->type = 0;
	return t;
}

struct arrfield *createarrf()
{
	struct arrfield *t = (struct arrfield *)malloc( sizeof(struct arrfield));
	t->next = NULL;
	t->type = t->size = 0;
	return t;
}

struct symboltable *query( char *name ) 
{
	int index = mystrhash( name );
	struct symboltable *p = NULL;
	p = hashtable[index];
	
	for(  ; p != NULL ; p= p->next ) 
	{
		if( strcmp( name , p->name ) )
		  ;
		else
		{
			return p;
		}
	}
	return NULL ;
}

int delsym( struct symboltable *sym )
{
	int index = mystrhash( sym->name );
	struct symboltable *p = NULL , *q = NULL;
	p = hashtable[index];
	if( p == NULL ) 
	  return 0;
	if( sym == p )
	{
		q = p;
		hashtable[index] = p->next;
		free(q);
		return 1;
	}
	for( q=p, p=p->next; p != NULL ; q=p , p=p->next ) 
	{
		if( sym == p )
		{
			q->next = p->next;
			free(p);
			return 1;
		}
			
	} 	
	return 0;
}

int delsymlist()
{
	struct depthlist *dep = curvarlist;
	struct symboltable *p = NULL;
	
	while( dep->depth != NULL )
	{
		p = dep->depth;
		dep->depth = p->depth;
		delsym( p );
	}
	curvarlist = curvarlist->list;
	return 1;
}

void *sematicsearch( struct treenode *root , struct sem_args *data )
{
	if( root == NULL ) 
	  	return NULL;
	
	switch( root->type ) 
	{
		case  TYPE_Program :
			data = (struct sem_args *)malloc( sizeof(*data) );
			memset( data, 0 , sizeof(*data) );
			sematicsearch( root->ch[0] , data );
			break;
		
		case  TYPE_ExtDefList :						
			sematicsearch( root->ch[0] , data );
			sematicsearch( root->ch[1] , data );	
			break;
		
		case  TYPE_ExtDef : 
			if( root->ch[1]->type == TYPE_SEMI ) 
			{
				sematicsearch( root->ch[0] , data );
			}
			else if( root->ch[1]->type == TYPE_ExtDecList )
			{
				sematicsearch( root->ch[0] , data );
				data->kind = SEM_NONE;
				data->a = NULL;
				sematicsearch( root->ch[1] , data );
			}
			else if( root->ch[2]->type == TYPE_CompSt )
			{
				sematicsearch( root->ch[0] , data );
				struct sem_args *new_args = (struct sem_args *)malloc( sizeof( *data ) );
				struct depthlist *d =createdeplist();
				adddepthlist( d );
				sematicsearch( root->ch[1] , new_args );
				insertfunc( data->type , symtofuncarg() , new_args->name , 1 , root->linenum);
				free( new_args );
				data->rettype = data->type;
				sematicsearch( root->ch[2] , data );
				delsymlist();
			}
			else
			{
				sematicsearch( root->ch[0] , data );
				struct sem_args *new_args = (struct sem_args *)malloc( sizeof( *data ) );
								
				struct depthlist *d =createdeplist();
				adddepthlist( d );
				sematicsearch( root->ch[1] , new_args );	
				insertfunc( data->type , symtofuncarg() , new_args->name , 0 , root->linenum);
				delsymlist();
			}							
			break;

		case TYPE_ExtDecList :
			if( root->ch_num == 1 )
			{
				sematicsearch( root->ch[0] , data );
			}
			else
			{
				sematicsearch( root->ch[0] , data );
				sematicsearch( root->ch[2] , data );
			}
			break ;


		case TYPE_VarDec :
			if( root->ch_num == 1 )
			{
				if( data->kind == SEM_NONE  )
				{
					insertvar( data->type , getstrtab(root->context.x) , root->linenum , 1 );
					data->name = getstrtab(root->context.x);
				}
				else if( data->kind == SEM_STRUCT )
				{
					insertvar( data->type , getstrtab(root->context.x) , root->linenum , 0 );
					data->name = getstrtab(root->context.x);
				}
				else
				{
					insertarr( data->type ,  getstrtab(root->context.x) , data->a );
					data->name =  getstrtab(root->context.x);
				} 
				return NULL;
			}
			else   // array 
			{
				struct arrfield *t = createarrf();
				t->next = data->a;
				data->kind = SEM_ARR;
				data->a = t ;
				sematicsearch( root->ch[0] , data );
				return NULL;
			}
			break;

		case TYPE_Specifier : 
			if( root->ch[0]->type == TYPE_TYPE_INT )
			{
				data->type = "int" ;
			}
			else if( root->ch[0]->type == TYPE_TYPE_FLOAT )
			{
				data->type = "float";
			}
			else
			{
				sematicsearch( root->ch[0] , data );
			}
			break;

		case TYPE_StructSpecifier :
			if( root->ch_num == 2 )
			{
				data->type = getstrtab( root->ch[1]->context.x );
				struct symboltable *tt =query( getstrtab( root->ch[1]->ch[0]->context.x) );
				if( tt == NULL )
				{
					printf("Error type 17 at line %d: Undefined struct '%s'\n" , root->linenum ,  getstrtab( root->ch[1]->ch[0]->context.x) );
					break;
				}
			}
			else
			{
				data->type = NULL ;   // OPTtag may be null
				sematicsearch( root->ch[1] , data ) ;
				if( data->type == NULL )
				{
					data->type = getanonymousstruct();
				}
				data->kind = SEM_STRUCT;
				struct depthlist *d =createdeplist();
				adddepthlist( d );
				if( root->ch[3] == NULL )
				{
					insertstruct( data->type , NULL , root->linenum );
				}
				else
				{
					char *tmpname = data->type;
					sematicsearch( root->ch[3] , data );
					insertstruct( tmpname , symtostruct() , root->linenum );
					data->type = tmpname;
				}
				delsymlist();
			}	
			break ;

		case TYPE_OptTag :		
			if( root->ch[0]->type == TYPE_ID )
			{
				data->type = getstrtab(root->ch[0]->context.x);
			}
			else
			{
				erroroutput(); 
			}
			break ;

		case TYPE_DefList : 
			// not NULL
			sematicsearch( root->ch[0] , data );
			sematicsearch( root->ch[1] , data );
			break;

		case TYPE_Def :					
			sematicsearch( root->ch[0] , data );
			sematicsearch( root->ch[1] , data );	
			break;
	
		case TYPE_DecList :		
			if( root->ch_num == 1 )
			{
				sematicsearch( root->ch[0] , data );
			}
			else
			{
				int kindbackup = data->kind;
				sematicsearch( root->ch[0] ,data );
				data->kind = kindbackup;	
				sematicsearch( root->ch[2] , data );
			}
			break ;

		case TYPE_Dec :		
			if( root->ch_num == 1 ) 
			{
				sematicsearch( root->ch[0] , data );
			}
			else
			{
				if( data->kind == SEM_STRUCT ) 
				{
					printf("Error type 15 at line %d: Initized variable in struct\n" , root->ch[1]->linenum ); 
				}
				else
				{
					sematicsearch( root->ch[0] , data );
					struct sem_args *new_args = (struct sem_args *)malloc( sizeof(*data) );
					sematicsearch( root->ch[2] , new_args );
					if( equalcmp( data->type , new_args->type ) )
					{
						printf("Error type 5 at line %d: Type Mismatched\n", root->ch[1]->linenum );
					}

				}
			}
			break;

		case TYPE_FunDec :	
			if( root->ch_num == 4 )
			{
				sematicsearch( root->ch[2] , data ) ;
				data->name = getstrtab( root->ch[0]->context.x );
			}
			else
			{
				data->name = getstrtab( root->ch[0]->context.x );
			}
			break ;

		case TYPE_VarList :
			if( root->ch_num == 1 )
			{
				sematicsearch( root->ch[0] , data );
			}
			else
			{
				sematicsearch( root->ch[0] , data );
				sematicsearch( root->ch[2] , data );
			}
			break;

		case TYPE_ParamDec :				
			sematicsearch( root->ch[0] , data );
			data->kind = SEM_NONE;
			sematicsearch( root->ch[1] , data );
			break;

		case TYPE_CompSt :
			sematicsearch( root->ch[1] , data );
			sematicsearch( root->ch[2] , data );
			break;

		case TYPE_StmtList :
			sematicsearch( root->ch[0] , data );
			sematicsearch( root->ch[1] , data );
			break;

		case TYPE_Stmt :
			data->kind = SEM_NONE;
			if( root->ch_num == 2 ) 
			{
				sematicsearch( root->ch[0] , data );
			}
			else if( root->ch_num == 1 )
			{
				sematicsearch( root->ch[0] , data );
			}
			else if( root->ch_num == 3 )
			{
				sematicsearch( root->ch[1] , data );
				if( equalcmp( data->type , data->rettype ) )
				{
					printf("Error type 8 at line %d: The return type mismatched\n" , root->ch[0]->linenum );
				}
			}
			else if( root->ch[0]->type == TYPE_IF && root->ch_num == 5 )
			{
				data->kind = SEM_CMP;
				sematicsearch( root->ch[2] , data );
				data->kind = SEM_NONE ;
				sematicsearch( root->ch[4] , data );	
			}
			else if( root->ch[0]->type == TYPE_WHILE )
			{
				data->kind = SEM_CMP;
				sematicsearch( root->ch[2] , data );
				data->kind = SEM_NONE ;
				sematicsearch( root->ch[4] , data );
			}
			else if( root->ch[0]->type == TYPE_IF )
			{
				data->kind = SEM_CMP;
				sematicsearch( root->ch[2] , data );
				data->kind = SEM_NONE ;
				sematicsearch( root->ch[4] , data );
				sematicsearch( root->ch[6] , data );
			}
			else
			{
				erroroutput();
			}
			break;

		case TYPE_Exp :	
			if( data->type == NULL ) 
				data->type = "int" ;
			if( root->ch[0]->type == TYPE_LP ) 
			{
				sematicsearch( root->ch[0] , data );
			}
			else if( root->ch[0]->type == TYPE_ID && root->ch_num == 1 ) 
			{
				data->name =  getstrtab( root->ch[0]->context.x);
				struct symboltable *t =query( data->name );
				
				if( t == NULL )
				{
					printf("Error type 1 at line %d: Undefined variable \'%s\'\n" , root->linenum , data->name );
				}
				else 
				{
					if( t->type == SYM_VARINT )
					{
						data->type = "int";
					}
					else if( t->type == SYM_VARFLOAT )
					{
						data->type = "float";
					}				
					else
					{
						data->type = t->data;
					}
				}
			}
			else if( root->ch[0]->type == TYPE_INT )
			{
				data->type = "int";
			}
			else if( root->ch[0]->type == TYPE_FLOAT )
			{
				data->type = "float";
			}
			else if( root->ch[1]->type == TYPE_ASSIGNOP ) 
			{
				if( ( root->ch[0]->ch[0]->type == TYPE_ID  && root->ch[0]->ch_num == 1 ) || ( root->ch[0]->ch_num > 1 && ((root->ch[0]->ch[1]->type == TYPE_LB ) || (root->ch[0]->ch[1]->type == TYPE_DOT ) ) ) )
				{
					// xxxxxx   ch[0]->ch[1]  may not exist
					sematicsearch( root->ch[0] , data );
					char *type1 = data->type;
					sematicsearch( root->ch[1] , data );
					char *type2 = data->type;
					sematicsearch( root->ch[2] , data );
					if( equalcmp( data->type , type1 ) )
					{	
						printf("Error type 5 at line %d: Type mismatched\n" , root->ch[1]->linenum );
					}
				}
				else
				{
					printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable\n" , root->ch[1]->linenum);
				}
			}
			else if( root->ch[1]->type == TYPE_DOT )
			{
				sematicsearch( root->ch[0] , data );						
				struct symboltable *tt = query( data->name );
				if( tt == NULL )
				{
					printf("Error type 1 at line %d: Underined variable \'%s\'\n", root->ch[1]->linenum , data->name );
					break ;
				}
				if( !isvarstruct( tt ) )
				{
					if( isfunc( tt ) )
					{
						if( (( struct funclist *)(tt->data))->retval->type == SYM_STRUCT )
						{
							tt = query( (( struct funclist *)(tt->data))->retval->name );
						}
						else
						{
							printf("Error type 13 at line %d: Illegal use of '.'\n" , root->ch[1]->linenum );
							break;
						} 
					}
					else
					{
						printf("Error type 13 at line %d: Illegal use of '.'\n" , root->ch[1]->linenum );
						break;
					}
				}
				else 
				{
					if( !check_field( query(tt->data) , getstrtab( root->ch[2]->context.x) ) )
					{
						printf("Error type 14 at line %d: Un-existed field \'%s\'\n" , root->ch[1]->linenum , getstrtab( root->ch[2]->context.x) );
					}
				}			
				// xxxxxx  for function use
			}
			else if( root->ch[0]->type == TYPE_ID && root->ch_num == 3 ) 
			{
				struct symboltable *t = query( getstrtab(root->ch[0]->context.x) );
				if( t == NULL )
				{
					printf("Error type 2 at line %d: Undefined function '%s'\n" , root->linenum , getstrtab(root->ch[0]->context.x) );
					break;
				}
				if( !isfunc( t )  )
				{
					printf("Error type 11 at line %d: \'%s\' must be a function\n" , root->ch[1]->linenum , t->name  );
					break;
				}
				data->type = getfuncret( t ); 
				if( ((struct funclist *)t->data)->param == NULL )
					;
				else
				{
					printf("Error type 9 at line %d: The method '%s' is not applicable for the arguments\n" , root->linenum , t->name  );
					break;
				}
			}
			else if( root->ch[0]->type == TYPE_ID )
			{
				struct symboltable *t = query( getstrtab(root->ch[0]->context.x) );
				if( t == NULL )
				{
					printf("Error type 2 at line %d: Undefined function '%s'\n" , root->linenum , getstrtab(root->ch[0]->context.x) ) ;
					break;
				}
				if( !isfunc( t )  )
				{
					printf("Error type 11 at line %d: \'%s\' must be a function\n" , root->ch[1]->linenum , t->name  );
					break;
				}
				data->type = getfuncret( t ) ; 
				struct treenode *tmp = root->ch[2] ;
				struct funcfield *f = ((struct funclist *)(t->data))->param;
				while( f != NULL && tmp != NULL )
				{
					if( f->type == SYM_VARINT && tmp->ch[0]->type == TYPE_INT ) 
					{
						f=f->next;
						if( tmp->ch_num == 3)
							tmp = tmp->ch[2];
						else
							tmp = NULL;
					}
					else if( f->type == SYM_VARFLOAT && tmp->ch[0]->type == TYPE_FLOAT ) 
					{
						f = f->next;
						if( tmp->ch_num == 3)
							tmp = tmp->ch[2];
						else
							tmp = NULL;
					}
					else
					{
						printf("Error type 9 at line %d: The method '%s' is not applicable for the arguments\n" , root->linenum , t->name );
						return NULL;
					}
				}
				if( f != NULL || tmp != NULL )
				{
					printf("Error type 9 at line %d: The method '%s' is not applicable for the arguments\n" , root->linenum , t->name );
					break;
				}
			}
			else if( root->ch[0]->type == TYPE_NOT )
			{
				sematicsearch( root->ch[1] , data );
				if( strcmp( data->type , "int") )
					printf("Error type 7 at line %d: Operation type mismatched\n" , root->linenum );
			}
			else if( root->ch[1]->type == TYPE_AND || root->ch[1]->type == TYPE_OR ) 
			{
				sematicsearch( root->ch[0] , data );
				char *type1 = data->type;
				sematicsearch( root->ch[1] , data );
				char *type2 = data->type;
				sematicsearch( root->ch[2] , data );
				if( equalcmp( data->type , type1 ) )
				{					
					printf("Error type 5 at line %d: Type mismatched\n" , root->ch[1]->linenum );
				}
			}
			else if( root->ch[1]->type == TYPE_RELOP_EQ || root->ch[1]->type == TYPE_RELOP_NE || root->ch[1]->type == TYPE_RELOP_GE ||  root->ch[1]->type == TYPE_RELOP_GT || root->ch[1]->type == TYPE_RELOP_LT || root->ch[1]->type == TYPE_RELOP_LE  )
			{
				sematicsearch( root->ch[0] , data );
				if( !strcmp( data->type , "int" ) )
				{
					sematicsearch( root->ch[2] , data );
					if( !strcmp( data->type , "int" ) )
					{
						data->type = "int";
					}
					else
					{
						printf("Error type 7 at line %d: Operation type mismatched\n" , root->ch[1]->linenum );
					}
				}
			}
			else if( root->ch[1]->type == TYPE_PLUS || root->ch[1]->type == TYPE_MINUS ||  root->ch[1]->type == TYPE_STAR || root->ch[1]->type == TYPE_DIV || root->ch[0]->type == TYPE_MINUS )
			{
				sematicsearch( root->ch[0] , data );
				if( !strcmp( data->type , "int" ) )
				{
					sematicsearch( root->ch[2] , data );
					if( !strcmp( data->type , "int" ) )
					{
						data->type = "int";
					}
					else
					{
						printf("Error type 7 at line %d: Operation type mismatched\n" , root->ch[1]->linenum );
					}
				}
			}
			else if( root->ch[1]->type == TYPE_LB ) 
			{
				if( root->ch[0]->ch[0]->type != TYPE_ID )
				{
					printf("Error type 5 at line %d: type mismatched\n" , root->ch[1]->linenum );
					break;
				}
				struct symboltable *s = query( getstrtab( root->ch[0]->ch[0]->context.x ) );
				if( s == NULL ) 
				{
					printf("Error type 1 at line %d: Underined variable \'%s\'\n", root->ch[1]->linenum , getstrtab( root->ch[0]->ch[0]->context.x ) );
					break;
				}
				if( s->type != SYM_VARARR )
				{
					printf("Error type 10 at line %d: '%s' must be an array\n" , root->ch[1]->linenum , getstrtab( root->ch[0]->ch[0]->context.x ) );
					break;
				}
				data->name = getstrtab( root->ch[0]->context.x);
				sematicsearch( root->ch[2] , data );
				if( strcmp( data->type , "int" ) ) 
				{
					printf("Error type 12 at line %d: Operands type mistaken\n" , root->linenum );
				}
			}
			break;

		case TYPE_Args :     // never  the  ccome here 
			if( root->ch[0]->ch_num == 1 )
				;
			else
				;
			break;

		case TYPE_ID :	   // only come from  PLUS MINUS AND OR MULTI DIV															
			break;

		default : 
			break;
	}
	
	return NULL;
}


int insertvar( char *type , char *name , int line , int whestruct  )
{
	if( checkvar( name ) )
	{ 		
		if( whestruct == 1 ) 
		{
			printf("Error type 3 at line %d: Redefined variable '%s'\n" , line , name ); 
		}
		
		else if( whestruct == 0 )
		{
			printf("Error type 15 at line %d: Redefined filed '%s'\n" , line , name );
		}
		return 0; 
	} 

	struct symboltable *t =(struct symboltable *)malloc( sizeof(struct symboltable) ) ;
	t->name = name;
	if( !strcmp( type , "int") )
	{
		t->type = SYM_VARINT;
	}
	else if( !strcmp( type , "float" ) )
	{
		t->type = SYM_VARFLOAT;
	}
	else
	{
		t->type = SYM_VARSTRUCT;
		t->data = type;
	}
	insertsymtable( t );
	return 1;
}

struct symboltable *getvarsym(  char *type , char *name )
{
	struct symboltable *t =(struct symboltable *)malloc( sizeof(struct symboltable) );
	t->name = name;
	if( !strcmp( name , "int") )
	{
		t->type = SYM_VARINT;
	}
	else if( !strcmp( name , "float" ) )
	{
		t->type = SYM_VARFLOAT;
	}
	else
	{
		t->type = SYM_VARSTRUCT;
		t->data = type;
	}
	return t;

}

int insertsymtable( struct symboltable *t)
{
	int index = mystrhash( t->name );
	t->next = hashtable[ index ];
	hashtable[ index ] = t;
	
	t->depth = curvarlist->depth;
	curvarlist->depth = t;

	return 1;
}

int insertsymtablenext( struct symboltable *t)
{
	int index = mystrhash( t->name );
	t->next = hashtable[ index ];
	hashtable[ index ] = t;
	
	t->depth = curvarlist->list->depth;
	curvarlist->list->depth = t;

	return 1;

}


/**
  * get a string for anonymous struct 
  * from 1 to 
  */

char *getanonymousstruct()
{
	anonymousstruct ++;
	char buf[10];     
	sprintf( buf , "%d" , anonymousstruct );
	char *test = (char *)malloc( strlen(buf) + 1 );
	strcpy( test , buf );	
	return test;
}



struct structfield *symtostruct(  )
{
	struct structfield *f = NULL , *prev = NULL;
	struct symboltable *p = NULL;
	
	p= curvarlist->depth;

	while( p != NULL )
	{
		f = malloc( sizeof( *f ) );
		f->next = prev;
		f->size = p->size;
		f->type = p->type;
		f->name = p->name;
		f->data = p->data;
		prev = f;
		p= p->depth;
	}

	return f;
}

int insertstruct(char *name , struct structfield *t , int line )
{
	struct symboltable *tt  = query( name );
	int size = 0;
	if( tt != NULL )
	{
		if( tt->type == SYM_VARINT )
			printf("Error type 16 at line %d: Duplicate name '%s'\n" , line , name );
		else if( tt->type == SYM_VARFLOAT )
			printf("Error type 16 at line %d: Duplicate name '%s'\n" , line , name );
		else if( tt->type == SYM_FUNC || tt->type == SYM_FUNCDEC )
			printf("Error type 16 at line %d: Duplicate name '%s'\n" , line , name );
		else if( tt->type == SYM_STRUCT )
			printf("Error type 16 at line %d: Duplicate name '%s'\n" , line , name );
	}

	tt = (struct symboltable *)malloc( sizeof(struct symboltable) );
	tt->size = 0;
	tt->type = SYM_STRUCT;
	tt->name = name;    
	tt->data = t;
	if( t != NULL ) 
	{
		size  = t->size;
		while( t->next != NULL )
		{
			t = t->next;
			size += t->size;
		}
		tt->size = size; 
	}
	insertsymtablenext( tt );
	return 1;
}

int insertarr( char *type , char *name , struct arrfield *t ) 
{
	struct symboltable *tt =(struct symboltable *)malloc( sizeof(struct symboltable) );
	struct arrfield *swapt = NULL, *pret = NULL;
	int size = 0;
	tt->type = SYM_VARARR;
	tt->name = name;

	if( t == NULL )
	{
		erroroutput();
	}
	swapt = t;
	tt->data = swapt;
	t = swapt;
	size = t->size;
	while( t->next != NULL ) 
	{
		t = t->next;
		size *= t->size;
	}
	if( !strcmp( type , "int") )
	{
		t->type = SYM_VARINT ;
	}
	else if( !strcmp( type , "float" ) )
	{
		t->type = SYM_VARFLOAT ;
	}
	else
	{
		t->type = SYM_VARSTRUCT ;
		t->next = (struct arrfield *)type ;
	}
	tt->size = size ;
	insertsymtable( tt );
	return 1;
}


int insertfunc( char *ret , struct funcfield *f , char *name , int dec , int line ) 
{
	struct symboltable *tt = query( name );
	if( tt != NULL ) 
	{
		if( tt->type == SYM_FUNC && dec == 1 )
		{ 
			printf("Error type 4 at line %d: Redefined function \'func\'\n" , line ) ; 
			return 0 ; 
		}
		if( tt->type == SYM_FUNCDEC || ( tt->type == SYM_FUNC && dec == 0 ) )
		{

			struct funclist *ff = tt->data ;
			struct funcfield *fe = ff->retval ;
			if( fe == f ) 
			{
				;
			}
			else
			{	
				if( !strcmp( ret , "int" ) && fe->type != SYM_VARINT )
				{
					printf("Error type 4 at line %d: Redefined function \'func\'\n" , line ); 
					return 0; 
				}
				if( !strcmp( ret , "float" ) && fe->type != SYM_VARFLOAT )
				{
					printf("Error type 4 at line %d: Redefined function \'func\'\n" , line );	 
					return 0; 
				}
				if( fe->type == SYM_VARINT || fe->type == SYM_VARFLOAT ) 
				{
					printf("Error type 4 at line %d: Redefined function \'func\'\n" , line ); 
					return 0; 
				}
			}
			if( dec == 1 )
			{
				tt->type = SYM_FUNC;
			}
			return 1;
		}
		else
		{
			printf("Error type 4 at line %d: Redefined , confiict with former define\n" , line ); 
			return 0;
		}
	}

	tt =(struct symboltable *)malloc( sizeof(struct symboltable) );
	struct funclist *ss = (struct funclist * )malloc( sizeof(struct funclist ) );

	tt->data = ss;

	if( dec == 0 ) 
	{
		tt->type = SYM_FUNCDEC;
	}
	else
	{
		tt->type = SYM_FUNC;
	}

	tt->name = name;
	ss->retval = (struct funcfield *)malloc( sizeof(struct funcfield) );
	
	if( !strcmp( ret , "int") )
	{
		ss->retval->type = SYM_VARINT;
	}
	else if( !strcmp( ret , "float" ) )
	{
		ss->retval->type = SYM_VARFLOAT;
	}
	else
	{
		ss->retval->type = SYM_VARSTRUCT;
		ss->retval->data = ret;
	}

	ss->retval->next = NULL;
	ss->param = f;

	insertsymtablenext( tt );

	return 1;
}


struct funcfield *symtofuncarg()
{
	struct funcfield *f = NULL , *prev = NULL;
	struct symboltable *p = NULL;
	
	p= curvarlist->depth;

	while( p != NULL )
	{
		f = malloc( sizeof( *f ) );
		f->next = prev ;
		f->type = p->type;
		f->name = p->name;
		f->data = p->data;
		prev = f;
		p= p->depth;

	}

	return f;
}

int equalcmp( char *type1  , char *type2 )
{
	if( !strcmp( type1 , type2 )  )
	{
		return 0;
	}
	else
	{
		return 1;
	}

	erroroutput();
	return 0;
}

char *getfuncret( struct symboltable *t )
{
	struct symboltable *t1 = t;
	struct funclist *fu = t1->data;
	if( fu->retval->type == SYM_VARINT )
		return "int";
	else if( fu->retval->type ==  SYM_VARFLOAT )
		return "float";
	else 
		return fu->retval->data;
}

int check_field( struct symboltable *t , char *name )
{
	struct structfield *ss = t->data;
	while( ss!= NULL )
	{	
		if( !strcmp( name , ss->name ) )
		{	
			return 1;
		}
		ss = ss->next;
	}
	return 0;
}

char *get_field( struct symboltable *t , char *name ) 
{
	return NULL;
}

int isvarstruct( struct symboltable *t ) 
{
	if( t == NULL )
	{
		erroroutput();
		return 0;
	}
	if( t->type == SYM_VARSTRUCT )
		return 1;
	else
		return 0;
}

int isfunc( struct symboltable *t )
{
	if( t == NULL )
	{
		erroroutput();
		return 0;
	}
	if( t->type == SYM_FUNC || t->type == SYM_FUNCDEC ) 
	{
		return 1;
	}
	else 
	  return 0;
}

int checkvar( char *name )
{
	struct symboltable *t = query( name ) ;
	if( t == NULL ) 
	{
		return 0;
	}
	else 
	{	
		struct symboltable *tt = curvarlist->depth;
		while( tt != NULL )
		{
			if( tt == t )
			{
				return 1;
			}
			tt = tt->depth;
		}
	} 
	return 0;
}


