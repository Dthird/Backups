#ifndef __MYTREE_H_
#define __MYTREE_H_

#include <malloc.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "symboltable.h"

union datatype{
	float f ;
	int x;
	unsigned int i ;
	char *name ;
};

#define SYNTAX_TREE_CHILD 7
#define list_entry( ptr,type,member ) \
	((type *)((char *)ptr-(unsigned long)(offsetof(type,member))))

struct list_head
{
	struct list_head *next ;
	struct list_head *prev ;
};

struct mystack
{
	int num ;
	struct list_head stack ;
};

struct treenode{
	struct list_head list ;
	union datatype context;
	int type ;
	int linenum ;
	int ch_num ;
	struct treenode *ch[ SYNTAX_TREE_CHILD ] ;
} ;

extern struct treenode* globaltable[1000];

#define TYPE_INT			1
#define TYPE_FLOAT			2 
#define TYPE_ID				3
#define TYPE_SEMI			4
#define TYPE_COMMA			5   	/*  5  */
#define TYPE_ASSIGNOP			6
#define TYPE_RELOP_NE			7
#define TYPE_RELOP_EQ			8
#define TYPE_RELOP_GE			9
#define TYPE_RELOP_GT			10  	/*  10  */
#define TYPE_RELOP_LT			11
#define TYPE_RELOP_LE			12
#define TYPE_PLUS			13
#define TYPE_MINUS			14
#define TYPE_STAR			15	/*  15  */
#define TYPE_DIV			16
#define TYPE_AND			17
#define TYPE_OR				18
#define TYPE_DOT			19
#define TYPE_NOT			20	/*  20  */
#define TYPE_TYPE_INT			21
#define TYPE_TYPE_FLOAT			22
#define TYPE_NE				23
#define TYPE_LP				24
#define TYPE_RP				25	/*  25	*/
#define TYPE_LB				26
#define TYPE_RB				27
#define TYPE_LC				28
#define TYPE_RC				29
#define TYPE_STRUCT			30	/*  30	*/
#define TYPE_RETURN			31
#define TYPE_IF				32  
#define TYPE_ELSE			33
#define TYPE_WHILE			34

#define TYPE_TOKEN_LINE			35	/* end of all the tokens */

#define TYPE_Program			36
#define TYPE_ExtDefList			37	 
#define TYPE_ExtDef			38	
#define TYPE_Specifier			39
#define TYPE_StructSpecifier		40	/*  45	*/
#define TYPE_OptTag			41
#define TYPE_Tag			42	
#define TYPE_VarDec			43
#define TYPE_FunDec			44
#define TYPE_VarList			45	/*  45	*/
#define TYPE_ParamDec			46
#define TYPE_CompSt			47	
#define TYPE_StmtList			48
#define TYPE_Stmt			49
#define TYPE_DefList			50	/*  50	*/
#define TYPE_Def			51
#define TYPE_DecList			52	
#define TYPE_Dec			53
#define TYPE_Exp			54
#define TYPE_Args			55	/*  35	*/
#define TYPE_ExtDecList			56
#define TYPE_TOTAL_NUM			57 	/* the end */

#define  patreenodeinit( s , line , type , context  )   \
	{		\
		s->linenum = line;    \
		s->type = type ;           \
		s->context = context ;        \
		s->ch_num = 0 ;            \
	}

int mybuild( struct mystack *pastack , int num , struct treenode *s ) ;

extern struct treenode *createpatreenode( int line , int type , union datatype context ) ;

extern struct treenode treenoderoot ;

int copystrtodata( union datatype *d , char *s ) ;

int cuttheempty( struct treenode *root );

int midorder(  struct treenode *root , int d ) ;

int printbytype( int type ,  int index , int line ) ;

int mypush( struct mystack *m , struct list_head *l ) ;

extern struct list_head *mypop( struct mystack *m ) ;

// insert to the tail
int insert_tail( struct list_head *s , struct list_head *a);

// init the head of the list 
int listheadinit( struct list_head *s ) ;

// remove element from the tail
extern struct list_head *remove_tail( struct list_head *s) ;

#endif
