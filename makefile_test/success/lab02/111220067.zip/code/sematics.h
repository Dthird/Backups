#ifndef __SEMATICS_H_
#define __SEMATICS_H_

#include "mytree.h"
#include <memory.h>

#define erroroutput() printf(" my error  in file :%s ,func: %s ,line: %d \n ", __FILE__ ,  __func__ , __LINE__ ); 


//#define SYM_VAR			1
#define SYM_FUNC		2
#define SYM_STRUCT		3
#define SYM_FUNCDEC		4

#define SYM_VARSTRUCT		5
#define SYM_VARINT		6
#define SYM_VARFLOAT		7
#define SYM_VARARR		8

struct symboltable
{
	struct symboltable *next;
	struct symboltable *depth;  	// means the stack depth
	int size;    	// how many bytes this token , none for var  function
	int type;    	// function  varible 
	char *name;
	void *data;   	//  structtype  variabletype functype
};

struct structfield
{
	struct structfield *next ;
	int size;
	char *name;
	int type;
	void *data;
};

struct variable
{
	union 
	{
		int i;
		float f;
	}data;
};

struct arrfield
{
	struct arrfield *next;
	int type;
	int size;
};

struct funclist
{
	struct funcfield *retval;
	struct funcfield *param;
};

struct funcfield
{
	struct funcfield *next;
	char *name;
	int type;
	void *data;
};

struct depthlist{
	struct depthlist *list;
	struct symboltable *depth;

};

int initsymtable();
int insertsymtable(struct symboltable *t);
int insertsymtablenext(struct symboltable *t );
int delsymlist();
int delsym(struct symboltable *sym );

struct symboltable *query(char *name);
struct depthlist *createdeplist();   
void adddepthlist(struct depthlist *t);
struct symboltable *createsymtable();
struct arrfield *createarrf();

struct sem_args
{
	int kind ;
	char *type ;
	struct arrfield *a ;
	char *name ;
	char *rettype ;
};

#define SEM_NONE		0
#define SEM_ARR			1
#define SEM_STRUCT		2
#define SEM_CMP			3

//  语义分析函数
void *sematicsearch(struct treenode *root, struct sem_args *data);

int insertsymtable(struct symboltable *t);

int insertvar(char *type, char *name, int line, int whestruct);
struct symboltable *getvarsym(char *type, char *name) ;

int insertarr(char *type, char *name, struct arrfield *t);
struct symboltable *getarrsym(char *type, char *name, struct arrfield *t);

int insertfunc(char *ret, struct funcfield *f, char *name, int dec, int line);

int insertstruct(char *name, struct structfield *t, int line);

struct structfield *symtostruct();
struct funcfield *symtofuncarg();

extern struct depthlist *curvarlist;
extern struct symboltable *hashtable[1<<14] ;

char *getanonymousstruct();

// cmp 
int equalcmp(char *type1, char *type2) ;

char *getfuncret(struct symboltable *t);

int check_field(struct symboltable *t, char *name);
char *get_field(struct symboltable *t, char *name);

int isvarint(struct symboltable *t);
int isvarfloat() ;
int isvararr(char *name);

int isvarstruct(struct symboltable *t);
int isfunc(struct symboltable *t);

int checkvar(char *name);

int finalcheck(struct treenode *root);

// for test 
unsigned int mystrhash( char *name )  ;

int checksymtable() ;


#endif

