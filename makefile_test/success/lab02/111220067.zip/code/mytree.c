#include "mytree.h"

struct treenode treenoderoot ;
struct treenode* globaltable[1000] ;

/**
  * @ num 表示 0 移入或者从空规约  还是 >0 规约  <0 用于处理特殊情况
  * 
  */

int mypush( struct mystack *m , struct list_head *l ) 
{
	m->num ++ ;
	insert_tail( &m->stack  , l ) ;
	return 0 ;
}

struct list_head *mypop( struct mystack *m )
{
	if( m->num <= 0 )
	{
		printf("the stack is empty\n");
		return NULL ;
	}
	m->num -- ;
	return remove_tail( &m->stack ) ;
}

int insert_tail( struct list_head *s , struct list_head *a)
{
	a->next = s ;
	a->prev = s->prev ;
	s->prev->next = a ;
	s->prev = a ;
	return 0;
}

int insert_head( struct list_head *s , struct list_head *a )
{
	a->next = s->next ;
	s->next = a ;
	a->next->prev = a ;
	a->prev = s ;
	return 0 ;
}

int listheadinit( struct list_head *s )
{
	s->prev = s ;
	s->next = s ;
	return 0;
}

struct list_head *remove_tail( struct list_head *s)
{

	struct list_head *t = s->prev ;
	s->prev = t->prev ;
	t->prev->next = s ;
	return t ;
}

int mybuild( struct mystack *pastack , int num , struct treenode *s )
{
	if( num == -8 )    // -1  no sense
	{	
		struct treenode *s = createpatreenode( 0 , TYPE_ExtDecList , (union datatype)0 );
		s->ch_num = 3 ;
		s->ch[2] = list_entry( mypop( pastack ) , struct treenode , list ) ;
		s->ch[1] = createpatreenode( 0 , TYPE_COMMA , (union datatype)0 ) ;
		s->ch[0] = list_entry( mypop( pastack ) , struct treenode , list ) ;
		return 0 ;
	}
	if( num == -11 )
	{

		struct treenode *s = createpatreenode( 0 , TYPE_ExtDecList , (union datatype)0 );
		s->ch_num = 5 ;
		s->ch[4] = createpatreenode( 0 , TYPE_RC , (union datatype)0 ) ;
		s->ch[3] = list_entry( mypop( pastack ) , struct treenode , list ) ;
		s->ch[2] = createpatreenode( 0 , TYPE_LC , (union datatype)0 ) ;
		s->ch[1] = list_entry( mypop( pastack ) , struct treenode , list ) ;
		s->ch[0] = createpatreenode( 0 , TYPE_STRUCT , (union datatype)0 ) ;
		return 0 ;
	}
	if( num == 0 )   //  insert
	{
		mypush( pastack , &(s->list) ) ;
		return 0 ;
	}
	else
	{
		struct treenode *a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
		switch( num)
		{
			case 1:	s->ch_num = 1 ;
					s->ch[0] = a1 ;
					break ;
			case 2: s->ch_num = 2 ;
					s->ch[1] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[0] = a1 ;
					break ;
			case 3: s->ch_num = 3 ;
					s->ch[2] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[1] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[0] = a1 ;
					break ;
			case 4: s->ch_num = 4 ;
					s->ch[3] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[2] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[1] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[0] = a1 ;
					break ;
			case 5: s->ch_num = 5 ;
					s->ch[4] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[3] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[2] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[1] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[0] = a1 ;
					break ;
			case 6: s->ch_num = 7 ;
					s->ch[5] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[4] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[3] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[2] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[1] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[0] = a1 ;
					break ;
			case 7: s->ch_num = 7 ;
					s->ch[0] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[1] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[2] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[3] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[4] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[5] = a1 ;
					a1 = list_entry( mypop( pastack ) , struct treenode , list ) ;
					s->ch[6] = a1 ;
					break ;
			default :	printf(" the child is %d  more than %d\n", num , SYNTAX_TREE_CHILD ) ;
						exit(-1);
		}
		mypush( pastack , &s->list ) ;

		
	}
	return 0 ;
}

struct treenode *createpatreenode( int line , int type , union datatype context )
{
	struct treenode *s = (struct treenode *)malloc( sizeof( struct treenode ) ) ;
	s->linenum = line ;
	s->type = type ;
	s->ch_num = 0;
	s->context = context ;
	return s ;
}



int copystrtodata( union datatype *d , char *s )
{
	d->name =(char *)malloc( strlen(s) +1) ;
	if( d->name <= 0 )
	{
		printf(" error  in file :%s ,func: %s ,line: %d\n ", __FILE__ ,  __func__ , __LINE__ );
		return -1;
	}
	strcpy( d->name , s );
	return 1 ;
}


int cuttheempty( struct treenode *root )
{
	return 0 ;
}

int midorder( struct treenode *root , int d )
{
	int i;
	if( root == NULL )
	  return -1 ;
	for(i=0;i<d ; i ++ )
	  printf("  ");
	printbytype( root->type , root->context.x ,root->linenum );
	for( i=0;i<root->ch_num ; i ++ )
	{
		midorder( root->ch[i] , d +1);
	}
	return 0;
}

int printbytype( int type , int index , int line )
{
	switch( type ) 
	{
		case  TYPE_INT : printf("INT: %d\n" , getinttab(index) ); break ;
		case  TYPE_FLOAT : printf("FLOAT: %f\n" , getfloattab(index) ); break ;
		case  TYPE_ID : printf("ID: %s\n" , getstrtab(index) ); break ;
		case  TYPE_SEMI : printf("SEMI\n"); break ;
		case  TYPE_COMMA : printf("COMMA\n"); break ;
		case  TYPE_ASSIGNOP : printf("ASSIGNOP\n"); break ;
		case  TYPE_RELOP_NE : printf("NE\n"); break ;
		case  TYPE_RELOP_EQ : printf("EQ\n"); break ;
		case  TYPE_RELOP_GE : printf("GE\n"); break ;
		case  TYPE_RELOP_GT : printf("GT\n"); break ;
		case  TYPE_RELOP_LT : printf("LT\n"); break ;
		case  TYPE_RELOP_LE : printf("LE\n"); break ;
		case  TYPE_PLUS : printf("PLUS\n"); break ;
		case  TYPE_MINUS : printf("MINUS\n"); break ;
		case  TYPE_STAR : printf("STAR\n"); break ;
		case  TYPE_DIV : printf("DIV\n"); break ;
		case  TYPE_AND : printf("AND\n"); break ;
		case  TYPE_OR : printf("OR\n"); break ;
		case  TYPE_DOT : printf("DOT\n"); break ;
		case  TYPE_NOT : printf("NOT\n"); break ;
		case  TYPE_TYPE_INT : printf("TYPE: int\n"); break ;
		case  TYPE_TYPE_FLOAT : printf("TYPE: float\n"); break ;
		case  TYPE_LP : printf("LP\n"); break ;
		case  TYPE_RP : printf("RP\n"); break ;
		case  TYPE_LB : printf("LB\n"); break ;
		case  TYPE_RB : printf("RB\n"); break ;
		case  TYPE_LC : printf("LC\n"); break ;
		case  TYPE_RC : printf("RC\n"); break ;
		case  TYPE_STRUCT : printf("STRUCT\n"); break ;
		case  TYPE_RETURN : printf("RETURN\n"); break ;
		case  TYPE_IF : printf("IF\n"); break ;
		case  TYPE_ELSE : printf("ELSE\n"); break ;
		case  TYPE_WHILE : printf("WHILE\n"); break ;
		case  TYPE_Program : printf("Program  (%d)\n",line ); break ;
		case  TYPE_ExtDefList : printf("ExtDefList  (%d)\n",line ); break ;
		case  TYPE_ExtDef : printf("ExtDef  (%d)\n",line ); break ;
		case  TYPE_Specifier : printf("Specifier  (%d)\n",line ); break ;
		case  TYPE_StructSpecifier : printf("StructSpecifier  (%d)\n",line ); break ;
		case  TYPE_OptTag : printf("OptTag  (%d)\n",line ); break ;
		case  TYPE_Tag : printf("Tag  (%d)\n",line ); break ;
		case  TYPE_VarDec : printf("VarDec  (%d)\n",line ); break ;
		case  TYPE_FunDec : printf("FunDec  (%d)\n",line ); break ;
		case  TYPE_VarList : printf("VarList  (%d)\n",line ); break ;
		case  TYPE_ParamDec : printf("ParamDec  (%d)\n",line ); break ;
		case  TYPE_CompSt : printf("CompSt  (%d)\n",line ); break ;
		case  TYPE_StmtList : printf("StmtList  (%d)\n",line ); break ;
		case  TYPE_Stmt : printf("Stmt  (%d)\n",line ); break ;
		case  TYPE_DefList : printf("DefList  (%d)\n",line ); break ;
		case  TYPE_Def : printf("Def  (%d)\n",line ); break ;
		case  TYPE_DecList : printf("DecList  (%d)\n",line ); break ;
		case  TYPE_Dec : printf("Dec  (%d)\n",line ); break ;
		case  TYPE_Exp : printf("Exp  (%d)\n",line ); break ;
		case  TYPE_Args : printf("Args  (%d)\n",line ); break ;
		case  TYPE_ExtDecList : printf("ExtDecList  (%d)\n",line ); break ;
		case  TYPE_TOTAL_NUM : printf("TOTAL_NUM %d\n", TYPE_TOTAL_NUM); break ;
		default : printf("error :  other type-----\n");
	}
	return 0 ;
}


