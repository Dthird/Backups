#ifndef SYMBOL_H
#define SYMBOL_H

#define MAX_TYPE 100
#define MAX_FUNCTION 100
#define MAX_VARIABLE 100
#define MAX_VARIABLE_STACK 100

#include "util.h"

typedef struct Type_* Type; 
typedef struct FieldList_* FieldList; 
typedef struct Function_* Function;
typedef struct Variable_* Variable;
typedef struct Struct_* Struct;
typedef struct syntaxNode* Node;

struct FieldList_ 
{ 
	char* name; // 域的名字 
	Type type; // 域的类型 
	FieldList tail; // 下一个域 
};

typedef struct Type_ 
{ 
	enum { BASIC, ARRAY, STRUCTURE, FUNCTION, UNKNOWN} kind; 
	union 
	{ 
		// 基本类型 
		enum { INT_, FLOAT_ } basic; 
		// 数组类型信息包括元素类型与数组大小构成 
		struct { Type elem; int size; } array; 
		// 结构体类型信息是一个链表 
		FieldList structure; 

		FieldList function;
	} u; 
}Type_; 

Type typeList[MAX_TYPE]; //类型表
int typeCnt;

/*struct Function_
{
	char* name;
	Type returnType; //返回类型
	int argc; //参数个数
	char** argv; //参数名
	Type* argType; //参数类型
};
*/

FieldList functionList[MAX_FUNCTION]; //函数表
int functionDefined[MAX_FUNCTION];
int functionDecLineNum[MAX_FUNCTION];
int functionCnt;

struct Variable_
{
	char* name;
	Type type; //基本类型和数组直接malloc，结构类型到类型表中查找
};

Variable variableList;
int variableCnt,variableTop;
int variableStack[MAX_VARIABLE_STACK];

/*******************************************************************/

Type functionType;
FieldList fieldList,varList;
int assignInDec;
void semanticAnalysis(Node);
void insertFunction(Node,int);
//flag：1 定义  
//      0 声明 
void insertType(Node);
void insertVariable(Node,char *);
void insertVarList(Node, char *);
void insertField(Node,char *);

int typeCheck(Type,Type); // 0表示不同，1表示相同
int fieldListCheck(FieldList,FieldList); //同上
void functionDecCheck();
Type functionCheck(Node);
Type findVariableById(Node,char *);
Type findTypeById(Node,char *);
FieldList findFunctionById(Node,char *);
void printType(Type);

void initial();
#endif