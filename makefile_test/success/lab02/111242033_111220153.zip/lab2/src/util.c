#include "util.h"

void yyerror(char *msg)
{
	errorFound=1;
    printf("Error type B at line %d: Syntax error\n", yylineno);
}

extern void output(struct syntaxNode *p,int d)
{
	if (strlen(p->token)==0)
		return;
	int i;
	for (i=0;i<d;i++)
		printf("  ");
	printf("%s",p->token);
	if (p->cnt==0)
	{
		if (p->tokenType==ID||p->tokenType==TYPE)
		{
			printf(": %s\n",p->content);
			return;
		}
		else if (p->tokenType==INT)
		{
			printf(": %d\n",p->iValue);
			return;
		}
		else if (p->tokenType==FLOAT)
		{
			printf(": %f\n",p->fValue);
			return;
		}
		else
		{
			printf("\n");
			return;
		}
	}
	else
	{
		printf(" (%d)\n", p->first_line);
		for (i=0;i<p->cnt;i++)
			output(p->childs[i],d+1);
	}
}
