#include <stdlib.h>
#include <stdio.h>
#include "symbol.h"
#include "util.h"

void initial()
{
	typeCnt = 1;
	typeList[0]=malloc(sizeof(struct Type_));
	typeList[0]->kind=UNKNOWN;

	fieldList=NULL;
	varList=NULL;
	memset(functionDefined, sizeof(functionDefined), 0);
	functionCnt = 0;

	memset(variableStack, sizeof(variableStack), 0);
	variableList = malloc(sizeof(struct Variable_) * MAX_VARIABLE);
	variableStack[0] = 0;
	variableCnt = 0;
	variableTop = 1;

	typeCnt=0;

	assignInDec=0;
}

void semanticAnalysis(Node root)
{
	//printf("%s %d\n",root->token,root->elementNum);

	if(root->cnt == 0)   //词法单元
	{
		return;
	}
	else            //语法单元
	{
		switch(root->elementType)
		{
			case Program:
			{
				semanticAnalysis(root->childs[0]);
				break;
			}
			case ExtDefList:
			{
				switch(root->elementNum)
				{
					case 0: 
					{
						semanticAnalysis(root->childs[0]);
						semanticAnalysis(root->childs[1]);
						break;
					}
					case 1: break;
				}
				break;
			}
			case ExtDef:
			{
				switch(root->elementNum)
				{
					case 0: 
					{
						semanticAnalysis(root->childs[0]);
						*root->type=*root->childs[0]->type;
						*root->childs[1]->type=*root->type;
						semanticAnalysis(root->childs[1]);
						break;	
					}
					case 1: 
					{
						semanticAnalysis(root->childs[0]);
						break;
					}
					case 2:
					{
						semanticAnalysis(root->childs[0]);
						*root->type=*root->childs[0]->type;
						functionType=root->type;
						*root->childs[1]->type=*root->type;
						//push stack
						variableStack[variableTop++] = variableCnt;
						semanticAnalysis(root->childs[1]);
						semanticAnalysis(root->childs[2]);
						insertFunction(root->childs[1],1);
						break;
					}
					case 3:
					{
						semanticAnalysis(root->childs[0]);
						*root->type=*root->childs[0]->type;
						functionType=root->type;
						*root->childs[1]->type=*root->type;
						//push stack
						variableStack[variableTop++] = variableCnt;
						semanticAnalysis(root->childs[1]);
						//pop stack
						variableCnt = variableStack[--variableTop];
						insertFunction(root->childs[1],0);
						break;
					}
				}
				break;
			}
			case ExtDecList: 
			{
				switch (root->elementNum)
				{
					case 0:
					{
						*root->childs[0]->type=*root->type;
						semanticAnalysis(root->childs[0]);
						break;
					}
					case 1:
					{
						*root->childs[0]->type=*root->type;
						semanticAnalysis(root->childs[0]);
						*root->childs[2]->type=*root->type;
						semanticAnalysis(root->childs[2]);
						break;
					}
				}
				break;
			}
			case Specifier:
			{
				switch (root->elementNum)
				{
					case 0: 
					{
						*root->type=*root->childs[0]->type;
						break;
					}
					case 1:
					{
						semanticAnalysis(root->childs[0]);
						*root->type=*root->childs[0]->type;
						break;
					}
				}
				break;
			}
			case StructSpecifier:
			{
				switch (root->elementNum)
				{
					case 0:
					{
						FieldList f=fieldList;
						root->type->kind=STRUCTURE;
						root->type->u.structure=malloc(sizeof(struct FieldList_));
						fieldList=root->type->u.structure;
						fieldList->tail=NULL;
						if (root->childs[1]->elementNum==0)
							fieldList->name = root->childs[1]->childs[0]->content;
						else
							fieldList->name = NULL;
						fieldList->type=root->type;
						semanticAnalysis(root->childs[3]);
						fieldList=f;
						insertType(root);
						break;
					}
					case 1: 
					{
						Type t;
						t=findTypeById(root,root->childs[1]->childs[0]->content);
						if (t==NULL)
						{
							errorFound=1;
							printf("Error type 17 at line %d: Undefined struct '%s'\n",root->first_line,root->childs[1]->childs[0]->content);
							root->type->kind=UNKNOWN;
						}
						else
							*root->type=*t;
						break;
					}
				}
				break;
			}	

		
			case VarDec:
			{
				switch (root->elementNum)
				{
					case 0:
					{
						if (fieldList==NULL&&varList==NULL)
							insertVariable(root,root->childs[0]->content);
						else if (fieldList!=NULL)
							insertField(root,root->childs[0]->content);
						else
						{
							insertVariable(root,root->childs[0]->content);
							insertVarList(root,root->childs[0]->content);
						}
						break;
					}
					case 1:
					{
						root->childs[0]->type->kind=ARRAY;
						root->childs[0]->type->u.array.elem=root->type;
						root->childs[0]->type->u.array.size=root->childs[2]->iValue;
						semanticAnalysis(root->childs[0]);
						break;
					}
				}
				break;
			}
			case FunDec:
			{
				switch (root->elementNum)
				{
					case 0:
					{
						FieldList f=varList;
						root->type->kind=FUNCTION;
						root->type->u.function=malloc(sizeof(struct FieldList_));
						varList=root->type->u.function;
						varList->name = root->childs[0]->content;
						varList->type=functionType;
						varList->tail=NULL;
						semanticAnalysis(root->childs[2]);
						varList=f;
						break;
					}
					case 1:
					{
						root->type->kind=FUNCTION;
						root->type->u.function=malloc(sizeof(struct FieldList_));
						root->type->u.function->name=root->childs[0]->content;
						root->type->u.function->type=functionType;
						root->type->u.function->tail=NULL;
						break;
					}
				}
				break;
			}
			case VarList:
			{
				switch (root->elementNum)
				{
					case 0:
					{
						semanticAnalysis(root->childs[0]);
						semanticAnalysis(root->childs[2]);
						break;
					}
					case 1:
					{
						semanticAnalysis(root->childs[0]);
						break;
					}
				}
				break;
			}	
			case ParamDec:
			{
				semanticAnalysis(root->childs[0]);
				*root->type=*root->childs[0]->type;
				*root->childs[1]->type=*root->type;
				semanticAnalysis(root->childs[1]);
				break;
			}
			case CompSt:
			{
				semanticAnalysis(root->childs[1]);
				semanticAnalysis(root->childs[2]);
				variableCnt = variableStack[--variableTop];
				//pop stack
				break;
			}
			case StmtList:
			{
				switch(root->elementNum)
				{
					case 0:
					{
						semanticAnalysis(root->childs[0]);
						semanticAnalysis(root->childs[1]);
						break;
					}
					case 1: break;
				}
				break;
			}
			case Stmt:
			{
				switch(root->elementNum)
				{
					case 0:
					{
						semanticAnalysis(root->childs[0]);//exp == NULL？
						break;
					}
					case 1: 
					{
						//puch stack
						variableStack[variableTop++] = variableCnt;
						semanticAnalysis(root->childs[0]);
						break;
					}
					case 2:
					{
						semanticAnalysis(root->childs[1]);//检查exp是否为NULL
						if(!typeCheck(functionType,root->childs[1]->type))
						{
							errorFound=1;
							printf("Error type 8 at line %d: The return type mismatched\n", root->first_line);
						}
						break;
					}
					case 3:
					{
						semanticAnalysis(root->childs[2]); //对以下7个函数调用添加exp检查语句
						semanticAnalysis(root->childs[4]);
						break;
					}
					case 4:
					{
						semanticAnalysis(root->childs[2]);
						semanticAnalysis(root->childs[4]);
						semanticAnalysis(root->childs[6]);
						break;
					}
					case 5:
					{
						semanticAnalysis(root->childs[2]);
						semanticAnalysis(root->childs[4]);
						break;
					}
				}
				break;
			}
			case DefList:
			{
				switch(root->elementNum)
				{
					case 0: 
					{
						semanticAnalysis(root->childs[0]);
						semanticAnalysis(root->childs[1]);
						break;
					}
					case 1: break;
				}
				break;
			}
			case Def:
			{
				semanticAnalysis(root->childs[0]);
				*root->type=*root->childs[0]->type;
				*root->childs[1]->type=*root->type;
				semanticAnalysis(root->childs[1]);
				break;
			}
			case DecList:
			{
				switch (root->elementNum)
				{
					case 0:
					{
						*root->childs[0]->type=*root->type;
						semanticAnalysis(root->childs[0]);
						break;
					}
					case 1:
					{
						*root->childs[0]->type=*root->type;
						semanticAnalysis(root->childs[0]);
						*root->childs[2]->type=*root->type;
						semanticAnalysis(root->childs[2]);
						break;
					}
				}
				break;
			}
			case Dec:
			{
				switch (root->elementNum)
				{
					case 0:
					{
						*root->childs[0]->type=*root->type;
						semanticAnalysis(root->childs[0]);
						break;
					}
					case 1:
					{
						*root->childs[0]->type=*root->type;
						assignInDec=1;
						semanticAnalysis(root->childs[0]);
						semanticAnalysis(root->childs[2]);
						assignInDec=0;
						if (!typeCheck(root->type,root->childs[2]->type))
						{
							errorFound=1;
							printf("Error type 5 at line %d: Type mismatched\n", root->first_line);
						}
						break;
					}
				}
				break;
			}
			case Exp:
			{
				Type t1,t2,t3,t4;

				switch(root->elementNum)
				{
					case 0:
					{
						semanticAnalysis(root->childs[0]);
						semanticAnalysis(root->childs[2]);
						if (root->childs[0]->elementNum<13||root->childs[0]->elementNum>15)
						{
							errorFound=1;
							printf("Error type 6 at line %d: The left-hand side of an assignment must be a variable \n", root->first_line);
							root->type->kind=UNKNOWN;
							break;
						}
						if (typeCheck(root->childs[0]->type,root->childs[2]->type))
						{
							*root->type=*root->childs[0]->type;
						}
						else
						{
							if (root->childs[0]->type!=NULL&&root->childs[0]->type->kind!=UNKNOWN&&root->childs[2]->type!=NULL&&root->childs[2]->type->kind!=UNKNOWN)
							{
								printf("Error type 5 at line %d: Type mismatched\n", root->first_line);
								errorFound=1;
							}
							root->type->kind=UNKNOWN;
						}
						break;
					}
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
					{
						semanticAnalysis(root->childs[0]);
						semanticAnalysis(root->childs[2]);
						if(typeCheck(root->childs[0]->type,root->childs[2]->type))
						{
							*root->type=*root->childs[0]->type;
						}
						else
						{
							if (root->childs[0]->type->kind!=UNKNOWN && root->childs[2]->type->kind!=UNKNOWN)
							{
								errorFound=1;
								printf("Error type 7 at line %d: Operands type mismatched\n", root->first_line);
							}
							root->type->kind=UNKNOWN;
						}
						break;
					}
					case 8: 
					case 9:
					case 10:
					{
						semanticAnalysis(root->childs[1]);
						*root->type=*root->childs[1]->type;
						break;
					}
					case 11: 
					case 12:
					{
						Type t=functionCheck(root);
						if (t==NULL)
						{
							root->type->kind=UNKNOWN;
						}
						else
							*root->type=*t;
						break;
					}
					case 13:
					{
						semanticAnalysis(root->childs[0]);
						semanticAnalysis(root->childs[2]);
						if (root->childs[2]->type->kind!=BASIC || root->childs[2]->type->u.basic!=INT_)
						{
							errorFound=1;
							printf("Error type 12 at line %d: Operands type mistaken\n",root->first_line);
						}
						if (root->childs[0]->type->kind!=ARRAY)
						{
							errorFound=1;
							printf("Error type 10 at line %d: \"",root->first_line);
							Node n=root->childs[0];
							int i=0;
							while (n->elementNum==13)
							{
								n=n->childs[0];
								i++;
							}
							printf("%s",n->childs[0]->content);
							while (i>0)
							{
								printf("[]");
								i--;
							}
							printf("\" must be an array\n");
						}
						else
						{
							*root->type=*root->childs[0]->type->u.array.elem;
						}
						break;							
					}
					case 14:
					{
						semanticAnalysis(root->childs[0]);
						if (root->childs[0]->type->kind!=STRUCTURE)
						{
							errorFound=1;
							printf("Error type 13 at line %d: Illegal use of \".\"\n",root->first_line);
							root->type->kind=UNKNOWN;
							break;
						}
						FieldList t5 = root->childs[0]->type->u.structure->tail;
						while(t5!= NULL)
						{
							if(!strcmp(t5->name,root->childs[2]->content))
							{
								*root->type=*t5->type;
								break;
							}
							else
								t5 = t5->tail;
						}
						if (t5==NULL)
						{
							errorFound=1;
							printf("Error type 14 at line %d: Un-existed field \"%s\"\n",root->first_line,root->childs[2]->content);
							root->type->kind=UNKNOWN;
						}
						break;
					}
					case 15:
					{
						*root->type=*findVariableById(root,root->childs[0]->content);
						break;
					}
					case 16:
					case 17:
					{
						*root->type=*root->childs[0]->type;
						break;
					}
				}
				break;
			}
			case Args:
			{
				switch (root->elementNum)
				{
					case 0:
					{
						semanticAnalysis(root->childs[0]);
						semanticAnalysis(root->childs[2]);
						break;
					}
					case 1:
					{
						semanticAnalysis(root->childs[0]);
						break;						
					}
				}
				break;	
			}
		}
	}
}

void insertFunction(Node node, int flag)
{
	char* id;
	id = node->type->u.function->name;
	int i;
	for(i = 0 ;i < functionCnt ;i++ )
	{
		if(!strcmp(functionList[i]->name,id))
			break;
	}
	if(i == functionCnt)
	{
		functionList[i] = node->type->u.function;
		functionDefined[i] = flag;
		functionDecLineNum[i]=node->first_line;
		functionCnt ++;
		return;
	}
	if(flag == 1 && functionDefined[i] == 1)
	{
		errorFound=1;
		printf("Error type 4 at line %d: Redefined function \"%s\"\n",node->first_line,id);
		return;
	}
	if(fieldListCheck(functionList[i], node->type->u.function))
	{
		functionDefined[i] |= flag;
		return;
	}
	errorFound=1;
	printf("Error type 19 at line %d: Inconsistent declaration of function \"%s\"\n",node->first_line,id);
	return;

}

void insertType(Node node)
{
	int i;
	Type t=node->type;
	char *name=t->u.structure->name;
	int renamed=0;
	if (strcmp(name,""))
	{
		for (i=0;i<typeCnt;i++)
		{
			if (typeList[i]->kind==STRUCTURE&&!strcmp(name,typeList[i]->u.structure->name))
			{
				renamed=1;
				errorFound=1;
				printf("Error type 16 at line %d: Duplicated name '%s'\n",node->first_line,name);
				break;
			}
		}
	}
	if (!renamed)
	{
		for (i=0;i<variableCnt;i++)
		{
			if (!strcmp(variableList[i].name,name))
			{
				errorFound=1;
				printf("Error type 16 at line %d: Duplicated name '%s'\n",node->first_line,name);
				break;
			}
		}
	}
	for (i=0;i<typeCnt;i++)
	{
		if (fieldListCheck(typeList[i]->u.structure->tail,t->u.structure->tail))
		{
			t->u.structure->type=typeList[i]->u.structure->type;
			break;
		}
	}
	if (i==typeCnt)
		t->u.structure->type=t;
	typeList[typeCnt++]=t;
}

void insertVariable(Node node ,char * name)
{
	int start = variableStack[variableTop];
	for(;start < variableCnt;start++)
	{
		if(!strcmp(variableList[start].name,name))
		{
			errorFound=1;
			printf("Error type 3 at line %d: Redefined variable \"%s\"\n",node->first_line, name);
			return;
		}
	}

	int i;
	for (i=0;i<typeCnt;i++)
	{
		if (typeList[i]->kind!=STRUCTURE)
			continue;
		if (!strcmp(typeList[i]->u.structure->name,name))
		{
			errorFound=1;
			printf("Error type 3 at line %d: Redefined variable \"%s\"\n",node->first_line, name);
			return;
		}
	}

	variableList[variableCnt].name = name;
	variableList[variableCnt++].type = node->type;
}


int typeCheck(Type type1, Type type2)
{
	if(type1->kind == UNKNOWN|| type2->kind == UNKNOWN || type1->kind != type2->kind)
		return 0;

	switch(type1->kind)
	{
		case BASIC:
		{
			return type1->u.basic == type2->u.basic;
		}
		case ARRAY:
		{
			return typeCheck(type1->u.array.elem,type2->u.array.elem);
		}
		case STRUCTURE:
		{
			return type1->u.structure->type == type2->u.structure->type;
		}
	}	
}

int fieldListCheck(FieldList field1,FieldList field2)
{
	if (field1==NULL && field2==NULL)
		return 1;
	if (field1==NULL || field2==NULL)
		return 0;
	while(1)
	{
		if(!typeCheck(field1->type, field2->type))
		{
			return 0;
		}
		field1 = field1->tail;
		field2 = field2->tail;
		if(field1 != NULL && field2 != NULL)
			continue;
		if(field1 == NULL && field2 == NULL)
			return 1;
		return 0;
	}
}

void insertVarList(Node node, char *name)
{
	FieldList f=varList;
	while (f->tail!=NULL)
		f=f->tail;
	f->tail=malloc(sizeof(struct FieldList_));
	f=f->tail;
	f->name=name;
	f->type=node->type;
	f->tail=NULL;
}


void insertField(Node node,char *name)
{
	FieldList f=fieldList;
	while (f->tail!=NULL)
	{
		if (!strcmp(f->tail->name,name))
		{
			errorFound=1;
			printf("Error type 15 at line %d: Redefined field '%s'\n",node->first_line,name);
			return;
		}

		f=f->tail;
	}
	f->tail=malloc(sizeof(struct FieldList_));
	f=f->tail;
	f->name=name;
	f->type=node->type;
	f->tail=NULL;
	if (assignInDec)
	{
		errorFound=1;
		printf("Error type 15 at line %d: Initialized field '%s'\n",node->first_line,name);
	}
}

Type functionCheck(Node node)
{
	FieldList func=findFunctionById(node,node->childs[0]->content);
	if (func==NULL)
		return NULL;
	Type r=typeList[0];
	switch (node->elementNum)
	{
		case 11:
		{
			Node n=node->childs[2];
			FieldList f=func->tail;
			if (f==NULL)
			{
				r=NULL;
				break;
			}
			while(1)
			{
				if (!typeCheck(n->childs[0]->type,f->type))
				{
					r=NULL;
					break;
				}
				if (n->elementNum==1)
					break;
				if (f->tail==NULL)
					break;
				n=n->childs[2];
				f=f->tail;
			}
			if (r==NULL)
				break;
			if (f->tail!=NULL||n->elementNum!=1)
			{
				r=NULL;
				break;
			}
			r=func->type;
			break;
		}
		case 12:
		{
			if (func->tail==NULL)
				r=func->type;
			else
				r=NULL;
			break;
		}
	}
	if (r==NULL)
	{
		errorFound=1;
		printf("Error type 9 at line %d: The method \"%s(",node->first_line,func->name);
		FieldList f=func->tail;
		if (f!=NULL)
		{
			printType(f->type);
			while (f->tail!=NULL)
			{
				f=f->tail;
				printf(", ");
				printType(f->type);
			}
		}
		printf(")\" is not applicable for the arguments \"(");
		if (node->elementNum==12)
		{
			printf(")\"\n");
		}
		else
		{
			Node n=node->childs[2];
			printType(n->childs[0]->type);
			while (n->elementNum==0)
			{
				n=n->childs[2];
				printf(", ");
				printType(n->childs[0]->type);
			}
			printf(")\"\n");
		}
	}
	return r;
}

Type findVariableById(Node node,char *name)
{
	int i;
	for (i=variableCnt-1;i>=0;i--)
	{
		if (!strcmp(variableList[i].name,name))
			return variableList[i].type;
	}
	errorFound=1;
	printf("Error type 1 at line %d: Undefined variable \"%s\"\n", node->first_line,name);
	return typeList[0];
}

Type findTypeById(Node node,char *name)
{
	int i;
	for (i=0;i<typeCnt;i++)
	{
		if (typeList[i]->kind!=STRUCTURE)
			continue;
		if (!strcmp(typeList[i]->u.structure->name,name))
			return typeList[i];
	}
	return NULL;
}

FieldList findFunctionById(Node node,char *name)
{
	int i;
	for (i=0;i<functionCnt;i++)
	{
		if (!strcmp(functionList[i]->name,name))
			return functionList[i];
	}
	for (i=variableCnt-1;i>=0;i--)
	{
		if (!strcmp(variableList[i].name,name))
			break;
	}
	if(i == -1)
	{
		errorFound=1;
		printf("Error type 2 at line %d: Undefined function \"%s\"\n",node->first_line,name);
	}
	else
	{
		errorFound=1;
		printf("Error type 11 at line %d: \"%s\" must be a function\n",node->first_line, name);
	}
	return NULL;
}

void printType(Type t)
{
	switch (t->kind)
	{
		case BASIC:
		{
			switch (t->u.basic)
			{
				case INT_:
				{
					printf("int");
					return;
				}
				case FLOAT_:
				{
					printf("float");
					return;
				}
			}
			return;
		}
		case ARRAY:
		{
			printType(t->u.array.elem);
			printf("[]");
			return;
		}
		case STRUCT:
		{
			printf("struct %s",t->u.structure->name);
			return;
		}
	}
}

void functionDecCheck()
{
	int i;
	for (i=0;i<functionCnt;i++)
	{
		if (!functionDefined[i])
		{
			errorFound=1;
			printf("Error type 18 at line %d: Undefined function \"%s\"\n",functionDecLineNum[i],functionList[i]->name);
		}
	}
}