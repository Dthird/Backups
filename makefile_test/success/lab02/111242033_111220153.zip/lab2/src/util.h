#ifndef UTIL_H
#define UTIL_H

#include <stdio.h>
#include <string.h>
#include "syntax.tab.h"
#include "symbol.h"

#define MAXCHILD 8

enum syntaxElementType
{
	//High-Level Definitions
	Program,
	ExtDefList,
	ExtDef,
	ExtDecList,
	//Specifiers
	Specifier,
	StructSpecifier,
	OptTag,
	Tag,
	//Declarators
	VarDec,
	FunDec,
	VarList,
	ParamDec,
	//Statements
	CompSt,
	StmtList,
	Stmt,
	//Local Definitions
	DefList,
	Def,
	DecList,
	Dec,
	//Expressions
	Exp,
	Args
};

typedef struct Type_* Type;

struct syntaxNode
{
    char token[20];//
	enum yytokentype tokenType;
	enum syntaxElementType elementType;
	int elementNum;
	char content[50];//变量名
    int index;
    int iValue;
    float fValue;
    Type type;
	int first_line;
    int cnt;
    struct syntaxNode *childs[MAXCHILD];
};

typedef struct syntaxNode* Node;
struct syntaxNode *root;
int errorFound;
extern int yylineno;
void output(struct syntaxNode* p,int d);

#endif
