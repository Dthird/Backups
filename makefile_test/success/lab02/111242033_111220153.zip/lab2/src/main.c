#include <stdio.h>
#include "syntax.tab.h"
#include "util.h"
#include "symbol.h"

int main(int argc, char** argv) 
{ 
    if (argc <= 1) return 1; 
    FILE* f = fopen(argv[1], "r"); 
    if (!f) 
    { 
        perror(argv[1]); 
        return 1; 
    } 
	errorFound=0;
    yyrestart(f); 
    yyparse(); 
    initial();
    semanticAnalysis(root);
    functionDecCheck();
	if (!errorFound)
    {
//      output(root,0);
    }
    return 0; 
}
