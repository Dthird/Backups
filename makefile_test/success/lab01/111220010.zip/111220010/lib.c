#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include "lib.h"

struct node *create_node(int type) {
	
	struct node *tree_node = malloc(sizeof(struct node));
	tree_node -> type = type;
	tree_node -> value = NULL;
	tree_node -> brother = NULL;
	tree_node -> child = NULL;
	return tree_node;
}

void add_value(struct node *tree_node, char *value) {
	int type = tree_node -> type;
	switch(type) {
		case I_INT   : tree_node -> value = malloc(sizeof(int)); 
			*((int *)(tree_node -> value)) = atoi(value); break;
		case I_FLOAT : tree_node -> value = malloc(sizeof(float));
			*((float *)(tree_node -> value)) = atof(value); break;
		case I_ID    : tree_node -> value = malloc(strlen(value) + 1);
			strcpy((char *)(tree_node -> value), value); break;
		case I_TYPE  : tree_node -> value = malloc(strlen(value) + 1);
			strcpy((char *)(tree_node -> value), value); break;
	}
}

void add_lineno(struct node *tree_node, int lineno) {
	tree_node -> lineno = lineno;
}

void insert_node(struct node *parent, ...) {
	
	va_list children_arg;
	va_start(children_arg, parent);
	struct node *child = va_arg(children_arg, struct node*);
	while (child -> type == I_EMPTY) {
		free(child);
		child = va_arg(children_arg, struct node*);
	}
	parent -> child = child;
	struct node *next_child = va_arg(children_arg, struct node*);
	while (next_child != NULL) {
		if (next_child -> type == I_EMPTY)
			free(next_child);
		else {
			child -> brother = next_child;
			child = next_child;
		}
		next_child = va_arg(children_arg, struct node*);
	}
}

void print_node(struct node *tree_node) {
	int type = tree_node -> type;
	switch(type) {
        case I_INT 		: printf("INT: %d\n", *((int *)(tree_node -> value))); break;
        case I_FLOAT 	: printf("FLOAT: %f\n", *((float *)(tree_node -> value))); break;
        case I_ID 		: printf("ID: %s\n", (char *)(tree_node -> value)); break;
        case I_SEMI 	: printf("SEMI\n"); break;
        case I_COMMA 	: printf("COMMA\n"); break;
        case I_ASSIGNOP	: printf("ASSIGNOP\n"); break;
        case I_RELOP 	: printf("RELOP\n"); break;
        case I_PLUS 	: printf("PLUS\n"); break;
        case I_MINUS 	: printf("MINUS\n"); break;
        case I_STAR 	: printf("STAR\n"); break;
        case I_DIV 		: printf("DIV\n"); break;
        case I_AND 		: printf("AND\n"); break;
        case I_OR 		: printf("OR\n"); break;
        case I_DOT 		: printf("DOT\n"); break;
        case I_NOT 		: printf("NOT\n"); break;
        case I_TYPE		: printf("TYPE: %s\n", (char *)(tree_node -> value)); break;
        case I_LP 		: printf("LP\n"); break;
        case I_RP 		: printf("RP\n"); break;
        case I_LB 		: printf("LB\n"); break;
        case I_RB 		: printf("RB\n"); break;
        case I_LC 	  	: printf("LC\n"); break;
        case I_RC 		: printf("RC\n"); break;
        case I_STRUCT 	: printf("STRUCT\n"); break;
        case I_RETURN 	: printf("RETURN\n"); break;
        case I_IF 		: printf("IF\n"); break;
        case I_ELSE 	: printf("ELSE\n"); break;
        case I_WHILE 	: printf("WHILE\n"); break;

		case I_PROGRAM 			: printf("Program (%d)\n", tree_node -> lineno); break;
		case I_EXT_DEF_LIST		: printf("ExtDefList (%d)\n", tree_node -> lineno); break;
		case I_EXT_DEF 			: printf("ExtDef (%d)\n", tree_node -> lineno); break;
		case I_SPECIFIER 		: printf("Specifier (%d)\n", tree_node -> lineno); break;
		case I_EXT_DEC_LIST 	: printf("ExtDecList (%d)\n", tree_node -> lineno); break;
		case I_FUN_DEC 			: printf("FunDec (%d)\n", tree_node -> lineno); break;
		case I_COMP_ST 			: printf("CompSt (%d)\n", tree_node -> lineno); break;
		case I_VAR_DEC 			: printf("VarDec (%d)\n", tree_node -> lineno); break;
		case I_STRUCT_SPECIFIER : printf("StructSpecifier (%d)\n", tree_node -> lineno); break;
		case I_OPT_TAG 			: printf("OptTag (%d)\n", tree_node -> lineno); break;
		case I_DEF_LIST 		: printf("DefList (%d)\n", tree_node -> lineno); break;
		case I_DEF 				: printf("Def (%d)\n", tree_node -> lineno); break;
		case I_TAG 				: printf("Tag (%d)\n", tree_node -> lineno); break;
		case I_VAR_LIST 		: printf("VarList (%d)\n", tree_node -> lineno); break;
		case I_PARAM_DEC 		: printf("ParamDec (%d)\n", tree_node -> lineno); break;
		case I_STMT_LIST 		: printf("StmtList (%d)\n", tree_node -> lineno); break;
		case I_STMT 			: printf("Stmt (%d)\n", tree_node -> lineno); break;
		case I_EXP 				: printf("Exp (%d)\n", tree_node -> lineno); break;
		case I_DEC_LIST 		: printf("DecList (%d)\n", tree_node -> lineno); break;
		case I_DEC 				: printf("Dec (%d)\n", tree_node -> lineno); break;
		case I_ARGS 			: printf("Args (%d)\n", tree_node -> lineno); break;
	}
}

int n = 0;

void print_blank() {
	int i;
	for (i = 0; i < n; i++)
		printf("  ");
}

void print_tree(struct node *root) {
	print_blank();
	print_node(root);
	struct node *child = root -> child;
	if (child != NULL) {
		n++;
		print_tree(child);
		n--;
	}
	struct node *brother = root -> brother;
	if (brother != NULL) {
		print_tree(brother);
		brother = brother -> brother;
	}
}

void delete_tree(struct node *root) {
	struct node *child = root -> child;
	if (child != NULL)
		delete_tree(child);
	struct node *brother = root -> brother;
	if (brother != NULL) {
		delete_tree(brother);
	}
	if (root -> value != NULL) {
		free(root -> value);
		root -> value = NULL;
	}
	free(root);
}

