#include <stdio.h>
#include <stdlib.h>
#include "lib.h"

extern FILE* yyin;
extern void yyrestart(FILE *input_file);

int main(int argc, char const *argv[]) {
	if (argc <= 1) return 1;
	FILE *f = fopen(argv[1], "r");
	if (!f) {
		perror(argv[1]);
		return 1;
	}
	error_flag = 0;
	error_lineno = 0;
	yyrestart(f);
	yyparse();
	if (error_flag == 0) {
		print_tree(root);
		delete_tree(root);
	}
	return 0;
}