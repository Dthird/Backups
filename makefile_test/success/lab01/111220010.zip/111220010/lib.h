#ifndef __LIB_H
#define __LIB_H

#include <stdarg.h>

#define I_EMPTY 	0
#define I_INT 		1
#define I_FLOAT 	2
#define I_ID 		3
#define I_SEMI 		4
#define I_COMMA 	5
#define I_ASSIGNOP 	6
#define I_RELOP 	7
#define I_PLUS 		8
#define I_MINUS 	9
#define I_STAR 		10
#define I_DIV 		11
#define I_AND 		12
#define I_OR 		13
#define I_DOT 		14
#define I_NOT 		15
#define I_TYPE 		16
#define I_LP 		17
#define I_RP 		18
#define I_LB 		19
#define I_RB 		20
#define I_LC 	  	21
#define I_RC 		22
#define I_STRUCT 	23
#define I_RETURN 	24
#define I_IF 		25
#define I_ELSE 		26
#define I_WHILE 	27

#define I_PROGRAM 			30
#define I_EXT_DEF_LIST		31
#define I_EXT_DEF 			32
#define I_SPECIFIER 		33
#define I_EXT_DEC_LIST 		34
#define I_FUN_DEC 			35
#define I_COMP_ST 			36
#define I_VAR_DEC 			37
#define I_STRUCT_SPECIFIER 	38
#define I_OPT_TAG 			39
#define I_DEF_LIST 			40
#define I_DEF 				41
#define I_TAG 				42
#define I_VAR_LIST 			43
#define I_PARAM_DEC 		44
#define I_STMT_LIST 		45
#define I_STMT 				46
#define I_EXP 				47
#define I_DEC_LIST 			48
#define I_DEC 				49
#define I_ARGS 				50

int error_flag;
int error_lineno;
struct node *root;

struct node {
	int type;
	void *value;
	int lineno;
	struct node *brother;
	struct node *child;
};

struct node *create_node(int type);
void insert_node(struct node *parent, ...);
void add_value(struct node *tree_node, char *value);
void add_lineno(struct node *tree_node, int lineno);
void print_tree(struct node *root);
void delete_tree(struct node *root);

#endif